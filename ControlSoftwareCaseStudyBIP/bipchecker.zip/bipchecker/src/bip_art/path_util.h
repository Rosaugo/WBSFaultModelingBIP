/*
 * path_util.h
 *
 *  Created on: Dec 18, 2016
 *      Author: wangqiang
 */

#ifndef PATH_UTIL_H_
#define PATH_UTIL_H_


#include "util/hash_map.h"
#include "util/util.h"
#include "bip_art/art.h"
#include "bip_art/art_path.h"
#include "bip_trans_builder/transition_builder.h"


namespace bipchecker{

//! Class for utility for path construction.
class PathUtil
{

public:

    typedef hash_set<const Symbol*,
		     hash_fun<const Symbol*>,
		     EqSymbol> symbols_t;


private:

    //! Transition builder.
    /*!
     * Transition builder carries the environment.
     */
    TransitionBuilder& trans_builder_;

public:

    //! Class constructor.
    /*!
     * \param trans_builder a transition builder.
     */
    explicit PathUtil(TransitionBuilder& trans_builder)
	: trans_builder_(trans_builder)
    {
    }

    //! Gets the transition builder.
    /*!
     * \return The transition builder.
     */
    TransitionBuilder& trans_builder() const { return trans_builder_; }


    //! Collects transition domains in a path.
    /*!
     * \param path an ART path.
     * \param trans_domain the list of transition domains.
     */
    void collect_transition_domains(const ARTPath& path,
				    std::deque<symbols_t*>& trans_domains) const;


private:

    //! Extracts transition domain.
    /*!
     * \param transition a transition.
     * \param domain the domain of the transition.
     */
    void extract_domain_symbols(const Transition& transition,
				symbols_t& domain) const;


    DISALLOW_COPY_AND_ASSIGN(PathUtil);

}; // class PathUtil


}



#endif /* PATH_UTIL_H_ */
