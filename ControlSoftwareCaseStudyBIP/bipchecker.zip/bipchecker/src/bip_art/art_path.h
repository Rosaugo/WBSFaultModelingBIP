/*
 * art_path.h
 *
 *  Created on: Dec 18, 2016
 *      Author: wangqiang
 */

#ifndef ART_PATH_H_
#define ART_PATH_H_

#include "bip_art/art.h"

namespace bipchecker {

//! Class for paths in ART.
class ARTPath {

	//! Start node.
	ART::ARTNode *start_;

	//! End node.
	ART::ARTNode *end_;

	//! Use dequeue for efficient insertion in back and front
	typedef std::deque<const BIPInteraction*> labels_t;

	//! Sequence of edges labeling the path.
	labels_t labels_;

	//! NOTE: we need to keep the order
	//! which means interaction transitions come before component transitions.
	//! currently we maintain this order by simply adding the interaction transitions first
	typedef std::vector<const CFAEdge*> edges_t;

	//! Deque to store the transitions for each interaction
	typedef std::deque<edges_t*> transitions_t;

	//! transitions of each interaction
	mutable transitions_t trans_;

public:

	//! Class constructor.
	/*!
	 * \param start the start node.
	 */
	explicit ARTPath(ART::ARTNode& start)
	: start_(&start), end_(&start) {
	}

	//! Gets the start node.
	/*!
	 * \return The start node.
	 */
	const ART::ARTNode& start() const {
		return *start_;
	}

	//! Gets the start node.
	/*!
	 * \return The start node.
	 */
	ART::ARTNode& start() {
		return *start_;
	}

	//! Gets the end node.
	/*!
	 * \return The end node.
	 */
	const ART::ARTNode& end() const {
		return *end_;
	}

	//! Gets the end node.
	/*!
	 * \return The end node.
	 */
	ART::ARTNode& end() {
		return *end_;
	}

	//! Gets the i-th label.
	/*!
	 * \param i an index.
	 * \return The i-th label.
	 */
	const BIPInteraction* label(size_t i) const {
		if (i < labels_.size())
			return labels_[i];

		return 0;
	}

	typedef labels_t::const_iterator label_iterator;

	//! Gets the start iterator of edge labels.
	/*!
	 * \return The start iterator of edge labels.
	 */
	label_iterator label_begin() const {
		return labels_.begin();
	}

	//! Gets the end iterator of edge labels.
	/*!
	 * \return The end iterator of edge labels.
	 */
	label_iterator label_end() const {
		return labels_.end();
	}

	//! Gets the length of the path.
	/*!
	 * \return The length of the path.
	 */
	size_t length() const {
		return labels_.size();
	}

	//! Extends the path at the end.
	/*!
	 * \param label an edge extending the path.
	 */
	void push_back(const BIPInteraction& label) {
		ART::ARTNode *new_end = end_->child(label);

		if (new_end != 0) {

			labels_.push_back(&label);
			end_ = new_end;
		}
	}

	//! Extends the path at the beginning.
	/*!
	 * \param label an edge extending the path.
	 */
	void push_front(const BIPInteraction& label) {
		const BIPInteraction *start_label = start_->label();

		if (start_label && start_label == &label) {

			labels_.push_front(&label);
			start_ = start_->parent();
		}
	}

	typedef transitions_t::const_iterator const_tran_iterator;

	const_tran_iterator transitions_begin() const {
		return trans_.begin();
	}

	const_tran_iterator transitions_end() const {
		return trans_.end();
	}


	typedef edges_t::const_iterator const_edge_iterator;

	const_edge_iterator transition_begin(size_t label) const {

		assert(label < trans_.size());

		edges_t *nodes = trans_[label];
		return nodes->begin();

		/*
		transitions_t::const_iterator cit = trans_.find(label);

		if (cit != trans_.end() && (*cit).second)
		nodes = (*cit).second;
		else {
			nodes = new edges_t();
			trans_[label] = nodes;
		}*/

	}

	const_edge_iterator transition_end(size_t label) const {

		assert(label < trans_.size());

		edges_t *nodes = trans_[label];
		return nodes->end();

		/*
		transitions_t::const_iterator cit = trans_.find(label);

		if (cit != trans_.end() && (*cit).second)
		nodes = (*cit).second;
		else {
			nodes = new edges_t();
			trans_[label] = nodes;
		}*/
	}

	edges_t* transitions(size_t label) const {

		edges_t * nodes = 0;
		if(label < trans_.size())
			nodes = trans_[label];

		/*
		transitions_t::const_iterator cit = trans_.find(label);

		if(cit != trans_.end())
		 nodes = (*cit).second;
		 */

		return nodes;
	}

	void add_transitions_front(edges_t* ts) {
		trans_.push_front(ts);
	}

	void add_transitions_back(edges_t* ts) {
		trans_.push_back(ts);
	}

	/*
	void add_transition(size_t label, const CFAEdge* trans){

		edges_t * edges = trans_[label];
		if(edges == 0){
			edges = new std::vector<const CFAEdge*>();
			trans_[label] = edges;
		}
		edges->push_back(trans);


			transitions_t::iterator it = trans_.find(label);
			if(it != trans_.end()){
				(*it).second->push_back(trans);
			} else{
				std::vector<const CFAEdge*>* temp = new std::vector<const CFAEdge*>();
				temp->push_back(trans);
				trans_[label] = temp;
			}

	}*/

	//! Class destructor.
	~ARTPath() {
		start_ = 0;
		end_ = 0;
		labels_.clear();

		for(transitions_t::iterator tit = trans_.begin();
				tit != trans_.end(); ++tit) {
			if(*tit) {
				(*tit)->clear();
				delete (*tit);
			}
		}
		trans_.clear();

		/*
		for(transitions_t::iterator tit = trans_.begin();
				tit != trans_.end(); ++tit){
			if((*tit).second){
				edges_t* edges = (*tit).second;
				edges->clear();
				delete edges;
			}
		}*/

	}

private:

	DISALLOW_COPY_AND_ASSIGN(ARTPath);

};
// class ARTPath


}

#endif /* ART_PATH_H_ */
