/*
 * art.h
 *
 *  Created on: Nov 23, 2014
 *      Author: wangqiang
 */

#ifndef ART_H_
#define ART_H_

#include <list>
#include <deque>
#include <vector>

#include "util/util.h"
#include "util/hash_map.h"
#include "bip_art/conc_location.h"
#include "bip_frontend/bip_interaction/interaction.h"
#include "bip_art/conc_abstract_state.h"
#include "bip_cfa/cfa_edge.h"


namespace bipchecker {

//! Abstract reachability tree (ART) class.
class ART {

public:

	//! ART-node class.
	class ARTNode {

	public:
		// Enumeration mark of ART node.
		enum Mark {
			UNMARKED, /*!< Node is unmarked. */
			MARKED_COVERED, /*!< Node is marked as covered. */
			MARKED_UNCOVERED /*!< Node is marked as uncovered. */
		};

	private:
		//! Global node id.
		static size_t fresh_id;

		//! Node id.
		size_t node_id_;

		//! Reference to the ART that owns the node.
		ART& art_;

		//! Abstract state labeling the node.
		ConcAbstractState *abstract_state_;

		typedef hash_map<const BIPInteraction*, ARTNode*,
				hash_fun<const BIPInteraction*>,
				EqBIPInteraction> children_t;

		//! Children of the node.
		children_t children_;

		typedef std::vector<const CFAEdge*> edges_t;

		typedef hash_map<const BIPInteraction*, edges_t*,
				hash_fun<const BIPInteraction*>,
				EqBIPInteraction> transitions_t;

		//! transitions of each interaction
		//! these transition are from different components, that
		//! will be taken when this interaction happens
		mutable transitions_t trans_;

		//! Parent of the node.
		ARTNode *parent_;

		//! Edge labeling the node (the source of the edge is the node's parent).
		const BIPInteraction *label_;

		//! Node's mark.
		Mark mark_;

		//! flag to indicate if it is fully expanded
		bool fully_expand_;

		//! Time stamp of the mark.
		size_t mark_time_stamp_;

		//! Global time stamp.
		static size_t time_stamp;

		//! NOTE: a covering node can not be covered.
		//! The nodes being covered
		std::set<ARTNode*> covered_nodes;

		//! The node the covers this one
		ARTNode* covering_node;

		//! The set of interactions should be backtracked
		std::set<const BIPInteraction*> backtracking_set;

		//! The set of interactions being taken
		std::set<const BIPInteraction*> taken_set;

	public:

		//! Class constructor.
		/*!
		 * Create an ART node by providing a reference to the ART and
		 * an abstract state. The edge labeling the node and its parent
		 * are left null, and the node is unmarked.
		 *
		 * \param art a reference to the ART that owns the node.
		 * \param abstract_state an abstract state labeling the node.
		 */
		explicit ARTNode(ART& art, ConcAbstractState *abstract_state)
		: node_id_(ARTNode::fresh_id++),
		art_(art),
		abstract_state_(abstract_state),
		parent_(0),
		label_(0),
		mark_(UNMARKED),
		fully_expand_(true),
		mark_time_stamp_(0),
		covering_node(0)
		{
			covered_nodes.clear();
			taken_set.clear();
			backtracking_set.clear();
		}

		//! Gets the node's id.
		/*!
		 * \return The node's id.
		 */
		size_t node_id() const {return node_id_;}

		//! Gets the ART owning the node.
		/*!
		 * \return The ART owning the node.
		 */
		const ART& art() const {return art_;}

		//! Gets the ART owning the node.
		/*!
		 * \return The ART owning the node.
		 */
		ART& art() {return art_;}

		//! Gets the abstract state labeling the node.
		/*!
		 * \return The abstract state labeling the node.
		 */
		const ConcAbstractState& abstract_state() const {return *abstract_state_;}

		//! Gets the abstract state labeling the node.
		/*!
		 * \return The abstract state labeling the node.
		 */
		ConcAbstractState& abstract_state() {return *abstract_state_;}

		//! Checks if this node is fully expanded
		/*
		 * \return true if fully expanded
		 */
		bool is_fully_expand() const {
			return fully_expand_;
		}

		//! Sets fully expanded flag
		/*
		 * \return
		 */
		void set_fully_expand(bool fully) {
			fully_expand_ = fully;
		}

		typedef children_t::const_iterator child_iterator;

		//! Gets the start iterator of the childern.
		/*!
		 * \return The start iterator of the childern.
		 */
		child_iterator child_begin() {return children_.begin();}

		//! Gets the end iterator of the childern.
		/*!
		 * \return The end iterator of the childern.
		 */
		child_iterator child_end() {return children_.end();}

		typedef children_t::const_iterator const_child_iterator;

		//! Gets the start const iterator of the childern.
		/*!
		 * \return The start iterator of the childern.
		 */
		const_child_iterator child_begin() const {return children_.begin();}

		//! Gets the end const iterator of the childern.
		/*!
		 * \return The end iterator of the childern.
		 */
		const_child_iterator child_end() const {return children_.end();}

		//! Add the given interaction into the backtracking set
		void add_backtracking(const BIPInteraction* ia) {
			backtracking_set.insert(ia);
		}

		//! Check if the backtracking set is empty or not
		bool is_backtracking_empty() const {
			return backtracking_set.empty();
		}

		void clear_backtracking() { 
		  backtracking_set.clear();
		}

		bool in_backtracking(const BIPInteraction* ia) const {
			std::set<const BIPInteraction*>::iterator it = backtracking_set.find(ia);
			return !(it == backtracking_set.end());
		}

		typedef std::set<const BIPInteraction*>::iterator backtracking_iterator;

		backtracking_iterator backtracking_begin() const {return backtracking_set.begin() ;}

		backtracking_iterator backtracking_end() const {return backtracking_set.end();}

		void add_taken(const BIPInteraction* ia) {
			taken_set.insert(ia);
		}

		bool has_been_taken(const BIPInteraction* ia) {
			std::set<const BIPInteraction*>::iterator it = taken_set.find(ia);
			return !(it == taken_set.end());
		}

		//! Checks if this node contains any children that are unmarked
		//! except for the one given as the parameter
		bool contain_unmarked_child(const ARTNode& node) const {

			for(const_child_iterator cit = children_.begin();
					cit != children_.end() ; ++cit){
				if((*cit).second != &node && (*cit).second->mark() == UNMARKED)
					return true;
			}

			return false;
		}


		bool is_taken(const BIPInteraction* interaction) const{
			children_t::const_iterator cit = children_.find(interaction);

			return (cit != children_.end());
		}


		// TODO(IN): The iterator const_child_iterator has
		//           to be replaced by a proper one. See CFA.

		//! Gets the parent of the node.
		/*!
		 * \return The parent of the node.
		 */
		const ARTNode* parent() const {return parent_;}

		//! Gets the parent of the node.
		/*!
		 * \return The parent of the node.
		 */
		ARTNode* parent() {return parent_;}

		//! Gets the node's child given the child's labeling edge.
		/*!
		 * \param label an edge.
		 * \return The child whose labeling edge match or 0 otherwise.
		 */
		const ARTNode* child(const BIPInteraction& label) const
		{
			children_t::const_iterator cit;

			if ( !children_.empty()
					&& (cit = children_.find(&label)) != children_.end())
			return (*cit).second;

			return 0;
		}

		//! Gets the node's child given the child's labeling edge.
		/*!
		 * \param label an edge.
		 * \return The child whose labeling edge match or 0 otherwise.
		 */
		ARTNode* child(const BIPInteraction& label)
		{
			children_t::iterator it;

			if ( !children_.empty()
					&& (it = children_.find(&label)) != children_.end())
			return (*it).second;

			return 0;

		}

		edges_t* transisitions(const BIPInteraction& label) const {

			transitions_t::const_iterator cit = trans_.find(&label);
			edges_t * nodes = 0;

			if(cit != trans_.end())
			 nodes = (*cit).second;

			return nodes;
		}

		typedef edges_t::const_iterator const_edge_iterator;

		const_edge_iterator transition_begin(const BIPInteraction& label) const {

			transitions_t::const_iterator cit = trans_.find(&label);
			edges_t *nodes = 0;

			if (cit != trans_.end() && (*cit).second)
			nodes = (*cit).second;
			else {
				nodes = new edges_t();
				trans_[&label] = nodes;
			}

			return nodes->begin();
		}

		const_edge_iterator transition_end(const BIPInteraction& label) const{

			transitions_t::const_iterator cit = trans_.find(&label);
			edges_t *nodes = 0;

			if (cit != trans_.end() && (*cit).second)
			nodes = (*cit).second;
			else {
				nodes = new edges_t();
				trans_[&label] = nodes;
			}

			return nodes->end();

		}

		//! Get the node's labeling edge.
		/*!
		 * \return The node's labeling edge.
		 */
		const BIPInteraction* label() const {return label_;}

		//! Gets the node's mark.
		/*!
		 * \return The node's mark.
		 */
		Mark mark() const {return mark_;}

		//! Gets the time stamp of the mark.
		/*!
		 * \return The time stamp of the mark.
		 */
		size_t mark_time_stamp() const {return mark_time_stamp_;}

		//! Checks if the node has a child.
		/*!
		 * \return True iff the node has a child.
		 */
		bool has_child() const {return !children_.empty();}

		//! Gets the number of node's children.
		/*!
		 * \return The number of node's children.
		 */
		size_t num_of_children() const {return children_.size();}

		//! Sets an abstract state.
		/*!
		 * \param abstract_state a new abstract state.
		 */
		void set_abstract_state(ConcAbstractState *abstract_state);

		//! Marks node as covered.
		void mark_covered()
		{
			mark_ = MARKED_COVERED;
			mark_time_stamp_ = ++time_stamp;
		}

		//! Marks node as uncovered.
		void mark_uncovered()
		{
			mark_ = MARKED_UNCOVERED;
			mark_time_stamp_ = ++time_stamp;
		}

		//! Unmarks node.
		void unmark()
		{
			mark_ = UNMARKED;
			mark_time_stamp_ = 0;
		}

		//! Adds a child to the node.
		/*!
		 * \param label an edge labeling the child..
		 * \param abstract_state an abstract state labeling the child.
		 */
		void add_child(const BIPInteraction& label, ConcAbstractState *abstract_state)
		{
			if (children_.empty()) // If this node has no children.
			art_.leaves_.erase(this);

			ARTNode *child = art_.create_node(abstract_state);

			child->parent_ = this;
			child->label_ = &label;
			children_[&label] = child;

		}

		void add_transition(const BIPInteraction& label, const CFAEdge* trans){

				transitions_t::iterator it = trans_.find(&label);
				if(it != trans_.end()){
					(*it).second->push_back(trans);
				} else{
					std::vector<const CFAEdge*>* temp = new std::vector<const CFAEdge*>();
					temp->push_back(trans);
					trans_[&label] = temp;
				}
		}

		void add_covered_node(ARTNode* node) {
			covered_nodes.insert(node);
		}

		typedef std::set<ARTNode*>::iterator covered_node_iterator;

		covered_node_iterator covered_nodes_begin() {
			return covered_nodes.begin();
		}

		covered_node_iterator covered_nodes_end() {
			return covered_nodes.end();
		}

		typedef std::set<ARTNode*>::const_iterator const_covered_node_iterator;

		const_covered_node_iterator const_covered_nodes_begin() const {
			return covered_nodes.begin();
		}

		const_covered_node_iterator const_covered_nodes_end() const {
			return covered_nodes.end();
		}

		void remove_covered_node(ARTNode* n) {

//			if(!covered_nodes.empty()) {
 				covered_nodes.erase(n);
//			}

		}

		void remove_covered_nodes() {
			covered_nodes.clear();

//			if(covering_node != 0) {
//			  covering_node->remove_covered_node(this);
//			}
		}

		void set_covering_node(ARTNode* n){
			covering_node = n;
		}

		ARTNode* get_covering_node() {
			return covering_node;
		}

		void build_dot_node(std::ostream& out) const;

		//! Class destructor.
		/*!
		 * Deleting a node means removing its subtrees.
		 */
		~ARTNode();

	private:

		DISALLOW_COPY_AND_ASSIGN(ARTNode);

	}; // class ARTNode

	struct EqARTNode
	{
		size_t operator()(const ARTNode *n) const {return n->node_id();}

		bool operator()(const ARTNode *n1, const ARTNode *n2) const
		{
			return n1->node_id() == n2->node_id();
		}
	};

	typedef std::list<ARTNode*> work_list_t;

private:

	//! The root node.
	ARTNode *root_;

	//! Number of nodes.
	size_t num_of_nodes_;

	size_t total_num_of_nodes_;

	size_t removed_num_of_nodes_;

	typedef hash_set<ARTNode*,
			EqARTNode,
			EqARTNode> nodes_t;

	typedef hash_set<const ARTNode*,
			EqARTNode,
			EqARTNode> const_nodes_t;

	typedef hash_map< const ConcLoc*, const_nodes_t*,
			hash_fun<const ConcLoc*>,
			EqConcLoc> loc_nodes_t;

	typedef std::list<work_list_t*> work_lists_t;

	//! A hook mapping from control location to node.
	/*!
	 * This hook is useful for coverage check.
	 */
	mutable loc_nodes_t loc_nodes_;

	//! A hook keeping track of leaves of the tree.
	/*!
	 * This hook is useful in refinement process.
	 */
	nodes_t leaves_;

	//! A hook keeping track of working lists associated  with the ART.
	work_lists_t lists_;

	typedef std::vector<ConcLoc*> conc_loc_pool_t;

	//! Pool of concurrent locations.
	/*!
	 * The mapping from control location to node
	 * requires control location to be constant.
	 * For the sequential case, the control location
	 * is owned by the CFA. Here, we need something
	 * to own the control location, and that is
	 * the purpose of having concurrent location pool.
	 */
	mutable conc_loc_pool_t conc_loc_pool_;

public:

	//! Class constructor.
	/*!
	 * \param init_abstract_state an abstract state that will label the root.
	 */
	explicit ART(ConcAbstractState *init_abstract_state)
	: num_of_nodes_(0),
	  total_num_of_nodes_(0),
	  removed_num_of_nodes_(0)
	{
		root_ = create_node(init_abstract_state);
	}

	//! Gets the ART's root.
	/*!
	 * \return The ART's root.
	 */
	const ARTNode& root() const {return *root_;}

	//! Gets the ART's root.
	/*!
	 * \return The ART's root.
	 */
	ARTNode& root() {return *root_;}

	//! Gets the ART's size.
	/*!
	 * ART's size is the number of nodes it has.
	 *
	 * \return The number of nodes.
	 */
	size_t size() const {return num_of_nodes_;}

	size_t total_number() const {return total_num_of_nodes_;}

	size_t removed_numer() const {return removed_num_of_nodes_;}

	typedef const_nodes_t::const_iterator const_nodes_iterator;

	//! Gets the start iterator to set of ART nodes corresponding with concurrent location.
	/*!
	 * \return The start iterator to set of ART nodes.
	 */
	const_nodes_iterator loc_begin(const ConcLoc& location) const
	{
		loc_nodes_t::const_iterator cit = loc_nodes_.find(&location);
		const_nodes_t *nodes = 0;

		if (cit != loc_nodes_.end() && (*cit).second)
		nodes = (*cit).second;
		else {
			nodes = new const_nodes_t();
			loc_nodes_[&location] = nodes;
		}

		return nodes->begin();
	}

	//! Gets the end iterator to set of ART nodes corresponding with CFA location.
	/*!
	 * \return The end iterator to set of ART nodes.
	 */
	const_nodes_iterator loc_end(const ConcLoc& location) const {
		loc_nodes_t::const_iterator cit = loc_nodes_.find(&location);
		const_nodes_t *nodes = 0;

		if (cit != loc_nodes_.end() && (*cit).second)
		nodes = (*cit).second;
		else {
			nodes = new const_nodes_t();
			loc_nodes_[&location] = nodes;
		}

		return nodes->end();
	}

	typedef nodes_t::const_iterator nodes_iterator;

	//! Gets the start iterator to the set of leaves.
	/*!
	 * \return The start iterator to the set of leaves.
	 */
	nodes_iterator leaf_begin() const {return leaves_.begin();}

	//! Gets the end iterator to the set of leaves.
	/*!
	 * \return The end iterator to the set of leaves.
	 */
	nodes_iterator leaf_end() const {return leaves_.end();}

	//! Creates a worklist (set of ART nodes) that is synchronized with the ART.
	/*!
	 * \return The synchronized worklist.
	 */
	work_list_t& create_work_list()	{
		// This function creates a working list whose
		// contents are synchronized with the ART.

		work_list_t *work_list = new work_list_t();
		lists_.push_back(work_list);

		return *work_list;
	}

	void build_dot(std::ostream& out) const;

	//! Class destructor.
	~ART();

private:

	DISALLOW_COPY_AND_ASSIGN(ART);

	//! Create node that will belong to the ART.
	/*!
	 * \param abstract_state an abstract state labeling the new node.
	 */
	ARTNode* create_node(ConcAbstractState *abstract_state);

	//! Detach node from the ART.
	/*!
	 * \param node an ART node to be detached.
	 */
	void detach_node(ARTNode& node);

	//! Remove node from existing worklists.
	/*!
	 * \param node an ART node to be removed from existing worklists.
	 */
	void remove_from_work_lists(ARTNode& node);


	//! Add node into the work-list
	void add_into_work_list(ARTNode& node);

}; // class ART

}

#endif /* ART_H_ */
