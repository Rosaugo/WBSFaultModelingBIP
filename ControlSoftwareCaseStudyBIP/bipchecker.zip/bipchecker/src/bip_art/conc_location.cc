/*
 * conc_location.cc
 *
 *  Created on: Dec 15, 2016
 *      Author: wangqiang
 */


#include "bip_art/conc_location.h"
#include "bip_art/conc_abstract_state.h"

namespace bipchecker{

ConcLoc::ConcLoc(const ConcAbstractState& state) {

    for (ConcAbstractState::const_iterator it = state.thread_begin();
	 it != state.thread_end();
	 ++it) {

	const Symbol *thread_id = (*it).first;
	const AbstractState *thread_state = (*it).second;

	(*this)[thread_id] = thread_state->control_location();

    }
}


std::ostream& operator<<(std::ostream& out, const ConcLoc& loc) {
    loc.print(out);
    return out;
}


}


