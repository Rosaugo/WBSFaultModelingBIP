/*
 * path_util.cc
 *
 *  Created on: Dec 18, 2016
 *      Author: wangqiang
 */


#include "bip_art/path_util.h"

namespace bipchecker{

void PathUtil::collect_transition_domains(const ARTPath& path,
		std::deque<symbols_t*>& trans_domains) const {

	for(ARTPath::const_tran_iterator tit = path.transitions_begin();
			tit != path.transitions_begin(); ++tit) {

	 	// Extract domain symbols of the transition.
		symbols_t *dom_syms = new symbols_t();

		for(ARTPath::const_edge_iterator eit = (*tit)->begin();
				eit != (*tit)->end(); ++eit) {

			// Build transition out of the edge.
			Transition *trans = trans_builder_.build_transition(**eit);

		 	extract_domain_symbols(*trans,*dom_syms);

		 	if(trans != 0) delete trans;
		}


		// Collect domain symbols.
		trans_domains.push_back(dom_syms);
	}

	/*
 	size_t index = 0;
    for (ARTPath::label_iterator cit = path.label_begin();
         cit != path.label_end();
         ++cit, ++index) {

	 	// Extract domain symbols of the transition.
	 	symbols_t *dom_syms = new symbols_t();

		for(ARTPath::const_edge_iterator cei = path.transition_begin(index);
				cei != path.transition_end(index); ++cei){
			//! for each CFAEdge in this interaction
			if(*cei){
				// Build transition out of the edge.
				Transition *trans = trans_builder_.build_transition(**cei);

			 	extract_domain_symbols(*trans,*dom_syms);

			 	if(trans != 0) delete trans;
			}
		}

		// Collect domain symbols.
		trans_domains.push_back(dom_syms);
    }*/
}

void PathUtil::extract_domain_symbols(const Transition& transition,
				 symbols_t& domain) const {

    for (Transition::const_domain_iterator cit = transition.domain_begin();
    		cit != transition.domain_end();
    		++cit) {

    	const expression *dom_expr = *cit;
    	const variable* dom_var = dynamic_cast<const variable*>(dom_expr);
    	assert(dom_var != 0);

    	variable* var_ = const_cast<variable*>(dom_var);
    	const Symbol& dom_sym = Symbol::symbol(var_->get_name());

    	domain.insert(&dom_sym);
    }

}


}


