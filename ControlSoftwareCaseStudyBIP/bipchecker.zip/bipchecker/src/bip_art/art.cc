/*
 * art.cc
 *
 *  Created on: Nov 24, 2014
 *      Author: wangqiang
 */

#include "bip_art/art.h"
#include <assert.h>

namespace bipchecker{

size_t ART::ARTNode::fresh_id = 0;
size_t ART::ARTNode::time_stamp = 0;

ART::ARTNode::~ARTNode() {

	// Root of a tree cannot be deleted. Delete tree instead.
	assert(this != art_.root_);

	// Detach node from the ART.
	art_.detach_node(*this);

	//! clearing the covering relation
	//! and put the uncovered nodes into the worklist
	for(auto cn : covered_nodes) {
		cn->set_covering_node(0);
		cn->unmark();
		art_.add_into_work_list(*cn);
	}

	covered_nodes.clear();

	//! check if this node is covered by another one
	if(covering_node != 0){
		covering_node->remove_covered_node(this);
	}

	// Move children in a temporary.
	std::vector<ARTNode*> temp;

	const BIPInteraction* temp_ia = 0;

	for (child_iterator it = child_begin(); it != child_end(); ++it) { // For each node's child.

		if((*it).first
				&& (*it).first->get_name() == std::string("BIP_Internal_Interaction")){
			temp_ia = (*it).first;
		}

		// Put child in the temporary.
		if ((*it).second)
			temp.push_back((*it).second);
	}

#warning [MRIN]: Why not simply delete it in the above loop when
#warning [MRIN]: the condition (*.it).second holds? This way we avoid
#warning [MRIN]: the loop below and the local variable temp
#warning [INMR]: I need the loop below because set/map/hash_map/hash_set are
#warning [INMR]: not synchronized: deleting elements while traversing them can
#warning [INMR]: cause errors.

	// Delete children in the temporary.
	for (std::vector<ARTNode*>::iterator it = temp.begin();
			it != temp.end(); ++it) {
		delete *it;
	}

	temp.clear();

	// When all children are deleted, this node becomes a leaf
	// and the last deleted child put it in the leaf hook. We should remove it
	// from the hook.
	art_.leaves_.erase(this);

	for(transitions_t::iterator tit = trans_.begin();
			tit != trans_.end(); ++tit){
		if((*tit).second){
			edges_t* edges = (*tit).second;
			edges->clear();
			delete edges;
		}
	}

	// Remove node from parent's children.
	// And add parent to the leaves if it no longer has a child.
	if (parent_) {
		(parent_->children_).erase(label_);

		if (!parent_->has_child())
			art_.leaves_.insert(parent_);
	}

	// Delete labeling abstract state.
	if (abstract_state_)
		delete abstract_state_;

	// Clear children and parent.
	children_.clear();
	parent_ = 0;

	// Decrement number of nodes.
	--(art_.num_of_nodes_);

	++(art_.removed_num_of_nodes_);

	if(temp_ia != 0)
		delete temp_ia;

}

void ART::ARTNode::set_abstract_state(ConcAbstractState *abstract_state) {

	if (abstract_state_) {

		// Get the old location.
		const ConcLoc *old_loc = &abstract_state_->conc_location();

		if (old_loc) {

			// Location-node mapping must contain mapping from the old location.
			assert(art_.loc_nodes_.find(old_loc) != art_.loc_nodes_.end());

			// Get the set of nodes at the old location.
			const_nodes_t *nodes = art_.loc_nodes_[old_loc];

			// This node must be in the range of the mapping.
			assert(nodes->find(this) != nodes->end());

			// Remove this node.
			nodes->erase(this);
		}

		// Deallocate the old abstract state.
		delete abstract_state_;
	}

	if (abstract_state) {

		// Get the new location.
		const ConcLoc *loc = &abstract_state->conc_location();

		if (loc) {

			// Add this node to the appropriate loc-node mapping.
			if (art_.loc_nodes_.find(loc) != art_.loc_nodes_.end())
				art_.loc_nodes_[loc]->insert(this);
			else {

				const_nodes_t *nodes = new const_nodes_t();
				nodes->insert(this);

			    ConcLoc *copy_loc = new ConcLoc(*loc);
			    art_.conc_loc_pool_.push_back(copy_loc);

				art_.loc_nodes_[copy_loc] = nodes;
			}
		}
	}

	// Set abstract state.
	abstract_state_ = abstract_state;
}

ART::~ART() {

	//std::cout << loc_nodes_.size() << std::endl;

	// Clean up hook.
	for (loc_nodes_t::iterator it = loc_nodes_.begin();
			it != loc_nodes_.end();
			++it) {

		//(*it).first->print(std::cout);

		if ((*it).second) {

			const_nodes_t *nodes = (*it).second;
			nodes->clear();
			delete nodes;
		}
	}

	loc_nodes_.clear();

	// Clean work lists.
	for (work_lists_t::iterator it = lists_.begin();
			it != lists_.end(); ++it) {
		if (*it) {
			work_list_t *list = *it;
			list->clear();
			delete list;
		}
	}

	lists_.clear();

	// Detach root from the tree.
	// Otherwise it cannot be allocated; see destructor
	// of ART::ARTNode.
	ARTNode *temp_root = root_;
	root_ = 0;

	delete temp_root;

    for (size_t i = 0; i < conc_loc_pool_.size(); ++i)
	delete conc_loc_pool_[i];

	// Clear leaves.
	leaves_.clear();

	// Set number of nodes to 0.
	num_of_nodes_ = 0;
	total_num_of_nodes_ = 0;
	removed_num_of_nodes_ = 0;
}

ART::ARTNode* ART::create_node(ConcAbstractState *abstract_state) {
	// Create a new node.
	ARTNode *node = new ARTNode(*this, abstract_state);

	// Insert node to the hook.
	const ConcLoc *loc = &abstract_state->conc_location();

	if (loc) {

		if (loc_nodes_.find(loc) != loc_nodes_.end())
			loc_nodes_[loc]->insert(node);
		else {

			const_nodes_t *nodes = new const_nodes_t();
			nodes->insert(node);

			ConcLoc *copy_loc = new ConcLoc(*loc);
			conc_loc_pool_.push_back(copy_loc);

			loc_nodes_[copy_loc] = nodes;
		}
	}

	// Creating a new node always means creating a new leaf.
	leaves_.insert(node);

	// Increment number of nodes.
	++num_of_nodes_;

	++total_num_of_nodes_;

	// Return the created node.
	return node;
}

void ART::ARTNode::build_dot_node(std::ostream& out_) const {

	//! first print this node

    // Determine shape.
    //std::string shape = "circle";

    std::string label = abstract_state_->to_string();

    out_ << node_id_
	 << " [ label=\"" << node_id_ << ": "
	 <<  label << "\"];";

    //! then print the children if exist
    for(child_iterator it = child_begin();
    		it != child_end(); ++it){

    	(*it).second->build_dot_node(out_);

    	//! for each child, draw edge.
        out_ << node_id_;
        out_ << " -> ";
        out_ << (*it).second->node_id();

        // Draw edge's label.
        out_ << " [ label=\"";
        out_ << (*it).first->get_name();
        out_ << "\" ];";
    }

    //! print the covering lines
    for(const_covered_node_iterator cit = const_covered_nodes_begin();
    		cit != const_covered_nodes_end(); ++cit){
    	//! for each child, draw edge.
        out_ << node_id_;
        out_ << " -> ";
        out_ << (*cit)->node_id();
        out_ << " [style=dotted];";

    }

}

void ART::build_dot(std::ostream& out_) const {

    out_ << "digraph "
	 << "ART"
	 << " { " << std::endl;

	root_->build_dot_node(out_);

    out_ << "}" << std::endl;


}

void ART::detach_node(ARTNode& node) {

	if (this == &(node.art())) {

		// Remove node from the leaf hook, if it is a leaf.
		if (!node.has_child())
			leaves_.erase(&node);

		// Remove node from the hook.
		const ConcAbstractState& state = node.abstract_state();
		const ConcLoc *loc = &state.conc_location();

		if (loc) {

			loc_nodes_t::iterator it = loc_nodes_.find(loc);

			if (it != loc_nodes_.end() && (*it).second) {

				const_nodes_t *nodes = (*it).second;
				nodes->erase(&node);
			}
		}
		// Update list of work lists.
		remove_from_work_lists(node);
	}
}

void ART::remove_from_work_lists(ARTNode& node) {

	for (work_lists_t::iterator it = lists_.begin(); it != lists_.end(); ++it) {
		if (*it) {
			work_list_t *work_list = *it;
			work_list->remove(&node);
		}
	}
}

void ART::add_into_work_list(ARTNode& node) {

	for (work_lists_t::iterator it = lists_.begin(); it != lists_.end(); ++it) {
		if (*it) {
			work_list_t *work_list = *it;
			work_list->push_back(&node);
		}
	}

}


}


