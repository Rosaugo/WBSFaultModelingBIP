/*
 * conc_location.h
 *
 *  Created on: Dec 15, 2016
 *      Author: wangqiang
 */

#ifndef CONC_LOCATION_H_
#define CONC_LOCATION_H_

#include "util/util.h"
#include "util/hash_map.h"
#include "util/symbol.h"
#include "bip_cfa/cfa_node.h"

#include <map>
#include <assert.h>

namespace bipchecker {

//! Forward declaration.
class ConcAbstractState;

typedef std::map<const Symbol*, const CFANode*, LtSymbol> conc_locs_t;

//! Class for locations in concurrent analysis.
/*!
 * We use std::map as a representation of concurrent locations:
 * - std::map guarantees the order, given the less-than comparator.
 * - no need for fast look-up (thus, hash_map is not necessary).
 */
class ConcLoc: public conc_locs_t {

public:

	//! Class constructor.
	explicit ConcLoc(const ConcAbstractState& state);

	//! Class copy constructor.
	explicit ConcLoc(const ConcLoc& conc_loc): conc_locs_t(conc_loc.begin(), conc_loc.end()) {}

	//! Checks equality.
	/*!
	 * \param other a concurrent location.
	 * \return True iff this equals other.
	 */
	bool equals(const ConcLoc& other) const {
		if (this->size() == other.size()) {

			conc_locs_t::const_iterator cit1 = begin();
			conc_locs_t::const_iterator ecit1 = end();

			for (; cit1 != ecit1; ++cit1) {

				const Symbol *thread_id = (*cit1).first;

				conc_locs_t::const_iterator cit2 = other.find(thread_id);

				if (cit2 == other.end() || (*cit1).second != (*cit2).second)
					return false;
			}
			return true;
		}
		return false;
	}

	//! Gets the hash code of concurrent location.
	/*!
	 * \return The hash code of concurrent location.
	 */
	size_t hash_code() const {
		size_t hash_num = 1;

		conc_locs_t::const_iterator it = begin();
		conc_locs_t::const_iterator eit = end();

		for (; it != eit; ++it) {

			assert((*it).first != 0);
			assert((*it).second != 0);

			const CFANode *loc = (*it).second;

			hash_num = 31 * hash_num + (loc == 0 ? 0 : loc->node_id());

		}
		return hash_num;
	}

	//! Prints concurrent location.
	/*
	 * \param out an output stream.
	 */
	void print(std::ostream& out) const {
		out << "<";

		conc_locs_t::const_iterator it = begin();
		conc_locs_t::const_iterator eit = end();

		size_t i = 0;

		for (; it != eit; ++i, ++it) {

			const Symbol* sym_id = (*it).first;
			const CFANode *loc = (*it).second;

			out << " [atom: " << sym_id->to_string() << "; loc: " << loc->name() << "]";

			if (i < size() - 1)
				out << ", ";
		}
		out << ">" << std::endl;
	}

	std::string to_string() const {

		std::string result = "<";

		conc_locs_t::const_iterator it = begin();
		conc_locs_t::const_iterator eit = end();

		size_t i = 0;

		for (; it != eit; ++i, ++it) {

			const Symbol* sym_id = (*it).first;
			const CFANode *loc = (*it).second;

			result += ( "[" + sym_id->to_string() + "." + loc->name() + "]");

			if (i < size() - 1)
				result += ", ";
		}
		result += ">";

		return result;
	}

	//! Class destructor.
	~ConcLoc() { }

private:

	DISALLOW_ASSIGN(ConcLoc);

};
// class ConcLoc.

struct EqConcLoc {
	bool operator()(const ConcLoc *l1, const ConcLoc *l2) const {
		if (l1 && !l2)
			return false;
		if (!l1 && l2)
			return false;
		if ((!l1 && !l2) || (l1 && l2 && l1->equals(*l2)))
			return true;

		return false;
	}
};

std::ostream& operator<<(std::ostream& out, const ConcLoc& loc);
}


hash_fun_namespace_open {

    // Hash function for concurrent location.
    template<> struct hash<bipchecker::ConcLoc*>
    {
	size_t operator() (const bipchecker::ConcLoc *l) const
	{
	    return l->hash_code();
	}
    };


    // Hash function for concurrent location.
    template<> struct hash<const bipchecker::ConcLoc*>
    {
	size_t operator() (const bipchecker::ConcLoc *l) const
	{
	    return l->hash_code();
	}
    };


}
hash_fun_namespace_close;


#endif /* CONC_LOCATION_H_ */
