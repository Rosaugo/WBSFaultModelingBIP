/*
 * conc_abstract_state.h
 *
 *  Created on: Dec 15, 2016
 *      Author: wangqiang
 */

#ifndef CONC_ABSTRACT_STATE_H_
#define CONC_ABSTRACT_STATE_H_


#include "util/util.h"
#include "util/hash_map.h"
#include "util/symbol.h"
#include "bip_art/abstract_state.h"
#include "bip_art/conc_location.h"

namespace bipchecker {

//! Base class of abstract state for concurrent program analysis.
/*!
 * The abstract state for concurrent program analysis must
 * consist of a collection of abstract states, one for each
 * thread.
 */
class ConcAbstractState {

protected:
	typedef hash_map<const Symbol*,
	AbstractState*,
	hash_fun<const Symbol*>,
	EqSymbol> thread_states_t;

	//! Thread abstract states.
	/*!
	 * The states of threads is represented as
	 * a mapping from thread's names (or symbol, or id) to thread states.
	 */
	thread_states_t thread_states_;

	//! Concurrent location.
	mutable ConcLoc *conc_location_;

	//! Flag indicating valid location.
	mutable bool valid_location_;

public:

	//! Class constructor.
	explicit ConcAbstractState(): conc_location_(0), valid_location_(false) {
	}

	//! Class copy constructor.
	explicit ConcAbstractState(const ConcAbstractState& state) {
		for (thread_states_t::const_iterator it = state.thread_states_.begin();
				it != state.thread_states_.end();
				++it) {

			const Symbol *sym = (*it).first;
			AbstractState *t_state = (*it).second;

			if (sym != 0 && t_state != 0)
			thread_states_[sym] = t_state->clone();
		}

		valid_location_ = state.valid_location_;

		if (valid_location_) //if(state.conc_location_ != 0)
		conc_location_ = new ConcLoc(*(state.conc_location_));
		else
		conc_location_ = 0;
	}

	//! Gets the number of single abstract states.
	/*!
	 * \return The number of single abstract states.
	 */
	size_t thread_size() const {
		return thread_states_.size();
	}

	// TODO(IN): This iterator has to be refined later to ensure
	//           that we are returning "const PredAbsState*".
	typedef thread_states_t::const_iterator const_iterator;

	//! Gets the start iterator of the thread states.
	/*!
	 * \return The start iterator of the thread states.
	 */
	const_iterator thread_begin() const {return thread_states_.begin();}

	//! Gets the end iterator of the thread states.
	/*!
	 * \return The end iterator of the thread states.
	 */
	const_iterator thread_end() const {return thread_states_.end();}

	//! Adds a thread state.
	/*!
	 * This function adds a thread state given a thread symbol. If
	 * the thread symbol is present, then the older thread state is
	 * replaced by the new one.
	 *
	 * \param id a thread id.
	 * \param thread_state a thread state.
	 * \return This object.
	 */
	virtual ConcAbstractState& add_thread_state(const Symbol& id,
			AbstractState *thread_state) {
		thread_states_t::iterator it = thread_states_.find(&id);

		if ( it != thread_states_.end() && (*it).second )
		delete (*it).second;

		thread_states_[&id] = thread_state;

		// Invalidate location.
		valid_location_ = false;

		return *this;
	}

	//! Gets the single thread abstract state of a thread with some id.
	/*!
	 * \param id an id for a thread.
	 * \return The single thread abstract state of a thread with some id, otherwise 0.
	 */
	const AbstractState* thread_state(const Symbol& id) const
	{
		thread_states_t::const_iterator it = thread_states_.find(&id);

		if (it != thread_states_.end())
		return (*it).second;

		return 0;
	}

	//! Gets the single thread abstract state of a thread with some id.
	/*!
	 * \param id an id for a thread.
	 * \return The single thread abstract state of a thread with some id, otherwise 0.
	 */
	AbstractState* thread_state(const Symbol& id)
	{
		thread_states_t::iterator it = thread_states_.find(&id);

		if (it != thread_states_.end()) {

			// Abstract state might be modified by caller,
			// so location should be made invalid.
			valid_location_ = false;

			return (*it).second;
		}
		return 0;
	}

	//! Gets the concurrent location.
	/*!
	 * \return The concurrent location.
	 */
	const ConcLoc& conc_location() const {
		if (!valid_location_) {

			if (conc_location_ != 0)
				delete conc_location_;

			conc_location_ = new ConcLoc(*this);
			valid_location_ = true;
		}

		return *conc_location_;
	}

	//! Validates location.
	/*!
	 * This function provides a mechanism to force recomputing location.
	 *
	 * \return The concurrent location.
	 */
	const ConcLoc& validate_location() {
		if (conc_location_ != 0)
			delete conc_location_;

		conc_location_ = new ConcLoc(*this);
		valid_location_ = true;

		return *conc_location_;
	}

	//! Clones the state.
	/*!
	 * \return The cloned state.
	 */
	virtual ConcAbstractState* clone() const {
		return new ConcAbstractState(*this);
	}

	virtual std::string to_string() const {
		std::string result = "<";

		for(const_iterator cit = thread_begin();
				cit != thread_end(); ){

//			const Symbol* th = (*cit).first;
			AbstractState* th_state = (*cit).second;

//			std::string th_name = th->to_string();
//			result += th_name;
//			result += ": ";
			result += th_state->to_string();

			cit++;
			if(cit != thread_end())
				result += ", ";
		}

		result += ">";
		return result;
	}

	//! Class virtual destructor.
	virtual ~ConcAbstractState() {
		for (thread_states_t::iterator it = thread_states_.begin();
				it != thread_states_.end();
				++it) {
			if((*it).second) delete (*it).second;
		}
		thread_states_.clear();
		if (conc_location_ != 0) delete conc_location_;
	}

private:
	DISALLOW_ASSIGN(ConcAbstractState);
}; // class ConcAbstractState

}

#endif /* CONC_ABSTRACT_STATE_H_ */
