/*
 * abstract_state.h
 *
 *  Created on: Dec 15, 2016
 *      Author: wangqiang
 */

#ifndef ABSTRACT_STATE_H_
#define ABSTRACT_STATE_H_


#include "util/util.h"
#include "bip_cfa/cfa.h"

namespace bipchecker {

//! Base class of abstract state.
class AbstractState {

	//! Program counter or location.
	/*!
	 * Control location is not owned by the abstract state.
	 * The type of control location is pointer to allow
	 * abstract states that contain no specific location,
	 * for example, the top and bottom location in location lattice.
	 */
	const CFANode *control_location_;


public:

	//! Class default constructor.
	explicit AbstractState(const CFANode& control_location)
	: control_location_(&control_location) {
	}

	//! Class default constructor.
	explicit AbstractState()
	: control_location_(0){
	}

	//! Class copy constructor.
	explicit AbstractState(const AbstractState& state) {
		control_location_ = state.control_location_;
	}

	//! Gets control location.
	/*!
	 * \return The control location.
	 */
	const CFANode* control_location() const {
		return control_location_;
	}

	//! Sets control location.
	/*!
	 * \param control_location a control location.
	 */
	void set_control_location(const CFANode& control_location) {
		control_location_ = &control_location;
	}

	//! Clones state.
	/*!
	 * \return The cloned state.
	 */
	virtual AbstractState* clone() const {
		return new AbstractState(*this);
	}

	//! To string
	virtual std::string to_string() {
		std::string result = "[";
		std::string loc = control_location()->name();
		result += loc;
		result += "]";
		return result;
	}

	//! Class virtual destructor.
	virtual ~AbstractState() {
	}

private:
	DISALLOW_ASSIGN (AbstractState);
};

}

#endif /* ABSTRACT_STATE_H_ */
