/*
 * z3_test.cc
 *
 *  Created on: Apr 10, 2017
 *      Author: wangqiang
 */


#include "bip_solver/solver_z3.h"

using namespace bipchecker;

void test_interpolation() ;

void test_translation();

int main(int argc, char *argv[]) {
	//test_interpolation();
	test_translation();
}

void test_translation() {
	std::string sx = "x";
	std::string si = "i";

	variable x(sx);
	variable i(si);
	literal one(1);
	literal two(2);

	binary_expression x_one(binary_expression::EQ, *x.clone(), *one.clone());
	binary_expression i_two(binary_expression::EQ, *i.clone(), *two.clone());
	binary_expression x_i(binary_expression::AND, *x_one.clone(), *i_two.clone());

	z3::context contxt;
	Z3Expr translator(contxt);
	z3::expr x_i_z3 = z3::expr(contxt, translator.z3expr(&x_i));
	expression* n_x_i = translator.to_expression(x_i_z3);
	n_x_i->pretty_print(std::cout);
	std::cout << std::endl;
	delete n_x_i;

	boolean b1("b1");
	boolean b2("b2");
	true_constant tc;
	binary_expression b1_b2(binary_expression::AND, *b1.clone(), *tc.clone());

	z3::expr b1_b2_z3 = z3::expr(contxt, translator.z3expr(&b1_b2));
	expression* n_b1_b2 = translator.to_expression(b1_b2_z3);
	n_b1_b2->pretty_print(std::cout);
	std::cout << std::endl;
	delete n_b1_b2;

	z3::expr tc_z3 = z3::expr(contxt, translator.z3expr(&tc));
	expression* n_tc = translator.to_expression(tc_z3);
	std::cout << is_true_constant(n_tc) << std::endl;
	delete n_tc;

	z3::expr one_z3 = z3::expr(contxt, translator.z3expr(&one));
	expression* n_one = translator.to_expression(one_z3);
	std::cout << is_literal(n_one) << std::endl;
	delete n_one;
}

void test_interpolation() {

	std::vector<expression*> exprs;
	std::vector<expression*> interps;

	std::string sx = "x";
	std::string si = "i";
	std::string sj = "j";
	std::string sx1 = "x1";
	std::string si1 = "i1";

	variable* x = new variable(sx);
	variable* i = new variable(si);
	variable* j = new variable(sj);
	variable* x1 = new variable(sx1);
	variable* i1 = new variable(si1);

	literal* zero = new literal(0);
	exprs.push_back(new binary_expression(binary_expression::EQ, *(i->clone()), *(zero->clone())));

	exprs.push_back(new binary_expression(binary_expression::EQ, *(x->clone()), *(j->clone())));

	literal* fifty = new literal(50);
	exprs.push_back(new binary_expression(binary_expression::LT, *(i->clone()), *(fifty->clone())));

	literal* one = new literal(1);
	binary_expression* plusone = new binary_expression(binary_expression::PLUS, *(i->clone()), *(one->clone()));
	exprs.push_back(new binary_expression(binary_expression::EQ, *(i1->clone()), *(plusone)));

	binary_expression* xplusone = new binary_expression(binary_expression::PLUS, *(x->clone()), *(one->clone()));
	exprs.push_back(new binary_expression(binary_expression::EQ, *(x1->clone()), *(xplusone)));

	exprs.push_back(new binary_expression(binary_expression::GE, *(i1->clone()), *(fifty->clone())));

	exprs.push_back(new binary_expression(binary_expression::EQ, *(j->clone()), *(zero->clone())));

	exprs.push_back(new binary_expression(binary_expression::LT, *(x1->clone()), *(fifty->clone())));

	z3::config config;
	Z3Solver* solver = new Z3Solver(config, z3::context::interpolation());
	z3::check_result result = solver->compute_interpolant(exprs, interps);

	for(std::vector<expression*>::iterator eit = exprs.begin();
			eit != exprs.end(); eit++){
		(*eit)->pretty_print(std::cout);
		std::cout << std::endl;
	}

	std::cout << std::endl;

	if(result == z3::unsat){
		for(std::vector<expression*>::iterator eit = interps.begin();
				eit != interps.end(); eit++){
			expression* texpr = (*eit);
			texpr->pretty_print(std::cout);
			std::cout << std::endl;
		}

		for(std::vector<expression*>::iterator eit = interps.begin();
				eit != interps.end(); eit++){
			delete (*eit);
		}
	}

	for(std::vector<expression*>::iterator eit = exprs.begin();
			eit != exprs.end(); eit++){
		delete (*eit);
	}

	delete x;
	delete i;
	delete j;
	delete x1;
	delete i1;
	delete zero;
	delete fifty;
	delete one;
	delete solver;
}




