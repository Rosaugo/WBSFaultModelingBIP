/*
 * cexbuilder_impact.h
 *
 *  Created on: Apr 5, 2017
 *      Author: wangqiang
 */

#ifndef CEXBUILDER_IMPACT_H_
#define CEXBUILDER_IMPACT_H_


#include "bip_cegar/cexbuilder.h"
#include "bip_impact/cex_impact.h"


namespace bipchecker {

/*
 *  Build a counter example path
 *  Build the SSA form
 *  and compute the interpolants,
 *  which will be extracted by refiner
 */
class CExBuilderImpact : public CExBuilder {

public:
    explicit CExBuilderImpact(TransitionBuilder& trans_builder)
    : CExBuilder(trans_builder){ }

    virtual CEx* build_cex(ART::ARTNode& node) const;

    //! Create the ART path
    CExImpact* create_cex_path(ART::ARTNode& node) const;

    virtual ~CExBuilderImpact(){}

private:
    DISALLOW_COPY_AND_ASSIGN(CExBuilderImpact);
}; // class CExBuilder.

}


#endif /* CEXBUILDER_IMPACT_H_ */
