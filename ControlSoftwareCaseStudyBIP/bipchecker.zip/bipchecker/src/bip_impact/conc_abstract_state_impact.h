/*
 * conc_abstract_state_impact.h
 *
 *  Created on: Apr 4, 2017
 *      Author: wangqiang
 */

#ifndef CONC_ABSTRACT_STATE_IMPACT_H_
#define CONC_ABSTRACT_STATE_IMPACT_H_



#include "util/util.h"
#include "util/hash_map.h"
#include "util/symbol.h"
#include "bip_art/abstract_state.h"
#include "bip_art/conc_location.h"
#include "bip_art/conc_abstract_state.h"
#include "bip_solver/expression.h"

namespace bipchecker {


class ConcAbstractStateImpact : public ConcAbstractState {

	//! Global data region
	expression* global_expr_;

public:

	//! Class constructor.
	explicit ConcAbstractStateImpact() {
		global_expr_ = new true_constant();
	}

	//! Class copy constructor.
	explicit ConcAbstractStateImpact(const ConcAbstractStateImpact& state)
	: ConcAbstractState(state)
	{
		if(state.global_expr_)
			global_expr_ = state.global_expr_->clone();
		else
			global_expr_ = new true_constant();
	}

	//! Get the global data region
	expression* global_state() {
		return global_expr_;
	}

	void set_global_state(expression* expr) {
		if(global_expr_)
			delete global_expr_;
		global_expr_ = expr;
	}

	//! Clones the state.
	/*!
	 * \return The cloned state.
	 */
	virtual ConcAbstractState* clone() const {
		return new ConcAbstractStateImpact(*this);
	}

	virtual std::string to_string() const {

		std::string result = "<";

		std::stringstream ss;
		global_expr_->pretty_print(ss);
		result += ss.str();
		result += ", ";

		for(const_iterator cit = thread_begin();
				cit != thread_end(); ){

//			const Symbol* th = (*cit).first;
			AbstractState* th_state = (*cit).second;

//			std::string th_name = th->to_string();
//			result += th_name;
//			result += ": ";
			result += th_state->to_string();

			cit++;
			if(cit != thread_end())
				result += ", ";
		}

		result += ">";
		return result;
	}

	//! Class virtual destructor.
	virtual ~ConcAbstractStateImpact() {
		if(global_expr_ != 0) 
		  delete global_expr_;
	}

private:
	DISALLOW_ASSIGN(ConcAbstractStateImpact);
}; 
// class ConcAbstractStateImpact

}



#endif /* CONC_ABSTRACT_STATE_IMPACT_H_ */
