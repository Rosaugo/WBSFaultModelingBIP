/*
 * abstract_state_impact.h
 *
 *  Created on: Apr 4, 2017
 *      Author: wangqiang
 */

#ifndef ABSTRACT_STATE_IMPACT_H_
#define ABSTRACT_STATE_IMPACT_H_


#include "util/util.h"
#include "bip_art/abstract_state.h"
#include "bip_solver/expression.h"


namespace bipchecker {


class AbstractStateImpact : public AbstractState {

	//! Abstract data state (or region).
	expression* abstract_data_state_;

public:

	//! Class constructor.
	/*!
	 * \param control_location control location.
	 * \param abstract_data_state region.
	 */
	explicit AbstractStateImpact(const CFANode& control_location,
			expression *abstract_data_state)
	: AbstractState(control_location),
	  abstract_data_state_(abstract_data_state){
	}

	//! Class default constructor.
	explicit AbstractStateImpact(const CFANode& control_location)
	: AbstractState(control_location), abstract_data_state_(0){
	}

	//! Class copy constructor.
	explicit AbstractStateImpact(const AbstractStateImpact& state)
	: AbstractState(state)
	{
		abstract_data_state_ = 0;

		if (state.abstract_data_state_)
			abstract_data_state_ = (state.abstract_data_state_)->clone();
	}

	//! Gets abstract data state (or region).
	/*!
	 * \return The region.
	 */
	const expression* abstract_data_state() const {
		return abstract_data_state_;
	}

	//! Sets abstract data state.
	/*!
	 * \param abstract_data_state an abstract data state (or region).
	 */
	void set_abstract_data_state(expression *abstract_data_state) {
		if (abstract_data_state_)
			delete abstract_data_state_;

		abstract_data_state_ = abstract_data_state;
	}

	//! Clones state.
	/*!
	 * \return The cloned state.
	 */
	virtual AbstractState* clone() const {
		return new AbstractStateImpact(*this);
	}

	virtual std::string to_string() {
		std::string result = "[";
		std::string loc = control_location()->name();
		result += loc;

//		result += ",";
//		std::stringstream ss;
//		abstract_data_state_->pretty_print(ss);
//		result += ss.str();

		result += "]";
		return result;
	}

	//! Class virtual destructor.
	virtual ~AbstractStateImpact() {
		if (abstract_data_state_)
			delete abstract_data_state_;
	}

private:
	DISALLOW_ASSIGN (AbstractStateImpact);
};

}


#endif /* ABSTRACT_STATE_IMPACT_H_ */
