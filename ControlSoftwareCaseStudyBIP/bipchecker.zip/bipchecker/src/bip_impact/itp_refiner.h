/*
 * Itp_refiner.h
 *
 *  Created on: Apr 5, 2017
 *      Author: wangqiang
 */

#ifndef ITP_REFINER_H_
#define ITP_REFINER_H_

#include "bip_cegar/refiner.h"

namespace bipchecker {

class ITPRefiner : public Refiner {

public:
    //! Class constructor.
    /*!
     * \param trans_builder a transition builder.
     */
    explicit ITPRefiner(TransitionBuilder& trans_builder): Refiner(trans_builder){ }

    //! Refines a precision given an abstract counter example.
    /*!
     * \param cex an infeasible counter-example.
     * \return True iff refinement is successful.
     */
    virtual bool refine(ART& art, CEx& cex, AbsDomain& domain, ART::work_list_t& work_list);

    //! Class virtual destructor.
    virtual ~ITPRefiner(){ }
};

}



#endif /* ITP_REFINER_H_ */
