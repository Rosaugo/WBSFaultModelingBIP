/*
 * impact_spor.cc
 *
 *  Created on: Jul 9, 2017
 *      Author: wang
 */

#include "bip_impact/impact_spor.h"
#include "util/logger.h"


namespace bipchecker {

void ConcImpactSPOR::expand_node(ART::ARTNode& node, work_list_t& work_list) const {

	// Get the labeling abstract state.
	const ConcAbstractState* state = &node.abstract_state();

	// Get the node location. delete it later
	const ConcLoc* location = &state->conc_location();

	//! compute the set of enabled interactions
	interactions_t enabled_interactions;
	cfa_edges_t initial_edges;

	compute_interactions(node, enabled_interactions, initial_edges);

	interactions_t resulting_interactions;
	resulting_interactions.clear();

	//! Add static partial order reduction here
	if(enabled_interactions.size() > 0) {

		sym_ports_t enabled_ports;

		compute_enabled_ports(node, enabled_ports);

		persistent_set(location, enabled_ports, enabled_interactions, resulting_interactions);
	}

	///////////////////////////////////////////////////////////////////////////////////
	////////////////// compute the successors of the enabled interactions /////////////
	///////////////////////////////////////////////////////////////////////////////////

	interactions_t::iterator ia_begin = resulting_interactions.begin();
	interactions_t::iterator ia_end = resulting_interactions.end();

	for(interactions_t::iterator iit = ia_begin; iit != ia_end; ++iit){

		//! for each enabled interaction,
		const BIPInteraction* temp_ia = *iit;

		Logger::log << Logger::level(2)
			<< "IMPACT: Compute post image of interaction "
			<< temp_ia->get_name()
			<< Logger::end;

		//! keep the set of CFAEdges for each enabled interaction
		cfa_edges_t temp_trans;

		get_cfa_edges(location, temp_ia, temp_trans);

		//! create a new successor node
		ConcAbstractState *new_state = 0;

		//! obtain the state of the current node
		const ConcAbstractState* original_state = state;
		const ConcAbstractStateImpact* original_state_impact =
				dynamic_cast<const ConcAbstractStateImpact*>(original_state);

		//! then compute the image given the set of transitions temp_trans
		new_state = transfer(*original_state_impact, temp_trans);

		//! create a successor node, and set the label to be the set of edges
		node.add_child(*temp_ia, new_state);

		for(auto cit : temp_trans) {
		  node.add_transition(*temp_ia, cit);
		}
	}

	////////////////////////////////////////////////////////////////////////////////////////
	///////////// compute the successor of internal transitions, if it exists //////////////
	////////////////////////////////////////////////////////////////////////////////////////
	if(!initial_edges.empty()){

		/// DEBUG HERE
		Logger::log << Logger::level(2)
			<< "IMPACT: Compute post image of initialization transitions. "
			<< Logger::end;

		//! there are some component , which can perform internal transitions
		//! then take the internal transitions all at once

		//! create successor node
		ConcAbstractState *new_state = 0;

		//! get the current state
		const ConcAbstractState* original_state = state;
		const ConcAbstractStateImpact* original_state_impact =
				dynamic_cast<const ConcAbstractStateImpact*>(original_state);

		new_state = transfer(*original_state_impact, initial_edges);

		//! this interaction is not in the interaction model, how can we delete it??
		//! TODO: add it to the interaction model
		BIPInteraction* temp_ia = new BIPInteraction(std::string("BIP_Internal_Interaction"));

		node.add_child(*temp_ia, new_state);

		for(cfa_edges_t::const_iterator cit = initial_edges.begin();
				cit != initial_edges.end(); ++cit){
			node.add_transition(*temp_ia, *cit);
		}

	}

	add_children_to_work_list(node, work_list);

	enabled_interactions.clear();
	initial_edges.clear();

	// Mark expanded node as UNCOVERED.
	node.mark_uncovered();
}

void ConcImpactSPOR::compute_enabled_ports(ART::ARTNode& node,
		sym_ports_t& enabled_ports) const {

	// Get the labeling abstract state.
	const ConcAbstractState* state = &node.abstract_state();

	// Get the node location. delete it later
	const ConcLoc* location = &state->conc_location();

	////////////////////////////////////////////////////////////////////////////////////////////
	//////////////// step 1: compute the enabled ports, and internal transitions ///////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	for(ConcLoc::const_iterator lit = location->begin();
			lit != location->end(); ++lit){

	  //! the component name
	  const Symbol* comp_id = (*lit).first;
	  std::string comp_name = comp_id->to_string();

	  //! the control location
	  const CFANode* comp_loc = (*lit).second;

	  std::set<std::string> temp_ports;
	  //! for each out-going edge, collect the set of ports
	  for(CFANode::const_iterator nit = comp_loc->out_begin();
	      nit != comp_loc->out_end(); ++nit){

	    const CFAEdge* temp_edge = (*nit);
	    //! check if it is internal
	    if(temp_edge->is_internal()){
	      //! this is an internal transition

	    } else{
	      //! this is a transition labelled with a port
	      assert(temp_edge->label() != 0);
	      std::string temp_name = temp_edge->label()->name()->name();
	      temp_ports.insert(temp_name);
	    }
	  }

	  enabled_ports[comp_name] = temp_ports;
	}

}

void ConcImpactSPOR::persistent_set(const ConcLoc* location,
		sym_ports_t& enabled_ports,
		interactions_t& enabled_interactions,
		interactions_t& resulting_interactions) const {

	concloc_interaction_map::iterator ciit = persistent_set_cache_.find(location);

	if (ciit != persistent_set_cache_.end()) {

		for (interactions_t::iterator it = (*ciit).second->begin();
				it != (*ciit).second->end(); ++it) {

			resulting_interactions.push_back(*it);
		}

	} else {

		interactions_t* temp_cache = new interactions_t();

		if( enabled_interactions.size() > 1) {

			interaction_set enabled_set;

			for(auto eit : enabled_interactions)
				enabled_set.insert(eit);

			//! pick an enabled interaction
			interactions_t::const_iterator temp_cit = enabled_interactions.begin();

			// Prepare a work list.
			std::deque<const BIPInteraction*> work_list;
			work_list.push_back(*temp_cit);

			interaction_set visited_set;

			while (!work_list.empty()) {

				// Get the current interaction.
				const BIPInteraction *current_ai = work_list.back();
				work_list.pop_back();
				visited_set.insert(current_ai);

				std::string current_name = current_ai->get_name();

				///! first check if the current interaction is enabled
				if(enabled_set.find(current_ai) == enabled_set.end() ) {
					// when it is disabled, then compute the NES

					bool partial_enabled = false;

					for(BIPInteraction::const_iterator ppit = current_ai->const_begin();
							ppit != current_ai->const_end() && !partial_enabled; ++ppit){

						std::string component = (*ppit)->get_threadName();
						std::string port = (*ppit)->get_PortName();

						///! then look up the enabled ports table
						sym_ports_t::iterator temp_it = enabled_ports.find(component);

						if((*temp_it).second.find(port) != (*temp_it).second.end()) {
							partial_enabled = true;
						}
					}

					if(partial_enabled ){

						//! first get the port which is disabled,
						for(BIPInteraction::const_iterator pit = current_ai->const_begin();
								pit != current_ai->const_end(); ++pit) { // for each port

							std::string component = (*pit)->get_threadName();
							std::string port = (*pit)->get_PortName();

							///! then look up the enabled ports table
							sym_ports_t::iterator temp_it = enabled_ports.find(component);
							assert(temp_it != enabled_ports.end());

							if((*temp_it).second.find(port) == (*temp_it).second.end()) {
								//! this port is disabled

								//! first find all the locations which enable this port
								const Symbol& comp_id = Symbol::symbol(component);
								conc_locs_t::const_iterator lit = location->find(&comp_id);
								assert(lit != location->end());

								//! this control location should be an intermediate location
								//! this is the current component location
								const CFANode* comp_loc = (*lit).second;
								const CFA* temp_cfa = &comp_loc->cfa();

								for(CFA::const_iterator nit = temp_cfa->begin();
										nit != temp_cfa->end(); ++nit) {

									//! for each node, check if it has the port as outgoing transition
									const CFANode* temp_node = *nit;
									bool has_port = false;

									for(CFANode::const_iterator neit = temp_node->out_begin();
											neit != temp_node->out_end() && !has_port; ++neit) {

										const CFAEdge* temp_out_edge = *neit;
										if(temp_out_edge->label() != 0) {
											if(temp_out_edge->label()->name()->name() == port)
												has_port = true;
										}
									} //! end for outgoing edges


									if(has_port) {

										//! then get all the incoming edges
										for(CFANode::const_iterator eit = temp_node->in_begin();
												eit != temp_node->in_end(); ++eit) {

											const CFAEdge* temp_edge = (*eit);

											if(!temp_edge->is_internal()) {

												std::string edge_name = temp_edge->label()->name()->name();

												for(InteractionModel::const_iterator cit = bim_->const_interaction_begin();
														cit != bim_->const_interaction_end();
														++cit) {

													if((*cit)->involved_port(component, edge_name)) {

														bool is_in_the_queue = false;

														for (std::deque<const BIPInteraction*>::iterator it = work_list.begin();
																it != work_list.end() && !is_in_the_queue; ++it) {

															const BIPInteraction *ab_id = *it;

															if ((*cit) == (ab_id))
																is_in_the_queue = true;
														}

														if (!is_in_the_queue
																&& visited_set.find(*cit) == visited_set.end())
															work_list.push_back(*cit);

													}

												}

											}

										} // end for incoming edges

									} //! end if has_port
								}

							} // end if

						} // end for ports

					}

				} else {
					// when it is enabled, then compute the set which can interact with it

					std::vector<const BIPInteraction*> temp_set;
					interact_with_interaction(current_ai, temp_set);

					for(std::vector<const BIPInteraction*>::iterator it = temp_set.begin();
							it != temp_set.end(); ++it) {

						bool is_in_the_queue = false;

						for (std::deque<const BIPInteraction*>::iterator iit = work_list.begin();
								iit != work_list.end() && !is_in_the_queue; ++iit) {

							const BIPInteraction *ab_id = *iit;

							if ((*it) == (ab_id))
								is_in_the_queue = true;
						}

						if (!is_in_the_queue &&
								visited_set.find(*it) == visited_set.end())
						work_list.push_back(*it);
					}
				}

			} //! end while loop

			//! put the enabled interactions in the visited set into the resulting set
			for(interactions_t::iterator it = enabled_interactions.begin();
					it != enabled_interactions.end(); ++it) {

				if(visited_set.find(*it) != visited_set.end()) {
					resulting_interactions.push_back(*it);
					temp_cache->push_back(*it);
				}
			}

//			if(number_before_por > number_after_por)
//				node.set_fully_expand(false);


		} else {

			interactions_t::iterator it = enabled_interactions.begin();

			resulting_interactions.push_back(*it);
			temp_cache->push_back(*it);

		}

		const ConcLoc* copy_loc = new ConcLoc(*location);
		persistent_set_cache_[copy_loc] = temp_cache;
		conc_loc_pool_.push_back(copy_loc);
	}
}

void ConcImpactSPOR::interact_with_interaction(const BIPInteraction* interaction1,
		std::vector<const BIPInteraction*>& interactions) const {

	for (InteractionModel::const_iterator cit = bim_->const_interaction_begin();
			cit != bim_->const_interaction_end(); ++cit) {

		const BIPInteraction* temp_interaction = (*cit);

		if (interference_->has_interference(interaction1, temp_interaction))
			interactions.push_back(temp_interaction);

	}

}



}

