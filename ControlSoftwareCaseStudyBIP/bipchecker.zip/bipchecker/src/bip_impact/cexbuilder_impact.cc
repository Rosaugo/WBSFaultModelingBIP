/*
 * cexbuilder_impact.cc
 *
 *  Created on: Apr 5, 2017
 *      Author: wangqiang
 */


#include "bip_impact/cexbuilder_impact.h"
#include "bip_solver/expression.h"
#include "bip_solver/solver_z3.h"

#include "util/logger.h"

namespace bipchecker {

CEx* CExBuilderImpact::build_cex(ART::ARTNode& node) const {

	// Init cex path.
	CExImpact *cex = create_cex_path(node);
	assert(cex != 0);

	// Get path's length.
	int path_length = cex->length();

	if (path_length > 0) {

		//! Create path expressions: sequence of expressions along the path.
		//! Timed expression in the SSA form
		std::vector<expression*> path_expressions(path_length);

		//! maintain the set of domain variables
		//! that have been seen during building the SSA in the forward manner
		Transition::domain_t vars_seen;

		//! maintain the set of new domain variables
		//! that will be added to the vars_seen set
		//! used to avoid adding redundant variables
		//! since only pointers to the variables are added
//		Transition::domain_t tobe_added;

		//! maintain the set of transitions
		//! deleted after building the SSA form of the path
		std::vector<Transition*> back_transitions;

		// Traverse the CEx forward.
		int current = 0;
		int finish = path_length;

		do {
		  // Get the edges.
		  std::vector<const CFAEdge*>* temp_edges = cex->transitions(current);

		  Transition* temp_tran = trans_builder_.build_transition(*temp_edges);
		  expression* temp_tran_expr = temp_tran->get_expression();
		  expression* temp_tran_guard = temp_tran->guard();
		  
		  expression* trans_expr = 
		    new binary_expression(binary_expression::AND, *(temp_tran_expr->clone()), *(temp_tran_guard->clone()));

		  for(Transition::domain_t::iterator vit = vars_seen.begin();
		      vit != vars_seen.end(); ++vit){
		    
		    expression* vexpr = *vit;
		    variable* v_var = dynamic_cast<variable*>(vexpr);
		    std::string v_var_name = v_var->get_name();
		    
		    bool seen = false;
		    for(Transition::const_domain_iterator dit = temp_tran->domain_begin();
			dit != temp_tran->domain_end() && !seen; ++dit){
		      
		      expression* dexpr = *dit;
		      variable* d_var = dynamic_cast<variable*>(dexpr);
		      std::string d_var_name = d_var->get_name();
		      if(d_var_name == v_var_name)
		    	  seen = true;
		    }
		    
		    if(!seen){
		      expression* shifted_var = new timed_expression( *(vexpr->clone()), 1);
		      expression* eq = new binary_expression(binary_expression::EQ, (*shifted_var), *(vexpr->clone()) );
		      
		      expression* temp_trans_expr = trans_expr;
		      trans_expr = new binary_expression(binary_expression::AND, *temp_trans_expr, *eq);
		    }
		  }

		  for(Transition::const_domain_iterator dit = temp_tran->domain_begin();
		      dit != temp_tran->domain_end(); ++dit){
		    expression* dexpr = *dit;
		    variable* d_var = dynamic_cast<variable*>(dexpr);
		    std::string d_var_name = d_var->get_name();
		    
		    bool seen = false;
		    for(Transition::domain_t::iterator vit = vars_seen.begin();
			vit != vars_seen.end(); ++vit){
		      
		      expression* vexpr = *vit;
		      variable* v_var = dynamic_cast<variable*>(vexpr);
		      std::string v_var_name = v_var->get_name();
		      if(d_var_name == v_var_name)
		    	  seen = true;
		    }
		    
		    if(!seen)
		      vars_seen.insert(dexpr);
		  }

		  expression* timed_trans_expr = new timed_expression(*trans_expr, current);
		  expression* simplified_expr = simplify(timed_trans_expr);
		  path_expressions[current] = simplified_expr;

		  ++current;
		  back_transitions.push_back(temp_tran);
		  delete timed_trans_expr;
		  
		} while (current != finish);
		

		// Set path expressions
		cex->set_path_expressions(path_expressions);

		//! compute the interpolants
		std::vector<expression*> interps;

		z3::config config;
		Z3Solver solver(config, z3::context::interpolation());
		z3::check_result result = solver.compute_interpolant(path_expressions, interps);

		if(result == z3::unsat){

			for(auto texpr : interps) {

			    expression* interp = untimed_expression(texpr);

			    cex->add_interpolants(interp);

				Logger::log << Logger::level(3)
					<< "IMPACT: Generate interpoant: "
					<< interp
					<< Logger::end;
			}

			cex->set_kind(CEx::ABSTRACT);
		  
		} else {
			cex->set_kind(CEx::CONCRETE);
		}

		// Clean up.
		vars_seen.clear();
//		tobe_added.clear();

//		delete solver;

		for(std::vector<Transition*>::iterator tit = back_transitions.begin();
		    tit != back_transitions.end(); ++tit)
			delete (*tit);

		for(std::vector<expression*>::iterator eit = interps.begin();
		    eit != interps.end(); eit++)
			delete (*eit);
	}

	return cex;
}


CExImpact* CExBuilderImpact::create_cex_path(ART::ARTNode& node) const {

	// Create an ART path (CEx) starting from the last node.
	CExImpact *cex = new CExImpact(node);

	// Get ART.
	ART& art = node.art();

	// Get ART root.
	ART::ARTNode& root = art.root();

	ART::ARTNode *walk = &node;

	// Build CEx path to the root.
	while (&root != walk) {

		const BIPInteraction *edge = walk->label();
		assert(edge != 0);

		// Prepend CEx.
		cex->push_front(*edge);

		// Advance walking node to parent.
		walk = walk->parent();

		std::vector<const CFAEdge*>* edges = new std::vector<const CFAEdge*>();
		for(ART::ARTNode::const_edge_iterator cti = walk->transition_begin(*edge);
		    cti != walk->transition_end(*edge); ++cti){
		  if(*cti){
		    edges->push_back(*cti);
		    //cex->add_transition(index, *cti);
		  }
		}
		cex->add_transitions_front(edges);
	}


	/*
	walk = &node;
	while(&root != walk){

		const BIPInteraction* edge = walk->label();
		assert(edge != 0);

		walk = walk->parent();

		for(ART::ARTNode::const_edge_iterator cti = walk->transition_begin(*edge);
				cti != walk->transition_end(*edge); ++cti){
			if(*cti){
				cex->add_transition(index, *cti);
			}
		}
		index--;
	}*/

	return cex;
}


}

