/*
 * impact_dpor.h
 *
 *  Created on: Jul 5, 2017
 *      Author: wang
 */

#ifndef IMPACT_DPOR_H_
#define IMPACT_DPOR_H_


#include "util/util.h"
#include <queue>
#include <utility>

#include "bip_frontend/bip_interaction/interaction_model.h"
#include "bip_frontend/bip_interaction/interference_relation.h"

#include "bip_impact/conc_impact.h"


namespace bipchecker{

class ConcImpactDPOR : public ConcImpact {

    //! bip interference relation
    BIPInterferenceRelation* interference_;

public:

    explicit ConcImpactDPOR(CExBuilder& cex_builder,
			Refiner& refiner,
			AbsDomain& domain,
			InteractionModel* ia_model,
			BIPInterferenceRelation* interference_relation):
    ConcImpact(cex_builder,refiner, domain, ia_model),
    	interference_(interference_relation) {}


	//! Performs reachability analysis.
	/*!
	 * \param init_state an initial abstract state.
	 * \return The CEGAR result consisting of an ART and status (ERROR, SAFE, or UNKNOWN).
	 */
    virtual ConcCEGARResult* reach(ConcAbstractState *init_state) const;


	//! Expands ART node.
	/*!
	 * \param node an ART node.
	 * \param work_list an ART work list.
	 */
    virtual void expand_node(ART::ARTNode& node, work_list_t& work_list) const;


    //! backtrack the path and compute the interleaving information
    void backtrack_path(ART::ARTNode& node, work_list_t& work_list) const;


    //! Check if there is an interfering interaction to explore one the covering node
    void backtrack_covering(ART::ARTNode& node, work_list_t& work_list) const;


    //! Check if an interaction is structurally enabled in a control location
    bool is_enabled(ART::ARTNode& node, const BIPInteraction* ia) const;


    //! Expand the interactons in the backtracking set
    void explore_backtracking(ART::ARTNode& node, const BIPInteraction& ia,
    		work_list_t& walk_list) const;


    void compute_interactions(ART::ARTNode& node,
    		interactions_t& enabled_interactions,
    		interactions_t& disabled_interactions,
    		cfa_edges_t& initial_edges) const ;


    //! Class destructor.
    virtual ~ConcImpactDPOR() { }

private:
    DISALLOW_COPY_AND_ASSIGN(ConcImpactDPOR);
};

}



#endif /* IMPACT_DPOR_H_ */
