/*
 * impact_dpor.cc
 *
 *  Created on: Jul 5, 2017
 *      Author: wang
 */


#include "bip_impact/impact_dpor.h"
#include "util/logger.h"


namespace bipchecker {


/*
 *  In the reachability analysis,
 *  we perform a DFS search, and whenever we visit a new node,
 *  	1: 	first analyze the dependency in the tree path,
 *  		and compute the backtracking information.
 *		2:	then does the abstract analysis and refinement
 */
ConcCEGARResult* ConcImpactDPOR::reach(ConcAbstractState *init_state) const {

	// Create an ART whose root is labeled with the initial abstract state.
	ART *art = new ART(init_state);

	// Prepare result.
	ConcCEGARResult *cegar_result = new ConcCEGARResult(art);

	// Get the root of ART.
	ART::ARTNode& root = art->root();
	assert(root.mark() == ART::ARTNode::UNMARKED);

	// Get a work list that is synchronized with the ART.
	work_list_t& work_list = art->create_work_list();

	// Place the root in the work list.
	work_list.push_back(&root);

	// Implement work-list algorithm.
	// INV: every node in the work list is unmarked.

	while(!work_list.empty()) {

		//! Pick a node.
		//! This node should be unmarked (un-processed).
		//!
		ART::ARTNode *node = choose_node(work_list);
		assert(node != 0);
		assert(node->mark() == ART::ARTNode::UNMARKED);

		Logger::log << Logger::level(1)
			    << "IMPACT: Take an ART node "
			    << node->node_id()
			    << Logger::end;

		//! Get the labeling abstract state.
		const ConcAbstractState& state = node->abstract_state();
		std::string node_loc = state.conc_location().to_string();

		//! first explore backtracking
		backtrack_path(*node, work_list);

		//! then do the abstract analysis and refinement
		if (is_error(state)) {

			Logger::log << Logger::level(1)
				    << "IMPACT: Build an abstract counterexample."
				    << Logger::end;

			//! the following function:
			//! 1:build the abstract counterexample
			//! 2:check the feasibility
			//! 3:compute the interpolants in case of UNSAT

			CEx *cex = cex_builder_.build_cex(*node);
			assert(cex != 0);

			if (cex->is_abstract()) { // Counter-example is spurious.

				Logger::log << Logger::level(1)
					    << "IMPACT: Counter-example is spurious."
					    << Logger::end;

				Logger::log << Logger::level(3)
					    << "IMPACT: Print counter-example. \n"
					    << *cex << Logger::end;

				Logger::log << Logger::level(1)
					    << "IMPACT: Do refinement."
					    << Logger::end;

				//! Do refinement.
				//! conjunct the interpolant to the corresponding state
				//! and update the covering information:
				//! 1: remove the uncovered nodes
				//! 2: add them into the work-list
				bool is_refined = refiner_.refine(*art, *cex, domain_, work_list);

				//! TODO:
				//! there is a problem if we remove the refined nodes with state false
				//! if there is a backtracking set in this node,
				//! we have to remove it from the worklist

				if (is_refined) {

					Logger::log << Logger::level(1)
						    << "IMPACT: Counter-example refinement completes."
						    << Logger::end;


				} else {// Refinement fails.

					Logger::log << Logger::level(1)
						   << "IMPACT: Counter example refinement fails."
						   << Logger::end;

					Logger::log << Logger::level(1)
						   << "IMPACT: Quit due to unable to refine the counter example."
						   << Logger::end;

					work_list.clear();
					cegar_result->set_complete_search(false);
					cegar_result->set_cex(cex);
					return cegar_result;
				}

			} else { // Counter-example is concrete.

				Logger::log << Logger::level(1)
					    << "IMPACT: Counter-example is concrete."
					    << Logger::end;

				cegar_result->set_status(ConcCEGARResult::ERROR);
				work_list.clear();
				cegar_result->set_cex(cex);
				return cegar_result;
			}

			delete cex;
		}
		////////////////////////! CASE 2: check if it can be covered
		else if (is_covered(*node, *art)) {

			//! TODO: When a node is covered,
			//! make sure the 'important' interactions are not ignored

			Logger::log << Logger::level(1)
				    << "IMPACT: ART node "
				    << node->node_id() << " is covered."
				    << Logger::end;

		    //! remove the covering information of node
		    //! add the uncovered nodes into the work-list

		    std::vector<ART::ARTNode*> node_its;
		    for(ART::ARTNode::covered_node_iterator cit = node->covered_nodes_begin();
		    		cit != node->covered_nodes_end(); ++cit) {
		    	ART::ARTNode* cnode = *cit;
		    	node_its.push_back(cnode);
		    }

		    for(auto nd: node_its) {
		    	node->remove_covered_node(nd);
		    	nd->set_covering_node(0);
		    	nd->unmark();
		    	work_list.push_back(nd);
		    }

		    //! mark it as covered
		    node->mark_covered();

		    //! get the covering node
		    //! and then backtrack the covering node
		    ART::ARTNode* covering_node = node->get_covering_node();
		    backtrack_covering(*covering_node, work_list);
		}
		//////////////////////! CASE 3: Force covering
		else if( fc && force_covering(*node, *art)) {

		  Logger::log << Logger::level(1)
			      << "IMPACT: Node "
			      << node->node_id() << ": " << node_loc
			      << "is forcely covered."
			      << Logger::end;

		    //! remove the covering information of node
		    //! add the uncovered nodes into the work-list

		    std::vector<ART::ARTNode*> node_its;
		    for(ART::ARTNode::covered_node_iterator cit = node->covered_nodes_begin();
		    		cit != node->covered_nodes_end(); ++cit) {
		    	ART::ARTNode* cnode = *cit;
		    	node_its.push_back(cnode);
		    }

		    for(auto nd: node_its) {
		    	node->remove_covered_node(nd);
		    	nd->set_covering_node(0);
		    	nd->unmark();
		    	work_list.push_back(nd);
		    }

		    //! mark it as covered
		    node->mark_covered();

		    //! get the covering node
		    //! and then backtrack the covering node
		    ART::ARTNode* covering_node = node->get_covering_node();
		    backtrack_covering(*covering_node, work_list);
		}
		///////////////////////! CASE 4: check if there is a backtracking set
//		else if (!node->is_backtracking_empty()) {
//			  Logger::log << Logger::level(1)
//				      << "IMPACT: Backtracking in node "
//				      << node->node_id() << ": " << node_loc
//				      << Logger::end;
//			  explore_backtracking(*node, work_list);
//		}
		//////////////////////! CASE 5: expand the state in the other cases
		else {

		  Logger::log << Logger::level(1)
			      << "IMPACT: Expand node "
			      << node->node_id() << ": " << node_loc
			      << Logger::end;

		  //! expand the current node and then mark it as uncovered.
		  expand_node(*node, work_list);
		}
	}

	if (cegar_result->status() == ConcCEGARResult::UNKNOWN)
	  cegar_result->set_status(ConcCEGARResult::SAFE);

	return cegar_result;
}


void ConcImpactDPOR::backtrack_path(ART::ARTNode& node, work_list_t& work_list) const {

	//! first compute the set of enabled interactions
	//! and the set of partially disabled interactions

	interactions_t enabled_interactions;
	interactions_t disabled_interactions;
	cfa_edges_t initial_edges;
	compute_interactions(node, enabled_interactions, disabled_interactions, initial_edges);

	interactions_t all_interactions;

	if(!enabled_interactions.empty()) {

		for(auto ei : enabled_interactions)
			all_interactions.push_back(ei);

		for(auto di : disabled_interactions)
			all_interactions.push_back(di);

		for(auto temp_ia : all_interactions) {

		//! backtrack the ART path,
		//! find the latest interaction
		//! that interferes with temp_ia,
		//! and that maybe co-enabled

		ART& art_ = node.art();
		ART::ARTNode* root_node = &art_.root();
		ART::ARTNode* walk_node = &node;
		bool flag = false;

		while(walk_node != root_node && !flag) {

			//! get the interaction to this node
			const BIPInteraction* walk_ia = walk_node->label();

			//! move one step back
			walk_node = walk_node->parent();

			//! check if this interaction interferes with temp_ia
			if(interference_->has_interference(walk_ia, temp_ia) && (!walk_node->has_been_taken(temp_ia)) &&
					( (is_enabled(*walk_node, temp_ia) && is_enabled(node, temp_ia) )
							|| (!is_enabled(node, temp_ia) && false))) {

				/// DEBUG HERE
				Logger::log << Logger::level(2)
					<< "IMPACT: Detect an interference between "
					<< temp_ia->get_name()
					<< " and " << walk_ia->get_name()
					<< Logger::end;

				//! TODO:
				//! is_taken check is not proper,
				//! since it may be taken, and be removed after refinement
				//! So each node should remember the interactions being taken

				//! get the set of interactions in the walk_node
				interactions_t walk_enabled_interactions;
				interactions_t walk_disabled_interactions;
				cfa_edges_t walk_edges;
				compute_interactions(*walk_node, walk_enabled_interactions, walk_disabled_interactions, walk_edges);

				for(auto eia : walk_enabled_interactions) {

					if(!walk_node->has_been_taken(eia)) {

						flag = true;

						/// DEBUG HERE
						Logger::log << Logger::level(2)
							<< "IMPACT: Explore an interfering interaction "
							<< eia->get_name()
							<< " on node " << walk_node->node_id()
							<< Logger::end;

						//! compute the successor node w.r.t temp_ia
						//! and add it into the worklist
						explore_backtracking(*walk_node, *eia, work_list);

						//! only explore one interaction
						break;
					}

				} //end for

				walk_disabled_interactions.clear();
				walk_edges.clear();
				walk_enabled_interactions.clear();

			}

			//! check this interaction does not interfere with another one in between
			//! i.e., i \not \rightarrow p
			//! 1: p is not the process of performing i
			//! 2: there is no j > i, s.t., j interferes with i and p performs j


			//! we do not check if they can be co-enabled or not,
			//! but add all the interfering interactions to the backtracking set
			//! and take the conjunction with the enabling interactions of the node later


			//! if there is an interference, then explore an interleaving
//			if(flag) {

//				walk_node->add_backtracking(temp_ia);
//				std::vector<ART::ARTNode*> new_nodes;
//				new_nodes.push_back(walk_node);
//				add_nodes_to_work_list(new_nodes, work_list);
//			}

		}

	}
	}

	enabled_interactions.clear();
	initial_edges.clear();
	disabled_interactions.clear();
	all_interactions.clear();
}

void ConcImpactDPOR::backtrack_covering(ART::ARTNode& node, work_list_t& work_list) const {

	//! compute the set of enabled interactions
	interactions_t enabled_interactions;
	interactions_t disabled_interactions;
	cfa_edges_t initial_edges;
	compute_interactions(node, enabled_interactions, disabled_interactions, initial_edges);

	//! for each enabled interaction, that is
	//! not taken, or in the backtracking set
	for(auto ei : enabled_interactions) {

	}
}

void ConcImpactDPOR::expand_node(ART::ARTNode& node, work_list_t& work_list) const {

	// Get the labeling abstract state.
	const ConcAbstractState* state = &node.abstract_state();

	// Get the node location. delete it later
	const ConcLoc* location = &state->conc_location();

	//! compute the set of enabled interactions
	interactions_t enabled_interactions;
	interactions_t disabled_interactions;
	cfa_edges_t initial_edges;
	compute_interactions(node, enabled_interactions, disabled_interactions, initial_edges);

	//! find all the interfering enabled interactions
	//! and then compute the successors

	if(enabled_interactions.empty() and initial_edges.empty()){
		  Logger::log << Logger::level(1)
			      << "IMPACT: Node "
			      << node.node_id() << " is a deadlock state."
			      << Logger::end;
	}

	const BIPInteraction* temp_ia = *(enabled_interactions.begin());

	interactions_t to_be_explored;
	to_be_explored.push_back(temp_ia);

	for(auto ei : enabled_interactions) {
		if(interference_->has_interference(ei, temp_ia))
			to_be_explored.push_back(ei);
	}

	////////////////////////////////////////////////////////////////////////////////////////
	///////////// compute the successor of initial transitions ////////////// //////////////
	////////////////////////////////////////////////////////////////////////////////////////
	if(!initial_edges.empty()){

		//! create successor node
		ConcAbstractState *new_state = 0;
		//!
		const ConcAbstractState* original_state = state;
		const ConcAbstractStateImpact* original_state_impact =
				dynamic_cast<const ConcAbstractStateImpact*>(original_state);

		/// DEBUG HERE
		Logger::log << Logger::level(2)
			<< "IMPACT: Compute post image of initialization transitions. "
			<< Logger::end;

		new_state = transfer(*original_state_impact, initial_edges);

		//! this interaction is not in the interaction model, how can we delete it??
		//! TODO: add it to the interaction model
		BIPInteraction* temp_ia = new BIPInteraction(std::string("BIP_Internal_Interaction"));

		node.add_child(*temp_ia, new_state);

		for(auto ie: initial_edges) {
			node.add_transition(*temp_ia, ie);
		}
	}

	//! pick an enabled interaction to explore
	//! simply take the first one
	if(!enabled_interactions.empty()) {

		for(auto ei : to_be_explored) {

			//! create a new successor node
			ConcAbstractState *new_state = 0;

			//! obtain the state of the current node
			const ConcAbstractState* original_state = state;
			const ConcAbstractStateImpact* original_state_impact =
					dynamic_cast<const ConcAbstractStateImpact*>(original_state);

			Logger::log << Logger::level(2)
				<< "IMPACT: Compute post image of interaction "
				<< ei->get_name() << Logger::end;

			//! keep the set of CFAEdges for each enabled interaction
			cfa_edges_t temp_trans;

			get_cfa_edges(location, ei, temp_trans);

			assert(!temp_trans.empty());

			//! then compute the image given the set of transitions temp_trans
			new_state = transfer(*original_state_impact, temp_trans);

			//! create a successor node, and set the label to be the set of edges
			node.add_child(*ei, new_state);

			for(auto cit : temp_trans) {
			  node.add_transition(*ei, cit);
			}

			//! remember it is taken
			node.add_taken(ei);
		}

	}

	add_children_to_work_list(node, work_list);

	enabled_interactions.clear();
	to_be_explored.clear();
	initial_edges.clear();

	// Mark expanded node as UNCOVERED.
	node.mark_uncovered();
}


void ConcImpactDPOR::explore_backtracking(ART::ARTNode& node,
		const BIPInteraction& ia,
		work_list_t& work_list) const {

	// Get the labeling abstract state.
	const ConcAbstractState* state = &node.abstract_state();

	// Get the node location. delete it later
	const ConcLoc* location = &state->conc_location();

	std::vector<ART::ARTNode*> new_nodes;

	const BIPInteraction* temp_ia = &ia;

	//! create a new successor node
	ConcAbstractState *new_state = 0;

	//! obtain the state of the current node
	const ConcAbstractState* original_state = state;
	const ConcAbstractStateImpact* original_state_impact =
			dynamic_cast<const ConcAbstractStateImpact*>(original_state);

	//! keep the set of CFAEdges for each enabled interaction
	std::vector<const CFAEdge*> temp_trans;

	///////////////////////////////////////////////////////////////
	//////////////// check if there is message passing ////////////
	///////////////////////////////////////////////////////////////
	if(temp_ia->has_data_transfer()){
		//! if there is data transfer, get the CFAEdge
		const CFA* ia_cfa = temp_ia->get_cfa();
		const CFANode& entry_node = ia_cfa->entry();
		assert(entry_node.out_degree() == 1);
		const CFAEdge* entry_edge = *(entry_node.out_begin());
		assert(entry_edge != 0);
		temp_trans.push_back(entry_edge);
	}

	for(BIPInteraction::const_iterator pit = temp_ia->const_begin();
			pit != temp_ia->const_end(); ++pit){
		//! for each port, expand the corresponding edge
		const BIPPort* temp_port = *pit;
		std::string temp_comp_name = temp_port->get_threadName();
		std::string temp_port_name = temp_port->get_PortName();

		//! find the current control location of this component
		const CFANode* temp_cfa_node = 0;
		for(ConcLoc::const_iterator lit = location->begin();
				lit != location->end(); ++lit){

			const Symbol* comp_id = (*lit).first;
			std::string temp_name = comp_id->to_string();
			if(temp_name == temp_comp_name){
				temp_cfa_node = (*lit).second;
			}

		}
		assert(temp_cfa_node != 0);

		const CFAEdge* temp_cfa_edge = 0;
		//! find the edge corresponding to the port
		for(CFANode::const_iterator eit = temp_cfa_node->out_begin();
				eit != temp_cfa_node->out_end(); ++eit){

			std::string temp_edge_name = (*eit)->label()->name()->name();
			if(temp_edge_name == temp_port_name){
			    temp_cfa_edge = *eit;
			}
		}
		assert(temp_cfa_edge != 0);

		temp_trans.push_back(temp_cfa_edge);
	}
	assert(!temp_trans.empty());

	//! then compute the image given the set of transitions temp_trans
	new_state = transfer(*original_state_impact, temp_trans);

	//! create a successor node, and set the label to be the set of edges
	node.add_child(*temp_ia, new_state);

	for(auto cit : temp_trans) {
		node.add_transition(*temp_ia, cit);
	}

	new_nodes.push_back(node.child(*temp_ia));

	node.add_taken(temp_ia);

	add_nodes_to_work_list(new_nodes, work_list);
}

bool ConcImpactDPOR::is_enabled(ART::ARTNode& node,
		const BIPInteraction* ia) const {

	// Get the labeling abstract state.
	const ConcAbstractState* state = &node.abstract_state();

	// Get the node location. delete it later
	const ConcLoc* location = &state->conc_location();

	//! this map tracks the set of enabled ports by each component
	sym_ports_t enabled_ports;

	////////////////////////////////////////////////////////////////////////////////////////////
	//////////////// step 1: compute the enabled ports, and internal transitions ///////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	for(ConcLoc::const_iterator lit = location->begin();
			lit != location->end(); ++lit){

	  //! the component name
	  const Symbol* comp_id = (*lit).first;
	  std::string comp_name = comp_id->to_string();

	  //! the control location
	  const CFANode* comp_loc = (*lit).second;

	  std::set<std::string> temp_ports;
	  //! for each out-going edge, collect the set of ports
	  for(CFANode::const_iterator nit = comp_loc->out_begin();
	      nit != comp_loc->out_end(); ++nit){

	    const CFAEdge* temp_edge = (*nit);
	    //! check if it is internal
	    if(temp_edge->is_internal()){
	      //! this is an internal transition

	    } else{
	      //! this is a transition labelled with a port
	      assert(temp_edge->label() != 0);
	      std::string temp_name = temp_edge->label()->name()->name();
	      temp_ports.insert(temp_name);
	    }
	  }

	  enabled_ports[comp_name] = temp_ports;
	}

	bool enabled = true;

	for(BIPInteraction::const_iterator bit = ia->const_begin();
			bit != ia->const_end() && enabled; ++bit){

		//! for each port, check if it is enabled
		const BIPPort* temp_port = *bit;
		std::string comp_name = temp_port->get_threadName();
		std::string port_name = temp_port->get_PortName();
		sym_ports_t::iterator temp_it = enabled_ports.find(comp_name);

		if(temp_it == enabled_ports.end()){
			enabled = false;
		} else {
			enabled =
				(*temp_it).second.find(port_name) == (*temp_it).second.end()? false:true ;
		}
    }

	return enabled;
}


void ConcImpactDPOR::compute_interactions(ART::ARTNode& node,
		interactions_t& enabled_interactions,
		interactions_t& disabled_interactions,
		cfa_edges_t& initial_edges) const {

	// Get the labeling abstract state.
	const ConcAbstractState* state = &node.abstract_state();

	// Get the node location. delete it later
	const ConcLoc* location = &state->conc_location();

	//! this map tracks the set of enabled ports by each component
	sym_ports_t enabled_ports;

	std::set<const BIPInteraction*> interaction_set;

	////////////////////////////////////////////////////////////////////////////////////////////
	//////////////// step 1: compute the enabled ports, and internal transitions ///////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	for(ConcLoc::const_iterator lit = location->begin();
			lit != location->end(); ++lit){

	  //! the component name
	  const Symbol* comp_id = (*lit).first;
	  std::string comp_name = comp_id->to_string();

	  //! the control location
	  const CFANode* comp_loc = (*lit).second;

	  std::set<std::string> temp_ports;
	  //! for each out-going edge, collect the set of ports
	  for(CFANode::const_iterator nit = comp_loc->out_begin();
	      nit != comp_loc->out_end(); ++nit){

	    const CFAEdge* temp_edge = (*nit);
	    //! check if it is internal
	    if(temp_edge->is_internal()){
	    	//! this is an internal transition
	    	initial_edges.push_back(temp_edge);
	    } else{
	    	//! this is a transition labelled with a port
	    	assert(temp_edge->label() != 0);
	    	std::string temp_name = temp_edge->label()->name()->name();
	    	temp_ports.insert(temp_name);
	    }
	  }

	  enabled_ports[comp_name] = temp_ports;
	}

	//////////////////////////////////////////////////////////////////////////////////
	///////////////////////// compute enabled interactions ///////////////////////////
	//////////////////////////////////////////////////////////////////////////////////

	for(InteractionModel::const_iterator mit = bim_->const_interaction_begin();
			mit != bim_->const_interaction_end(); ++mit){

		//! for each interaction, check if it is enabled;
		const BIPInteraction* temp_ia =*mit;
		bool enabled = true;
		for(BIPInteraction::const_iterator bit = temp_ia->const_begin();
				bit != temp_ia->const_end() && enabled; ++bit){

			//! for each port, check if it is enabled
			const BIPPort* temp_port = *bit;
			std::string comp_name = temp_port->get_threadName();
			std::string port_name = temp_port->get_PortName();
			sym_ports_t::iterator temp_it = enabled_ports.find(comp_name);

			if(temp_it == enabled_ports.end()){
				enabled = false;
			} else {
				enabled =
					(*temp_it).second.find(port_name) == (*temp_it).second.end()? false:true ;
			}
	    }

	    if(enabled){
	      //! this interaction is enabled, and store them in an ordered way
	      enabled_interactions.push_back(temp_ia);
	      interaction_set.insert(temp_ia);
	    }
	}

	for(InteractionModel::const_iterator mit = bim_->const_interaction_begin();
			mit != bim_->const_interaction_end(); ++mit){

		const BIPInteraction* temp_ia =*mit;

		std::set<const BIPInteraction*>::iterator ia = interaction_set.find(temp_ia);
		if(ia == interaction_set.end()) {
			//! if it is disabled, check if it is partially enabled

			bool partial_enabled = false;

			for(BIPInteraction::const_iterator ppit = temp_ia->const_begin();
					ppit != temp_ia->const_end() && !partial_enabled; ++ppit){

				std::string component = (*ppit)->get_threadName();
				std::string port = (*ppit)->get_PortName();

				///! then look up the enabled ports table
				sym_ports_t::iterator temp_it = enabled_ports.find(component);

				if((*temp_it).second.find(port) != (*temp_it).second.end()) {
					partial_enabled = true;
				}
			}

			if(partial_enabled)
				disabled_interactions.push_back(temp_ia);

		} // end if

	} // end for

	enabled_ports.clear();
	interaction_set.clear();
}

}

