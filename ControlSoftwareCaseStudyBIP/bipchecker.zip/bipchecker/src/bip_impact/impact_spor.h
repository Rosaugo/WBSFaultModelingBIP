/*
 * impact_spor.h
 *
 *  Created on: Jul 9, 2017
 *      Author: wang
 */

#ifndef IMPACT_SPOR_H_
#define IMPACT_SPOR_H_


#include "util/util.h"

#include "bip_frontend/bip_interaction/interaction_model.h"
#include "bip_frontend/bip_interaction/interference_relation.h"

#include "bip_impact/conc_impact.h"

namespace bipchecker {

class ConcImpactSPOR : public ConcImpact {

public:

	typedef hash_set<const BIPInteraction*,
			EqBIPInteraction,
			EqBIPInteraction> interaction_set;

	typedef hash_map<const ConcLoc*,
			interactions_t*,
			hash_fun<const ConcLoc*>,
			EqConcLoc> concloc_interaction_map;

	typedef std::vector<const ConcLoc*> conc_loc_pool_t;

private:

    //! bip interference relation
    BIPInterferenceRelation* interference_;

    //! cache
    mutable concloc_interaction_map persistent_set_cache_;

	//! Pool of concurrent locations.
	mutable conc_loc_pool_t conc_loc_pool_;

public:

    explicit ConcImpactSPOR(CExBuilder& cex_builder,
			Refiner& refiner,
			AbsDomain& domain,
			InteractionModel* ia_model,
			BIPInterferenceRelation* interference_relation):
			ConcImpact(cex_builder,refiner, domain, ia_model),
			interference_(interference_relation) {}

	//! Expands ART node.
	/*!
	 * \param node an ART node.
	 * \param work_list an ART work list.
	 */
    virtual void expand_node(ART::ARTNode& node, work_list_t& work_list) const;


    void persistent_set(const ConcLoc* loc,
    		sym_ports_t& enabled_ports,
    		interactions_t& enabled_interactions,
    		interactions_t& resulting_interactions) const;


    void interact_with_interaction(const BIPInteraction* interaction1,
    		std::vector<const BIPInteraction*>& interactions) const ;


    void compute_enabled_ports(ART::ARTNode& node,
    		sym_ports_t& enabled_ports) const ;

    //! Class destructor.
    virtual ~ConcImpactSPOR() {

    	std::vector<interactions_t*> temp;

    	for(concloc_interaction_map::iterator it = persistent_set_cache_.begin();
    			it != persistent_set_cache_.end(); ++it){
    		temp.push_back((*it).second);
    	}

    	for(std::vector<interactions_t*>::iterator iit = temp.begin();
    			iit != temp.end(); ++iit){
    		delete (*iit);
    	}

    	persistent_set_cache_.clear();
    	temp.clear();

        for (size_t i = 0; i < conc_loc_pool_.size(); ++i)
        	delete conc_loc_pool_[i];

        conc_loc_pool_.clear();
    }

private:

    DISALLOW_COPY_AND_ASSIGN(ConcImpactSPOR);

};

}



#endif /* IMPACT_SPOR_H_ */
