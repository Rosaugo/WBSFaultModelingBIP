/*
 * conc_impact.h
 *
 *  Created on: Apr 5, 2017
 *      Author: wangqiang
 */

#ifndef CONC_IMPACT_H_
#define CONC_IMPACT_H_



#include "util/util.h"
#include <queue>
#include <utility>

#include "bip_frontend/bip_interaction/interaction_model.h"

#include "bip_cegar/conc_cegar.h"

#include "bip_impact/conc_abstract_state_impact.h"
#include "bip_impact/abstract_state_impact.h"
#include "bip_impact/cexbuilder_impact.h"
#include "bip_impact/itp_refiner.h"

namespace bipchecker{

class ConcImpact : public ConcCEGAR {

protected:
    //! bip interaction model
    InteractionModel* bim_;

    //! abstraction domain
    //! Not used in impact algorithm
    AbsDomain& domain_;

    //! flag for enabling force covering
    bool fc;

public:

    explicit ConcImpact(CExBuilder& cex_builder,
			Refiner& refiner,
			AbsDomain& domain,
			InteractionModel* ia_model):
			ConcCEGAR(cex_builder,refiner),
			bim_(ia_model), domain_(domain), fc(false) {}


	typedef std::list<const BIPInteraction*> interactions_t;

	typedef std::vector<const CFAEdge*> cfa_edges_t;

	typedef hash_map<std::string, std::set<std::string>,
			hash_fun<std::string>, EqStr> sym_ports_t;

	//! Performs reachability analysis.
	/*!
	 * \param init_state an initial abstract state.
	 * \return The CEGAR result consisting of an ART and status (ERROR, SAFE, or UNKNOWN).
	 */
    virtual ConcCEGARResult* reach(ConcAbstractState *init_state) const;


	//! Chooses a node from the work list.
	/*!
	 * \param work_list a work list.
	 * \return The chosen node.
	 */
    virtual ART::ARTNode* choose_node(work_list_t& work_list) const;


	//! Perform covering check.
	/*!
	 * \param node an ART node
	 * \param art the ART tree that contains the above node
	 * \return True if the node can be covered
	 */
    virtual bool is_covered(const ART::ARTNode& node, const ART& art) const;


	//! Expands ART node.
	/*!
	 * \param node an ART node.
	 * \param work_list an ART work list.
	 */
    virtual void expand_node(ART::ARTNode& node, work_list_t& work_list) const;


    //! Compute the set of enabled interactions in an ART node
    /*!
     * \param node an ART node
     * \param interactions the set of enabled interactions
     * \param edges the set of initial edges
     */
    void compute_interactions(ART::ARTNode& node,
    		interactions_t& enabled_interactions,
    		cfa_edges_t& edges) const;


    //! Get the set of CFA edges of a BIP interaction
    /*!
     * \param location the given control location
     * (since an edge may have different starting location)
     * \param ia the given BIP interaction
     * \param edges the set of corresponding CFA edges
     */
    void get_cfa_edges(const ConcLoc* location,
    		const BIPInteraction* ia,
    		cfa_edges_t& edges) const ;

	//! Compute an successor of an abstract state.
	/*!
	 * \param state the given current abstract state
	 * \param edges the set of CFG edges for one interaction
	 * \return a successor abstract state following the CFG edges
	 */
    ConcAbstractStateImpact* transfer(const ConcAbstractStateImpact& state,
    		cfa_edges_t& edges) const;


    //! NOT USED
    //! Remove the ART nodes with state predicate false
    void close_refined_nodes(ART& art, CEx& cex) const;

    //! Enable force covering in impact
    void enable_force_covering() { fc = true; }

    //! Forcely cover a tree node
    //! return true if it is covered
    bool force_covering(ART::ARTNode& node, ART& art) const ;

    //! Build a first order encoding of a path
    void build_path_expr(expression*, expression*,
    		std::vector<std::vector<const CFAEdge*>>& edges,
			std::vector<expression*>& edge_expr) const;
    
    //! Class destructor.
    virtual ~ConcImpact() {
    }

private:
    DISALLOW_COPY_AND_ASSIGN(ConcImpact);
};

}


#endif /* CONC_IMPACT_H_ */
