/*
 * conc_impact.cc
 *
 *  Created on: Apr 5, 2017
 *      Author: wangqiang
 */


#include <assert.h>
#include "bip_impact/conc_impact.h"
#include "util/logger.h"

namespace bipchecker {


ConcCEGARResult* ConcImpact::reach(ConcAbstractState *init_state) const {

	// Init time.
	double init_time = get_cpu_time();

	// Create an ART whose root is labelled with the initial abstract state.
	ART *art = new ART(init_state);

	// Prepare result.
	ConcCEGARResult *cegar_result = new ConcCEGARResult(art);

	// Get the root of ART.
	ART::ARTNode& root = art->root();
	assert(root.mark() == ART::ARTNode::UNMARKED);

	// Get a work list that is synchronized with the ART.
	work_list_t& work_list = art->create_work_list();

	// Place the root in the work list.
	work_list.push_back(&root);

	// Implement work-list algorithm.
	// INV: every node in the work list is unmarked.

	while (!work_list.empty()) {

		if (time_limit_ >= 0.0) { // Time limit is enabled.
			if ((get_cpu_time() - init_time) > time_limit_) { // Out of time.
				Logger::log << "IMPACT: Timeout." << Logger::end;
				cegar_result->set_complete_search(false);
				work_list.clear();
				return cegar_result;
			}
		}

		if(mem_limit_ > 0) {
			if(art->size() >= mem_limit_ ) {
				Logger::log << "IMPACT: space limit." << Logger::end;
				cegar_result->set_complete_search(false);
				work_list.clear();
				return cegar_result;
			}
		}

		//! Pick a node.
		//! This node should be unmarked (un-processed).
		ART::ARTNode *node = choose_node(work_list);
		assert(node != 0);
		assert(node->mark() == ART::ARTNode::UNMARKED);

		// Get the labeling abstract state.
		const ConcAbstractState& state = node->abstract_state();

		////////////! CASE 1: check if it is an error state.
		if (is_error(state)) {

			Logger::log << Logger::level(1) 
				    << "IMPACT: Build an abstract counterexample."
				    << Logger::end;

			//! the following function:
			//! 1:build the abstract counterexample
			//! 2:check the feasibility
			//! 3:compute the interpolants in case of UNSAT
			CEx *cex = cex_builder_.build_cex(*node);
			assert(cex != 0);

			if (cex->is_abstract()) { // Counter-example is spurious.

				Logger::log << Logger::level(1) 
					    << "IMPACT: Counterexample is spurious."
					    << Logger::end;

				Logger::log << Logger::level(3) 
					    << "IMPACT: Print counterexample. \n"
					    << *cex << Logger::end;

				Logger::log << Logger::level(1) 
					    << "IMPACT: Do refinement." 
					    << Logger::end;

				//! The following function refines the abstraction:
				//! 1: conjunct the interpolant to the corresponding state
				//! 2: remove the nodes with state 'false'
				//! 3: update the covering information:
				//!  uncovering the covered nodes and
				//!  adding them into the worklist
				//! NOTE: when we delete a node,
				//! we also have to update the covering information of this node
				bool is_refined = refiner_.refine(*art, *cex, domain_, work_list);

				if (is_refined) {

					Logger::log << Logger::level(1)
						    << "IMPACT: Counter-example refinement completes."
						    << Logger::end;

				} else {// Refinement fails.

					Logger::log << Logger::level(1)
						   << "IMPACT: Counter example refinement fails." 
						   << Logger::end;

					Logger::log << Logger::level(1)
						   << "IMPACT: Quit due to unable to refine the counter example." 
						   << Logger::end;

					work_list.clear();
					cegar_result->set_complete_search(false);
					cegar_result->set_cex(cex);
					return cegar_result;
				}

			} else { // Counter-example is concrete.

				Logger::log << Logger::level(1) 
					    << "IMPACT: Counterexample is concrete."
					    << Logger::end;

				cegar_result->set_status(ConcCEGARResult::ERROR);
				work_list.clear();
				cegar_result->set_cex(cex);
				return cegar_result;
			}

			delete cex;
		}
		////////////////////////! CASE 2: check if it can be covered
		else if (is_covered(*node, *art)) {

			//! check if node can be covered
			//! register the covering information if covered
		    //! and uncover the covered nodes of this one
		    //! and add the uncovered nodes into the worklist

			Logger::log << Logger::level(1) 
				    << "IMPACT: ART node " 
				    << node->node_id() << " is covered." 
				    << Logger::end;

		    std::vector<ART::ARTNode*> node_its;
		    for(ART::ARTNode::covered_node_iterator cit = node->covered_nodes_begin();
		    		cit != node->covered_nodes_end(); ++cit) {
		    	ART::ARTNode* cnode = *cit;
		    	node_its.push_back(cnode);
		    }
		    
		    for(auto nd: node_its) {
		    	node->remove_covered_node(nd);
		    	nd->set_covering_node(0);
		    	nd->unmark();
		    	work_list.push_back(nd);
		    }

		    //! mark it as covered
		    //! NOTE it is a leaf node
		    node->mark_covered();
		}
		//////////////////////! CASE 3: Force covering
		else if( fc && force_covering(*node, *art)) { 

			//! check if node can be forcely covered
			//! register the covering information if covered
		    //! and uncover the covered nodes of this one
		    //! and add the uncovered nodes into the worklist

			//std::string node_loc = node->abstract_state().conc_location().to_string();

		  Logger::log << Logger::level(1) 
			      << "IMPACT: Node " 
			      << node->node_id()
			      << " is forcely covered."
			      << Logger::end;


		    std::vector<ART::ARTNode*> node_its;
		    for(ART::ARTNode::covered_node_iterator cit = node->covered_nodes_begin();
		    		cit != node->covered_nodes_end(); ++cit) {
		    	ART::ARTNode* cnode = *cit;
		    	node_its.push_back(cnode);
		    }

		    for(auto nd: node_its) {
		    	node->remove_covered_node(nd);
		    	nd->set_covering_node(0);
		    	nd->unmark();
		    	work_list.push_back(nd);
		    }

		    //! mark it as covered
		    //! NOTE it is a leaf node
		    node->mark_covered();
		}
		//////////////////////! CASE 4: expand the state in the other cases
		else {

		  Logger::log << Logger::level(1) 
			      << "IMPACT: Expand node " 
			      << node->node_id()
			      << Logger::end;

		  //! expand the current node and then mark it as uncovered.
		  expand_node(*node, work_list);
		}
	} //! end while loop

	if (cegar_result->status() == ConcCEGARResult::UNKNOWN)
	  cegar_result->set_status(ConcCEGARResult::SAFE);

	return cegar_result;
}


void ConcImpact::expand_node(ART::ARTNode& node, work_list_t& work_list) const {

	// Get the labeling abstract state.
	const ConcAbstractState* state = &node.abstract_state();

	// Get the node location. delete it later
	const ConcLoc * location = &state->conc_location();

	//! compute the set of enabled interactions
	interactions_t enabled_interactions;
	cfa_edges_t initial_edges;
	compute_interactions(node, enabled_interactions, initial_edges);

	interactions_t::iterator ia_begin = enabled_interactions.begin();
	interactions_t::iterator ia_end = enabled_interactions.end();

	///////////////////////////////////////////////////////////////////////////////////
	////////////////// compute the successors of the enabled interactions /////////////
	///////////////////////////////////////////////////////////////////////////////////
	for(interactions_t::iterator iit = ia_begin; iit != ia_end; ++iit){

		//! for each enabled interaction,
		const BIPInteraction* temp_ia = *iit;

		Logger::log << Logger::level(2)
			<< "IMPACT: Compute post image of interaction "
			<< temp_ia->get_name()
			<< Logger::end;

		//! keep the set of CFAEdges for each enabled interaction
		cfa_edges_t temp_trans;

		get_cfa_edges(location, temp_ia, temp_trans);

		//! create a new successor node
		ConcAbstractState *new_state = 0;

		//! obtain the state of the current node
		const ConcAbstractState* original_state = state;
		const ConcAbstractStateImpact* original_state_impact =
				dynamic_cast<const ConcAbstractStateImpact*>(original_state);

		//! then compute the image given the set of transitions temp_trans
		new_state = transfer(*original_state_impact, temp_trans);

		//! create a successor node, and set the label to be the set of edges
		node.add_child(*temp_ia, new_state);

		for(auto cit : temp_trans) {
		  node.add_transition(*temp_ia, cit);
		}
	}

	////////////////////////////////////////////////////////////////////////////////////////
	///////////// compute the successor of internal transitions, if it exists //////////////
	////////////////////////////////////////////////////////////////////////////////////////
	if(!initial_edges.empty()){

		//! there are some component , which can perform internal transitions
		//! then take the internal transitions all at once

		//! create successor node
		ConcAbstractState *new_state = 0;

		//! get the current state
		const ConcAbstractState* original_state = state;
		const ConcAbstractStateImpact* original_state_impact =
				dynamic_cast<const ConcAbstractStateImpact*>(original_state);

		/// DEBUG HERE
		Logger::log << Logger::level(2)
			<< "IMPACT: Compute post image of initialization transitions. "
			<< Logger::end;

		new_state = transfer(*original_state_impact, initial_edges);

		//! this interaction is not in the interaction model, how can we delete it??
		//! TODO: add it to the interaction model
		BIPInteraction* temp_ia = new BIPInteraction(std::string("BIP_Internal_Interaction"));

		node.add_child(*temp_ia, new_state);

		for(cfa_edges_t::const_iterator cit = initial_edges.begin();
				cit != initial_edges.end(); ++cit){
			node.add_transition(*temp_ia, *cit);
		}

	}

	add_children_to_work_list(node, work_list);

	enabled_interactions.clear();
	initial_edges.clear();

	// Mark expanded node as UNCOVERED.
	node.mark_uncovered();
}

void ConcImpact::get_cfa_edges(const ConcLoc* location,
		const BIPInteraction* ia,
		cfa_edges_t& edges) const {

	///////////////////////////////////////////////////////////////
	//////////////// check if there is message passing ////////////
	///////////////////////////////////////////////////////////////
	if(ia->has_data_transfer()){
		//! if there is data transfer, get the CFAEdge
		const CFA* ia_cfa = ia->get_cfa();
		const CFANode& entry_node = ia_cfa->entry();
		assert(entry_node.out_degree() == 1);
		const CFAEdge* entry_edge = *(entry_node.out_begin());
		assert(entry_edge != 0);
		edges.push_back(entry_edge);
	}

	for(BIPInteraction::const_iterator pit = ia->const_begin();
			pit != ia->const_end(); ++pit){

		//! for each port, expand the corresponding edge
		const BIPPort* temp_port = *pit;
		std::string temp_comp_name = temp_port->get_threadName();
		std::string temp_port_name = temp_port->get_PortName();

		//! find the current control location of this component
		const CFANode* temp_cfa_node = 0;
		for(ConcLoc::const_iterator lit = location->begin();
		    lit != location->end(); ++lit){

		  const Symbol* comp_id = (*lit).first;
		  std::string temp_name = comp_id->to_string();
		  if(temp_name == temp_comp_name){
		    temp_cfa_node = (*lit).second;
		  }

		}
		assert(temp_cfa_node != 0);

		const CFAEdge* temp_cfa_edge = 0;
		//! find the edge corresponding to the port
		for(CFANode::const_iterator eit = temp_cfa_node->out_begin();
		    eit != temp_cfa_node->out_end(); ++eit){

		  std::string temp_edge_name = (*eit)->label()->name()->name();
		  if(temp_edge_name == temp_port_name){
		    temp_cfa_edge = *eit;
		  }
		}
		assert(temp_cfa_edge != 0);

		edges.push_back(temp_cfa_edge);
	}
	assert(!edges.empty());
}

void ConcImpact::compute_interactions(ART::ARTNode& node,
		interactions_t& enabled_interactions,
		cfa_edges_t& initial_edges) const {

	// Get the labeling abstract state.
	const ConcAbstractState* state = &node.abstract_state();

	// Get the node location. delete it later
	const ConcLoc* location = &state->conc_location();

	//! this map tracks the set of enabled ports by each component
	sym_ports_t enabled_ports;

	////////////////////////////////////////////////////////////////////////////////////////////
	//////////////// step 1: compute the enabled ports, and internal transitions ///////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	for(ConcLoc::const_iterator lit = location->begin();
			lit != location->end(); ++lit){

	  //! the component name
	  const Symbol* comp_id = (*lit).first;
	  std::string comp_name = comp_id->to_string();

	  //! the control location
	  const CFANode* comp_loc = (*lit).second;

	  std::set<std::string> temp_ports;
	  //! for each out-going edge, collect the set of ports
	  for(CFANode::const_iterator nit = comp_loc->out_begin();
	      nit != comp_loc->out_end(); ++nit){

	    const CFAEdge* temp_edge = (*nit);
	    //! check if it is internal
	    if(temp_edge->is_internal()){
	      //! this is an internal transition
	      initial_edges.push_back(temp_edge);

	    } else{
	      //! this is a transition labelled with a port
	      assert(temp_edge->label() != 0);
	      std::string temp_name = temp_edge->label()->name()->name();
	      temp_ports.insert(temp_name);
	    }
	  }

	  enabled_ports[comp_name] = temp_ports;
	}

	//////////////////////////////////////////////////////////////////////////////////
	///////////////////////// compute enabled interactions ///////////////////////////
	//////////////////////////////////////////////////////////////////////////////////

	for(InteractionModel::const_iterator mit = bim_->const_interaction_begin();
			mit != bim_->const_interaction_end(); ++mit){

		//! for each interaction, check if it is enabled;
		const BIPInteraction* temp_ia =*mit;
		bool enabled = true;
		for(BIPInteraction::const_iterator bit = temp_ia->const_begin();
				bit != temp_ia->const_end() && enabled; ++bit){

			//! for each port, check if it is enabled
			const BIPPort* temp_port = *bit;
			std::string comp_name = temp_port->get_threadName();
			std::string port_name = temp_port->get_PortName();
			sym_ports_t::iterator temp_it = enabled_ports.find(comp_name);

			if(temp_it == enabled_ports.end()){
				enabled = false;
			} else {
				enabled =
					(*temp_it).second.find(port_name) == (*temp_it).second.end()? false:true ;
			}
	    }

	    if(enabled){
	      //! this interaction is enabled, and store them in an ordered way
	      enabled_interactions.push_back(temp_ia);
	    }
	}

	enabled_ports.clear();

}


ConcAbstractStateImpact* ConcImpact::transfer(const ConcAbstractStateImpact& state,
		std::vector<const CFAEdge*>& edges) const {

	// Prepare a new abstract state.
	ConcAbstractStateImpact *new_state = new ConcAbstractStateImpact();

	//! TODO: Update global state using ic3 style forward propagation

	////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////// update the thread states then /////////////////////////
	////////////////////////////////////////////////////////////////////////////////////
	//! find the components which participate the interaction
	for (ConcAbstractStateImpact::const_iterator it = state.thread_begin();
			it != state.thread_end(); ++it) {

		const Symbol *t_id = (*it).first;
		const AbstractState *t_state = ((*it).second);
		const AbstractStateImpact* t_state_i = dynamic_cast<const AbstractStateImpact*>(t_state);
		assert(t_state != 0);

		//! find the corresponding edge
		bool found = false;
		const CFAEdge* edge = 0;
		for(std::vector<const CFAEdge*>::const_iterator eit = edges.begin();
				eit != edges.end() && !found; ++eit){
			const CFAEdge* temp_edge = (*eit);
			const CFANode& from = temp_edge->from();
			const CFA& cfa = from.cfa();
			const Symbol& cfa_id = Symbol::symbol(cfa.name());
			if(&cfa_id == t_id){
				found = true;
				edge = temp_edge;
			}
		}

		if(edge != 0){
			/// DEBUG HERE
			Logger::log << Logger::level(5)
				<< "IMPACT: Perform transfer relation in component "
				<< t_id->to_string() << " on component state."
				<< Logger::end;

			// Create abstract data state.
			expression *sym_state = new true_constant();

			// Create a new abstract state.
			AbstractStateImpact *rt_new_state = new AbstractStateImpact(edge->to(), sym_state);

			// Add the new state of running thread into the successor state.
			new_state->add_thread_state(*t_id, rt_new_state);

		} else {

			//! then this component does not participate, copy the component state
			AbstractStateImpact *t_new_state = new AbstractStateImpact(*t_state_i);
			new_state->add_thread_state(*t_id, t_new_state);
		}

	}//! end for all component

	return new_state;
}


bool ConcImpact::force_covering(ART::ARTNode& node, ART& art) const {

	//! node to be covered
    ConcAbstractState& state = node.abstract_state();
    ConcAbstractStateImpact& cstate = dynamic_cast<ConcAbstractStateImpact&>(state);
    expression* global_region = cstate.global_state();

    const ConcLoc* loc = &state.conc_location();
    assert(loc != 0);

    Logger::log << Logger::level(2)
    	<< "IMPACT: Check force covering of ART node "
		<< node.node_id() << ". " << node.abstract_state().to_string() 
		<< Logger::end;


    //! Find a node with the same control location,
    //! Test whether its state interpolant holds in this node
    //!   find the common ancestor,
    //!   build the path from this ancestor to this node
    //!   check the relative inductiveness

    ART::const_nodes_iterator it = art.loc_begin(*loc);
    ART::const_nodes_iterator end_it = art.loc_end(*loc);
    
    bool covered = false;

    for(; it != end_it && 
	  ((*it)->node_id() < node.node_id()) && 
	  ((*it)->mark() == ART::ARTNode::MARKED_UNCOVERED) &&
	  !covered; ++it) {

      //! backtrack from the two nodes to root
      //! keep track of the node ids
      //! find the common node id

      ART::ARTNode* root = &(art.root());
      ART::ARTNode* walk = &node;
      
      std::set<int> node_ids;

      while(walk != root) {
    	  node_ids.insert(walk->node_id());
    	  walk = walk->parent();
      }

      const ART::ARTNode* walk2_c = (*it);
      ART::ARTNode* walk2 = const_cast<ART::ARTNode*>(walk2_c);
      
      bool flag = false;
      while(walk2 != &node && walk2 != root && !flag) {
	
    	  int walk2_id = walk2->node_id();
    	  std::set<int>::iterator idit = node_ids.find(walk2_id);

    	  if(idit != node_ids.end()) {
    		  //! find a common ancestor,
    		  //! walk2 is the common ancestor node
    		  flag = true;

    		  const ConcAbstractState& cstate_walk = walk2->abstract_state();
    		  ConcAbstractState& cstate_walk_ = const_cast<ConcAbstractState&>(cstate_walk);
    		  ConcAbstractStateImpact& cstate_impact_walk = dynamic_cast<ConcAbstractStateImpact&>(cstate_walk_);
    		  expression* global_region_walk = cstate_impact_walk.global_state();


    		  //! check if the state of (*it), which has the same control location with node,
    		  //! holds in state of node
    		  const ConcAbstractState& state2 = (*it)->abstract_state();
    		  ConcAbstractState& cstate2_ = const_cast<ConcAbstractState&>(state2);
    		  ConcAbstractStateImpact& cstate2 = dynamic_cast<ConcAbstractStateImpact&>(cstate2_);
    		  expression* global_region2 = cstate2.global_state();
	  
    		  //! build the path from walk2 to node
    		  std::vector<std::vector<const CFAEdge*>> edge_vec;

    		  walk = &node;
    		  while(walk != walk2) {
    			  //! get the label leading to walk
    			  const BIPInteraction *edge_label = walk->label();

    			  walk = walk->parent();

    			  std::vector<const CFAEdge*> edges;
    			  for(ART::ARTNode::const_edge_iterator cti = walk->transition_begin(*edge_label);
    					  cti != walk->transition_end(*edge_label); ++cti)
    				  edges.push_back(*cti);
	    
    			  edge_vec.insert(edge_vec.begin(), edges);
    		  }

    		  std::vector<expression*> path_expressions(edge_vec.size());

    		  //! add frame condition
    		  build_path_expr(global_region_walk, global_region2, edge_vec, path_expressions);

    		  size_t path_length = path_expressions.size();

    		  expression* path_expr = new true_constant();
    		  for(auto expr : path_expressions ) {
    			  path_expr = new binary_expression(binary_expression::AND, *path_expr, *expr);
    		  }

    		  //! build the implication
    		  expression* conj = new binary_expression(binary_expression::AND,
    				  *global_region_walk->clone(), *path_expr);
		   
    		  expression* timed_expr = new timed_expression(*global_region2->clone(), path_length);

//    		  std::cout << conj << std::endl;
//    		  std::cout << timed_expr << std::endl;

    		  if(sat(conj)) {
    			  //! the path is feasible
        		  //! check the validity
        		  covered = imply(conj, timed_expr);

        		  if(covered) {
        			  //! conjunct global_region2 to global_region
        			  global_region = new binary_expression(binary_expression::AND,
        					  *global_region->clone(), *global_region2->clone());

        			  expression* simp_state = simplify(global_region);
        			  cstate.set_global_state(simp_state);

        			  delete global_region;

        			  //! then record this covering information:
        			  //! node_c is covered by other_node_c
        			  ART::ARTNode* other_node_c = const_cast<ART::ARTNode*>(*it);
//        			  ART::ARTNode& node_c = const_cast<ART::ARTNode&>(node);

        			  other_node_c->add_covered_node(&node);
        			  node.set_covering_node(other_node_c);
        		  }

        		  delete conj;
        		  delete timed_expr;
    		  }
				
    	  } //! if

    	  walk2 = walk2->parent();
      }

    }
    return covered;
}

    
void ConcImpact::build_path_expr(expression* expr1, expression* expr2,
    		std::vector<std::vector<const CFAEdge*>>& edges,
    		std::vector<expression*>& path_expressions) const {

	int current = 0;

	Transition::domain_t vars_seen;
	std::vector<Transition*> back_transitions;

	std::vector<expression*> var_expr1;
	std::vector<expression*> var_expr2;

	vars_in_expression(expr1, var_expr1);
	vars_in_expression(expr2, var_expr2);

	for(auto e : var_expr1) {
		vars_seen.insert(e);
	}

	for(auto e : var_expr2) {
		vars_seen.insert(e);
	}

	for(std::vector<std::vector<const CFAEdge*>>::iterator it = edges.begin();
	      it != edges.end(); ++it) {

		std::vector<const CFAEdge*> temp_edges = (*it);

		Transition* temp_tran = cex_builder_.trans_builder().build_transition(temp_edges);
		expression* temp_tran_expr = temp_tran->get_expression();
		expression* temp_tran_guard = temp_tran->guard();

		expression* trans_expr =
				new binary_expression(binary_expression::AND, *(temp_tran_expr->clone()), *(temp_tran_guard->clone()));
	  
		for(Transition::domain_t::iterator vit = vars_seen.begin();
				vit != vars_seen.end(); ++vit){
	    
			expression* vexpr = *vit;
			variable* v_var = dynamic_cast<variable*>(vexpr);
			std::string v_var_name = v_var->get_name();
	    
			bool seen = false;
			for(Transition::const_domain_iterator dit = temp_tran->domain_begin();
					dit != temp_tran->domain_end() && !seen; ++dit){
	      
				expression* dexpr = *dit;
				variable* d_var = dynamic_cast<variable*>(dexpr);
				std::string d_var_name = d_var->get_name();
				if(d_var_name == v_var_name)
					seen = true;
			}
		
			if(!seen){
				expression* shifted_var = new timed_expression( *(vexpr->clone()), 1);
				expression* eq = new binary_expression(binary_expression::EQ, (*shifted_var), *(vexpr->clone()) );
	      
				expression* temp_trans_expr = trans_expr;
				trans_expr = new binary_expression(binary_expression::AND, *temp_trans_expr, *eq);
			}
		}
	  
		for(Transition::const_domain_iterator dit = temp_tran->domain_begin();
				dit != temp_tran->domain_end(); ++dit){
			expression* dexpr = *dit;
			variable* d_var = dynamic_cast<variable*>(dexpr);
			std::string d_var_name = d_var->get_name();
	    
			bool seen = false;
			for(Transition::domain_t::iterator vit = vars_seen.begin();
					vit != vars_seen.end(); ++vit){
	      
				expression* vexpr = *vit;
				variable* v_var = dynamic_cast<variable*>(vexpr);
				std::string v_var_name = v_var->get_name();
				if(d_var_name == v_var_name)
					seen = true;
			}

			if(!seen)
				vars_seen.insert(dexpr);
		}

		expression* timed_trans_expr = new timed_expression(*trans_expr, current);
		expression* simplified_expr = simplify(timed_trans_expr);
		path_expressions[current] = simplified_expr;
	  
		++current;
		back_transitions.push_back(temp_tran);
		delete timed_trans_expr;
	}

	for(auto e : var_expr1) {
		delete e;
	}

	for(auto e : var_expr2) {
		delete e;
	}

	vars_seen.clear();

	for(std::vector<Transition*>::iterator tit = back_transitions.begin();
	    tit != back_transitions.end(); ++tit)
	  delete (*tit);
}

bool ConcImpact::is_covered(const ART::ARTNode& node, const ART& art) const {

	const ConcAbstractState& state = node.abstract_state();
	ConcAbstractState& cstate_ = const_cast<ConcAbstractState&>(state);
	ConcAbstractStateImpact& cstate = dynamic_cast<ConcAbstractStateImpact&>(cstate_);
	expression* global_region = cstate.global_state();

	// Get location.
	const ConcLoc *loc = &state.conc_location();
	assert(loc != 0);

	bool is_covered = false;

	Logger::log << Logger::level(2)
		<< "IMPACT: Check coverage of ART node "
		<< node.node_id() << "." << node.abstract_state().to_string()
		<< Logger::end;

	//! Go through the nodes with the same control location
	ART::const_nodes_iterator it = art.loc_begin(*loc);
	ART::const_nodes_iterator end_it = art.loc_end(*loc);

	for (; it != end_it && !is_covered; ++it) {

		const ART::ARTNode *other_node = *it;

		if (other_node != &node  
		    && other_node->node_id() < node.node_id() 
		    && other_node->mark() == ART::ARTNode::MARKED_UNCOVERED) {

		  const ConcAbstractState &other_state = other_node->abstract_state();
		  ConcAbstractState& costate_ = const_cast<ConcAbstractState&>(other_state);
		  ConcAbstractStateImpact& costate = dynamic_cast<ConcAbstractStateImpact&>(costate_);
		  expression* other_global_region = costate.global_state();

		  //! return true, if the global region of current node implies that of the other one
		  //! intuitively, it means the current node region is "smaller" than the other one
		  is_covered = imply(global_region, other_global_region);

		  if(is_covered) {

		    Logger::log << Logger::level(3) 
				<< "IMPACT: - It's covered by ART node "
				<< other_node->node_id() << "." << other_node->abstract_state().to_string()
				<< Logger::end;

		    //! then record this covering information:
		    //! node_c is covered by other_node_c
		    ART::ARTNode* other_node_c = const_cast<ART::ARTNode*>(other_node);
		    ART::ARTNode& node_c = const_cast<ART::ARTNode&>(node);
		    other_node_c->add_covered_node(&node_c);
		    node_c.set_covering_node(other_node_c); 
		  }
		}
	}

	return is_covered;
  }


void ConcImpact::close_refined_nodes(ART& art, CEx& cex) const {

	ART::ARTNode& error_node = cex.end();
	ART::ARTNode& root = art.root();
	ART::ARTNode* walk = error_node.parent();

	std::vector<ART::ARTNode*> node_vec;

	// traversal the CEx path backwards to the root
	while (&root != walk) {
	  node_vec.insert(node_vec.begin(), walk);
	  walk = walk->parent();
	}

	bool flag = false;
	ART::ARTNode* del_node;

	for(std::vector<ART::ARTNode*>::iterator  it = node_vec.begin();
	    it != node_vec.end() && !flag; it++) {
	  
	  ART::ARTNode* node = *it;
	  const ConcAbstractState& state = node->abstract_state();
	  ConcAbstractState& cstate_ = const_cast<ConcAbstractState&>(state);
	  ConcAbstractStateImpact& cstate = dynamic_cast<ConcAbstractStateImpact&>(cstate_);
	  expression* global_region = cstate.global_state();

	  //std::cout << global_region << std::endl;
	  
	  if(is_false_constant(global_region)) {
	    flag = true;
	    del_node = node;
	  }
	}

	if(flag){

		/// DEBUG HERE
		Logger::log << Logger::level(2)
			    << "IMPACT: Remove ART nodes from node "
			    << del_node->node_id()
			    << Logger::end;

		delete del_node;
	}
}


ART::ARTNode* ConcImpact::choose_node(ART::work_list_t& work_list) const {

	ART::ARTNode *chosen_node = 0;
	bool flag = false;

	if (!work_list.empty()) {

		do{
			chosen_node = work_list.back();
			work_list.pop_back();

			const ConcAbstractState& state = chosen_node->abstract_state();
			ConcAbstractState& cstate_ = const_cast<ConcAbstractState&>(state);
			ConcAbstractStateImpact& cstate = dynamic_cast<ConcAbstractStateImpact&>(cstate_);
			expression* global_region = cstate.global_state();
			false_constant* is_false = dynamic_cast<false_constant*>(global_region);

			if(is_false != 0)
				flag = true;
			else
				flag = false;

		} while(flag);
	}

	return chosen_node;
}

}

