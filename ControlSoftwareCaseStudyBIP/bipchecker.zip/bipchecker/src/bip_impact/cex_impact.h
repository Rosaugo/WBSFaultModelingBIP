/*
 * cex_impact.h
 *
 *  Created on: Apr 5, 2017
 *      Author: wangqiang
 */

#ifndef CEX_IMPACT_H_
#define CEX_IMPACT_H_

#include "util/util.h"
#include "util/hash_map.h"
#include "z3++.h"

#include "bip_cegar/cex.h"
#include "bip_solver/expression.h"

namespace bipchecker{


class CExImpact: public CEx {

public:

	typedef std::vector<expression*> expression_sequence;

private:

	//! Path expressions.
	expression_sequence path_expressions_;

	//! Sequence of interpolants
	expression_sequence interps_;

public:

	//! Class constructor.
	/*!
	 * \param start the start of the counter-example path.
	 */
	explicit CExImpact(ART::ARTNode& start): CEx(start) { }


	typedef expression_sequence::const_iterator expr_iterator;

	//! Gets the start iterator of path expressions.
	/*!
	 * \return The start iterator of path expressions.
	 */
	expr_iterator path_expr_begin() const {
		return path_expressions_.begin();
	}

	//! Gets the end iterator of path expressions.
	/*!
	 * \return The end iterator of path expressions.
	 */
	expr_iterator path_expr_end() const {
		return path_expressions_.end();
	}

	//! Sets path expressions.
	/*!
	 * \param path_expressions a sequence of expressions.
	 */
	void set_path_expressions(const expression_sequence& path_expressions);

	//! Prints path expressions
	/*!
	 * \param out an output stream
	 */
	void print_path_expressions(std::ostream& out) const;

	//! Adds interpolants
	/*!
	 * \param expr an interpolant
	 */
	void add_interpolants(expression* expr) {
		interps_.push_back(expr);
	}


	//! Gets the start iterator of interpolants expressions.
	/*!
	 * \return The start iterator of interpolants expressions.
	 */
	expr_iterator interp_begin() const {
		return interps_.begin();
	}

	//! Gets the end iterator of interpolants expressions.
	/*!
	 * \return The end iterator of interpolants expressions.
	 */
	expr_iterator interp_end() const {
		return interps_.end();
	}

	//! Prints cex.
	/*!
	 * \param out an output stream.
	 */
	virtual void print_cex(std::ostream& out) const;

	//! Class destructor.
	virtual ~CExImpact();

private:

	DISALLOW_COPY_AND_ASSIGN(CExImpact);

};
// class CEx

std::ostream& operator<<(std::ostream&, const CExImpact&);

}




#endif /* CEX_IMPACT_H_ */
