/*
 * itp_refiner.cc
 *
 *  Created on: Apr 5, 2017
 *      Author: wangqiang
 */


#include "bip_impact/itp_refiner.h"
#include "bip_impact/conc_abstract_state_impact.h"
#include "bip_impact/cex_impact.h"
#include "util/logger.h"


namespace bipchecker {

bool ITPRefiner::refine(ART& art, CEx& cex,
		AbsDomain& domain, ART::work_list_t& work_list) {

	//! take the interpolants in the counterexample
	//! and add each of them into the corresponding ART node
	//! (excluding the first and the last nodes)
	//! the last node is labeled with constant 'false'

	//! Get the error node first
	ART::ARTNode& error_node = cex.end();
	const ConcAbstractState& state = error_node.abstract_state();
	ConcAbstractState& cstate_ = const_cast<ConcAbstractState&>(state);
	ConcAbstractStateImpact& cstate = dynamic_cast<ConcAbstractStateImpact&>(cstate_);
	cstate.set_global_state(new false_constant());

	// Get ART root.
	ART::ARTNode& root = art.root();

	// Set the walking node as the error node
	ART::ARTNode *walk = error_node.parent();

	CExImpact& cex_impact = dynamic_cast<CExImpact&>(cex);
	CExImpact::expr_iterator interp_it = cex_impact.interp_end();
	interp_it--;

	bool success = false;
	std::vector<ART::ARTNode*> rm_nodes;

	// traversal the CEx path backwards to the root
	while (&root != walk) {

		expression* interp = *interp_it;

		  {
			//! check if the current interpolant is implied:
			//! update the node state by adding it, if not

			const ConcAbstractState& walk_state = walk->abstract_state();
			ConcAbstractState& walk_cstate_ = const_cast<ConcAbstractState&>(walk_state);
			ConcAbstractStateImpact& walk_cstate = dynamic_cast<ConcAbstractStateImpact&>(walk_cstate_);
			expression* global_state = walk_cstate.global_state();

			bool implied = imply(global_state, interp);

			if(!implied) {
			  //! the current global state does not imply the discovered interpolant
			  //! then update the state of the node
			  expression* n_global_state = new binary_expression(binary_expression::AND,
	    				*global_state->clone(), *interp->clone());

			  expression* simp_state = simplify(n_global_state);
			  walk_cstate.set_global_state(simp_state);
			  delete n_global_state;

			  //! refinement is successful
			  success = true;


			  //! check if the current interpolant is false constant
			  //! if it is, then remove the subtree from the current node
			  if(is_false_constant(simp_state)) {
					rm_nodes.push_back(walk);
			  }

			  //! since the state of the node is strengthened,
			  //! we have to check if the current covering relation still holds.
			  //! if not, we should uncover the covered nodes and put them into the worklist
			  std::vector<ART::ARTNode*> node_its;
			  for(ART::ARTNode::covered_node_iterator cit = walk->covered_nodes_begin();
			      cit != walk->covered_nodes_end(); ++cit) {

			    ART::ARTNode* cnode = *cit;
			    assert(cnode->mark() == ART::ARTNode::MARKED_COVERED);

			    //! check if the covering still holds
			    const ConcAbstractState& cover_state = cnode->abstract_state();
			    ConcAbstractState& cover_state_ = const_cast<ConcAbstractState&>(cover_state);
			    ConcAbstractStateImpact& c_state = dynamic_cast<ConcAbstractStateImpact&>(cover_state_);
			    expression* cnode_state = c_state.global_state();
			    bool flag = imply(cnode_state, simp_state);

			    if(!flag){
			      //! covering relation does not hold
			      //! unmark the node and add it into the worklist
			      cnode->unmark();
			      cnode->set_covering_node(0);
			      work_list.push_back(cnode);
			      node_its.push_back(cnode);
			    }
			  }

			  //! remove some covering information from this node
			  for(std::vector<ART::ARTNode*>::iterator iit = node_its.begin();
			      iit != node_its.end(); ++iit) {
				  walk->remove_covered_node(*iit);
			  }

			}
		}

		// Advance walking node to parent.
		walk = walk->parent();

		if(interp_it != cex_impact.interp_begin())
		  interp_it--;
	}

	for(auto n: rm_nodes) {
		/// DEBUG HERE
		Logger::log << Logger::level(2)
			    << "IMPACT: Remove ART nodes from node "
			    << n->node_id()
			    << Logger::end;

		delete n;
	}

	return success;
}

}
