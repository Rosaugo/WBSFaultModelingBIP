// $Id: expression.h 48 2009-09-05 08:07:10Z tb $
/** \file expression.h Implements an example calculator class group. */

#ifndef PARSE_CONTEXT_H
#define PARSE_CONTEXT_H

#include <map>
#include <vector>
#include <ostream>
#include <stdexcept>
#include <cmath>

#include "bip_frontend/bip_ast/bip_ast.h"

namespace bipchecker {

/** parse context used to save the parsed expressions. This context is
 * passed along to the example::Driver class and fill during parsing via bison
 * actions. */
class ParseContext {

	//! Translation unit result.
	ASTTranslationUnit *translation_unit_;

public:

	//! Class constructor.
	explicit ParseContext() {
		translation_unit_ = new ASTTranslationUnit();
	}

	//! Initializes context.
	void init_context() {

		if (translation_unit_ != 0)
			delete translation_unit_;

		translation_unit_ = 0;
	}

	//! Sets the resulting translation unit.
	/*!
	 * \param translation_unit a translation unit.
	 */
	void set_translation_unit(ASTTranslationUnit *translation_unit) {
		if (translation_unit_ != 0)
			delete translation_unit_;

		translation_unit_ = translation_unit;
	}

	//! Gets the resulting translation unit.
	/*!
	 * \return The resulting translation unit.
	 */
	ASTTranslationUnit *translation_unit() {
		ASTTranslationUnit *tu = translation_unit_;
		translation_unit_ = 0;
		return tu;
	}

	//! Class destructor.
	~ParseContext() {
		init_context();
	}

};

}

#endif // EXPRESSION_H
