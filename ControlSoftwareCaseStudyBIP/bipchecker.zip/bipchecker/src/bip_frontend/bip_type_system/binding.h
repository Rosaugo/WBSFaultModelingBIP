/*
 * binding.h
 *
 *  Created on: Nov 11, 2014
 *      Author: wangqiang
 */

#ifndef BINDING_H_
#define BINDING_H_

#include "util/util.h"
#include <ostream>
#include <string>

namespace bipchecker{

class Scope;

//! Class for bindings.
class Binding
{

    //! Binding name.
    std::string name_;

    //! The scope where the binding belongs.
    Scope& scope_;

    // Binding's name should not change.

    // Binding's scope should not change: scope is responsible for
    // deallocating bindings contained in the scope. If binding's
    // scope can change, then the binding must be removed from the
    // previous scope and added to the new scope; overkill indeed.
    // That's the reason for having scope of type reference.

    // Removing binding from a scope also deallocating the binding.

public:

    //! Class constructor.
    /*!
     * \param name a name for the binding.
     * \param scope the scope where the binding should be placed.
     */
    explicit Binding(const std::string& name, Scope& scope)
	: name_(name), scope_(scope)
    {
    }

    //! Gets the binding name.
    /*!
     * \return The binding name.
     */
    const std::string& name() const { return name_; }

    //! Gets the scope where the binding belongs.
    /*!
     * \return The scope.
     */
    Scope& scope() const { return scope_; }

    //! Prints binding.
    /*!
     * \param out an output stream.
     */
    virtual void print_binding(std::ostream& out) const = 0;


    //! Class virtual destructor.
    virtual ~Binding()
    {
    }

private:

    DISALLOW_COPY_AND_ASSIGN(Binding);


}; // class Binding

//! Prints binding.
/*!
 * \param out an output stream.
 * \param binding a binding.
 * \return The output stream.
 */
std::ostream& operator<<(std::ostream& out, const Binding& binding);


}


#endif /* BINDING_H_ */
