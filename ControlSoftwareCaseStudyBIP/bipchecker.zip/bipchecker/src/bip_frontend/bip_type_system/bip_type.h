/*
 * bip_type.h
 *
 *  Created on: Nov 11, 2014
 *      Author: wangqiang
 */

#ifndef BIP_TYPE_H_
#define BIP_TYPE_H_


#include <iostream>

namespace bipchecker{


//! Class for types.
class Type
{

public:

    //! Class constructor.
    explicit Type() { }

    //! Class copy constructor.
    explicit Type(const Type&)  {  }

    //! Clones type.
    /*!
     * \return The cloned type.
     */
    virtual Type* clone() const = 0;

    //! Checks equality of types.
    /*!
     * \param type a type.
     * \return True if the types are equal.
     */
    virtual bool equals(const Type& type) const = 0;


    //! Prints type.
    /*!
     * \param out an output stream.
     */
    virtual void print_type(std::ostream& out) const = 0;

    //! Class virtual destructor.
    virtual ~Type()  {}


}; // class Type

//! Prints type.
/*!
 * \param out an output stream.
 * \param type a type.
 * \return The output stream.
 */
std::ostream& operator<<(std::ostream& out, const Type& type);


}


#endif /* BIP_TYPE_H_ */
