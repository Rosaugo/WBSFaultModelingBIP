/*
 * binding.cc
 *
 *  Created on: Nov 11, 2014
 *      Author: wangqiang
 */


#include "bip_frontend/bip_type_system/binding.h"

namespace bipchecker{


std::ostream& operator<<(std::ostream& out, const Binding& binding)
{
    binding.print_binding(out);
    return out;
}


}
