/*
 * bip_type_system.h
 *
 *  Created on: Nov 6, 2014
 *      Author: wangqiang
 */

#ifndef BIP_TYPE_SYSTEM_H_
#define BIP_TYPE_SYSTEM_H_

#include "bip_frontend/bip_ast/bip_ast.h"
#include "bip_frontend/bip_type_system/bip_type.h"
#include "bip_frontend/bip_type_system/binding.h"
#include "bip_frontend/bip_type_system/scope.h"

namespace bipchecker {

class DataType: public Type {

public:
	enum BasicType {
		UNSPECIFIED, FLOAT, INT, BOOL
	};

private:
	BasicType type_;

public:
	explicit DataType() :
			type_(UNSPECIFIED) {
	}
	explicit DataType(BasicType type) :
			type_(type) {
	}

	explicit DataType(const DataType& type) :
			Type(type) {
		type_ = type.type_;
	}

	DataType* clone() const {
		return new DataType(*this);
	}

	void print_type(std::ostream& out) const {
		if (type_ == INT) {
			out << "int";
		} else if (type_ == BOOL) {
			out << "bool";
		} else if (type_ == FLOAT) {
			out << "float";
		} else {
			out << "unspecified type";
		}
	}

	bool equals(const Type& type) const {
		const DataType* data_type = dynamic_cast<const DataType*>(&type);
		if (data_type != 0) {
			bool eq = (type_ == data_type->type_ ? true : false);
			if (!eq)
				return false;
			return true;
		}
		return false;
	}

	BasicType type() const {
		return type_;
	}

	void set_type(const BasicType& type) {
		type_ = type;
	}

	~DataType() {
	}
};

/**
 * class for data variables
 *
 */
class DataVariable: public Binding {

	Type* type_;
	bool global_variable;

public:

	explicit DataVariable(const std::string& name, Type *type, Scope& scope)
	: Binding(name, scope),
	  type_(type),
	  global_variable(false) {
	}

	Type* type() const {
		return type_;
	}

	bool is_global() const {
		return global_variable;
	}

	void set_global(bool global){
		global_variable = global;
	}

	//??? do we really need this equality check function?
	bool equals(const Binding& var) const {
		const DataVariable* variable = dynamic_cast<const DataVariable*>(&var);
		if (variable != 0) {
			bool eq_name = (name() == variable->name());
			if (!eq_name)
				return false;

			bool eq_scope = (&scope() == &(variable->scope()));
			if (!eq_scope)
				return false;

			bool eq_type =
					(type_ != 0) ?
							(type_->equals(*variable->type_)) :
							(variable->type_ == 0);
			if (!eq_type)
				return false;

			return true;
		}
		return false;
	}

	void print_binding(std::ostream& out) const {
		if(global_variable)
			out << "global ";
		else
			out << "local ";
		out << "variable " << this->name() << " : " << *type_;
	}

	~DataVariable() {
		if (type_)
			delete type_;
	}

};

/**
 * class for Port Type
 * A port may refer to a list of variables, which are exported
 * The port name should be unique.
 */
class PortType: public Type {

	std::string name_; // type name

	std::vector<DataVariable*> parameters_;

	typedef std::vector<DataVariable*>::iterator iterator;

public:

	typedef std::vector<DataVariable*>::const_iterator const_iterator;

	explicit PortType(std::string name) :
			name_(name) {
	}

	explicit PortType(const PortType& type) :
			Type(type) {
		name_ = type.name_;

		for (const_iterator cit = type.begin(); cit != type.end(); ++cit) {
			if (*cit) {
				add_parameter(
						new DataVariable((*cit)->name(),
								(*cit)->type()->clone(), (*cit)->scope()));
			}
		}
	}

	void add_parameter(DataVariable* var) {
		if (var != 0) {
			parameters_.push_back(var);
		}
	}

	const_iterator begin() const {
		return parameters_.begin();
	}

	const_iterator end() const {
		return parameters_.end();
	}

	iterator begin() {
		return parameters_.begin();
	}

	iterator end() {
		return parameters_.end();
	}

	std::string name() const {
		return name_;
	}

	unsigned int arity() const {
		return parameters_.size();
	}

	void print_type(std::ostream& out) const {
		out << "port type " << name_;
	}

	bool equals(const Type& type) const {

		const PortType* port_type = dynamic_cast<const PortType*>(&type);

		if (port_type != 0) {
			bool eq_name = (name_ == port_type->name_ ? true : false);
			if (!eq_name)
				return false;

			unsigned int this_size = arity();
			if (this_size == port_type->arity()) {
				for (unsigned int i = 0; i < this_size; ++i) {
					DataVariable *e = parameters_[i];
					DataVariable *oe = port_type->parameters_[i];

					bool eq = (e != 0 ? e->equals(*oe) : (oe == 0));

					if (!eq)
						return false;
				}

				return true;
			}
		}

		return false;
	}

	PortType* clone() const {
		return new PortType(*this);
	}

	~PortType() {
		for (iterator cit = parameters_.begin(); cit != parameters_.end();
				++cit) {
			if (*cit) {
				delete *cit;
			}
		}
		parameters_.clear();
	}
};

/**
 * class for port instance (literal)
 */
class Port: public Binding {

	Type* type_;
	std::vector<DataVariable*> parameters_;

	typedef std::vector<DataVariable*>::iterator iterator;

public:
	typedef std::vector<DataVariable*>::const_iterator const_iterator;

	explicit Port(const std::string& name, Type * type, Scope& scope) :
			Binding(name, scope), type_(type) {
	}

	void add_parameter(DataVariable* var) {
		if (var)
			parameters_.push_back(var);
	}

	Type* type() const {
		return type_;
	}

	void set_type(Type* type){
		if(type_)
			delete type_;
		type_ = 0;
		if(type != 0)
			type_ = type;
	}

	unsigned int arity() const {
		return parameters_.size();
	}

	iterator begin() {
		return parameters_.begin();
	}

	iterator end() {
		return parameters_.end();
	}

	const_iterator begin() const {
		return parameters_.begin();
	}

	const_iterator end() const {
		return parameters_.end();
	}

	bool equals(const Binding& port) const {
		const Port* pt = dynamic_cast<const Port*>(&port);
		if (pt != 0) {

			bool eq_name = (name() == pt->name());
			if (!eq_name)
				return false;

			bool eq_scope = (&scope() == &(pt->scope()));
			if (!eq_scope)
				return false;

			bool eq_type =
					(type_ != 0) ?
							(type_->equals(*pt->type_)) : (pt->type_ == 0);
			if (!eq_type)
				return false;

			unsigned int this_size = arity();
			if (this_size == pt->arity()) {
				for (unsigned int i = 0; i < this_size; ++i) {
					DataVariable *e = parameters_[i];
					DataVariable *oe = pt->parameters_[i];

					bool eq = (e != 0 ? e->equals(*oe) : (oe == 0));

					if (!eq)
						return false;
				}

				return true;
			}

		}
		return false;
	}

	void print_binding(std::ostream& out) const {
		out << "port " << name() << " : " << *type_;
	}

	~Port() {
		if (type_)
			delete type_;

		for (iterator cit = parameters_.begin(); cit != parameters_.end();
				++cit) {
			if (*cit) {
				delete *cit;
			}
		}
		parameters_.clear();
	}

};

/*
 * class for connector type
 * TODO : how to represent the data transfer??
 *
 */
class ConnectorType: public Type {

	std::string name_;

	//!  a connector can only connect ports of the same type
	std::vector<Port*> paras_;

	typedef std::vector<Port*>::iterator iterator;

public:
	typedef std::vector<Port*>::const_iterator const_iterator;

	explicit ConnectorType(std::string name) :
			name_(name) {
	}

	explicit ConnectorType(const ConnectorType& type) :
			Type(type) {
		name_ = type.name_;

		for (const_iterator cit = type.begin(); cit != type.end(); ++cit) {
			if (*cit)
				add_parameter(
						new Port((*cit)->name(), (*cit)->type()->clone(),
								(*cit)->scope()));
		}
	}

	void add_parameter(Port* pt) {

		if (pt != 0)
			paras_.push_back(pt);
	}

	unsigned int arity() const {
		return paras_.size();
	}

	iterator begin() {
		return paras_.begin();
	}

	iterator end() {
		return paras_.end();
	}

	const_iterator begin() const {
		return paras_.begin();
	}

	const_iterator end() const {
		return paras_.end();
	}

	std::string name() const {
		return name_;
	}

	void print_type(std::ostream& out) const {
		out << "connector type" << name_;
	}

	bool equals(const Type& type) const {
		const ConnectorType* cnt_type =
				dynamic_cast<const ConnectorType*>(&type);
		if (cnt_type != 0) {
			bool eq_name = (name_ == cnt_type->name_ ? true : false);
			if (!eq_name)
				return false;

			unsigned int this_size = arity();
			if (this_size == cnt_type->arity()) {
				for (unsigned int i = 0; i < this_size; ++i) {
					Port *e = paras_[i];
					Port *oe = cnt_type->paras_[i];

					bool eq = (e != 0 ? e->equals(*oe) : (oe == 0));

					if (!eq)
						return false;
				}
				return true;
			}
		}
		return false;
	}

	ConnectorType* clone() const {
		return new ConnectorType(*this);
	}

	~ConnectorType() {
		for (iterator cit = paras_.begin(); cit != paras_.end(); ++cit) {
			if (*cit) {
				delete *cit;
			}
		}
		paras_.clear();
	}
};

class ComponentType: public Type {

public:
	enum CType {
		UNSPECIFIED, ATOM, COMPOUND
	};
private:
	std::string name_;
	CType type_;

	std::vector<DataVariable*> paras_;
	typedef std::vector<DataVariable*>::iterator iterator;

public:

	typedef std::vector<DataVariable*>::const_iterator const_iterator;

	explicit ComponentType(std::string name) :
			name_(name), type_(UNSPECIFIED) {
	}

	explicit ComponentType(std::string name, CType type) :
			name_(name), type_(type) {
	}

	explicit ComponentType(const ComponentType& type) :
			Type(type) {
		type_ = type.type_;
		name_ = type.name_;
		for (const_iterator it = type.begin(); it != type.end(); ++it) {
			if (*it)
				add_parameter(
						new DataVariable((*it)->name(), (*it)->type()->clone(),
								(*it)->scope()));
		}
	}

	std::string name() const {
		return name_;
	}

	CType type() const {
		return type_;
	}

	void add_parameter(DataVariable* var) {
		if (var != 0)
			paras_.push_back(var);
	}

	unsigned int arity() const {
		return paras_.size();
	}

	const_iterator begin() const {
		return paras_.begin();
	}

	const_iterator end() const {
		return paras_.end();
	}

	iterator begin() {
		return paras_.begin();
	}

	iterator end() {
		return paras_.end();
	}

	void print_type(std::ostream& out) const {
		out << "atomic type " << name_;
	}

	bool equals(const Type& type) const {
		const ComponentType* comp_type =
				dynamic_cast<const ComponentType*>(&type);

		if (comp_type != 0) {
			bool eq_n = (name_ == comp_type->name_ ? true : false);
			if (!eq_n)
				return false;
			bool eq_t = (type_ == comp_type->type_ ? true : false);
			if (!eq_t)
				return false;

			unsigned int this_size = arity();
			if (this_size == comp_type->arity()) {
				for (unsigned int i = 0; i < this_size; ++i) {
					DataVariable *e = paras_[i];
					DataVariable *oe = comp_type->paras_[i];

					bool eq = (e != 0 ? e->equals(*oe) : (oe == 0));

					if (!eq)
						return false;
				}

				return true;
			}
		}
		return false;
	}

	ComponentType* clone() const {
		return new ComponentType(*this);
	}

	~ComponentType() {
		for (iterator cit = paras_.begin(); cit != paras_.end(); ++cit) {
			if (*cit) {
				delete *cit;
			}
		}
		paras_.clear();
	}
};

class Component;

/**
 * we do not need connector scope
 *
 */
/*
 class ConnectorScope: public Scope{

 Connector& cnt_;

 public:
 explicit ConnectorScope(Connector& connector);

 Connector& connector() {return cnt_;}

 const Connector& connector() const {return cnt_;}

 ~ConnectorScope() {}

 };*/

class ComponentScope: public Scope {

	Component & comp_;

public:
	explicit ComponentScope(Component& comp);

	Component& component() {
		return comp_;
	}

	const Component& component() const {
		return comp_;
	}

	~ComponentScope() {
	}
};

/**
 * class for connector instances
 */
class Connector: public Binding {

	Type* type_;

	std::vector<Port*> paras_;

	typedef std::vector<Port*>::iterator iterator;

	// ConnectorScope scope_;

public:
	typedef std::vector<Port*>::const_iterator const_iterator;

	explicit Connector(const std::string& name, Type* type, Scope& scope) :
			Binding(name, scope), type_(type) //, scope_(*this)
	{
	}

	void add_parameter(Port* pt) {
		if (pt != 0)
			paras_.push_back(pt);
	}

	const_iterator begin() const {
		return paras_.begin();
	}

	const_iterator end() const {
		return paras_.end();
	}

	// ConnectorScope& connector_scope() {return scope_;}

	// const ConnectorScope& connector_scope() const {return scope_;}

	void print_binding(std::ostream& out) const {
		out << "connector " << name() << " : " << *type_;
	}

	~Connector() {
		if (type_)
			delete type_;

		for (iterator it = paras_.begin(); it != paras_.end(); ++it) {
			if (*it) {
				delete *it;
			}
		}
		paras_.clear();
	}

};

/**
 * class for component instances
 */
class Component: public Binding {

	Type* type_;
	std::vector<ASTLiteralExpression*> paras_;
	typedef std::vector<ASTLiteralExpression*>::iterator iterator;

	ComponentScope scope_;

public:
	typedef std::vector<ASTLiteralExpression*>::const_iterator const_iterator;

	explicit Component(const std::string& name, Scope& scope) :
			Binding(name, scope), type_(0), scope_(*this) {
	}

	explicit Component(const std::string& name, Type* type, Scope& scope) :
			Binding(name, scope), type_(type), scope_(*this) {
	}

	Type* type() {return type_;}

	const Type* type() const {return type_;}

	ComponentScope& component_scope() {
		return scope_;
	}

	const ComponentScope& component_scope() const {
		return scope_;
	}

	const_iterator begin() const {
		return paras_.begin();
	}

	const_iterator end() const {
		return paras_.end();
	}

	iterator begin() {
		return paras_.begin();
	}

	iterator end() {
		return paras_.end();
	}

	void add_parameter(ASTLiteralExpression* literal) {
		if (literal)
			paras_.push_back(literal);
	}

	unsigned int arity() const {
		return paras_.size();
	}

	void set_type(const Type* t) {
		if (type_)
			delete type_;
		type_ = 0;
		if (t)
			type_ = t->clone();
	}

	void print_binding(std::ostream& out) const {
		//! TODO: complete the printing.
		out << "component " << name() << " : " << *type_;

		out << std::endl;

	    out << "-- BEGIN component scope --" << std::endl;
	    out << scope_;
	    out << "-- END component scope --" << std::endl;

	}

	~Component() {
		if (type_)
			delete type_;

		for (iterator it = paras_.begin(); it != paras_.end(); ++it) {
			if (*it)
				delete (*it);
		}
		paras_.clear();
	}

};

}

#endif /* BIP_TYPE_SYSTEM_H_ */
