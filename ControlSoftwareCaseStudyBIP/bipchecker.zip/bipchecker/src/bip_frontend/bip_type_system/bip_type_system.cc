/*
 * bip_type_system.cc
 *
 *  Created on: Nov 17, 2014
 *      Author: wangqiang
 */



#include "bip_frontend/bip_type_system/bip_type_system.h"

namespace bipchecker{

//ConnectorScope::ConnectorScope(Connector& connector): Scope(connector.connector_scope()),cnt_(connector){}

ComponentScope::ComponentScope(Component& comp)	:Scope(comp.component_scope()), comp_(comp) {}

}
