/*
 * scope.cc
 *
 *  Created on: Nov 11, 2014
 *      Author: wangqiang
 */


#include "bip_frontend/bip_type_system/scope.h"

namespace bipchecker{

std::ostream& operator<<(std::ostream& out, const Scope& scope)
{
    scope.print_scope(out);
    return out;
}

}
