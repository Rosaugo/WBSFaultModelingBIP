/*
 * bip_type.cc
 *
 *  Created on: Nov 11, 2014
 *      Author: wangqiang
 */


#include "bip_frontend/bip_type_system/bip_type.h"
#include <iostream>

namespace bipchecker{


std::ostream& operator<<(std::ostream& out, const Type& type)
{
    type.print_type(out);
    return out;
}


}

