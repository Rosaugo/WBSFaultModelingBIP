/*
 * binding_list.cc
 *
 *  Created on: Nov 11, 2014
 *      Author: wangqiang
 */

#include "bip_frontend/bip_type_system/binding_list.h"

namespace bipchecker{

std::ostream& operator<<(std::ostream& out, const BindingList& list)
{
    list.print_binding_list(out);
    return out;
}

}


