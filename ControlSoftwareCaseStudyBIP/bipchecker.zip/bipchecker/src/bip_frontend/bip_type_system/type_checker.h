/*
 * type_checker.h
 *
 *  Created on: Nov 6, 2014
 *      Author: wangqiang
 */

#ifndef TYPE_CHECKER_H_
#define TYPE_CHECKER_H_

#include <iostream>
#include "bip_frontend/bip_ast/ast_visitor.h"
#include "bip_frontend/bip_type_system/bip_type_system.h"
#include "bip_frontend/bip_type_system/scope.h"

namespace bipchecker{

class TypeChecker: public ASTVisitor{

	Scope* scope_;

	// Keep track the number of found type errors.
	unsigned int num_type_errors_;

	std::ostream& err_;

public:
	explicit TypeChecker(std::ostream& err = std::cerr)
	: ASTVisitor(true), scope_(0), num_type_errors_(0), err_(err)
	{
		temp_connector_type_ = 0;
		temp_atom_def_ = 0;
		in_connector_def_ = false;
		in_component_ = false;
		current_component_scope_ = 0;
	}

    // visit functions
     int visit(const ASTExpression*);
     int visit(const ASTName*) {return ASTVisitor::CONTINUE;}
     int visit(const ASTStatement*);
     int visit(const ASTTransition*);
     int visit(const ASTDeclaration*);
     int visit(const ASTDefinition*);
     int visit(const ASTTranslationUnit*);

    // leave functions
     int leave(const ASTExpression*) {return ASTVisitor::CONTINUE;}
     int leave(const ASTName*) {return ASTVisitor::CONTINUE;}
     int leave(const ASTStatement*) {return ASTVisitor::CONTINUE;}
     int leave(const ASTTransition*){return ASTVisitor::CONTINUE;}
     int leave(const ASTDeclaration*) {return ASTVisitor::CONTINUE;}
     int leave(const ASTDefinition*) {return ASTVisitor::CONTINUE;}
     int leave(const ASTTranslationUnit*) ;

     Scope* symbol_table() {

    		Scope *temp = scope_;

    		scope_ = 0;

    		return temp;
     }

     unsigned int number_of_errors() const {return num_type_errors_;}

     ~TypeChecker();

private:

     //! temporal containers used for type checking

     //! port type is a map from its type name to its arity
     //! we assume the type of its argument can only be integer, this is not checked
     std::vector<PortType*> port_types_;

     ConnectorType* temp_connector_type_;

     std::vector<ConnectorType*> connector_types_;

     bool in_connector_def_;

     std::vector<ComponentType*> component_types_;

     //! the following pointers are not owned by this typechecker
     std::vector<Component*> comps_;

     const ASTAtomDefinition* temp_atom_def_;

     std::vector<std::string> temp_port_names_;

     std::vector<std::string> temp_connector_names_;

     std::vector<std::string> temp_control_locations_;

     const Scope* current_component_scope_;

     bool in_component_;

     Scope* create_symbol_table();

     void error(const ASTNode&, const std::string&, bool end = false);

};

}



#endif /* TYPE_CHECKER_H_ */
