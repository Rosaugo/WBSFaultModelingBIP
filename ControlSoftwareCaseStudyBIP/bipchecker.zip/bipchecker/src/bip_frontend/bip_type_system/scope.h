/*
 * scope.h
 *
 *  Created on: Nov 11, 2014
 *      Author: wangqiang
 */

#ifndef SCOPE_H_
#define SCOPE_H_

#include <ostream>
#include <string>
#include <vector>
#include <assert.h>
#include "bip_frontend/bip_type_system/binding.h"
#include "util/hash_map.h"
#include "util/util.h"

namespace bipchecker {

//! Class for scope.
class Scope {

	//! Parent scope.
	Scope *parent_;

	//typedef hash_map<std::string,
	//BindingList*,
	//hash_fun<std::string>,
	//EqStr > symbol_table_t;

	typedef hash_map<std::string,
			Binding*,
			hash_fun<std::string>,
			EqStr> symbol_table_t;

	//! Internal symbol table.
	symbol_table_t symbol_table_;

	typedef std::vector<std::string> symbol_stack_t;

	//! Auxiliary symbol stack.
	symbol_stack_t symbol_stack_;

	//! Scope mark.
	std::string scope_mark;

public:

	//! Class constructor.
	explicit Scope()
	: parent_(0), scope_mark("$$")
	{
	}

	//! Class constructor.
	/*!
	 * \param parent the parent scope.
	 */
	explicit Scope(Scope& parent)
	: parent_(&parent), scope_mark("$$")
	{
	}

	//! Gets the parent scope.
	/*!
	 * \return The parent scope.
	 */
	const Scope* parent() const {return parent_;}

	//! Gets the parent scope.
	/*!
	 * \return The parent scope.
	 */
	Scope* parent() {return parent_;}

	// TODO(IN): This iterator should be replaced by a proper one,
	//           that is, the one that contains pairs
	//           of (string,const BindingList*).

	typedef symbol_table_t::const_iterator const_iterator;

	//! Gets the start iterator to the internal symbol table.
	/*!
	 * \return The start iterator to the internal symbol table.
	 */
	const_iterator begin() const {return symbol_table_.begin();}

	//! Gets the end iterator to the internal symbol table.
	/*!
	 * \return The end iterator to the internal symbol table.
	 */
	const_iterator end() const {return symbol_table_.end();}

	//! Finds locally an entry in the internal symbol table.
	/*!
	 * This function does not recurse to the parent scope.
	 * \param name a name of the entry.
	 * \return The binding list corresponding to the name; otherwise 0.
	 *
	const BindingList* find(const std::string& name) const
	{
		const_iterator it = symbol_table_.find(name);

		return (it == end()) ? 0 : (*it).second;
	}*/

	const Binding* find(const std::string& name) const{
		const_iterator it = symbol_table_.find(name);

		return (it == end()) ? 0 : (*it).second;
	}

	//! Finds locally an entry in the internal symbol table.
	/*!
	 * This function does recurse to the parent scope.
	 * \param name a name of the entry.
	 * \return The binding list corresponding to the name; otherwise 0.
	 *
	const BindingList* find_global(const std::string& name) const
	{

		const Scope *current_scope = 0; // a pointer to a constant Scope, the Scope value can not be changed. "Scope *const " means const pointer
		const Scope *parent_scope = this;
		const BindingList *binding_list = 0;

		do {

			current_scope = parent_scope;
			parent_scope = this->parent();

			binding_list = current_scope->find(name);

		}while (binding_list == 0 && parent_scope != 0);

		return binding_list;

	}*/

	//! Adds binding.
	/*!
	 * \param binding a binding.
	 */
	void add_binding(Binding *binding)
	{
		const std::string& name = binding->name();

		if (!name.empty()) {

			const_iterator it = symbol_table_.find(name);

			if (it == end()) {

				//BindingList *binding_list = new BindingList();
				//binding_list->add_binding(binding);

				//symbol_table_[name] = binding_list;
				symbol_table_[name] = binding;

			} else {

				assert(false);
				//BindingList *binding_list = symbol_table_[name];
				//binding_list->add_binding(binding);

			}

			symbol_stack_.push_back(name);
		}

	}

	//! Marks the beginning of a scope.
	/*!
	 * TODO(IN): This function seems to be no longer used.
	 */
	void begin_scope()
	{
		symbol_stack_.push_back(Scope::scope_mark);
	}

	//! Marks the end of a scope.
	/*!
	 * TODO(IN): This functioni seems to be no longer used.
	 *
	 * This function pop all symbols from the auxiliary stack symbols
	 * until the most recent mark of the beginning of scope.
	 */
	void end_scope()
	{
		std::string s = symbol_stack_.back();
		symbol_stack_.pop_back();

		while (s != Scope::scope_mark) {

			remove_binding(s);

			s = symbol_stack_.back();
			symbol_stack_.pop_back();

		}

	}

	//! Gets the size of the internal symbol table.
	/*!
	 * \return The size of the internal symbol table.
	 */
	size_t size() {return symbol_table_.size();}

	//! Checks if the internal symbol table is empty.
	/*!
	 * \return True iff the internal symbol table is empty.
	 */
	bool empty() {return symbol_table_.empty();}

	//! Prints scope.
	/*!
	 * \param out an output stream.
	 */
	void print_scope(std::ostream& out) const
	{
		out << "BEGIN SCOPE" << std::endl;
		out << "===========" << std::endl;

		for (const_iterator it = begin(); it != end(); ++it) {
			if ((*it).second) {
				out << (*it).first << " --> " << std::endl;
				out << "--------------" << std::endl;
				out << *((*it).second) << std::endl;
			}
		}
		out << "END SCOPE" << std::endl;
		out << "=========" << std::endl;
	}

	//! Class virtual destructor.
	virtual ~Scope()
	{
		parent_ = 0;

		for (symbol_table_t::iterator it = symbol_table_.begin();
				it != symbol_table_.end();
				++it) {

			if ((*it).second)
			delete (*it).second;
		}

		symbol_table_.clear();

	}

private:

	//! Removes binding associated with a name.
	/*!
	 * \param name the name of the binding to be removed.
	 */
	void remove_binding(const std::string& name)
	{
		const_iterator it = symbol_table_.find(name);

		if (it != end()) {

			//BindingList *binding_list = symbol_table_[name];
			Binding* binding_ = symbol_table_[name];

			//binding_list->remove_binding();
			if(binding_ != 0)
				delete binding_;

			//if (binding_list->empty()) {

			//	delete binding_list;
			//	symbol_table_.erase(name);

			//}
			symbol_table_.erase(name);
		}

	}

	DISALLOW_COPY_AND_ASSIGN(Scope);

}; // class Scope

//! Prints scope.
/*!
 * \param out an output stream.
 * \param scope a scope.
 * \return The output stream.
 */
std::ostream& operator<<(std::ostream& out, const Scope& scope);

}

#endif /* SCOPE_H_ */
