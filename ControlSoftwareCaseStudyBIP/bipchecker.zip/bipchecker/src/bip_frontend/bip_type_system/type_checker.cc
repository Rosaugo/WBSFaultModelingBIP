/*
 * type_checker.cc
 *
 *  Created on: Nov 6, 2014
 *      Author: wangqiang
 */

#include "bip_frontend/bip_type_system/type_checker.h"
#include <assert.h>

namespace bipchecker {

int TypeChecker::visit(const ASTExpression* expression) {

	const ASTIdExpression* id_expr =
			dynamic_cast<const ASTIdExpression*>(expression);
	const ASTUnaryExpression* unary_expr =
			dynamic_cast<const ASTUnaryExpression*>(expression);
	const ASTBinaryExpression* binary_expr =
			dynamic_cast<const ASTBinaryExpression*>(expression);
	const ASTLiteralExpression* literal_expr =
			dynamic_cast<const ASTLiteralExpression*>(expression);
	const ASTQualifiedIdExpression* qualify_id =
			dynamic_cast<const ASTQualifiedIdExpression*>(expression);
	const ASTExpressionList* expr_list =
			dynamic_cast<const ASTExpressionList*>(expression);

	if (id_expr != 0) {
		if (in_connector_def_)
			error(*id_expr, "illegal expression in the down action.");

		if (in_component_) {
			//! check if this expression (variable) is declared
			std::string var_name = id_expr->name()->name();
			if (current_component_scope_->find(var_name) == 0) {
				error(*id_expr, "undeclared variable.");
			}
		}

	} else if (qualify_id != 0) {
		if (in_component_)
			error(*qualify_id, "illegal expression in the transition.");

		//! get the qualifier, the name of the port
		std::string port_name = qualify_id->qualifier()->name();

		//! get the variable name
		std::string var_name = qualify_id->name()->name();

		//! find the corresponding port declaration
		assert(temp_connector_type_ != 0);
		bool found_port = false;
		PortType* pt_type = 0;
		for (ConnectorType::const_iterator cit = temp_connector_type_->begin();
				cit != temp_connector_type_->end() && !found_port; ++cit) {
			if (*cit) {
				const Port* pt_ = *cit;
				std::string temp_pt_name = pt_->name();
				if (temp_pt_name == port_name) {
					found_port = true;
					assert(pt_->type() != 0);
					pt_type = dynamic_cast<PortType*>(pt_->type());
				}
			}
		}

		if (!found_port) {
			error(*qualify_id, "undeclared port.");
		} else {
			assert(pt_type != 0);
			bool found_var = false;
			for (PortType::const_iterator cit = pt_type->begin();
					cit != pt_type->end() && !found_var; ++cit) {
				if (*cit) {
					std::string temp_var_name = (*cit)->name();
					if (temp_var_name == var_name) {
						found_var = true;
					}
				}
			}
			if (!found_var)
				error(*qualify_id,
						"undeclared variable (port type error or variable undefined).");
		}

	} else if (unary_expr != 0) {
		const ASTExpression* oprd = unary_expr->operand();
		if (oprd != 0) {
			oprd->accept(*this);
		}
	} else if (binary_expr != 0) {
		const ASTExpression* op1 = binary_expr->operand1();
		const ASTExpression* op2 = binary_expr->operand2();
		if (op1 != 0)
			op1->accept(*this);
		if (op2 != 0)
			op2->accept(*this);
	} else if (expr_list != 0) {

		for (ASTExpressionList::const_iterator cit = expr_list->begin();
				cit != expr_list->end(); ++cit) {
			if (*cit) {
				(*cit)->accept(*this);
			}
		}

	} else if (literal_expr != 0) {
		//! do nothing
	}

	return ASTVisitor::SKIP;
}

int TypeChecker::visit(const ASTStatement* statement) {

	const ASTExpressionStatement* expr_stat =
			dynamic_cast<const ASTExpressionStatement*>(statement);
	const ASTIfStatement* if_stat =
			dynamic_cast<const ASTIfStatement*>(statement);
	const ASTCompoundStatement* comp =
			dynamic_cast<const ASTCompoundStatement*>(statement);

	if (expr_stat != 0) {

		assert(expr_stat->expression() != 0);
		expr_stat->expression()->accept(*this);

	} else if (if_stat != 0) {

		assert(if_stat->condition() != 0);
		if_stat->condition()->accept(*this);

		assert(if_stat->then_clause() != 0);
		if_stat->then_clause()->accept(*this);

		if (if_stat->else_clause() != 0) {
			if_stat->else_clause()->accept(*this);
		}

	} else if (comp != 0) {

		for (ASTCompoundStatement::const_iterator cit = comp->begin();
				cit != comp->end(); ++cit) {
			if (*cit) {
				(*cit)->accept(*this);
			}
		}
	}

	return ASTVisitor::SKIP;
}

int TypeChecker::visit(const ASTTransition* transition) {

	const ASTInitialTransition* init =
			dynamic_cast<const ASTInitialTransition*>(transition);
	const ASTSingleTransition* single =
			dynamic_cast<const ASTSingleTransition*>(transition);
	const ASTTransitionList* tran_list =
			dynamic_cast<const ASTTransitionList*>(transition);
	const ASTInteraction* interaction =
			dynamic_cast<const ASTInteraction*>(transition);

	if (init != 0) {

		assert(temp_control_locations_.size() != 0);
		std::string init_loc = init->location()->name()->name();
		//! check if this location is declared
		bool found_loc = false;

		for (std::vector<std::string>::iterator sit =
				temp_control_locations_.begin();
				sit != temp_control_locations_.end() && !found_loc; ++sit) {
			if (*sit == init_loc) {
				found_loc = true;
			}
		}

		if (!found_loc) {
			error(*init, "undefined initial control location.");
		}

		if (init->action() != 0) {

			assert(temp_atom_def_ != 0);
			std::string atom_type_name = temp_atom_def_->name()->name()->name();
			//! check the component scope
			const Scope* component_scope = 0;
			bool found_scope = false;
			for (Scope::const_iterator cit = scope_->begin();
					cit != scope_->end() && !found_scope; ++cit) {
				if ((*cit).second) {
					//! for each component binding, find the ones with this name
					const Component* component =
							dynamic_cast<const Component*>((*cit).second);
					const ComponentType* comp_type =
							dynamic_cast<const ComponentType*>(component->type());
					std::string component_tname = comp_type->name();
					if (component_tname == atom_type_name) {
						component_scope = &component->component_scope();
						found_scope = true;
					}
				}
			}
			current_component_scope_ = component_scope;

			init->action()->accept(*this);
		}

	} else if (single != 0) {

		assert(temp_control_locations_.size() != 0);
		std::string s_loc = single->source()->name()->name();
		std::string t_loc = single->target()->name()->name();
		//! check if this location is declared
		bool found_sloc = false;
		bool found_tloc = false;
		for (std::vector<std::string>::iterator sit =
				temp_control_locations_.begin();
				sit != temp_control_locations_.end()
						&& (!found_sloc || !found_tloc); ++sit) {
			if (*sit == s_loc) {
				found_sloc = true;
			}

			if (*sit == t_loc) {
				found_tloc = true;
			}

		}

		if (!found_sloc || !found_tloc) {
			error(*single, "undefined source or target control location.");
		}

		//! check if the port is declared if it is not an internal transition

		std::string port_name = single->label()->name()->name();
		if (!single->is_internal()) {
			bool found_name = false;
			for (std::vector<std::string>::const_iterator scit =
					temp_port_names_.begin();
					scit != temp_port_names_.end() && !found_name; ++scit) {
				if (*scit == port_name) {
					found_name = true;
				}
			}

			if (!found_name)
				error(*single, "undeclared of port name.");
		}

		if ((single->guard() != 0) || (single->action() != 0)) {
			assert(temp_atom_def_ != 0);
			std::string atom_type_name = temp_atom_def_->name()->name()->name();
			//! check the component scope
			const Scope* component_scope = 0;
			bool found_scope = false;
			for (Scope::const_iterator cit = scope_->begin();
					cit != scope_->end() && !found_scope; ++cit) {
				if ((*cit).second) {
					//! for each component binding, find the ones with this name
					const Component* component =
							dynamic_cast<const Component*>((*cit).second);
					const ComponentType* comp_type =
							dynamic_cast<const ComponentType*>(component->type());
					std::string component_tname = comp_type->name();
					if (component_tname == atom_type_name) {
						component_scope = &component->component_scope();
						found_scope = true;
					}
				}
			}
			current_component_scope_ = component_scope;
		}

		if (single->guard() != 0) {
			single->guard()->accept(*this);
		}

		if (single->action() != 0) {
			single->action()->accept(*this);
		}

	} else if (tran_list != 0) {

		for (ASTTransitionList::const_iterator cit = tran_list->begin();
				cit != tran_list->end(); ++cit) {
			if (*cit) {
				(*cit)->accept(*this);
			}
		}

	} else if (interaction != 0) {
		//! do nothing
	}

	return ASTVisitor::SKIP;
}

int TypeChecker::visit(const ASTDeclaration* declaration) {

	const ASTDataDeclaration* data_decl =
			dynamic_cast<const ASTDataDeclaration*>(declaration);
	const ASTPortDeclaration* port_decl =
			dynamic_cast<const ASTPortDeclaration*>(declaration);
	const ASTAtomDeclaration* atom_decl =
			dynamic_cast<const ASTAtomDeclaration*>(declaration);
	const ASTConnectorDeclaration* cnt_decl =
			dynamic_cast<const ASTConnectorDeclaration*>(declaration);
	const ASTDeclarationList* decl_list =
			dynamic_cast<const ASTDeclarationList*>(declaration);

	if (data_decl != 0) {
		//! this branch is jumped from the atom definition
		//! for each component binding, find the data variable declarations
		assert(comps_.size() != 0);
		for (std::vector<Component*>::const_iterator cit = comps_.begin();
				cit != comps_.end(); ++cit) {

			//! create a data variable binding
			std::string data_name = data_decl->name()->name()->name();
			DataType* data_type = new DataType();
			if (data_decl->is_bool()) {
				data_type->set_type(DataType::BOOL);
			} else if (data_decl->is_float()) {
				data_type->set_type(DataType::FLOAT);
			} else if (data_decl->is_int()) {
				data_type->set_type(DataType::INT);
			}
			DataVariable* data_var = new DataVariable(data_name, data_type,
					(*cit)->component_scope());

			//! add binding to the component scope

			ComponentScope& temp_comp_scope = (*cit)->component_scope();

			if (temp_comp_scope.find(data_name) != 0) {
				error(*data_decl, "redeclaration of variable (or parameter).");
			} else {
				temp_comp_scope.add_binding(data_var);

				if (data_decl->is_parameter()) {
					DataVariable* new_data_var = new DataVariable(data_name,
							data_type->clone(), (*cit)->component_scope());

					//! add the parameters of the type
					ComponentType* temp_comp_type =
							dynamic_cast<ComponentType*>((*cit)->type());
					assert(temp_comp_type != 0);
					temp_comp_type->add_parameter(new_data_var);
				}
			}
		}

	} else if (port_decl != 0) {
		//! this branch is jumped from the atomic definition
		//! it checks the port as well as the parameter declarations

		assert(port_types_.size() != 0);
		assert(temp_atom_def_ != 0);

		Scope* component_scope = 0;
		std::vector<Scope*> temp_scope_;

		//! check the type is defined
		std::string type_name = port_decl->type()->name()->name();
		std::string port_name = port_decl->name()->name()->name();

		const ASTIdExpression* temp_id =
				dynamic_cast<const ASTIdExpression*>(port_decl->parameters());
		const ASTExpressionList* temp_list =
				dynamic_cast<const ASTExpressionList*>(port_decl->parameters());

		bool found_type = false;
		PortType* found_port_type = 0;
		for (std::vector<PortType*>::const_iterator cit = port_types_.begin();
				cit != port_types_.end() && !found_type; ++cit) {

			if (*cit) {
				std::string temp_name = (*cit)->name();
				if (temp_name == type_name) {
					//! then check the parameters coincide

					std::string atom_type_name =
							temp_atom_def_->name()->name()->name();
					//! check the component scope
					bool found_scope = false;
					for (Scope::const_iterator sit = scope_->begin();
							sit != scope_->end(); ++sit) {
						if ((*sit).second) {
							//! for each component binding, find the ones with this name
							Component* component =
									dynamic_cast<Component*>((*sit).second);
							ComponentType* comp_type =
									dynamic_cast<ComponentType*>(component->type());
							std::string component_tname = comp_type->name();

							if (component_tname == atom_type_name) {
								temp_scope_.push_back(
										&component->component_scope());

								if (!found_scope) {
									component_scope =
											&component->component_scope();
									found_scope = true;
								}

							}
						}
					}
					assert(component_scope != 0);

					if (temp_id != 0) {
						//! when it is a single parameter
						if ((*cit)->arity() == 1) {

							//! then find the variable
							std::string var_name = temp_id->name()->name();
							const Binding* temp_binding = component_scope->find(
									var_name);
							if (temp_binding == 0) {
								error(*temp_id, "unknown variable.");
							} else {
								const DataVariable* temp_var =
										dynamic_cast<const DataVariable*>(temp_binding);
								if (temp_var != 0) {
									DataVariable* para_var = *((*cit)->begin());
									if (para_var->type()->equals(
											*temp_var->type())) {
										found_type = true;
										found_port_type = *cit;

										for(std::vector<Scope*>::iterator tsit = temp_scope_.begin();
												tsit != temp_scope_.end(); ++tsit){

											//! for each variable binding equaling temp_var
											//! set it as global variable
											const Binding* const_global_var = (*tsit)->find(var_name);
											Binding* global_binding =
													const_cast<Binding*>(const_global_var);
											DataVariable* global_var =
													dynamic_cast<DataVariable*>(global_binding);
											global_var->set_global(true);

										}

									}
								}
							}

						}

					} else if (temp_list != 0) {
						//! when it is a list of parameters
						if (temp_list->size() == (*cit)->arity()) {
							PortType::const_iterator pit = (*cit)->begin();
							for (ASTExpressionList::const_iterator ccit =
									temp_list->begin();
									ccit != temp_list->end(); ++ccit) {
								if (*ccit) {
									//! for each expression
									const ASTIdExpression* temp_var =
											dynamic_cast<const ASTIdExpression*>(*ccit);
									assert(temp_var != 0);
									std::string temp_var_name =
											temp_var->name()->name();
									const Binding* temp_var_binding =
											component_scope->find(
													temp_var_name);
									if (temp_var_binding == 0) {
										error(*temp_var, "unknown variable.");
									} else {
										const DataVariable* temp_data_var =
												dynamic_cast<const DataVariable*>(temp_var_binding);
										if (temp_data_var != 0) {
											DataVariable* temp_para_var = *pit;
											if (temp_para_var->type()->equals(
													*temp_data_var->type())) {
												found_type = true;
												found_port_type = *cit;

												for(std::vector<Scope*>::iterator tsit = temp_scope_.begin();
														tsit != temp_scope_.end(); ++tsit){

													//! for each variable binding equaling temp_var
													//! set it as global variable
													const Binding* const_global_var = (*tsit)->find(temp_var_name);
													Binding* global_binding =
															const_cast<Binding*>(const_global_var);
													DataVariable* global_var =
															dynamic_cast<DataVariable*>(global_binding);
													global_var->set_global(true);

												}

											}
										}
									}
								}
								++pit;
							}
						}

					} else {
						//! empty parameter
						if ((*cit)->arity() == 0) {
							found_type = true;
							found_port_type = *cit;
						}
					}
				}
			}
		}

		if (!found_type)
			error(*port_decl, "unknown port type (or parameter error).");
		else {

			bool found_name = false;
			for (std::vector<std::string>::const_iterator scit =
					temp_port_names_.begin();
					scit != temp_port_names_.end() && !found_name; ++scit) {
				if (*scit == port_name) {
					found_name = true;
				}
			}

			if (found_name)
				error(*port_decl, "redeclaration of port name.");
			else {
				temp_port_names_.push_back(port_name);

				if (component_scope->find(port_name) != 0) {
					error(*port_decl,
							"used name (we assume variables and ports use different names. Please rename the port or variable to avoid conflicts).");
				} else {

					for (std::vector<Scope*>::iterator sit =
							temp_scope_.begin(); sit != temp_scope_.end();
							++sit) {
						if (*sit) {

							Port* n_port = new Port(port_name,
									found_port_type->clone(), *(*sit));

							//! add parameters
							if (temp_id != 0) {
								std::string var_name = temp_id->name()->name();
								const Binding* temp_binding = (*sit)->find(
										var_name);
								const DataVariable* temp_var =
										dynamic_cast<const DataVariable*>(temp_binding);
								n_port->add_parameter(
										new DataVariable(temp_var->name(),
												temp_var->type()->clone(),
												temp_var->scope()));
							} else if (temp_list != 0) {
								for (ASTExpressionList::const_iterator ccit =
										temp_list->begin();
										ccit != temp_list->end(); ++ccit) {
									if (*ccit) {
										const ASTIdExpression* temp_var =
												dynamic_cast<const ASTIdExpression*>(*ccit);
										assert(temp_var != 0);
										std::string temp_var_name =
												temp_var->name()->name();
										const Binding* temp_var_binding =
												(*sit)->find(temp_var_name);
										const DataVariable* temp_data_var =
												dynamic_cast<const DataVariable*>(temp_var_binding);
										n_port->add_parameter(
												new DataVariable(
														temp_data_var->name(),
														temp_data_var->type()->clone(),
														temp_data_var->scope()));
									}
								}
							}

							(*sit)->add_binding(n_port);
						}
					}

				}
			}
		}

	} else if (atom_decl != 0) {
		//! we can enter this branch only when the parent is a compound component definition
		assert(scope_ != 0);
		//! create a new component binding, and it will create a component scope immediately
		std::string binding_name = atom_decl->name()->name()->name();
		Component* comp_binding = new Component(binding_name, *scope_);

		//! add parameters if they exist
		const ASTExpression* paras = atom_decl->parameters();
		if (paras != 0) {
			const ASTLiteralExpression* literal =
					dynamic_cast<const ASTLiteralExpression*>(paras);
			const ASTExpressionList* list =
					dynamic_cast<const ASTExpressionList*>(paras);

			if (literal != 0) {
				comp_binding->add_parameter(literal->clone());
			} else if (list != 0) {
				for (ASTExpressionList::const_iterator cit = list->begin();
						cit != list->end(); ++cit) {
					if (*cit) {
						const ASTLiteralExpression* temp =
								dynamic_cast<const ASTLiteralExpression*>(*cit);
						assert(temp != 0);
						comp_binding->add_parameter(temp->clone());
					}
				}
			}
		}

		//! set the type
		assert(component_types_.size() != 0);
		std::string type_name = atom_decl->type()->name()->name();
		bool found_type = false;
		const ComponentType* atom_type = 0;
		for (std::vector<ComponentType*>::const_iterator cit =
				component_types_.begin();
				cit != component_types_.end() && !found_type; ++cit) {
			if (*cit) {
				std::string temp_name = (*cit)->name();
				if (temp_name == type_name) {
					found_type = true;
					atom_type = *cit;
				}
			}
		}

		if (!found_type) {
			error(*atom_decl, "undeclared atom component type.");
		}

		//! in the type setting function, the parameter is cloned.
		comp_binding->set_type(atom_type);

		if (scope_->find(binding_name) == 0) {
			//! add the binding to the current scope
			scope_->add_binding(comp_binding);
		} else {
			//! there exists a binding, which means we have to component with the same name
			error(*atom_decl, "redeclaration of atom component.");
		}

	} else if (cnt_decl != 0) {
		//! 1: type is defined
		//! 2: parameters coincide
		//! 3: name is different

		assert(connector_types_.size() != 0);
		std::string cnt_type_name = cnt_decl->type()->name()->name();
		bool found_cnt_type = false;
		const ConnectorType* cnt_type = 0;
		const Type* cnt_port_type = 0;
		for (std::vector<ConnectorType*>::const_iterator cit =
				connector_types_.begin();
				cit != connector_types_.end() && !found_cnt_type; ++cit) {
			if (*cit) {
				if ((*cit)->name() == cnt_type_name) {
					found_cnt_type = true;
					cnt_type = (*cit);
				}
			}
		}

		if (!found_cnt_type)
			error(*cnt_decl, "connector type not found.");
		else{
			//! find the connected port type
			const Port* cnt_port = *cnt_type->begin();
			cnt_port_type = cnt_port->type();
		}

		std::string cnt_name = cnt_decl->name()->name()->name();
		bool found_cnt_name = false;
		for (std::vector<std::string>::iterator it =
				temp_connector_names_.begin();
				it != temp_connector_names_.end() && !found_cnt_name; ++it) {
			if (*it == cnt_name) {
				found_cnt_name = true;
			}
		}
		if (found_cnt_name)
			error(*cnt_decl, "redeclaration of connector name.");
		else
			temp_connector_names_.push_back(cnt_name);

		const ASTExpression* paras = cnt_decl->parameters();
		const ASTQualifiedIdExpression* qualify_id =
				dynamic_cast<const ASTQualifiedIdExpression*>(paras);
		const ASTExpressionList* qualify_id_list =
				dynamic_cast<const ASTExpressionList*>(paras);

		if (qualify_id != 0) {
			std::string qualifier = qualify_id->qualifier()->name();
			std::string id_name = qualify_id->name()->name();
			if (scope_->find(qualifier) == 0) {
				//!
				error(*cnt_decl,
						"illegal connector parameter found (component name not found).");
			} else {
				const Binding* temp_binding = scope_->find(qualifier);
				const Component* temp_comp =
						dynamic_cast<const Component*>(temp_binding);
				const ComponentScope* comp_scope =
						&(temp_comp->component_scope());
				if (comp_scope->find(id_name) == 0) {
					error(*cnt_decl,
							"illegal connector parameter found (port name not found).");
				} else{
					const Binding* connected_binding = comp_scope->find(id_name);
					const Port* connected_port =
							dynamic_cast<const Port*>(connected_binding);
					if(!connected_port->type()->equals(*cnt_port_type)){
						error(*cnt_decl,
							"illegal connector parameter found (port type mismatches).");
					}
				}
			}

		} else if (qualify_id_list != 0) {
			//! the following vector is used to check if a connector connects the same component twice
			std::vector<std::string> comp_names;

			for (ASTExpressionList::const_iterator cit =
					qualify_id_list->begin(); cit != qualify_id_list->end();
					++cit) {
				if (*cit) {
					const ASTQualifiedIdExpression* temp_qualify_id =
							dynamic_cast<const ASTQualifiedIdExpression*>(*cit);

					std::string temp_qualifier =
							temp_qualify_id->qualifier()->name();

					bool found_comp_name = false;
					for (std::vector<std::string>::iterator nit =
							comp_names.begin();
							nit != comp_names.end() && !found_comp_name;
							++nit) {
						if (*nit == temp_qualifier) {
							found_comp_name = true;
						}
					}
					if (found_comp_name)
						error(*cnt_decl,
								"illegal connector parameter found (connecting ports from the same component).");
					else
						comp_names.push_back(temp_qualifier);

					std::string temp_id_name = temp_qualify_id->name()->name();
					if (scope_->find(temp_qualifier) == 0) {
						//!
						error(*cnt_decl,
								"illegal connector parameter found (component name not found).");
					} else {
						const Binding* temp_binding = scope_->find(
								temp_qualifier);
						const Component* temp_comp =
								dynamic_cast<const Component*>(temp_binding);
						const ComponentScope* comp_scope =
								&(temp_comp->component_scope());
						if (comp_scope->find(temp_id_name) == 0) {
							error(*cnt_decl,
									"illegal connector parameter found (port name not found).");
						} else{
							const Binding* connected_binding = comp_scope->find(temp_id_name);
							const Port* connected_port =
									dynamic_cast<const Port*>(connected_binding);
							if(!connected_port->type()->equals(*cnt_port_type)){
								error(*cnt_decl,
									"illegal connector parameter found (port type mismatches).");
							}
						}
					}
				}
			}

		} else {
			error(*cnt_decl, "illegal connector parameter found.");
		}

	} else if (decl_list != 0) {

		for (ASTDeclarationList::const_iterator cit = decl_list->begin();
				cit != decl_list->end(); ++cit) {
			if (*cit) {
				(*cit)->accept(*this);
			}
		}

	}

	return ASTVisitor::SKIP;
}

int TypeChecker::visit(const ASTDefinition* definition) {

	const ASTPortDefinition* port_def =
			dynamic_cast<const ASTPortDefinition*>(definition);
	const ASTConnectorDefinition* cnt_def =
			dynamic_cast<const ASTConnectorDefinition*>(definition);
	const ASTAtomDefinition* atom_def =
			dynamic_cast<const ASTAtomDefinition*>(definition);
	const ASTCompoundDefinition* comp_def =
			dynamic_cast<const ASTCompoundDefinition*>(definition);

	if (port_def != 0) {

		std::string type_name = port_def->name()->name()->name();

		//! create a new port type
		PortType* port_type = new PortType(type_name);
		//! add parameters: create new data variables and then add them

		if (port_def->parameters() != 0) {

			const ASTDeclarationList* dlist =
					dynamic_cast<const ASTDeclarationList*>(port_def->parameters());

			if (dlist != 0) {

				//! check if there are redefined parameters
				std::vector<std::string> names;
				bool found = false;
				for (ASTDeclarationList::const_iterator cit = dlist->begin();
						cit != dlist->end() && !found; ++cit) {
					//! it should be a data declaration
					const ASTDataDeclaration* temp =
							dynamic_cast<const ASTDataDeclaration*>(*cit);
					if (temp == 0) {

						error(*temp,
								"wrong variable declaration in port type definition");

					} else {

						std::string var = temp->name()->name()->name();

						for (std::vector<std::string>::iterator it =
								names.begin(); it != names.end() && !found;
								++it) {
							if ((*it) == var) {
								found = true;
							}
						}

						if (!found) {

							//! add the name
							names.push_back(var);

							//! add parameter
							Scope* dummy_scope = new Scope();
							DataType* data_type = new DataType();
							if (temp->is_bool()) {
								data_type->set_type(DataType::BOOL);
							} else if (temp->is_float()) {
								data_type->set_type(DataType::FLOAT);
							} else if (temp->is_int()) {
								data_type->set_type(DataType::INT);
							}

							DataVariable* data_var = new DataVariable(var,
									data_type, *dummy_scope);
							port_type->add_parameter(data_var);
						} else {

							error(*dlist, "redeclaration of port parameters");

						}
					}
				}

			} else { //! the parameter is just a single data declaration

				const ASTDataDeclaration* data_decl =
						dynamic_cast<const ASTDataDeclaration*>(port_def->parameters());
				assert(data_decl != 0);
				Scope* dummy_scope = new Scope(); //! how to free this memory?
				DataType* data_type = new DataType();
				if (data_decl->is_bool()) {
					data_type->set_type(DataType::BOOL);
				} else if (data_decl->is_float()) {
					data_type->set_type(DataType::FLOAT);
				} else if (data_decl->is_int()) {
					data_type->set_type(DataType::INT);
				}
				DataVariable* data_var = new DataVariable(
						data_decl->name()->name()->name(), data_type,
						*dummy_scope);

				port_type->add_parameter(data_var);
			}

		}

		//! check if there is a port name clashing
		bool clashing = false;
		for (std::vector<PortType*>::iterator it = port_types_.begin();
				it != port_types_.end() && !clashing; ++it) {
			if (*it && (*it)->equals(*port_type)) {
				clashing = true;
			}
		}

		if (clashing) {
			error(*port_def, "redeclaration of port type");
		} else
			port_types_.push_back(port_type);

		return ASTVisitor::SKIP;

	} else if (cnt_def != 0) {

			//! get the connector type name
			std::string cnt_name = cnt_def->name()->name()->name();
			ConnectorType* cnt_type = new ConnectorType(cnt_name);

			//! add PortType parameters
			const ASTDeclaration* decl = cnt_def->parameters();
			const ASTPortDeclaration* port_decl =
					dynamic_cast<const ASTPortDeclaration*>(decl);
			const ASTDeclarationList* dlist =
					dynamic_cast<const ASTDeclarationList*>(decl);

			const ASTExpression* connected_ports = cnt_def->connected_ports();
			//! it should be an id expression or a list of id expressions
			const ASTIdExpression* id_expr =
					dynamic_cast<const ASTIdExpression*>(connected_ports);
			const ASTExpressionList* exprs =
					dynamic_cast<const ASTExpressionList*>(connected_ports);

			if (port_decl != 0) { //! when it is a single port,
				//! find the name of the port type, and the corresponding PortType
				std::string type_name = port_decl->type()->name()->name();
				//! get the Port name
				std::string port_name = port_decl->name()->name()->name();

				if (id_expr == 0) {
					error(*id_expr, "error in defining interaction.");
				} else {
					std::string defined_port = id_expr->name()->name();
					if (port_name != defined_port) {
						error(*id_expr, "error in defining interaction.");
					}
				}

				bool found = false;
				PortType* pt = 0;
				for (std::vector<PortType*>::iterator it = port_types_.begin();
						it != port_types_.end() && !found; ++it) {
					if (*it && (*it)->name() == type_name) {
						found = true;
						pt = *it;
					}
				}

				if (!found) {
					error(*port_decl, "unknown reference to the port type");
				} else {

					Port* n_port = new Port(port_name, pt->clone(),
							*(new Scope()));
					cnt_type->add_parameter(n_port);

				}

			} else {				//! when it is a list of ports

				if (exprs == 0) {
					error(*cnt_def, "error in defining interaction.");
				}

				//! holding the names of parameters
				std::vector<std::string> names;

				bool found_name = false;
				bool found_type = true;
				for (ASTDeclarationList::const_iterator cit = dlist->begin();
						cit != dlist->end() && !found_name && found_type;
						++cit) {

					//! it should be a port declaration
					const ASTPortDeclaration* temp =
							dynamic_cast<const ASTPortDeclaration*>(*cit);

					if (temp == 0) {

						error(*temp,
								"error in port declaration in connector type definition");

					} else {

						std::string var = temp->name()->name()->name();

						for (std::vector<std::string>::iterator it =
								names.begin(); it != names.end() && !found_name;
								++it) {
							if ((*it) == var) {
								found_name = true;
							}
						}

						if (!found_name) {
							//! add the name
							names.push_back(var);

							//! find the name of the port type, and the corresponding PortType
							std::string type_name =
									temp->type()->name()->name();

							PortType* pt = 0;
							found_type = false;
							for (std::vector<PortType*>::iterator it =
									port_types_.begin();
									it != port_types_.end() && !found_type;
									++it) {
								if (*it && (*it)->name() == type_name) {
									found_type = true;
									pt = *it;
								}
							}

							if (!found_type) {
								error(*temp,
										"unknown reference to the port type");
							} else {
								//! create a new Port
								Port* n_port = new Port(var, pt->clone(),
										*(new Scope()));
								cnt_type->add_parameter(n_port);
							}
						} else {
							error(*dlist,
									"redeclaration of connector parameters");
						}
					}
				}

				if (exprs != 0) {
					std::vector<std::string> temp_names;
					//! check if the defined ports are the same with the parameters
					for (ASTExpressionList::const_iterator cit = exprs->begin();
							cit != exprs->end(); ++cit) {
						if (*cit) {
							const ASTIdExpression* temp_id =
									dynamic_cast<const ASTIdExpression*>(*cit);

							if (temp_id != 0) {
								std::string temp_name = temp_id->name()->name();
								bool temp_found = false;
								for (std::vector<std::string>::iterator it =
										names.begin();
										it != names.end() && !temp_found;
										++it) {
									if (*it == temp_name)
										temp_found = true;
								}

								if (!temp_found)
									error(*temp_id,
											"error in defining interaction.");
								else {
									//! found the name, then check it is redefined
									bool redefined = false;
									for (std::vector<std::string>::iterator temp_it =
											temp_names.begin();
											temp_it != temp_names.end()
													&& !redefined; ++temp_it) {
										if (*temp_it == temp_name) {
											redefined = true;
										}
									}
									if (redefined) {
										error(*exprs,
												"error in interaction definition (redeclaration of ports).");
									} else {
										temp_names.push_back(temp_name);
									}
								}

							} else {
								error(*exprs,
										"error in defining in interaction.");
							}
						}
					}
				}
			}

			//! check if there is a port name clashing
			bool clashing = false;
			for (std::vector<ConnectorType*>::iterator it =
					connector_types_.begin();
					it != connector_types_.end() && !clashing; ++it) {
				if (*it && (*it)->equals(*cnt_type)) {
					clashing = true;
				}
			}

			if (clashing) {
				error(*port_def, "redeclaration of connector type");
			} else
				connector_types_.push_back(cnt_type);

			//! 1: check the interaction definition is correct
			//! 2: check the ports are exactly declared as the parameters
			if (cnt_def->interactions() != 0) {
				const ASTInteraction* ia =
						dynamic_cast<const ASTInteraction*>(cnt_def->interactions());
				if (ia == 0) {
					error(*(cnt_def->interactions()),
							"error in interaction definition (we only support strong synchronization).");
				} else {

					if (!(ia->connected_ports()->equals(
							cnt_def->connected_ports()))) {
						error(*ia, "unknown defined interaction.");
					}

					temp_connector_type_ = cnt_type;
					in_connector_def_ = true;

					if (ia->guard() != 0) {
						ia->guard()->accept(*this);
					}

					if (ia->action() != 0) {
						ia->action()->accept(*this);
					}

					in_connector_def_ = false;
				}
			}

		return ASTVisitor::SKIP;

	} else if (atom_def != 0) {

		std::string atom_type_name = atom_def->name()->name()->name();
		//! then find the bindings with this type name
		for (Scope::const_iterator cit = scope_->begin(); cit != scope_->end();
				++cit) {
			if ((*cit).second) {
				//! for each component binding, find the ones with this name
				Component* component = dynamic_cast<Component*>((*cit).second);
				const ComponentType* comp_type =
						dynamic_cast<const ComponentType*>(component->type());
				std::string component_tname = comp_type->name();
				if (component_tname == atom_type_name) {
					//! since each atomic type may have several instances
					//! we use this temporal vector to store the instances
					//! of the same atomic type.
					comps_.push_back(component);
				}
			}
		}
		assert(comps_.size() != 0);

		if (atom_def->parameters() != 0) {
			atom_def->parameters()->accept(*this);
		}

		if (atom_def->data_declarations() != 0) {
			atom_def->data_declarations()->accept(*this);
		}

		for (std::vector<Component*>::iterator comit = comps_.begin();
				comit != comps_.end(); ++comit) {
			if (*comit) {
				unsigned int declared_arity = (*comit)->arity();
				ComponentType* comp_type =
						dynamic_cast<ComponentType*>((*comit)->type());
				assert(comp_type != 0);
				unsigned int defined_arity = comp_type->arity();
				if (declared_arity != defined_arity) {
					error(*atom_def,
							"mismatching between atom type definition and declaration (number of parameters).");
				}
			}
		}

		comps_.clear();
		temp_atom_def_ = atom_def;
		in_component_ = true;

		if (atom_def->port_declarations() != 0) {
			temp_port_names_.clear();
			atom_def->port_declarations()->accept(*this);
		}

		//! 1: check control locations declaration
		//! find the set of control locations
		const ASTExpression* control_locations = atom_def->control_location();
		temp_control_locations_.clear();

		const ASTIdExpression* single_loc =
				dynamic_cast<const ASTIdExpression*>(control_locations);
		const ASTExpressionList* locations =
				dynamic_cast<const ASTExpressionList*>(control_locations);

		if (single_loc != 0) {
			temp_control_locations_.push_back(single_loc->name()->name());
		} else if (locations != 0) {
			for (ASTExpressionList::const_iterator ecit = locations->begin();
					ecit != locations->end(); ++ecit) {
				if (*ecit) {
					const ASTIdExpression* temp_loc =
							dynamic_cast<const ASTIdExpression*>(*ecit);
					temp_control_locations_.push_back(temp_loc->name()->name());
				}
			}
		}

		//! 2: check transitions declaration
		if (atom_def->initial_transition() != 0) {
			atom_def->initial_transition()->accept(*this);
		}

		if (atom_def->transitions() != 0) {
			atom_def->transitions()->accept(*this);
		}

		//temp_atom_def_ = 0;
		in_component_ = false;

	} else if (comp_def != 0) {

		const ASTDeclaration* cnt_decls = comp_def->connectors();
		if (cnt_decls != 0) {
			//! type checking the connector declarations are correct
			cnt_decls->accept(*this);
		}

	} else {

		error(*definition, "unknown type definition.");
	}

	return ASTVisitor::SKIP;
}

int TypeChecker::visit(const ASTTranslationUnit* unit) {
	//! in current type checking procedure, we need to declare port
	//! types before connector type declarations. In other words
	//! types can be used only after they have been declared.

	if (!scope_) {
		scope_ = create_symbol_table();
	}

	//! we need this look-ahead to
	//! find the compound component definition, for each
	//! atomic component instance, we will create a component
	//! scope. The same goes for CFA construction.
	//!
	const ASTCompoundDefinition* comp_def = 0;
	for (ASTTranslationUnit::const_iterator cit = unit->begin();
			cit != unit->end(); ++cit) {
		if ((*cit)) {

			const ASTCompoundDefinition* temp_def =
					dynamic_cast<const ASTCompoundDefinition*>(*cit);
			const ASTAtomDefinition* atom_def =
					dynamic_cast<const ASTAtomDefinition*>(*cit);

			if (temp_def != 0) {
				comp_def = temp_def;
			} else if (atom_def != 0) {
				//! this is an atom type definition, create a ComponentType for each
				std::string atom_type_name = atom_def->name()->name()->name();
				ComponentType* atom_type = new ComponentType(atom_type_name);

				component_types_.push_back(atom_type);
				//! in this look-ahead, we do not add parameters.

			}

		}
	}

	//! for each component instance, we create a binding in the scope
	const ASTDeclaration* comp_decls = comp_def->components();
	assert(comp_decls != 0);
	//! it should be a single atom declaration or a list
	comp_decls->accept(*this);

	//! we do not visit the target states at this moment

	return ASTVisitor::CONTINUE;
}

int TypeChecker::leave(const ASTTranslationUnit* unit) {

	//! checking the target states are correctly specifying
	const ASTExpression* targets = unit->target_state();

	const ASTQualifiedIdExpression* single_target  =
			dynamic_cast<const ASTQualifiedIdExpression*>(targets);
	const ASTExpressionList* list_target =
			dynamic_cast<const ASTExpressionList*>(targets);

	if(single_target != 0){

		std::string target_location = single_target->name()->name();

		//! for this given control location, find the component and then check if it is declared
		std::string target_component_name = single_target->qualifier()->name();

		const Binding* binding_ = scope_->find(target_component_name);
		if(binding_ == 0){
			error(*targets, "unknown component in the target state specification.");
		} else{

			const Component* component_ = dynamic_cast<const Component*>(binding_);
			const Type* type_ = component_->type();
			const ComponentType* comp_type = dynamic_cast<const ComponentType*>(type_);

			std::string target_comp_type_name = comp_type->name();

			for(ASTTranslationUnit::const_iterator cit = unit->begin();
					cit != unit->end(); ++cit){
				if(*cit){
					const ASTAtomDefinition* atom_def =
							dynamic_cast<const ASTAtomDefinition*>(*cit);
					if(atom_def != 0){
						std::string temp_type_name = atom_def->name()->name()->name();
						if(temp_type_name == target_comp_type_name){
							//! find the set of control locations
							const ASTExpression* locations = atom_def->control_location();
							//! and check if the target is contained

							const ASTIdExpression* single_loc =
									dynamic_cast<const ASTIdExpression*>(locations);
							const ASTExpressionList* locs =
									dynamic_cast<const ASTExpressionList*>(locations);

							if(single_loc != 0){
								//! this location must be the target
								std::string loc_name = single_loc->name()->name();
								if(loc_name != target_location)
									error(*targets, "unknown control location in the target state specification.");
							} else if(locs != 0){
								bool found_loc = false;
								for(ASTExpressionList::const_iterator eit = locs->begin();
										eit != locs->end() && !found_loc; ++eit){
									if(*eit){
										const ASTIdExpression* temp_id =
												dynamic_cast<const ASTIdExpression*>(*eit);
										std::string temp_name = temp_id->name()->name();
										if(temp_name == target_location)
											found_loc = true;
									}
								}
								if(!found_loc)
									error(*targets, "unknown control location in the target state specification.");
							}

						}
					}
				}
			}

		}

	} else if( list_target != 0){

		for(ASTExpressionList::const_iterator cit = list_target->begin();
				cit != list_target->end(); ++ cit){
			if(*cit){

				const ASTQualifiedIdExpression* temp_single =
						dynamic_cast<const ASTQualifiedIdExpression*>(*cit);

				std::string target_location = temp_single->name()->name();

				//! for this given control location, find the component and then check if it is declared
				std::string target_component_name = temp_single->qualifier()->name();

				const Binding* binding_ = scope_->find(target_component_name);
				if(binding_ == 0){
					error(*targets, "unknown component in the target state specification.");
				} else{

					const Component* component_ = dynamic_cast<const Component*>(binding_);
					const Type* type_ = component_->type();
					const ComponentType* comp_type = dynamic_cast<const ComponentType*>(type_);

					std::string target_comp_type_name = comp_type->name();

					for(ASTTranslationUnit::const_iterator cit = unit->begin();
							cit != unit->end(); ++cit){
						if(*cit){
							const ASTAtomDefinition* atom_def =
									dynamic_cast<const ASTAtomDefinition*>(*cit);
							if(atom_def != 0){
								std::string temp_type_name = atom_def->name()->name()->name();
								if(temp_type_name == target_comp_type_name){
									//! find the set of control locations
									const ASTExpression* locations = atom_def->control_location();
									//! and check if the target is contained

									const ASTIdExpression* single_loc =
											dynamic_cast<const ASTIdExpression*>(locations);
									const ASTExpressionList* locs =
											dynamic_cast<const ASTExpressionList*>(locations);

									if(single_loc != 0){
										//! this location must be the target
										std::string loc_name = single_loc->name()->name();
										if(loc_name != target_location)
											error(*targets, "unknown control location in the target state specification.");
									} else if(locs != 0){
										bool found_loc = false;
										for(ASTExpressionList::const_iterator eit = locs->begin();
												eit != locs->end() && !found_loc; ++eit){
											if(*eit){
												const ASTIdExpression* temp_id =
														dynamic_cast<const ASTIdExpression*>(*eit);
												std::string temp_name = temp_id->name()->name();
												if(temp_name == target_location)
													found_loc = true;
											}
										}
										if(!found_loc)
											error(*targets, "unknown control location in the target state specification.");
									}

								}
							}
						}
					}

				}

			}
		}

	}

	return ASTVisitor::CONTINUE;
}


Scope* TypeChecker::create_symbol_table() {
	Scope *scope = new Scope();

	return scope;
}

void TypeChecker::error(const ASTNode& node, const std::string& message,
		bool end) {

	++num_type_errors_;

	const ASTNodeLocation& loc = node.node_location();

	err_ << loc.file_name() << ":"
			<< (end ? loc.end_line_number() : loc.start_line_number())
			<< ": error: " << message << std::endl;
}

TypeChecker::~TypeChecker() {
	if (scope_)
		delete scope_;

	num_type_errors_ = 0;

	for (std::vector<PortType*>::const_iterator cit = port_types_.begin();
			cit != port_types_.end(); ++cit) {
		if (*cit){
			//! release the dummy scope pointer first

			for(PortType::const_iterator pit = (*cit)->begin();
					pit != (*cit)->end(); ++pit){
				//! for each data variable
				if(*pit){
					Scope* dummy = &(*pit)->scope();
					if(dummy != 0)
						delete dummy;
				}
			}

			delete *cit;
		}
	}
	port_types_.clear();

	for (std::vector<ConnectorType*>::const_iterator cit =
			connector_types_.begin(); cit != connector_types_.end(); ++cit) {
		if (*cit){
			//! for each port
			for(ConnectorType::const_iterator ccit = (*cit)->begin();
					ccit != (*cit)->end(); ++ccit){
				if(*ccit){
					Scope* dummy = &(*ccit)->scope();
					if(dummy != 0)
						delete dummy;
				}
			}
			delete *cit;
		}
	}
	connector_types_.clear();

	for (std::vector<ComponentType*>::const_iterator cit =
			component_types_.begin(); cit != component_types_.end(); ++cit) {
		if (*cit)
			delete *cit;
	}
	component_types_.clear();

}

}
