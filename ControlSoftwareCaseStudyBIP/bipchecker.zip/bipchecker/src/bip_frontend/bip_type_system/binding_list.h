/*
 * binding_list.h
 *
 *  Created on: Nov 11, 2014
 *      Author: wangqiang
 *
 *      NOT USED !!!
 */

#ifndef BINDING_LIST_H_
#define BINDING_LIST_H_

#include <deque>
#include <ostream>
#include <string>
#include "bip_frontend/bip_type_system/binding.h"

namespace bipchecker {

class BindingList {
	typedef std::deque<Binding*> bindings_t;
	bindings_t bindings_;

public:

	explicit BindingList() {
	}

	typedef bindings_t::const_iterator const_iterator;
	const_iterator const_begin() const {
		return bindings_.begin();
	}
	const_iterator const_end() const {
		return bindings_.end();
	}

	typedef bindings_t::const_iterator iterator;
	iterator begin() const {
		return bindings_.begin();
	}
	iterator end() const {
		return bindings_.end();
	}

	void add_binding(Binding *binding) {
		if (binding)
			bindings_.push_front(binding);
	}

	void remove_binding() {
		if (!bindings_.empty()) {

			Binding *binding = bindings_.front();
			bindings_.pop_front();

			if (binding)
				delete binding;

		}

	}

	int size() const {
		return bindings_.size();
	}
	bool empty() const {
		return bindings_.empty();
	}

	~BindingList() {

		for (bindings_t::iterator it = bindings_.begin(); it < bindings_.end();
				++it) {

			if (*it)
				delete *it;
		}

		bindings_.clear();
	}

	// Debugging

	void print_binding_list(std::ostream& out) const {
		int i = 0;

		for (const_iterator it = begin(); it < end(); ++it) {

			if (*it) {

				out << "** binding " << i << " ** :" << std::endl;
				out << **it << std::endl << std::endl;

				++i;
			}

		}

	}

};
// class BindingList

std::ostream& operator<<(std::ostream&, const BindingList&);

}

#endif /* BINDING_LIST_H_ */
