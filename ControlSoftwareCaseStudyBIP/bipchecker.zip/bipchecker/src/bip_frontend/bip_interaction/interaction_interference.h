/*
 * interaction_interference.h
 *
 *  Created on: Dec 2, 2014
 *      Author: wangqiang
 */

#ifndef INTERACTION_INTERFERENCE_H_
#define INTERACTION_INTERFERENCE_H_

#include "util/util.h"
#include "util/symbol.h"

namespace bipchecker{

class BIPInteractionInterference {

    //! interaction1
    const Symbol& interaction1_;

    //! interaction2
    const Symbol& interaction2_;

public:

    //! Class constructor.
    /*!
     * \param thread1 a thread name.
     * \param thread2 a thread name.
     */
    explicit BIPInteractionInterference(const Symbol& i1,
				const Symbol& i2)
	: interaction1_(i1),
	  interaction2_(i2)
    {
    }


    //! Class copy constructor.
    explicit BIPInteractionInterference(const BIPInteractionInterference& interaction_interference)
	: interaction1_(interaction_interference.interaction1_),
	  interaction2_(interaction_interference.interaction2_)
    {
    }


    //! Gets thread 1.
    /*!
     * \return The thread 1.
     */
    const Symbol& interaction1() const { return interaction1_; }


    //! Gets thread 2.
    /*!
     * \return The thread 2.
     */
    const Symbol& interaction2() const { return interaction2_; }

    //! clone function
    BIPInteractionInterference* clone() const {
    	return new BIPInteractionInterference(*this);
    }

    void print_interaction_interference(std::ostream& out) const {

    	out << "Interaction " << interaction1_.to_string();

    	out << " may be interfered with interaction " << interaction2_.to_string() << std::endl;
    }


    //! Checks if this thread interference equals the other.
    /*!
     * \param other a thread interference.
     * \return True iff this thread interference equals the other.
     */
    bool equals(const BIPInteractionInterference& other) const
    {
	if ( &interaction1_ == &(other.interaction1_)
	     && &interaction2_ == &(other.interaction2_) )
	    return true;

	return false;
    }

    //! Computes the hash code.
    /*!
     * \return The hash code.
     */
    size_t hash_code() const
    {
	size_t hash_num = 1;

	hash_num = 31 * hash_num + interaction1_.symbol_id();
	hash_num = 31 * hash_num + interaction2_.symbol_id();

	return hash_num;
    }


    //! Class destructor.
    ~BIPInteractionInterference() {}

private:

    DISALLOW_ASSIGN(BIPInteractionInterference);

};


struct EqHashBIPInteractionInterference
{
    size_t operator()(const BIPInteractionInterference *ti) const
    {
	return ti->hash_code();
    }

    bool operator() (const BIPInteractionInterference *ti1,
		     const BIPInteractionInterference *ti2) const
    {
	if (ti1 && !ti2)
	    return false;
	if (!ti1 && ti2)
	    return false;
	if ( (!ti1 && !ti2)
	     || (ti1 && ti2 && ti1->equals(*ti2)) )
	    return true;

	return false;
    }

};


}



#endif /* INTERACTION_INTERFERENCE_H_ */
