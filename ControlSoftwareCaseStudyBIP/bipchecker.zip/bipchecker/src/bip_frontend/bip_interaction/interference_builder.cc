/*
 * interference_builder.cc
 *
 *  Created on: Dec 2, 2014
 *      Author: wangqiang
 */

#include "bip_frontend/bip_interaction/interference_builder.h"

namespace bipchecker{


void BIPInterferenceBuilder::build_interferences() {

	//! Create an empty interference relation.
	BIPInterferenceRelation *interferences = new BIPInterferenceRelation();

	//! Build the interaction interference relation.
	build_interaction_interference(*interferences);

	if(bip_interference_relation_ != 0)
		delete bip_interference_relation_;

	bip_interference_relation_ = interferences;
}


void BIPInterferenceBuilder::build_interaction_interference(BIPInterferenceRelation& interference) const {

	for (InteractionModel::const_iterator iit1 = im_.const_interaction_begin();
			iit1 != im_.const_interaction_end(); ++iit1) {

		//! for each interaction
		for (InteractionModel::const_iterator iit2 = iit1 + 1;
				iit2 != im_.const_interaction_end(); ++iit2) {

			const BIPInteraction* interaction1 = (*iit1);
			const BIPInteraction* interaction2 = (*iit2);

			std::string interaction1_name = interaction1->get_name();
			std::string interaction2_name = interaction2->get_name();


			const Symbol& interaction_sym1 = Symbol::symbol(interaction1_name);
			const Symbol& interaction_sym2 = Symbol::symbol(interaction2_name);

			//! TODO check if they have the same location
			if (has_same_thread(interaction1, interaction2)) {

				BIPInteractionInterference* ia = new BIPInteractionInterference(interaction_sym1, interaction_sym2);

				interference.add_interaction_interference(ia);

				BIPInteractionInterference* symmetry = new BIPInteractionInterference(interaction_sym2, interaction_sym1);

				interference.add_interaction_interference(symmetry);
			}

		}

	}

}

bool BIPInterferenceBuilder::has_same_thread(const BIPInteraction* interaction1,
		const BIPInteraction* interaction2) const {

	for (BIPInteraction::const_iterator cit = interaction1->const_begin();
			cit != interaction1->const_end(); ++cit) {
		//! for each associated port, get the corresponding thread
		const BIPPort* port = (*cit);
		const std::string port_name = port->get_threadName();

		//! check if this thread involves in another interaction
		for (BIPInteraction::const_iterator cit2 = interaction2->const_begin();
				cit2 != interaction2->const_end(); ++cit2) {
			const BIPPort* port2 = *cit2;
			const std::string port2_name = port2->get_threadName();
			if (port2_name == port_name) {
				return true;
			}
		}
	}
	return false;
}


}

