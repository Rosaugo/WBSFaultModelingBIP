/*
 * interaction_extractor.h
 *
 *  Created on: Nov 26, 2014
 *      Author: wangqiang
 */

#ifndef INTERACTION_EXTRACTOR_H_
#define INTERACTION_EXTRACTOR_H_

#include "bip_frontend/bip_ast/ast_visitor.h"
#include "bip_frontend/bip_interaction/interaction_model.h"

namespace bipchecker{


class InteractionExtractor: public ASTVisitor {

	//! resulting interaction model
	InteractionModel* im_;

public:

	explicit InteractionExtractor()
	: ASTVisitor(true), im_(0),
	  temp_guard_(0),
	  temp_action_(0)
	{}

	InteractionModel* InteractionMode(){ return im_; }

	// visit functions
	int visit(const ASTExpression*) { return ASTVisitor::SKIP; }
	int visit(const ASTName*) { return ASTVisitor::SKIP; }
	int visit(const ASTStatement*)  { return ASTVisitor::SKIP; }
	int visit(const ASTTransition*)  ;
	int visit(const ASTDeclaration*)  { return ASTVisitor::SKIP; }
	int visit(const ASTDefinition*) { return ASTVisitor::SKIP; }
	int visit(const ASTTranslationUnit*);

	// leave functions
	int leave(const ASTExpression*) { return ASTVisitor::CONTINUE; }
	int leave(const ASTName*) { return ASTVisitor::CONTINUE; }
	int leave(const ASTStatement*) { return ASTVisitor::CONTINUE; }
	int leave(const ASTTransition*) { return ASTVisitor::CONTINUE; }
	int leave(const ASTDeclaration*) { return ASTVisitor::CONTINUE; }
	int leave(const ASTDefinition*) { return ASTVisitor::CONTINUE; }
	int leave(const ASTTranslationUnit*) { return ASTVisitor::CONTINUE; }

	~InteractionExtractor() {
		temp_cnt_def_.clear();
		temp_atom_def_.clear();
		temp_port_def_.clear();
		temp_actual_parameters_.clear();
		temp_atom_decls_.clear();
		temp_formal_parameters_.clear();
		actual_vars_.clear();
		formal_vars_.clear();
	}

private:
	std::vector<const ASTConnectorDefinition*> temp_cnt_def_;

	std::vector<const ASTAtomDefinition*> temp_atom_def_;

	std::vector<const ASTPortDefinition*> temp_port_def_;

	std::vector<const ASTQualifiedIdExpression*> temp_actual_parameters_;

	std::vector<const ASTAtomDeclaration*> temp_atom_decls_;

	std::vector<const ASTPortDeclaration*> temp_formal_parameters_;

	std::vector<std::string> actual_vars_;

	std::vector<std::string> formal_vars_;

	std::string port_type_name_;

	ASTExpression* temp_guard_;
	ASTStatement* temp_action_;

	ASTExpression* visit_expression(const ASTExpression*);

	ASTStatement* visit_action(const ASTStatement*);
};


}


#endif /* INTERACTION_EXTRACTOR_H_ */
