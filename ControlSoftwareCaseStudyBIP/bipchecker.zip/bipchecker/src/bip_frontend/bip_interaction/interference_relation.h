/*
 * interference_relation.h
 *
 *  Created on: Dec 2, 2014
 *      Author: wangqiang
 */

#ifndef INTERFERENCE_RELATION_H_
#define INTERFERENCE_RELATION_H_

#include "bip_frontend/bip_interaction/interaction_model.h"
#include "bip_frontend/bip_interaction/interaction_interference.h"
#include "util/hash_map.h"
#include "util/util.h"

namespace bipchecker{

class BIPInterferenceRelation
{

public:

    //! Enum kind of interference relation.
    enum InterferenceRelationKind
    {
	DEPENDENCE,    /*!< Dependence relation. */
	INDEPENDENCE   /*!< Independence relation. */
    };

	//!
	typedef hash_set<BIPInteractionInterference*,
			EqHashBIPInteractionInterference,
			EqHashBIPInteractionInterference> bip_interaction_interferences_t;

private:

    //! Kind of interference relation.
    InterferenceRelationKind kind_;

    bip_interaction_interferences_t bip_interaction_interferences_;

public:

	typedef bip_interaction_interferences_t::const_iterator interaction_const_iterator;

	interaction_const_iterator interaction_const_begin() const {
		return bip_interaction_interferences_.begin();
	}

	interaction_const_iterator interaction_const_end() const {
		return bip_interaction_interferences_.end();
	}

	explicit BIPInterferenceRelation(InterferenceRelationKind kind = BIPInterferenceRelation::DEPENDENCE)
	:kind_(kind) {
	}

	//! Class copy constructor.
	explicit BIPInterferenceRelation(const BIPInterferenceRelation& interferences)
	{
	  for( interaction_const_iterator tit = interferences.interaction_const_begin();
    			tit != interferences.interaction_const_end(); ++tit){
    		BIPInteractionInterference* bit = *tit;
    		add_interaction_interference(bit->clone());
	  }

	  kind_ = interferences.kind_;
	}

    //! Looks up bip thread interference between threads id1 and id2.
    /*!
     * \param id1 the id of a thread 1.
     * \param id2 the id of a thread 2.
     * \return The interference between threads id1 and id2, otherwise 0.
     */
    const BIPInteractionInterference* look_up_interaction(const Symbol& id1, const Symbol& id2) const;

    bool has_interference(const BIPInteraction* i1, const BIPInteraction* i2) const;

    //! Gets the size of interference relation.
    /*!
     * \return The size of interference relation.
     */
    size_t interaction_interference_size() const { return bip_interaction_interferences_.size(); }


    //! Adds an interference into the relation.
    /*!
     * Adding a new interference will override the interference with
     * the same ids.
     *
     * Adding a new interference fails if the atomic blocks are
     * not in the domain.
     *
     * \param interference an interference.
     * \return True iff the interference is added into the relation.
     */
    void add_interaction_interference(BIPInteractionInterference *interference);


    //! Removes an interference from the relation.
    /*!
     * \param interference an interference.
     */
    void remove_interaction_interference(const BIPInteractionInterference& interference);

    void print_interaction_interferences(std::ostream& out) const {

    	for(interaction_const_iterator it = interaction_const_begin();
    			it != interaction_const_end(); ++it){
    		(*it)->print_interaction_interference(out);
    	}

    }

    ~BIPInterferenceRelation(){

    	std::vector<BIPInteractionInterference*> temp_key;

    	for (bip_interaction_interferences_t::iterator it = bip_interaction_interferences_.begin();
    			it != bip_interaction_interferences_.end(); ++it)
    		temp_key.push_back(*it);

    	for (size_t i = 0; i < temp_key.size(); ++i)
    		delete temp_key[i];

    	temp_key.clear();
    	bip_interaction_interferences_.clear();
    }

private:

    DISALLOW_ASSIGN(BIPInterferenceRelation);

};


}


#endif /* INTERFERENCE_RELATION_H_ */
