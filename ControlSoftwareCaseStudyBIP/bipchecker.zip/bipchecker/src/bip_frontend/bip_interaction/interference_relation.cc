/*
 * interference_relation.cc
 *
 *  Created on: Dec 2, 2014
 *      Author: wangqiang
 */


#include "bip_frontend/bip_interaction/interference_relation.h"

namespace bipchecker{


const BIPInteractionInterference* BIPInterferenceRelation::look_up_interaction(const Symbol& id1, const Symbol& id2) const
{
	BIPInteractionInterference* key = new BIPInteractionInterference(id1,id2);

	interaction_const_iterator tit = bip_interaction_interferences_.find(key);

	delete key;

	if(tit != bip_interaction_interferences_.end())
		return *tit;

	return 0;
}

bool BIPInterferenceRelation::has_interference(const BIPInteraction* interaction1,
		const BIPInteraction* interaction2) const
{
	//! first get the names of two interactions

	std::string interaction1_name = interaction1->get_name();

//	for (BIPInteraction::const_iterator cit = interaction1->const_begin();
//			cit != interaction1->const_end(); ++cit){
//		const std::string port_name = (*cit)->get_PortName();
//		interaction1_name = interaction1_name + port_name;
//	}

	std::string interaction2_name = interaction2->get_name();

//	for (BIPInteraction::const_iterator cit = interaction2->const_begin();
//			cit != interaction2->const_end(); ++cit){
//		const std::string port_name = (*cit)->get_PortName();
//		interaction2_name = interaction2_name + port_name;
//	}

	const Symbol& interaction_sym1 = Symbol::symbol(
			interaction1_name);
	const Symbol& interaction_sym2 = Symbol::symbol(
			interaction2_name);

	const BIPInteractionInterference* irelation = look_up_interaction(interaction_sym1,
			interaction_sym2);

	if(irelation != 0)
		return true;
	else
		return false;
}

void BIPInterferenceRelation::add_interaction_interference(BIPInteractionInterference* interference)
{
	const Symbol& sym1 = interference->interaction1();
	const Symbol& sym2 = interference->interaction1();

	const BIPInteractionInterference* it = look_up_interaction(sym1,sym2);

	if(it == 0)
	{
		//! interference does not exist
		//! add a new one
		bip_interaction_interferences_.insert(interference);
	}

}

void BIPInterferenceRelation::remove_interaction_interference(const BIPInteractionInterference& interference)
{
	const Symbol& sym1 = interference.interaction1();
	const Symbol& sym2 = interference.interaction2();

	BIPInteractionInterference* key = new BIPInteractionInterference(sym1,sym2);

	interaction_const_iterator tit = bip_interaction_interferences_.find(key);

	if(tit != bip_interaction_interferences_.end())
	{
		BIPInteractionInterference *old_interference = *tit;
		bip_interaction_interferences_.erase(tit);
		delete old_interference;
	}
	delete key;
}


}

