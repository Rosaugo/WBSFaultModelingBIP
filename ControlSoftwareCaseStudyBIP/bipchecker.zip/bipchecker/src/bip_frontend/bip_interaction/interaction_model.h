/*
 * interaction_model.h
 *
 *  Created on: Nov 26, 2014
 *      Author: wangqiang
 */

#ifndef INTERACTION_MODEL_H_
#define INTERACTION_MODEL_H_

#include "bip_frontend/bip_interaction/interaction.h"

namespace bipchecker{


//! this class is responsible for the destruction of
//! interaction models
//! Note:
//! the set of interactions are concrete instances,
//! they may have the same interaction name, hence
//! the associated CFA is the same, but the
//! involved ports are different.
//! Throughout the project, we will only use one object
//! of the class, which is created when building the
//! the super CFA. All the kernel states shoule point to
//! this object, and can not modify it.

class InteractionModel{

	typedef std::vector< BIPInteraction *> interaction_list;
	interaction_list InteractionList;

public:
	explicit InteractionModel(){}

	typedef interaction_list::const_iterator const_iterator;
	const_iterator const_interaction_begin() const {return InteractionList.begin();}
	const_iterator const_interaction_end() const {return InteractionList.end();}

	typedef interaction_list::iterator iterator;
	iterator interaction_begin() {return InteractionList.begin();}
	iterator interaction_end() {return InteractionList.end();}

	~InteractionModel(){

		for(const_iterator it = const_interaction_begin();
				it!=const_interaction_end();++it)
		{
			if(*it) delete (*it);
		}

		InteractionList.clear();
	}

	//! it should return possibly a set of interactions
	std::vector<BIPInteraction*> get_interaction(const std::string& name) const
	{
		std::vector<BIPInteraction*> temp;
		for(const_iterator it = const_interaction_begin();
				it!= const_interaction_end(); ++it)
		{
			if((*it)->get_name() == name)
			{
				temp.push_back(*it);
			}
		}
		return temp;
	}

	void add_interaction( BIPInteraction * newinteraction){
		if(newinteraction) InteractionList.push_back(newinteraction);
	}

	void print_interactions(std::ostream & out) const
	{
		for(const_iterator it = const_interaction_begin();
				it != const_interaction_end(); ++it)
		{
			(*it)->print_interaction(out);
			out << std::endl;
		}
	}

};


}


#endif /* INTERACTION_MODEL_H_ */
