/*
 * interaction_extractor.cc
 *
 *  Created on: Nov 26, 2014
 *      Author: wangqiang
 */

#include "bip_frontend/bip_interaction/interaction_extractor.h"

#include <assert.h>

namespace bipchecker{

ASTStatement*
InteractionExtractor::visit_action(const ASTStatement* statement){

	ASTStatement* result = 0;

	const ASTExpressionStatement* expr_stat =
			dynamic_cast<const ASTExpressionStatement*>(statement);
	const ASTIfStatement* if_stat =
			dynamic_cast<const ASTIfStatement*>(statement);
	const ASTCompoundStatement* comp =
			dynamic_cast<const ASTCompoundStatement*>(statement);

	if(expr_stat != 0){

		result = new ASTExpressionStatement(visit_expression(expr_stat->expression()));

	} else if(if_stat != 0){

		ASTExpression* new_guard = visit_expression(if_stat->condition());
		ASTStatement* new_then_clause = visit_action(if_stat->then_clause());

		ASTStatement* new_else_clause = 0;
		if(if_stat->else_clause() != 0)
			new_else_clause = visit_action(if_stat->else_clause());

		result = new ASTIfStatement(new_guard, new_then_clause, new_else_clause);

	} else if(comp != 0){
		ASTStatement* temp = 0;
		ASTCompoundStatement* temp_comp = new ASTCompoundStatement();
		for(ASTCompoundStatement::const_iterator ccit = comp->begin();
				ccit != comp->end(); ++ccit){
			if(*ccit){
				temp = visit_action(*ccit);
				temp_comp->add_statement(temp);
			}
		}
		result = temp_comp;
	}

	return result;
}

ASTExpression*
InteractionExtractor::visit_expression(const ASTExpression* expression){

	ASTExpression* result = 0;

	const ASTIdExpression* id_expr =
			dynamic_cast<const ASTIdExpression*>(expression);
	const ASTUnaryExpression* unary_expr =
			dynamic_cast<const ASTUnaryExpression*>(expression);
	const ASTBinaryExpression* binary_expr =
			dynamic_cast<const ASTBinaryExpression*>(expression);
	const ASTLiteralExpression* literal_expr =
			dynamic_cast<const ASTLiteralExpression*>(expression);
	const ASTQualifiedIdExpression* qualify_id =
			dynamic_cast<const ASTQualifiedIdExpression*>(expression);
	const ASTExpressionList* expr_list =
			dynamic_cast<const ASTExpressionList*>(expression);

	if(id_expr != 0){

		result = id_expr->clone();

	} else if(unary_expr != 0){

		ASTExpression* new_unary_expr =
				new ASTUnaryExpression(unary_expr->un_operator(), visit_expression(unary_expr->operand()));

		result = new_unary_expr;

	} else if(binary_expr != 0){

		ASTExpression* new_binary_expr =
				new ASTBinaryExpression( visit_expression(binary_expr->operand1()),binary_expr->bin_operator(),
						visit_expression(binary_expr->operand2()));

		result = new_binary_expr;

	} else if(literal_expr != 0){

		result = literal_expr->clone();

	} else if(qualify_id != 0){

		//! this formal port name and variable name will be substituted
		std::string port_name = qualify_id->qualifier()->name();
		std::string var_name = qualify_id->name()->name();

		//! find the atom, which declares this port
		std::string atom_name("");
		std::string actual_port_name("");
		std::vector<const ASTQualifiedIdExpression*>::const_iterator actual_id = temp_actual_parameters_.begin();
		for(std::vector<const ASTPortDeclaration*>::const_iterator pit = temp_formal_parameters_.begin();
				pit != temp_formal_parameters_.end(); ++pit, ++actual_id){
			if(*pit){
				std::string temp_port_name = (*pit)->name()->name()->name();
				if(temp_port_name == port_name){
					atom_name = (*actual_id)->qualifier()->name();
					actual_port_name = (*actual_id)->name()->name();
					break;
				}
			}
		}

		//! find the atom type
		std::string atom_type_name("");
		for(std::vector<const ASTAtomDeclaration*>::const_iterator cit = temp_atom_decls_.begin();
				cit != temp_atom_decls_.end(); ++cit){
			if(*cit){
				std::string temp_atom_name = (*cit)->name()->name()->name();
				if(temp_atom_name == atom_name){
					atom_type_name = (*cit)->type()->name()->name();
				}
			}
		}

		for(std::vector<const ASTAtomDefinition*>::const_iterator acit = temp_atom_def_.begin();
				acit != temp_atom_def_.end(); ++acit){

			if(*acit){
				//! find the type with name atom_type_name
				std::string temp_name = (*acit)->name()->name()->name();
				if(temp_name == atom_type_name){

					//! find the actual port
					const ASTDeclaration* actual_decls = (*acit)->port_declarations();
					const ASTPortDeclaration* actual_single_port=
							dynamic_cast<const ASTPortDeclaration*>(actual_decls);
					const ASTDeclarationList* actual_list_decl=
							dynamic_cast<const ASTDeclarationList*>(actual_decls);
					if(actual_single_port != 0){

						std::string temp_single_name = actual_single_port->name()->name()->name();

						if(temp_single_name == actual_port_name){

							const ASTExpression* port_paras = actual_single_port->parameters();
							const ASTIdExpression* single_para =
									dynamic_cast<const ASTIdExpression*>(port_paras);
							const ASTExpressionList* list_para =
									dynamic_cast<const ASTExpressionList*>(port_paras);

							if(single_para != 0){

								actual_vars_.push_back(single_para->name()->name());

							} else if(list_para != 0){

								for(ASTExpressionList::const_iterator ecit = list_para->begin();
										ecit != list_para->end(); ++ecit){
									if(*ecit){
										const ASTIdExpression* temp_id_expr=
												dynamic_cast<const ASTIdExpression*>(*ecit);
										assert(temp_id_expr != 0);

										actual_vars_.push_back(temp_id_expr->name()->name());
									}
								}
							}

							break;
						}

					} else if(actual_list_decl != 0){
						for(ASTDeclarationList::const_iterator dcit = actual_list_decl->begin();
								dcit != actual_list_decl->end(); ++dcit){
							if(*dcit){
								const ASTPortDeclaration* temp_port_decl =
										dynamic_cast<const ASTPortDeclaration*>(*dcit);
								std::string temp_port_name = temp_port_decl->name()->name()->name();

								if(temp_port_name == actual_port_name){

									const ASTExpression* port_paras = temp_port_decl->parameters();
									const ASTIdExpression* single_para =
											dynamic_cast<const ASTIdExpression*>(port_paras);
									const ASTExpressionList* list_para =
											dynamic_cast<const ASTExpressionList*>(port_paras);

									if(single_para != 0){
										actual_vars_.push_back(single_para->name()->name());
									} else if(list_para != 0){
										for(ASTExpressionList::const_iterator ecit = list_para->begin();
												ecit != list_para->end(); ++ecit){
											if(*ecit){
												const ASTIdExpression* temp_id_expr=
														dynamic_cast<const ASTIdExpression*>(*ecit);
												assert(temp_id_expr != 0);
												actual_vars_.push_back(temp_id_expr->name()->name());
											}
										}
									}

									break;
								}

							}
						}
					}

				}

			}
		} //! end atom definition

		//! find the port type definition
		for(std::vector<const ASTPortDefinition*>::const_iterator pcit = temp_port_def_.begin();
				pcit != temp_port_def_.end(); ++pcit){
			if(*pcit){

				std::string temp_name = (*pcit)->name()->name()->name();
				if(temp_name == port_type_name_){

					//!
					const ASTDeclaration* port_para_decl = (*pcit)->parameters();
					const ASTDataDeclaration* single_data =
							dynamic_cast<const ASTDataDeclaration*>(port_para_decl);
					const ASTDeclarationList* list_data=
							dynamic_cast<const ASTDeclarationList*>(port_para_decl);

					if(single_data != 0){

						formal_vars_.push_back(single_data->name()->name()->name());

					} else if(list_data != 0){
						for(ASTDeclarationList::const_iterator vcit = list_data->begin();
								vcit != list_data->end(); ++vcit){
							if(*vcit){
								const ASTDataDeclaration* temp_data =
										dynamic_cast<const ASTDataDeclaration*>(*vcit);

								assert(temp_data != 0);
								formal_vars_.push_back(temp_data->name()->name()->name());
							}
						}
					}
				}

			}
		} //! end port definition

		std::string actual_var_name("");
		std::vector<std::string>::const_iterator ascit = actual_vars_.begin();
		for(std::vector<std::string>::const_iterator scit = formal_vars_.begin();
				scit != formal_vars_.end(); ++scit, ++ascit){
			if((*scit) == var_name){
				actual_var_name = (*ascit);
			}
		}

		ASTQualifiedIdExpression* new_qualified_var =
				new ASTQualifiedIdExpression(new ASTName(atom_name), new ASTName(actual_var_name));

		result = new_qualified_var;

	} else if(expr_list != 0){
		ASTExpressionList* temp_list = new ASTExpressionList();
		for (ASTExpressionList::const_iterator cit = expr_list->begin();
				cit != expr_list->end(); ++cit) {
			if(*cit){
				temp_list->add_expression(visit_expression(*cit));
			}
		}
		result = temp_list;
	}

	return result;
}


int InteractionExtractor::visit(const ASTTransition* transition) {

	const ASTInteraction* interaction =
			dynamic_cast<const ASTInteraction*>(transition);
	assert(interaction != 0);

	const ASTExpression* guard = interaction->guard();
	const ASTStatement* action = interaction->action();

	if(guard != 0){
		temp_guard_ = visit_expression(guard);
	}

	if(action != 0){
		temp_action_ = visit_action(action);
	}

	return ASTVisitor::SKIP;
}

int InteractionExtractor::visit(const ASTTranslationUnit* unit) {

	if(im_ != 0)
		delete im_;

	im_ = new InteractionModel();

	//! first find all the connector definitions
	//! and keep them in the temporal vector
	for(ASTTranslationUnit::const_iterator cit = unit->begin();
			cit != unit->end(); ++cit){
		if(*cit){
			const ASTConnectorDefinition* cnt_def =
					dynamic_cast<const ASTConnectorDefinition*>(*cit);

			const ASTAtomDefinition* atom_def =
					dynamic_cast<const ASTAtomDefinition*>(*cit);

			const ASTCompoundDefinition* comp_def =
					dynamic_cast<const ASTCompoundDefinition*>(*cit);

			const ASTPortDefinition* port_def =
					dynamic_cast<const ASTPortDefinition*>(*cit);

			if(cnt_def != 0)
				temp_cnt_def_.push_back(cnt_def);
			else if(atom_def != 0)
				temp_atom_def_.push_back(atom_def);
			else if(comp_def != 0){
				const ASTDeclaration* atom_decls = comp_def->components();

				const ASTAtomDeclaration* single_decl =
						dynamic_cast<const ASTAtomDeclaration*>(atom_decls);
				const ASTDeclarationList* list_decl =
						dynamic_cast<const ASTDeclarationList*>(atom_decls);

				if(single_decl != 0){

					temp_atom_decls_.push_back(single_decl);

				} else if(list_decl != 0){
					for(ASTDeclarationList::const_iterator cdit = list_decl->begin();
							cdit != list_decl->end(); ++cdit){
						if(*cdit){
							const ASTAtomDeclaration* temp =
									dynamic_cast<const ASTAtomDeclaration*>(*cdit);
							assert(temp != 0);
							temp_atom_decls_.push_back(temp);
						}
					}
				}

			} //! end comp_def
			else if(port_def != 0){
				temp_port_def_.push_back(port_def);
			}

		}
	} // end for

	for(ASTTranslationUnit::const_iterator cit = unit->begin(); cit != unit->end(); ++cit){
		if(*cit){

			//! in this function, we only visit compound component definition
			//! to extract the interaction declarations
			const ASTCompoundDefinition* comp_def =
					dynamic_cast<const ASTCompoundDefinition*>(*cit);

			if(comp_def != 0){
				//! get the connector declarations
				const ASTDeclaration* connector_decls_ = comp_def->connectors();

				//! check if it is a lit or a singleton
				const ASTConnectorDeclaration* single_decl =
						dynamic_cast<const ASTConnectorDeclaration*>(connector_decls_);
				const ASTDeclarationList* list_decl =
						dynamic_cast<const ASTDeclarationList*>(connector_decls_);

				if(single_decl != 0){
					std::string interaction_name = single_decl->name()->name()->name();
					BIPInteraction* new_ia = new BIPInteraction(interaction_name);
					size_t rank = 0;

					//! get the parameters
					const ASTExpression* paras_ = single_decl->parameters();
					temp_actual_parameters_.clear();
					temp_formal_parameters_.clear();
					actual_vars_.clear();
					formal_vars_.clear();

					const ASTQualifiedIdExpression* qualified_id =
							dynamic_cast<const ASTQualifiedIdExpression*>(paras_);
					const ASTExpressionList* expr_list =
							dynamic_cast<const ASTExpressionList*>(paras_);

					if(qualified_id != 0){
						std::string comp_name = qualified_id->qualifier()->name();
						std::string port_name = qualified_id->name()->name();

						BIPPort* new_port = new BIPPort(port_name, comp_name);
						new_ia->add_port(new_port);
						if(unit->component_involved(comp_name)){
							rank++;
						}

						temp_actual_parameters_.push_back(qualified_id);

					} else if(expr_list != 0){

						for(ASTExpressionList::const_iterator ceit = expr_list->begin();
								ceit != expr_list->end(); ++ceit){
							if(*ceit){
								//! for each parameter
								const ASTQualifiedIdExpression* temp_qualified_id =
										dynamic_cast<const ASTQualifiedIdExpression*>(*ceit);
								assert(temp_qualified_id != 0);

								std::string temp_comp_name = temp_qualified_id->qualifier()->name();
								std::string temp_port_name = temp_qualified_id->name()->name();

								BIPPort* temp_port = new BIPPort(temp_port_name, temp_comp_name);
								new_ia->add_port(temp_port);
								if(unit->component_involved(temp_comp_name))
									rank++;

								temp_actual_parameters_.push_back(temp_qualified_id);
							}
						}

					}
					new_ia->set_rank(rank);

					//! check if there is data transfer by looking at the connector definition
					std::string cnt_type_name = single_decl->type()->name()->name();
					for(std::vector<const ASTConnectorDefinition*>::const_iterator cit = temp_cnt_def_.begin();
							cit != temp_cnt_def_.end(); ++cit){
						//! find the connector definition with the name cnt_type_name
						std::string temp_name = (*cit)->name()->name()->name();
						if(temp_name == cnt_type_name){
							const ASTConnectorDefinition* temp_cnt_def = (*cit);
							const ASTTransition* cnt_act = temp_cnt_def->interactions();
							if(cnt_act != 0){
								//! this interaction has data transfer
								//! then create a new cfa associated to this new interaction
								CFA *cfa = new CFA(std::string(""));

								assert(!temp_actual_parameters_.empty());

								const ASTDeclaration* paras = temp_cnt_def->parameters();
								const ASTPortDeclaration* port_decl =
										dynamic_cast<const ASTPortDeclaration*>(paras);
								const ASTDeclarationList* decl_list =
										dynamic_cast<const ASTDeclarationList*>(paras);

								if(port_decl != 0){
									assert(temp_actual_parameters_.size() == 1);
									temp_formal_parameters_.push_back(port_decl);

									port_type_name_ = port_decl->type()->name()->name();

								} else if(decl_list != 0){
									assert(temp_actual_parameters_.size() == decl_list->size());
									for(ASTDeclarationList::const_iterator dcit = decl_list->begin();
											dcit != decl_list->end(); ++dcit){
										const ASTPortDeclaration* temp_port_decl =
												dynamic_cast<const ASTPortDeclaration*>(*dcit);
										temp_formal_parameters_.push_back(temp_port_decl);

										port_type_name_ = temp_port_decl->type()->name()->name();
									}
								}

								//! prepare the data structure to visit the transition
								cnt_act->accept(*this);

								CFANode& init_loc = cfa->create_node();
								init_loc.set_line_no(single_decl->node_location().start_line_number());

								cfa->add_edge(cfa->entry(),0, temp_guard_, temp_action_, init_loc, false);

								new_ia->set_cfa(cfa);
							}
						}
					}

					im_->add_interaction(new_ia);

				} else if(list_decl != 0){//! for a list of connector declarations

					for(ASTDeclarationList::const_iterator cdit = list_decl->begin();
							cdit != list_decl->end(); ++cdit){
						if(*cdit){
							//! for each connector declaration

							temp_actual_parameters_.clear();
							temp_formal_parameters_.clear();
							actual_vars_.clear();
							formal_vars_.clear();
							temp_guard_ = 0;
							temp_action_ = 0; //!! delete the old one?


							const ASTConnectorDeclaration* temp_cnt_decl =
									dynamic_cast<const ASTConnectorDeclaration*>(*cdit);

							assert(temp_cnt_decl != 0);

							std::string interaction_name = temp_cnt_decl->name()->name()->name();
							BIPInteraction* new_ia = new BIPInteraction(interaction_name);
							size_t rank = 0;

							//! get the parameters
							const ASTExpression* paras_ = temp_cnt_decl->parameters();

							const ASTQualifiedIdExpression* qualified_id =
									dynamic_cast<const ASTQualifiedIdExpression*>(paras_);
							const ASTExpressionList* expr_list =
									dynamic_cast<const ASTExpressionList*>(paras_);

							if(qualified_id != 0){
								std::string comp_name = qualified_id->qualifier()->name();
								std::string port_name = qualified_id->name()->name();

								BIPPort* new_port = new BIPPort(port_name, comp_name);
								new_ia->add_port(new_port);
								if(unit->component_involved(comp_name))
									rank++;

								temp_actual_parameters_.push_back(qualified_id);

							} else if(expr_list != 0){

								for(ASTExpressionList::const_iterator ceit = expr_list->begin();
										ceit != expr_list->end(); ++ceit){
									if(*ceit){
										//! for each parameter
										const ASTQualifiedIdExpression* temp_qualified_id =
												dynamic_cast<const ASTQualifiedIdExpression*>(*ceit);
										assert(temp_qualified_id != 0);

										std::string temp_comp_name = temp_qualified_id->qualifier()->name();
										std::string temp_port_name = temp_qualified_id->name()->name();

										BIPPort* temp_port = new BIPPort(temp_port_name, temp_comp_name);
										new_ia->add_port(temp_port);
										if(unit->component_involved(temp_comp_name))
											rank++;

										temp_actual_parameters_.push_back(temp_qualified_id);
									}
								}

							}
							new_ia->set_rank(rank);


							//! check if there is data transfer by looking at the connector definition
							std::string cnt_type_name = temp_cnt_decl->type()->name()->name();
							for(std::vector<const ASTConnectorDefinition*>::const_iterator cit = temp_cnt_def_.begin();
									cit != temp_cnt_def_.end(); ++cit){
								//! find the connector definition with the name cnt_type_name
								std::string temp_name = (*cit)->name()->name()->name();
								if(temp_name == cnt_type_name){
									const ASTConnectorDefinition* temp_cnt_def = (*cit);
									const ASTTransition* cnt_act = temp_cnt_def->interactions();
									if(cnt_act != 0){
										//! this interaction has data transfer
										//! then create a new cfa associated to this new interaction
										CFA *cfa = new CFA(std::string(""));

										assert(!temp_actual_parameters_.empty());

										const ASTDeclaration* paras = temp_cnt_def->parameters();
										const ASTPortDeclaration* port_decl =
												dynamic_cast<const ASTPortDeclaration*>(paras);
										const ASTDeclarationList* decl_list =
												dynamic_cast<const ASTDeclarationList*>(paras);

										if(port_decl != 0){
											assert(temp_actual_parameters_.size() == 1);
											temp_formal_parameters_.push_back(port_decl);

											port_type_name_ = port_decl->type()->name()->name();

										} else if(decl_list != 0){
											assert(temp_actual_parameters_.size() == decl_list->size());
											for(ASTDeclarationList::const_iterator dcit = decl_list->begin();
													dcit != decl_list->end(); ++dcit){
												const ASTPortDeclaration* temp_port_decl =
														dynamic_cast<const ASTPortDeclaration*>(*dcit);
												temp_formal_parameters_.push_back(temp_port_decl);

												port_type_name_ = temp_port_decl->type()->name()->name();
											}
										}

										//! prepare the data structure to visit the transition
										cnt_act->accept(*this);

										CFANode& init_loc = cfa->create_node();
										init_loc.set_line_no(temp_cnt_decl->node_location().start_line_number());

										cfa->add_edge(cfa->entry(),0, temp_guard_, temp_action_, init_loc, false);

										new_ia->set_cfa(cfa);
									}
								}
							}

							im_->add_interaction(new_ia);

						}
					}

				} //! end list of connectors

			}//! end comp_def

		}
	}

	return ASTVisitor::SKIP;
}


}


