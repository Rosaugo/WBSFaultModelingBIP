/*
 * interaction.cc
 *
 *  Created on: Nov 26, 2014
 *      Author: wangqiang
 */

#include "bip_frontend/bip_interaction/interaction.h"

namespace bipchecker{

size_t BIPInteraction::fresh_id_ = 0;

}


