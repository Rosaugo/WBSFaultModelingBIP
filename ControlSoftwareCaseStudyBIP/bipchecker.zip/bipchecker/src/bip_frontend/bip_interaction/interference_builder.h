/*
 * interference_builder.h
 *
 *  Created on: Dec 2, 2014
 *      Author: wangqiang
 */

#ifndef INTERFERENCE_BUILDER_H_
#define INTERFERENCE_BUILDER_H_

#include "util/util.h"
#include "bip_frontend/bip_interaction/interference_relation.h"

namespace bipchecker{


class BIPInterferenceBuilder {

	const InteractionModel& im_;

	BIPInterferenceRelation* bip_interference_relation_;

public:
	explicit BIPInterferenceBuilder(const InteractionModel& im)
	: im_(im),
	  bip_interference_relation_(0){
	}

    void build_interferences();

    BIPInterferenceRelation* get_interference_relation() const{
    	return bip_interference_relation_;
    }

    ~BIPInterferenceBuilder(){ }

private:

    void build_interaction_interference(BIPInterferenceRelation& interference) const;

    bool has_same_thread(const BIPInteraction* i1, const BIPInteraction* i2) const;

    DISALLOW_COPY_AND_ASSIGN(BIPInterferenceBuilder);

};


}


#endif /* INTERFERENCE_BUILDER_H_ */
