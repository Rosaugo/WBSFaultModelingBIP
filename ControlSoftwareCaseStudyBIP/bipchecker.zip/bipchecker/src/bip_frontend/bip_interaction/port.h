/*
 * port.h
 *
 *  Created on: Nov 26, 2014
 *      Author: wangqiang
 */

#ifndef PORT_H_
#define PORT_H_


namespace bipchecker{

class BIPPort{

	std::string portName;

	std::string threadName;

public:
	explicit BIPPort(std::string& portname, std::string& threadname)
	: portName(portname), threadName(threadname) {}

	~BIPPort() {}

	bool equals(const BIPPort * port) const {
		return (portName==(port->get_PortName())) and (threadName==(port->get_threadName()));
	}

	bool is_from_thread(std::string& threadname) const {
		return threadName == threadname ? true: false;
	}

	std::string get_PortName() const{ return portName; }

	std::string get_threadName() const { return threadName; }

	void print_port(std::ostream & out) const { out << portName; }
};

}

#endif /* PORT_H_ */
