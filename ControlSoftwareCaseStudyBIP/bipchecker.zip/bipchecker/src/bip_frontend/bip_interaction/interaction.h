/*
 * interaction.h
 *
 *  Created on: Nov 26, 2014
 *      Author: wangqiang
 */

#ifndef INTERACTION_H_
#define INTERACTION_H_

#include "bip_cfa/cfa.h"
#include "bip_frontend/bip_interaction/port.h"
#include "util/symbol.h"

namespace bipchecker{

/*
 * class for individual definition of interaction
 * this class can not change the Port objects.
 *
 */
class BIPInteraction {

	//! name of this interaction
	std::string name;

	static size_t fresh_id_;

	size_t interaction_id_;

	//! CFA representation of the data transfer
	//! this cfa is owned by BIPInteraction object
	CFA* cfa_;

	//! set of ports involved in this interaction
	//! the interaction class is responsible for the
	//! destruction of Port objects
	typedef std::vector<const BIPPort *> port_list;

	port_list ports;

	//! the rank level based on if it involves the target component
	//! if rank_ is greater than 0, then it is involved
	size_t rank_;

public:

	typedef port_list::const_iterator const_iterator;

	explicit BIPInteraction(const std::string & n)
	: name(n), interaction_id_(fresh_id_++), cfa_(0), rank_(0){
	}

	size_t rank() const {return rank_;}

	void set_rank(size_t rank){ rank_ = rank;}

	size_t number_of_ports() const {return ports.size();}

	const_iterator const_begin() const {return ports.begin();}
	const_iterator const_end() const {return ports.end();}

	void add_port(const BIPPort * port){
	  if(port and !has_port(port))
	    ports.push_back(port);
	}

	bool has_port(const BIPPort * port) const {
		for(const_iterator it=const_begin(); it!=const_end(); ++it){
			if((*it)->equals(port)){
				return true;
			}
		}
		return false;
	}


	bool has_port(const Symbol& port_name) const {
		for(const_iterator it = const_begin(); it != const_end(); ++it){
			const BIPPort* port = (*it);
			if(port->get_PortName() == port_name.to_string()){
				return true;
			}
		}
		return false;
	}

	bool involved_port(std::string component, std::string port) const {

		for(const_iterator it = const_begin(); it != const_end(); ++it){

			const BIPPort* bip_port = (*it);

			if(bip_port->get_PortName() == port
					&& bip_port->get_threadName() == component){
				return true;
			}

		}
		return false;
	}

	void set_name(const std::string & i_name)  {name = i_name;}

	std::string get_name() const {return name;}

	CFA * get_cfa() const {return cfa_;}

	void set_cfa( CFA* cfa){
		if(cfa_ != 0)
			delete cfa_;

		cfa_ = cfa;
	}

	size_t interaction_id() const {return interaction_id_;}

	//! this function checks if the interaction has defined data transfer.
	bool has_data_transfer() const {
		return (cfa_ != 0 && cfa_->size()==2);
	}

	//! Computes hash code of this atomic block id.
	/*!
	 * \return The hash code of this atomic block id.
	 */
	size_t hash_code() const {
	  size_t hash_num = 1;

	  hash_num = 31 * hash_num + interaction_id_;

	  return hash_num;
	}

	void print_interaction(std::ostream & out) const
	{
		out << "interaction " << name << ": ";
		for(const_iterator it=const_begin();it!=const_end();++it)
		{
			(*it)->print_port(out);
			out << " ";
		}
		out << std::endl;
	}

	~BIPInteraction()
	{
		for(const_iterator it=const_begin();it!=const_end();++it)
		{
			if(*it){delete (*it);}
		}
		ports.clear();

		if(cfa_ != 0)
			delete cfa_;
	}

};


//! Struct for interaction id equality.
struct EqBIPInteraction {

    size_t operator() (const BIPInteraction *id) const
    {
	return id->hash_code();
    }

	bool operator()(const BIPInteraction *e1, const BIPInteraction *e2) const {
		if (e1 && !e2)
			return false;
		if (!e1 && e2)
			return false;
		if ((!e1 && !e2) || (e1 && e2 && e1->interaction_id() == e2->interaction_id()))
			return true;

		return false;
	}

};

//! Struct for interaction less-than inequality.
struct LtBIPInteraction {

	bool operator()(const BIPInteraction *e1, const BIPInteraction *e2) const {
		return (e1->interaction_id() < e2->interaction_id());
	}

};

struct RankBIPInteraction{
	bool operator()(const BIPInteraction* e1, const BIPInteraction* e2) const{
		if(e1->rank() > e2->rank())
			return true;
		else if(e1->rank() == e2->rank() && e1->number_of_ports() > e2->number_of_ports())
			return true;
		else
			return false;
		//return (e1->rank() > e2->rank());
	}
};

}

hash_fun_namespace_open {

//! Struct for interaction hash function.
	template<> struct hash<const bipchecker::BIPInteraction*>
	{

		size_t operator() (const bipchecker::BIPInteraction *e) const
		{
			return e->interaction_id();
		}

	};

}
hash_fun_namespace_close;




#endif /* INTERACTION_H_ */
