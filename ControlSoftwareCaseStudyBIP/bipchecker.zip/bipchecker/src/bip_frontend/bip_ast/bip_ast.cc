/*
 * bip_ast.cc
 *
 *  Created on: Oct 30, 2014
 *      Author: wangqiang
 */

#include "bip_frontend/bip_ast/bip_ast.h"
#include "bip_frontend/bip_ast/ast_visitor.h"

namespace bipchecker {

bool ASTName::accept(ASTVisitor& v) const {

	if (v.visit_name) {

		switch (v.visit(this)) {

		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	if (v.visit_name) {

		switch (v.leave(this)) {

		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}

	}

	return true;
}

ASTBinaryExpression::ASTBinaryExpression(const ASTBinaryExpression& expr) :
		ASTExpression(expr) {
	operand1_ = 0;
	operand2_ = 0;

	if (expr.operand1_)
		set_operand1(expr.operand1_->clone());

	bin_operator_ = expr.bin_operator_;

	if (expr.operand2_)
		set_operand2(expr.operand2_->clone());

}

ASTBinaryExpression& ASTBinaryExpression::operator=(
		const ASTBinaryExpression& expr) {
	if (this != &expr) {
		if (operand1_) {
			delete operand1_;
			operand1_ = 0;
		}

		if (operand2_) {
			delete operand2_;
			operand2_ = 0;
		}

		ASTExpression::operator=(expr);

		if (expr.operand1_)
			set_operand1(expr.operand1_->clone());

		bin_operator_ = expr.bin_operator_;

		if (expr.operand2_)
			set_operand2(expr.operand2_->clone());
	}
	return *this;
}

bool ASTBinaryExpression::is_boolean_expression() const {
	if (bin_operator_ == OP_EQ || bin_operator_ == OP_GE
			|| bin_operator_ == OP_GT || bin_operator_ == OP_LE
			|| bin_operator_ == OP_LT || bin_operator_ == OP_AND
			|| bin_operator_ == OP_OR || bin_operator_ == OP_NE)
		return true;

	return false;
}

bool ASTBinaryExpression::accept(ASTVisitor& v) const {
	if (v.visit_expression) {

		switch (v.visit(this)) {

		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	if (operand1_ && !(operand1_->accept(v)))
		return false;

	if (operand2_ && !(operand2_->accept(v)))
		return false;

	if (v.visit_expression) {
		switch (v.leave(this)) {

		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	return true;
}

/*
// class ASTConditionalExpression
ASTConditionalExpression::ASTConditionalExpression(
		const ASTConditionalExpression& expr) :
		ASTExpression(expr) {

	condition_ = 0;
	true_expression_ = 0;
	false_expression_ = 0;

	if (expr.condition_)
		set_condition(expr.condition_->clone());

	if (expr.true_expression_)
		set_true_expression(expr.true_expression_->clone());

	if (expr.false_expression_)
		set_false_expression(expr.false_expression_->clone());

}

ASTConditionalExpression& ASTConditionalExpression::operator=(
		const ASTConditionalExpression& expr) {
	if (this != &expr) {

		if (condition_) {
			delete condition_;
			condition_ = 0;
		}

		if (true_expression_) {
			delete true_expression_;
			true_expression_ = 0;
		}

		if (false_expression_) {
			delete false_expression_;
			false_expression_ = 0;
		}

		ASTExpression::operator=(expr);

		if (expr.condition_)
			set_condition(expr.condition_->clone());

		if (expr.true_expression_)
			set_true_expression(expr.true_expression_->clone());

		if (expr.false_expression_)
			set_false_expression(expr.false_expression_->clone());

	}

	return *this;
}

bool ASTConditionalExpression::accept(ASTVisitor& v) const {
	if (v.visit_expression) {

		switch (v.visit(this)) {

		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	if (condition_ && !(condition_->accept(v)))
		return false;

	if (true_expression_ && !(true_expression_->accept(v)))
		return false;

	if (false_expression_ && !(false_expression_->accept(v)))
		return false;

	if (v.visit_expression) {

		switch (v.leave(this)) {

		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	return true;
}
*/

// class ASTExpressionList
ASTExpressionList::ASTExpressionList(const ASTExpressionList& expr) :
		ASTExpression(expr) {
	for (const_iterator cit = expr.begin(); cit < expr.end(); ++cit) {

		if (*cit)
			add_expression((*cit)->clone());
	}
}

ASTExpressionList& ASTExpressionList::operator=(const ASTExpressionList& expr) {
	if (this != &expr) {

		for (iterator it = expressions_.begin(); it < expressions_.end();
				++it) {

			if (*it)
				delete *it;
		}

		expressions_.clear();

		ASTExpression::operator=(expr);

		for (const_iterator cit = expr.begin(); cit < expr.end(); ++cit) {

			if (*cit)
				add_expression((*cit)->clone());
		}
	}
	return *this;
}

bool ASTExpressionList::accept(ASTVisitor& v) const {

	if (v.visit_expression) {

		switch (v.visit(this)) {

		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	for (const_iterator cit = begin(); cit < end(); ++cit) {

		if (*cit) {
			if (!((*cit)->accept(v)))
				return false;
		}
	}

	if (v.visit_expression) {
		switch (v.leave(this)) {

		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	return true;
}

ASTExpressionList::~ASTExpressionList() {
	for (iterator it = expressions_.begin(); it < expressions_.end(); ++it) {

		if (*it)
			delete *it;
	}

	expressions_.clear();
}

// class ASTIdExpression
ASTIdExpression::ASTIdExpression(const ASTIdExpression& expr) :
		ASTExpression(expr) {
	name_ = 0;

	if (expr.name_)
		set_name(new ASTName(*(expr.name_)));
}

ASTIdExpression& ASTIdExpression::operator=(const ASTIdExpression& expr) {
	if (this != &expr) {

		if (name_) {
			delete name_;
			name_ = 0;
		}

		ASTExpression::operator=(expr);

		if (expr.name_)
			set_name(new ASTName(*(expr.name_)));

	}

	return *this;
}

bool ASTIdExpression::accept(ASTVisitor& v) const {
	if (v.visit_expression) {

		switch (v.visit(this)) {

		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	if (name_ && !(name_->accept(v)))
		return false;

	if (v.visit_expression) {

		switch (v.leave(this)) {

		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}
	return true;
}

bool ASTQualifiedIdExpression::accept(ASTVisitor& v) const{

	if (v.visit_expression) {

		switch (v.visit(this)) {

		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	if(qualifier_ && !(qualifier_->accept(v)))
		return false;

	if (name_ && !(name_->accept(v)))
		return false;

	if (v.visit_expression) {

		switch (v.leave(this)) {

		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}
	return true;

}

// class ASTLiteralExpression
ASTLiteralExpression::ASTLiteralExpression(const ASTLiteralExpression& expr) :
		ASTExpression(expr), value_(expr.value_), kind_(expr.kind_) {
}

ASTLiteralExpression& ASTLiteralExpression::operator=(
		const ASTLiteralExpression& expr) {
	if (this != &expr) {

		ASTExpression::operator=(expr);

		value_ = expr.value_;
		kind_ = expr.kind_;

	}
	return *this;
}

bool ASTLiteralExpression::accept(ASTVisitor& v) const {

	if (v.visit_expression) {

		switch (v.visit(this)) {

		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	if (v.visit_expression) {

		switch (v.leave(this)) {

		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	return true;
}

// class ASTUnaryExpression
ASTUnaryExpression::ASTUnaryExpression(const ASTUnaryExpression& expr) :
		ASTExpression(expr) {
	operand_ = 0;

	if (expr.operand_)
		set_operand(expr.operand_->clone());

	un_operator_ = expr.un_operator_;
}

ASTUnaryExpression& ASTUnaryExpression::operator=(
		const ASTUnaryExpression& expr) {
	if (this != &expr) {

		if (operand_) {
			delete operand_;
			operand_ = 0;
		}

		ASTExpression::operator=(expr);

		if (expr.operand_)
			set_operand(expr.operand_->clone());

		un_operator_ = expr.un_operator_;

	}

	return *this;
}

bool ASTUnaryExpression::is_boolean_expression() const {
	if (un_operator_ == OP_NOT)
		return true;

	return false;
}

bool ASTUnaryExpression::accept(ASTVisitor& v) const {
	if (v.visit_expression) {

		switch (v.visit(this)) {

		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	if (operand_ && !(operand_->accept(v)))
		return false;

	if (v.visit_expression) {

		switch (v.leave(this)) {

		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	return true;
}

bool ASTExpression::is_boolean_expression() const {
#warning [MRIN]: Check if the implementation of is_boolean_expression is correct
#warning [INMR]: The impl. is correct, but the proper (and recommended) way of
#warning [INMR]: localizing the impl. (that is, in object-oriented way) is to have
#warning [INMR]: the default in the super class, while the specialization in
#warning [INMR]: the corresponding subclass.
#warning [INMR]: With the proper impl. we avoid performing static/dynamic cast.
	return false;
}

// class ASTCompoundStatement
ASTCompoundStatement::ASTCompoundStatement(const ASTCompoundStatement& stmt) :
		ASTStatement(stmt) // ASTNode(stmt), ASTStatement(stmt)
{
	for (const_iterator cit = stmt.begin(); cit < stmt.end(); ++cit) {

		if (*cit)
			add_statement((*cit)->clone());

	}
}

ASTCompoundStatement& ASTCompoundStatement::operator=(
		const ASTCompoundStatement& stmt) {
	if (this != &stmt) {

		for (iterator it = statements_.begin(); it < statements_.end(); ++it) {

			if (*it)
				delete *it;
		}

		statements_.clear();

		ASTStatement::operator=(stmt);

		for (const_iterator cit = stmt.begin(); cit < stmt.end(); ++cit) {
			if (*cit)
				add_statement((*cit)->clone());
		}
	}

	return *this;
}

bool ASTCompoundStatement::accept(ASTVisitor& v) const {
	if (v.visit_statement) {

		switch (v.visit(this)) {

		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	for (const_iterator cit = begin(); cit < end(); ++cit) {

		if (*cit) {
			if (!((*cit)->accept(v)))
				return false;
		}

	}

	if (v.visit_statement) {

		switch (v.leave(this)) {

		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	return true;
}

ASTCompoundStatement::~ASTCompoundStatement() {
	for (iterator it = statements_.begin(); it < statements_.end(); ++it) {

		if (*it)
			delete *it;
	}

	statements_.clear();
}

// class ASTExpressionStatement
ASTExpressionStatement::ASTExpressionStatement(
		const ASTExpressionStatement& stmt) :
		ASTStatement(stmt) // ASTNode(stmt), ASTStatement(stmt)
{
	expression_ = 0;

	if (stmt.expression_)
		set_expression(stmt.expression_->clone());

}

ASTExpressionStatement& ASTExpressionStatement::operator=(
		const ASTExpressionStatement& stmt) {
	if (this != &stmt) {

		if (expression_) {
			delete expression_;
			expression_ = 0;
		}

		ASTStatement::operator=(stmt);

		if (stmt.expression_)
			set_expression(stmt.expression_->clone());

	}

	return *this;
}

bool ASTExpressionStatement::accept(ASTVisitor& v) const {

	if (v.visit_statement) {

		switch (v.visit(this)) {

		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	if (expression_ && !(expression_->accept(v)))
		return false;

	if (v.visit_statement) {

		switch (v.leave(this)) {

		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	return true;
}

// class ASTIfStatement
ASTIfStatement::ASTIfStatement(const ASTIfStatement& stmt) :
		ASTStatement(stmt) {
	condition_ = 0;
	then_clause_ = 0;
	else_clause_ = 0;

	if (stmt.condition_)
		set_condition(stmt.condition_->clone());

	if (stmt.then_clause_)
		set_then_clause(stmt.then_clause_->clone());

	if (stmt.else_clause_)
		set_else_clause(stmt.else_clause_->clone());

}

ASTIfStatement& ASTIfStatement::operator=(const ASTIfStatement& stmt) {
	if (this != &stmt) {

		if (condition_) {
			delete condition_;
			condition_ = 0;
		}

		if (then_clause_) {
			delete then_clause_;
			then_clause_ = 0;
		}

		if (else_clause_) {
			delete else_clause_;
			else_clause_ = 0;
		}

		ASTStatement::operator=(stmt);

		if (stmt.condition_)
			set_condition(stmt.condition_->clone());

		if (stmt.then_clause_)
			set_then_clause(stmt.then_clause_->clone());

		if (stmt.else_clause_)
			set_else_clause(stmt.else_clause_->clone());
	}
	return *this;
}

bool ASTIfStatement::accept(ASTVisitor& v) const {
	if (v.visit_statement) {

		switch (v.visit(this)) {

		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	if (condition_ && !(condition_->accept(v)))
		return false;

	if (then_clause_ && !(then_clause_->accept(v)))
		return false;

	if (else_clause_ && !(else_clause_->accept(v)))
		return false;

	if (v.visit_statement) {
		switch (v.leave(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}
	return true;
}

ASTSingleTransition& ASTSingleTransition::operator=(
		const ASTSingleTransition& transition) {
	if (this != &transition) {
		if (label_) {
			delete label_;
			label_ = 0;
		}
		if (source_) {
			delete source_;
			source_ = 0;
		}
		if (target_) {
			delete target_;
			target_ = 0;
		}
		if (guard_) {
			delete guard_;
			guard_ = 0;
		}
		if (action_) {
			delete action_;
			action_ = 0;
		}

		ASTTransition::operator =(transition);

		is_internal_=transition.is_internal_;

		if (transition.label_) {
			set_label(transition.label_->clone());
		}

		if (transition.source_) {
			set_source(transition.source_->clone());
		}

		if (transition.target_) {
			set_target(transition.target_->clone());
		}

		if (transition.guard_)
			set_guard(transition.guard_->clone());

		if (transition.action_)
			set_action(transition.action_->clone());
	}
	return *this;
}

bool ASTSingleTransition::accept(ASTVisitor& v) const {

	if (v.visit_transition) {
		switch (v.visit(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	if (label_ && !(label_->accept(v)))
		return false;

	if (source_ && !(source_->accept(v)))
		return false;

	if (target_ && !(target_->accept(v)))
		return false;

	if (guard_ && !(guard_->accept(v)))
		return false;

	if (action_ && !(action_->accept(v)))
		return false;

	if (v.visit_transition) {
		switch (v.leave(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}
	return true;
}

bool ASTInteraction::accept(ASTVisitor& v) const{
	if (v.visit_transition) {
		switch (v.visit(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	if (ports_ && !(ports_->accept(v)))
		return false;

	if (guard_ && !(guard_->accept(v)))
		return false;

	if (action_ && !(action_->accept(v)))
		return false;

	if (v.visit_transition) {
		switch (v.leave(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}
	return true;
}

ASTTransitionList::ASTTransitionList(const ASTTransitionList& transition_list) :
		ASTTransition(transition_list) {

	for (const_iterator tit = transition_list.begin();
			tit != transition_list.end(); ++tit) {
		if (*tit) {
			add_transition((*tit)->clone());
		}
	}
}

ASTTransitionList& ASTTransitionList::operator=(
		const ASTTransitionList& transitions) {

	if (this != &transitions) {
		for (const_iterator tit = transitions_.begin();
				tit != transitions_.end(); ++tit) {
			if (*tit) {
				delete *tit;
			}
		}
		transitions_.clear();
		ASTTransition::operator=(transitions);

		for (const_iterator ntit = transitions.begin();
				ntit != transitions.end(); ++ntit) {
			if (*ntit) {
				add_transition((*ntit)->clone());
			}
		}

	}
	return *this;
}

bool ASTTransitionList::accept(ASTVisitor& v) const {
	if (v.visit_transition) {
		switch (v.visit(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	for (const_iterator tit = transitions_.begin(); tit != transitions_.end();
			++tit) {
		if (*tit) {
			if (!(*tit)->accept(v)) {
				return false;
			}
		}
	}

	if (v.visit_transition) {
		switch (v.leave(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}
	return true;
}

bool ASTInitialTransition::accept(ASTVisitor& v) const {
	if (v.visit_transition) {
		switch (v.visit(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	if (location_ && !(location_->accept(v)))
		return false;

	if (action_ && !(action_->accept(v)))
		return false;

	if (v.visit_transition) {
		switch (v.leave(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}
	return true;
}

bool ASTDataDeclaration::accept(ASTVisitor& v) const {
	if (v.visit_declaration) {
		switch (v.visit(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	if (name_ && !(name_->accept(v)))
		return false;

	if (v.visit_declaration) {
		switch (v.leave(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}
	return true;
}

bool ASTPortDeclaration::accept(ASTVisitor& v) const {
	if (v.visit_declaration) {
		switch (v.visit(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	if (type_ && !(type_->accept(v)))
		return false;

	if (name_ && !(name_->accept(v)))
		return false;

	if (params_ && !(params_->accept(v)))
		return false;

	if (v.visit_declaration) {
		switch (v.leave(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}
	return true;
}

bool ASTConnectorDeclaration::accept(ASTVisitor& v) const{
	if (v.visit_declaration) {
		switch (v.visit(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	if (type_ && !(type_->accept(v)))
		return false;

	if (name_ && !(name_->accept(v)))
		return false;

	if (params_ && !(params_->accept(v)))
		return false;

	if (v.visit_declaration) {
		switch (v.leave(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}
	return true;
}

bool ASTAtomDeclaration::accept(ASTVisitor& v) const{
	if (v.visit_declaration) {
		switch (v.visit(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	if (type_ && !(type_->accept(v)))
		return false;

	if (name_ && !(name_->accept(v)))
		return false;

	if (params_ && !(params_->accept(v)))
		return false;

	if (v.visit_declaration) {
		switch (v.leave(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}
	return true;
}

bool ASTDeclarationList::accept(ASTVisitor& v) const {
	if (v.visit_declaration) {

		switch (v.visit(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	for (const_iterator cit = begin(); cit < end(); ++cit) {

		if (*cit) {
			if (!((*cit)->accept(v)))
				return false;
		}
	}

	if (v.visit_declaration) {

		switch (v.leave(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	return true;
}

ASTDeclarationList::ASTDeclarationList(const ASTDeclarationList& declarations) :
		ASTDeclaration(declarations) {

	for (const_iterator cit = declarations.begin(); cit < declarations.end();
			++cit) {

		if (*cit)
			add_declaration((*cit)->clone());
	}
}

ASTDeclarationList& ASTDeclarationList::operator=(
		const ASTDeclarationList& declarations) {
	if (this != &declarations) {
		// delete current object
		for (iterator it = declarations_.begin(); it < declarations_.end();
				++it) {
			if (*it)
				delete *it;
		}
		declarations_.clear();

		// call base assignment
		ASTDeclaration::operator=(declarations);

		for (const_iterator cit = declarations.begin();
				cit < declarations.end(); ++cit) {

			if (*cit)
				add_declaration((*cit)->clone());
		}

	}
	return *this;
}

bool ASTPortDefinition::accept(ASTVisitor& v) const{
	if (v.visit_definition) {

		switch (v.visit(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	if(name_ && !(name_->accept(v)))
		return false;

	if(params_ && !(params_->accept(v)))
		return false;

	if (v.visit_definition) {

		switch (v.leave(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	return true;
}

bool ASTAtomDefinition::accept(ASTVisitor& v) const{
	if (v.visit_definition) {

		switch (v.visit(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	if(name_ && !(name_->accept(v)))
		return false;

	if(params_ && !(params_->accept(v)))
		return false;

	if(data_decls_ && !(data_decls_->accept(v)))
		return false;

	if(port_decls_ && !(port_decls_->accept(v)))
		return false;

	if(control_locs_ &&!(control_locs_->accept(v)))
		return false;

	if(initial_tran_ && !(initial_tran_->accept(v)))
		return false;

	if(transitions_ && !(transitions_->accept(v)))
		return false;

	if (v.visit_definition) {

		switch (v.leave(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	return true;
}

bool ASTConnectorDefinition::accept(ASTVisitor& v) const{
	if (v.visit_definition) {

		switch (v.visit(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	if(name_ && !(name_->accept(v)))
		return false;

	if(params_ && !(params_->accept(v)))
		return false;

	if(ports_ && !(ports_->accept(v)))
		return false;

	if(interactions_ && !(interactions_->accept(v)))
		return false;

	if (v.visit_definition) {

		switch (v.leave(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	return true;
}

bool ASTCompoundDefinition::accept(ASTVisitor& v) const{
	if (v.visit_definition) {

		switch (v.visit(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	if(name_ && !(name_->accept(v)))
		return false;

	if(components_ && !(components_->accept(v)))
		return false;

	if(connectors_ && !(connectors_->accept(v)))
		return false;

	if (v.visit_definition) {

		switch (v.leave(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	return true;
}

// class ASTTranslationUnit

ASTTranslationUnit::ASTTranslationUnit(const ASTTranslationUnit& unit) :
		ASTNode(unit) {
	for (const_iterator cit = unit.begin(); cit < unit.end(); ++cit) {

		if (*cit)
			add_definition((*cit)->clone());
	}

	name_ = 0;
	if (unit.name_)
		set_package_name(new ASTName(*(unit.name_)));

	target_state_ = 0;
	if(unit.target_state_)
		set_target_state(unit.target_state_->clone());

}

ASTTranslationUnit& ASTTranslationUnit::operator=(
		const ASTTranslationUnit& unit) {
	if (this != &unit) { // check self-assignment

		// delete current object
		for (iterator it = definitions_.begin(); it < definitions_.end();
				++it) {
			if (*it)
				delete *it;
		}
		definitions_.clear();

		if (name_) {
			delete name_;
			name_ = 0;
		}

		if(target_state_){
			delete target_state_;
			target_state_ = 0;
		}

		// call base assignment
		ASTNode::operator=(unit);

		for (const_iterator cit = unit.begin(); cit < unit.end(); ++cit) {

			if (*cit)
				add_definition((*cit)->clone());
		}

		if (unit.name_)
			set_package_name(new ASTName(*(unit.name_)));

		if(unit.target_state_)
			set_target_state(unit.target_state_->clone());
	}

	return *this;
}

bool ASTTranslationUnit::accept(ASTVisitor& v) const {
	if (v.visit_translation_unit) {

		switch (v.visit(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	if (name_ && !(name_->accept(v)))
		return false;

	//if(target_state_ && !(target_state_->accept(v)))
	//	return false;

	for (const_iterator cit = begin(); cit < end(); ++cit) {

		if (*cit) {
			if (!((*cit)->accept(v)))
				return false;
		}
	}

	if (v.visit_translation_unit) {

		switch (v.leave(this)) {
		case ASTVisitor::ABORT:
			return false;
		case ASTVisitor::SKIP:
			return true;
		default:
			break;
		}
	}

	return true;
}

ASTTranslationUnit::~ASTTranslationUnit() {

	for (iterator it = definitions_.begin(); it < definitions_.end(); ++it) {
		if (*it)
			delete *it;
	}

	definitions_.clear();

	if (name_)
		delete name_;

	if(target_state_)
		delete target_state_;
}

}

