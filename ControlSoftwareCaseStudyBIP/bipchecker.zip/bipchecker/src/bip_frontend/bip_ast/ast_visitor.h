/*
 * ast_visitor.h
 *
 *  Created on: Oct 30, 2014
 *      Author: wangqiang
 */

#ifndef AST_VISITOR_H_
#define AST_VISITOR_H_


#include "bip_frontend/bip_ast/bip_ast.h"

namespace bipchecker{

class ASTVisitor {

public:

    static const int ABORT = 0;
    static const int CONTINUE = 1;
    static const int SKIP = 2;

    bool visit_expression;
    bool visit_name;
    bool visit_statement;
    bool visit_transition;
    bool visit_declaration;
    bool visit_definition;
    bool visit_translation_unit;

    explicit ASTVisitor(bool visit_node = false):
	  visit_expression(visit_node),
	  visit_name(visit_node),
	  visit_statement(visit_node),
	  visit_transition(visit_node),
	  visit_declaration(visit_node),
	  visit_definition(visit_node),
	  visit_translation_unit(visit_node) {}

    // visit functions
    virtual int visit(const ASTExpression*) { return CONTINUE; }
    virtual int visit(const ASTName*) { return CONTINUE; }
    virtual int visit(const ASTStatement*) { return CONTINUE; }
    virtual int visit(const ASTTransition*) {return CONTINUE;}
    virtual int visit(const ASTDeclaration*) {return CONTINUE;}
    virtual int visit(const ASTDefinition*) {return CONTINUE;}
    virtual int visit(const ASTTranslationUnit*) { return CONTINUE; }

    // leave functions
    virtual int leave(const ASTExpression*) { return CONTINUE; }
    virtual int leave(const ASTName*) { return CONTINUE; }
    virtual int leave(const ASTStatement*) { return CONTINUE; }
    virtual int leave(const ASTTransition*) {return CONTINUE;}
    virtual int leave(const ASTDeclaration*) {return CONTINUE;}
    virtual int leave(const ASTDefinition*) {return CONTINUE;}
    virtual int leave(const ASTTranslationUnit*) { return CONTINUE; }

    virtual ~ASTVisitor() { }

};


}


#endif /* AST_VISITOR_H_ */
