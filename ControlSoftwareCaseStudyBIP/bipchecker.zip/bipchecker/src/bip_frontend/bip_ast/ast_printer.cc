/*
 * ast_printer.cc
 *
 *  Created on: Nov 5, 2014
 *      Author: wangqiang
 */

#include "bip_frontend/bip_ast/ast_printer.h"

namespace bipchecker {

int ASTPrinter::visit(const ASTName* name) {
	out_ << name->name();

	return ASTVisitor::SKIP; // finishing visiting this node, not need to call the leave function
}

int ASTPrinter::leave(const ASTName* name) {
	return ASTVisitor::CONTINUE;
}

int ASTPrinter::visit(const ASTExpression* expression) {
	const ASTIdExpression* id_expr =
			dynamic_cast<const ASTIdExpression*>(expression);
	const ASTUnaryExpression* unary_expr =
			dynamic_cast<const ASTUnaryExpression*>(expression);
	const ASTBinaryExpression* binary_expr =
			dynamic_cast<const ASTBinaryExpression*>(expression);
	const ASTLiteralExpression* literal_expr =
			dynamic_cast<const ASTLiteralExpression*>(expression);
	const ASTQualifiedIdExpression* qualify_id =
			dynamic_cast<const ASTQualifiedIdExpression*>(expression);
	const ASTExpressionList* expr_list =
			dynamic_cast<const ASTExpressionList*>(expression);

	if (id_expr != 0) {
		id_expr->name()->accept(*this);
	} else if (qualify_id != 0) {
		qualify_id->qualifier()->accept(*this);
		out_ << ".";
		qualify_id->name()->accept(*this);
	} else if (unary_expr != 0) {
		out_ << "(";
		if (unary_expr->is_minus()) {
			out_ << "-";
		} else if (unary_expr->is_not()) {
			out_ << "!";
		}
		unary_expr->operand()->accept(*this);
		out_ << ")";

	} else if (binary_expr != 0) {
		out_ << "(";
		binary_expr->operand1()->accept(*this);
		switch (binary_expr->bin_operator()) {
		case (ASTBinaryExpression::OP_ASSIGN):
			out_ << "=";
			break;
		case (ASTBinaryExpression::OP_DIV):
			out_ << "/";
			break;
		case (ASTBinaryExpression::OP_PLUS):
			out_ << "+";
			break;
		case (ASTBinaryExpression::OP_MINUS):
			out_ << "-";
			break;
		case (ASTBinaryExpression::OP_MULT):
			out_ << "*";
			break;
		case (ASTBinaryExpression::OP_OR):
			out_ << "||";
			break;
		case (ASTBinaryExpression::OP_AND):
			out_ << "&&";
			break;
		case (ASTBinaryExpression::OP_EQ):
			out_ << "==";
			break;
		case (ASTBinaryExpression::OP_GE):
			out_ << ">=";
			break;
		case (ASTBinaryExpression::OP_GT):
			out_ << ">";
			break;
		case (ASTBinaryExpression::OP_LE):
			out_ << "<=";
			break;
		case (ASTBinaryExpression::OP_LT):
			out_ << "<";
			break;
		case (ASTBinaryExpression::OP_NE):
			out_ << "!=";
			break;
		}
		binary_expr->operand2()->accept(*this);
		out_ << ")";

	} else if (expr_list != 0) {
		//! check if it is control location definition
		bool is_control_def = false;
		const ASTAtomDefinition* def =
				dynamic_cast<const ASTAtomDefinition*>(expr_list->parent());
		const ASTConnectorDeclaration* cnt_decl =
				dynamic_cast<const ASTConnectorDeclaration*>(expr_list->parent());
		if (def != 0 || cnt_decl != 0)
			is_control_def = true;

		for (ASTExpressionList::const_iterator cit = expr_list->begin();
				cit != expr_list->end(); ++cit) {
			if (*cit)
				(*cit)->accept(*this);
			out_ << " ";
			ASTExpressionList::const_iterator next = cit + 1;
			if (is_control_def && next != expr_list->end()) {
				out_ << ", ";
			}
		}

	} else if (literal_expr != 0) {
		out_ << literal_expr->value();
	}

	return ASTVisitor::SKIP;
}

int ASTPrinter::leave(const ASTExpression* expression) {
	return ASTVisitor::CONTINUE;
}

int ASTPrinter::visit(const ASTStatement* statement) {
	// TODO
	const ASTExpressionStatement* expr_stat =
			dynamic_cast<const ASTExpressionStatement*>(statement);
	const ASTIfStatement* if_stat =
			dynamic_cast<const ASTIfStatement*>(statement);
	const ASTCompoundStatement* comp =
			dynamic_cast<const ASTCompoundStatement*>(statement);

	if (expr_stat != 0) {
		expr_stat->expression()->accept(*this);
		out_ << " ; ";
	} else if (if_stat != 0) {
		out_ << "if(";
		if_stat->condition()->accept(*this);
		out_ << ")";
		out_ << "then ";
		if_stat->then_clause()->accept(*this);
		if (if_stat->else_clause() != 0) {
			out_ << " else ";
			if_stat->else_clause()->accept(*this);
		}
		out_ << "fi";
	} else if (comp != 0) {
		for (ASTCompoundStatement::const_iterator cit = comp->begin();
				cit != comp->end(); ++cit) {
			if (*cit)
				(*cit)->accept(*this);
		}
	}

	return ASTVisitor::SKIP;
}

int ASTPrinter::leave(const ASTStatement* statement) {
	return ASTVisitor::CONTINUE;
}

int ASTPrinter::visit(const ASTTransition* transition) {
	//TODO
	const ASTInitialTransition* init =
			dynamic_cast<const ASTInitialTransition*>(transition);
	const ASTSingleTransition* single =
			dynamic_cast<const ASTSingleTransition*>(transition);
	const ASTTransitionList* tran_list =
			dynamic_cast<const ASTTransitionList*>(transition);
	const ASTInteraction* interaction =
			dynamic_cast<const ASTInteraction*>(transition);

	if (init != 0) {
		out_ << "initial to ";
		init->location()->accept(*this);
		if (init->action() != 0) {
			out_ << " do {";
			init->action()->accept(*this);
			out_ << "}";
		}
		out_ << std::endl;
	} else if (single != 0) {
		// check if it is an internal transition
		if (single->is_internal()) {
			//out_ << "internal ";
			single->label()->accept(*this);
		} else {
			out_ << "on ";
			single->label()->accept(*this);
		}
		out_ << " from ";
		single->source()->accept(*this);
		out_ << " to ";
		single->target()->accept(*this);
		if (single->guard() != 0) {
			out_ << " provided( ";
			single->guard()->accept(*this);
			out_ << ") ";
		}
		if (single->action() != 0) {
			out_ << " do { ";
			single->action()->accept(*this);
			out_ << " }";
		}
		out_ << std::endl;

	} else if (tran_list != 0) {

		for (ASTTransitionList::const_iterator cit = tran_list->begin();
				cit != tran_list->end(); ++cit) {
			if (*cit)
				(*cit)->accept(*this);
		}

	} else if (interaction != 0) {
		out_ << "on ";
		interaction->connected_ports()->accept(*this);

		if (interaction->guard() != 0) {
			out_ << " provided( ";
			interaction->guard()->accept(*this);
			out_ << " )";
		}
		if (interaction->action() != 0) {
			out_ << " down {";
			interaction->action()->accept(*this);
			out_ << " }";
		}
		out_ << std::endl;
	}

	return ASTVisitor::SKIP;
}

int ASTPrinter::leave(const ASTTransition* transition) {
	return ASTVisitor::CONTINUE;
}

int ASTPrinter::visit(const ASTDeclaration* declaration) {

	const ASTDataDeclaration* data_decl =
			dynamic_cast<const ASTDataDeclaration*>(declaration);
	const ASTPortDeclaration* port_decl =
			dynamic_cast<const ASTPortDeclaration*>(declaration);
	const ASTAtomDeclaration* atom_decl =
			dynamic_cast<const ASTAtomDeclaration*>(declaration);
	const ASTConnectorDeclaration* cnt_decl =
			dynamic_cast<const ASTConnectorDeclaration*>(declaration);
	const ASTDeclarationList* decl_list =
			dynamic_cast<const ASTDeclarationList*>(declaration);

	if (data_decl != 0) {

		//const ASTPortDefinition* port_def =
		//		dynamic_cast<const ASTPortDefinition*>(data_decl->parent());

		if (data_decl->is_parameter()) {
			if (data_decl->is_bool()) {
				out_ << "bool ";
			} else if (data_decl->is_float()) {
				out_ << "float ";
			} else if (data_decl->is_int()) {
				out_ << "int ";
			}
			data_decl->name()->accept(*this);
		} else {
			out_ << "data ";
			if (data_decl->is_bool()) {
				out_ << "bool ";
			} else if (data_decl->is_float()) {
				out_ << "float ";
			} else if (data_decl->is_int()) {
				out_ << "int ";
			}
			data_decl->name()->accept(*this);
			out_ << std::endl;
		}
	} else if (port_decl != 0) {
		if (port_decl->is_exported()) {
			out_ << "export ";
		}

		// check if this declaration is inside a connector type definition or not
		//const ASTDefinition* def =
		//		dynamic_cast<const ASTDefinition*>(port_decl->parent());
		//const ASTConnectorDefinition* cnt_def =
		//		dynamic_cast<const ASTConnectorDefinition*>(port_decl->parent());
		//const ASTConnectorDefinition* cnt_def2 =
		//		dynamic_cast<const ASTConnectorDefinition*>(port_decl->parent()->parent());

		if (port_decl->is_parameter()) {
			port_decl->type()->accept(*this);
			out_ << " ";
			port_decl->name()->accept(*this);
		} else {
			out_ << "port ";
			port_decl->type()->accept(*this);
			out_ << " ";
			port_decl->name()->accept(*this);
			out_ << "(";
			if (port_decl->parameters() != 0) {
				port_decl->parameters()->accept(*this);
			}
			out_ << ")" << std::endl;
		}

	} else if (atom_decl != 0) {
		out_ << "component ";
		atom_decl->type()->accept(*this);
		out_ << " ";
		atom_decl->name()->accept(*this);
		out_ << "(";
		if (atom_decl->parameters() != 0)
			atom_decl->parameters()->accept(*this);
		out_ << ")" << std::endl;

	} else if (cnt_decl != 0) {
		out_ << "connector ";
		cnt_decl->type()->accept(*this);
		out_ << " ";
		cnt_decl->name()->accept(*this);
		out_ << "(";
		cnt_decl->parameters()->accept(*this);
		out_ << ")" << std::endl;
	} else if (decl_list != 0) {
		const ASTConnectorDefinition* cnt_def =
				dynamic_cast<const ASTConnectorDefinition*>(decl_list->parent());

		for (ASTDeclarationList::const_iterator cit = decl_list->begin();
				cit != decl_list->end(); ++cit) {
			if (*cit)
				(*cit)->accept(*this);
			ASTDeclarationList::const_iterator next = cit + 1;
			if (cnt_def != 0 && next != decl_list->end()) {
				out_ << ", ";
			}
		}
	}

	return ASTVisitor::SKIP;
}

int ASTPrinter::leave(const ASTDeclaration* declaration) {
	return ASTVisitor::CONTINUE;
}

int ASTPrinter::visit(const ASTDefinition* definition) {

	const ASTPortDefinition* port_def =
			dynamic_cast<const ASTPortDefinition*>(definition);
	const ASTConnectorDefinition* cnt_def =
			dynamic_cast<const ASTConnectorDefinition*>(definition);
	const ASTAtomDefinition* atom_def =
			dynamic_cast<const ASTAtomDefinition*>(definition);
	const ASTCompoundDefinition* comp_def =
			dynamic_cast<const ASTCompoundDefinition*>(definition);

	if (port_def != 0) {
		out_ << "port type ";
		port_def->name()->accept(*this);
		out_ << "(";
		if (port_def->parameters() != 0)
			port_def->parameters()->accept(*this);
		out_ << ")" << std::endl;
	} else if (cnt_def != 0) {
		out_ << "connector type ";
		cnt_def->name()->accept(*this);
		out_ << "(";
		cnt_def->parameters()->accept(*this);
		out_ << ")" << std::endl;
		out_ << "  define ";
		cnt_def->connected_ports()->accept(*this);
		out_ << std::endl;
		if (cnt_def->interactions() != 0)
			cnt_def->interactions()->accept(*this);
		out_ << "end" << std::endl;

	} else if (atom_def != 0) {
		out_ << "atom type ";
		atom_def->name()->accept(*this);
		out_ << "(";
		if (atom_def->parameters() != 0)
			atom_def->parameters()->accept(*this);
		out_ << ")" << std::endl;
		if (atom_def->data_declarations() != 0)
			atom_def->data_declarations()->accept(*this);
		if (atom_def->port_declarations() != 0)
			atom_def->port_declarations()->accept(*this);
		out_ << "place ";
		atom_def->control_location()->accept(*this);
		out_ << std::endl;
		atom_def->initial_transition()->accept(*this);
		// out_ << std::endl;
		atom_def->transitions()->accept(*this);
		// out_ << std::endl;
		out_ << "end" << std::endl;

	} else if (comp_def != 0) {
		out_ << "compound type ";
		comp_def->name()->accept(*this);
		out_ << "()" << std::endl;
		comp_def->components()->accept(*this);
		comp_def->connectors()->accept(*this);
		out_ << "end" << std::endl;

	} else {
		std::cerr
				<< "Type Error: unknown ASTDefinition type (Port, Connector, Atom and Compound)!"
				<< std::endl;
		return ASTVisitor::ABORT;
	}

	return ASTVisitor::SKIP;
}

int ASTPrinter::leave(const ASTDefinition* definition) {
	return ASTVisitor::CONTINUE;
}

int ASTPrinter::visit(const ASTTranslationUnit* unit) {
	out_ << "package ";
	out_ << unit->package_name()->name();
	out_ << std::endl;

	for (ASTTranslationUnit::const_iterator cit = unit->begin();
			cit != unit->end(); ++cit) {
		if ((*cit))
			(*cit)->accept(*this);
	}

	const ASTExpression* target = unit->target_state();
	const ASTQualifiedIdExpression* single_target =
			dynamic_cast<const ASTQualifiedIdExpression*>(target);
	const ASTExpressionList* target_list =
			dynamic_cast<const ASTExpressionList*>(target);

	out_ << "BIPTARGET (";
	if(single_target != 0){
		out_ << single_target->qualifier()->name();
		out_ << ".";
		out_ << single_target->name()->name();
	} else if(target_list != 0){
		for(ASTExpressionList::const_iterator cit = target_list->begin();
				cit != target_list->end(); ++cit){
			if(*cit){
				const ASTQualifiedIdExpression* temp =
						dynamic_cast<const ASTQualifiedIdExpression*>(*cit);
				out_ << temp->qualifier()->name();
				out_ << ".";
				out_ << temp->name()->name();
				out_ << " ";
			}
		}
	}

	out_ << ")" << std::endl;
	out_ << "end" << std::endl;

	return ASTVisitor::SKIP;
}

int ASTPrinter::leave(const ASTTranslationUnit* unit) {
	return ASTVisitor::CONTINUE;
}

}

