/*
 * ast_printer.h
 *
 *  Created on: Nov 5, 2014
 *      Author: wangqiang
 */

#ifndef AST_PRINTER_H_
#define AST_PRINTER_H_


#include <iostream>
#include "bip_frontend/bip_ast/ast_visitor.h"

namespace bipchecker{

class ASTPrinter: public ASTVisitor{

	std::ostream& out_;

public:
	explicit ASTPrinter(std::ostream& out = std::cout)
	:  ASTVisitor(true), out_(out){}

    // visit functions
     int visit(const ASTExpression*);
     int visit(const ASTName*);
     int visit(const ASTStatement*);
     int visit(const ASTTransition*);
     int visit(const ASTDeclaration*);
     int visit(const ASTDefinition*);
     int visit(const ASTTranslationUnit*);

    // leave functions
     int leave(const ASTExpression*);
     int leave(const ASTName*);
     int leave(const ASTStatement*);
     int leave(const ASTTransition*);
     int leave(const ASTDeclaration*);
     int leave(const ASTDefinition*);
     int leave(const ASTTranslationUnit*);

    ~ASTPrinter() { }

    /*
private:

    inline bool accept(const ASTNode *n)
    {
	return ( n && !(n->accept(*this)) ) ? false : true;
    }
*/

};

}


#endif /* AST_PRINTER_H_ */
