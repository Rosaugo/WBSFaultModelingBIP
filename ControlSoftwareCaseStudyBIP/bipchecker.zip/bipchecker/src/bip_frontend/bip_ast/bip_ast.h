/*
 * bip_ast.h
 *
 *  Created on: Oct 29, 2014
 *      Author: wangqiang
 */

#ifndef BIP_AST_H_
#define BIP_AST_H_

#include <string>
#include <vector>

namespace bipchecker {

class ASTNodeLocation {
	std::string file_name_;
	unsigned int start_line_number_;
	unsigned int end_line_number_;
	unsigned int start_column_number_;
	unsigned int end_column_number_;

public:

	explicit ASTNodeLocation() {
	}

	explicit ASTNodeLocation(std::string file_name,
			unsigned int start_line_number, unsigned int end_line_number,
			unsigned int start_column_number, unsigned int end_column_number) :
			file_name_(file_name), start_line_number_(start_line_number), end_line_number_(
					end_line_number), start_column_number_(start_column_number), end_column_number_(
					end_column_number) {
	}

	explicit ASTNodeLocation(const ASTNodeLocation& node_location) :
			file_name_(node_location.file_name_), start_line_number_(
					node_location.start_line_number_), end_line_number_(
					node_location.end_line_number_), start_column_number_(
					node_location.start_column_number_), end_column_number_(
					node_location.end_column_number_) {
	}

	std::string file_name() const {
		return file_name_;
	}
	unsigned int start_line_number() const {
		return start_line_number_;
	}
	unsigned int end_line_number() const {
		return end_line_number_;
	}
	unsigned int start_column_number() const {
		return start_column_number_;
	}
	unsigned int end_column_number() const {
		return end_column_number_;
	}

	void set_file_name(std::string file_name) {
		file_name_ = file_name;
	}

	void set_start_line_number(unsigned int start_line_number) {
		start_line_number_ = start_line_number;
	}

	void set_end_line_number(unsigned int end_line_number) {
		end_line_number_ = end_line_number;
	}

	void set_start_column_number(unsigned int start_column_number) {
		start_column_number_ = start_column_number;
	}

	void set_end_column_number(unsigned int end_column_number) {
		end_column_number_ = end_column_number;
	}

};
// class ASTNodeLocation

class ASTTranslationUnit;
class ASTVisitor;

/**
 * base class for all AST entities
 */
class ASTNode {

	ASTNodeLocation node_location_;
	ASTNode *parent_;

public:

	explicit ASTNode() :
			parent_(0) {
	}

	explicit ASTNode(const ASTNode& node) :
			node_location_(node.node_location_), parent_(node.parent_) {
	}

	ASTNode& operator=(const ASTNode& node) {
		if (this != &node) {
			node_location_ = node.node_location_;
			parent_ = node.parent_;
		}
		return *this;
	}

	const ASTNodeLocation& node_location() const {
		return node_location_;
	}

	ASTNode* parent() const {
		return parent_;
	}

	virtual ASTTranslationUnit* translation_unit() const {
		return (parent_ != 0) ? parent_->translation_unit() : 0;
	}

	void set_node_location(const ASTNodeLocation& node_location) {
		node_location_ = node_location;
	}

	void set_parent(ASTNode& parent) {
		parent_ = &parent;
	}

	virtual bool accept(ASTVisitor& v) const = 0;

	virtual ~ASTNode() {
		parent_ = 0;
	}
};
// class ASTNode

class ASTName: public ASTNode {
	std::string name_;

public:

	explicit ASTName(const std::string& name) :
			name_(name) {
	}

	explicit ASTName(const ASTName& name) :
			ASTNode(name), name_(name.name_) {
	}

	ASTName& operator=(const ASTName& name) {
		if (this != &name) {
			ASTNode::operator=(name);
			name_ = name.name_;
		}
		return *this;
	}

	const std::string& name() const {
		return name_;
	}

	bool accept(ASTVisitor& v) const;

	bool equals(const ASTName *name) const {
		if (name != 0)
			return (name_ == name->name_);

		return false;
	}

	~ASTName() {
	}

};
// class ASTName

class ASTExpression: public ASTNode {

public:

	explicit ASTExpression() {
	}

	explicit ASTExpression(const ASTExpression& expression) :
			ASTNode(expression) {
	}

	ASTExpression& operator=(const ASTExpression& expression) {
		if (this != &expression)
			ASTNode::operator=(expression);

		return *this;
	}

	virtual bool is_boolean_expression() const;

	virtual ASTExpression* clone() const = 0;

	virtual bool equals(const ASTExpression *expression) const = 0;

	virtual ~ASTExpression() {
	}

};
// class ASTExpression

/**
 * class for simple Identifiers, e.g. variables
 */
class ASTIdExpression: public ASTExpression {
	ASTName *name_;

public:

	explicit ASTIdExpression() :
			name_(0) {
	}

	explicit ASTIdExpression(ASTName *name) :
			name_(name) {
		if (name_)
			name_->set_parent(*this);
	}

	explicit ASTIdExpression(const ASTIdExpression&);

	ASTIdExpression& operator=(const ASTIdExpression&);

	const ASTName* name() const {
		return name_;
	}

	void set_name(ASTName *name) {
		if (name_)
			delete name_;
		name_ = name;
		if (name_)
			name_->set_parent(*this);
	}

	bool accept(ASTVisitor& v) const;

	ASTIdExpression* clone() const {
		return new ASTIdExpression(*this);
	}

	bool equals(const ASTExpression *expression) const {
		const ASTIdExpression *id_expr =
				dynamic_cast<const ASTIdExpression*>(expression);

		if (id_expr != 0) {
			bool eq = (
					name_ != 0 ?
							name_->equals(id_expr->name_) :
							(id_expr->name_ == 0));
			if (!eq)
				return false;
			return true;
		}
		return false;
	}

	~ASTIdExpression() {
		if (name_)
			delete name_;
	}

};
// class ASTIdExpression

/**
 *  class for qualified identifiers,
 *  e.g. A.x where A is the component defined variable x
 */
class ASTQualifiedIdExpression: public ASTExpression {

	ASTName* qualifier_;
	ASTName* name_;

public:

	explicit ASTQualifiedIdExpression(ASTName* qualifier, ASTName* name) :
			qualifier_(qualifier), name_(name) {
		if (qualifier_)
			qualifier_->set_parent(*this);
		if (name_)
			name_->set_parent(*this);
	}

	explicit ASTQualifiedIdExpression(const ASTQualifiedIdExpression& expr) :
			ASTExpression(expr) {
		qualifier_ = 0;
		name_ = 0;
		if (expr.qualifier_)
			set_qualifier(new ASTName(*expr.qualifier_));
		if (expr.name_)
			set_name(new ASTName(*expr.name_));
	}

	ASTQualifiedIdExpression& operator=(const ASTQualifiedIdExpression& expr) {
		if (this != &expr) {
			if (qualifier_) {
				delete qualifier_;
				qualifier_ = 0;
			}
			if (name_) {
				delete name_;
				name_ = 0;
			}
			ASTExpression::operator =(expr);
			if (expr.qualifier_)
				set_qualifier(new ASTName(*expr.qualifier_));
			if (expr.name_)
				set_name(new ASTName(*expr.name_));
		}
		return *this;
	}

	const ASTName* qualifier() const {
		return qualifier_;
	}

	const ASTName* name() const {
		return name_;
	}

	void set_qualifier(ASTName* qualifier) {
		if (qualifier_)
			delete qualifier_;
		qualifier_ = qualifier;
		if (qualifier_)
			qualifier_->set_parent(*this);
	}

	void set_name(ASTName* name) {
		if (name_)
			delete name_;
		name_ = name;
		if (name_)
			name_->set_parent(*this);
	}

	bool accept(ASTVisitor& v) const;

	ASTQualifiedIdExpression* clone() const {
		return new ASTQualifiedIdExpression(*this);
	}

	bool equals(const ASTExpression *expression) const {
		const ASTQualifiedIdExpression *id_expr =
				dynamic_cast<const ASTQualifiedIdExpression*>(expression);

		if (id_expr != 0) {
			bool eq = (
					name_ != 0 ?
							name_->equals(id_expr->name_) :
							(id_expr->name_ == 0));
			if (!eq)
				return false;

			bool eq2 = (
					qualifier_ != 0 ?
							qualifier_->equals(id_expr->qualifier_) :
							(id_expr->qualifier_ == 0));
			if (!eq2)
				return false;

			return true;
		}
		return false;
	}

	~ASTQualifiedIdExpression() {
		if (name_)
			delete name_;
		if (qualifier_)
			delete qualifier_;
	}

};

class ASTLiteralExpression: public ASTExpression {

public:

	enum LiteralKind {
		FLOAT_LIT, INT_LIT, BOOL_LIT
	};

private:

	std::string value_;
	LiteralKind kind_;

public:

	explicit ASTLiteralExpression(const std::string& value, LiteralKind kind) :
			value_(value), kind_(kind) {
	}

	explicit ASTLiteralExpression(const ASTLiteralExpression&);

	ASTLiteralExpression& operator=(const ASTLiteralExpression&);

	const std::string& value() const {
		return value_;
	}
	LiteralKind kind() const {
		return kind_;
	}

	bool is_float() const {return kind_==FLOAT_LIT?true:false;}
	bool is_int() const {return kind_==INT_LIT?true:false;}
	bool is_bool() const {return kind_==BOOL_LIT?true:false;}

	void set_value(std::string& value) {
		value_ = value;
	}

	void set_kind(LiteralKind kind) {
		kind_ = kind;
	}

	bool accept(ASTVisitor& v) const;

	ASTLiteralExpression* clone() const {
		return new ASTLiteralExpression(*this);
	}

	bool equals(const ASTExpression *expression) const {
		const ASTLiteralExpression *lit_expr =
				dynamic_cast<const ASTLiteralExpression*>(expression);

		if (lit_expr != 0) {
			return (value_ == lit_expr->value_ && kind_ == lit_expr->kind_);
		}
		return false;
	}

	~ASTLiteralExpression() {
	}

};
// class ASTLiteralExpression

class ASTUnaryExpression: public ASTExpression {

public:

	enum UnaryOp {
		OP_MINUS, OP_NOT, OP_PLUS,
	};

private:

	UnaryOp un_operator_;
	ASTExpression *operand_;

public:

	explicit ASTUnaryExpression(UnaryOp un_operator, ASTExpression *operand) :
			un_operator_(un_operator), operand_(operand) {
		if (operand_)
			operand_->set_parent(*this);
	}

	explicit ASTUnaryExpression(const ASTUnaryExpression&);

	ASTUnaryExpression& operator=(const ASTUnaryExpression&);

	UnaryOp un_operator() const {
		return un_operator_;
	}
	const ASTExpression* operand() const {
		return operand_;
	}

	bool is_minus() const {return un_operator_==OP_MINUS?true:false;}
	bool is_not() const {return un_operator_==OP_NOT?true:false;}
	bool is_plus() const {return un_operator_==OP_PLUS?true:false;}

	void set_un_operator(UnaryOp un_operator) {
		un_operator_ = un_operator;
	}

	void set_operand(ASTExpression *operand) {
		if (operand_)
			delete operand_;

		operand_ = operand;

		if (operand_)
			operand_->set_parent(*this);

	}

	ASTExpression* detach_operand() {
		ASTExpression *temp = operand_;
		operand_ = 0;

		return temp;
	}

	bool is_boolean_expression() const;

	bool accept(ASTVisitor& v) const;

	ASTUnaryExpression* clone() const {
		return new ASTUnaryExpression(*this);
	}

	bool equals(const ASTExpression *expression) const {
		const ASTUnaryExpression *un_expr =
				dynamic_cast<const ASTUnaryExpression*>(expression);

		if (un_expr != 0) {

			if (un_operator_ != un_expr->un_operator_)
				return false;

			bool eq = (
					operand_ != 0 ?
							operand_->equals(un_expr->operand_) :
							(un_expr->operand_ == 0));

			if (!eq)
				return false;

			return true;
		}

		return false;
	}

	~ASTUnaryExpression() {
		if (operand_)
			delete operand_;
	}

};
// class ASTUnaryExpression

class ASTBinaryExpression: public ASTExpression {

public:

	enum BinaryOp {
		OP_ASSIGN,

		OP_EQ,
		OP_NE,
		OP_GE,
		OP_GT,
		OP_LE,
		OP_LT,

		OP_AND,
		OP_OR,

		OP_DIV,
		OP_MINUS,
		OP_MULT,
		OP_PLUS
	};

private:

	ASTExpression *operand1_;
	BinaryOp bin_operator_;
	ASTExpression *operand2_;

public:

	explicit ASTBinaryExpression(ASTExpression *operand1, BinaryOp bin_operator,
			ASTExpression *operand2) :
			operand1_(operand1), bin_operator_(bin_operator), operand2_(
					operand2) {
		if (operand1_)
			operand1_->set_parent(*this);

		if (operand2_)
			operand2_->set_parent(*this);

	}

	explicit ASTBinaryExpression(const ASTBinaryExpression&);

	ASTBinaryExpression& operator=(const ASTBinaryExpression&);

	const ASTExpression* operand1() const {
		return operand1_;
	}

	BinaryOp bin_operator() const {
		return bin_operator_;
	}

	const ASTExpression* operand2() const {
		return operand2_;
	}


	void set_operand1(ASTExpression* operand1) {
		if (operand1_)
			delete operand1_;

		operand1_ = operand1;

		if (operand1_)
			operand1_->set_parent(*this);

	}

	void set_bin_operator(BinaryOp bin_operator) {
		bin_operator_ = bin_operator;
	}

	void set_operand2(ASTExpression* operand2) {
		if (operand2_)
			delete operand2_;

		operand2_ = operand2;

		if (operand2_)
			operand2_->set_parent(*this);

	}

	ASTExpression* detach_operand1() {
		ASTExpression *temp = operand1_;
		operand1_ = 0;

		return temp;
	}

	ASTExpression* detach_operand2() {
		ASTExpression *temp = operand2_;
		operand2_ = 0;

		return temp;
	}

	bool is_boolean_expression() const;

	bool accept(ASTVisitor& v) const;

	ASTBinaryExpression* clone() const {
		return new ASTBinaryExpression(*this);
	}

	bool equals(const ASTExpression *expression) const {
		const ASTBinaryExpression *bin_expr =
				dynamic_cast<const ASTBinaryExpression*>(expression);

		if (bin_expr != 0) {

			if (bin_operator_ != bin_expr->bin_operator_)
				return false;

			bool eq = (
					operand1_ != 0 ?
							operand1_->equals(bin_expr->operand1_) :
							(bin_expr->operand1_ == 0));

			if (!eq)
				return false;

			eq = (operand2_ != 0 ?
					operand2_->equals(bin_expr->operand2_) :
					(bin_expr->operand2_ == 0));

			if (!eq)
				return false;

			return true;
		}

		return false;
	}

	~ASTBinaryExpression() {
		if (operand1_)
			delete operand1_;

		if (operand2_)
			delete operand2_;
	}

};
// class ASTBinaryExpression

/*
 class ASTConditionalExpression: public ASTExpression {

 ASTExpression *condition_;
 ASTExpression *true_expression_;
 ASTExpression *false_expression_;

 public:

 explicit ASTConditionalExpression() :
 condition_(0), true_expression_(0), false_expression_(0) {
 }

 explicit ASTConditionalExpression(ASTExpression *condition,
 ASTExpression *true_expression, ASTExpression *false_expression) :
 condition_(condition), true_expression_(true_expression), false_expression_(
 false_expression) {
 if (condition_)
 condition_->set_parent(*this);

 if (true_expression_)
 true_expression_->set_parent(*this);

 if (false_expression_)
 false_expression_->set_parent(*this);
 }

 explicit ASTConditionalExpression(const ASTConditionalExpression&);

 ASTConditionalExpression& operator=(const ASTConditionalExpression&);

 const ASTExpression* condition() const {
 return condition_;
 }
 const ASTExpression* true_expression() const {
 return true_expression_;
 }
 const ASTExpression* false_expression() const {
 return false_expression_;
 }

 void set_condition(ASTExpression *condition) {
 if (condition_)
 delete condition_;

 condition_ = condition;

 if (condition_)
 condition_->set_parent(*this);
 }

 void set_true_expression(ASTExpression *true_expression) {
 if (true_expression_)
 delete true_expression_;

 true_expression_ = true_expression;

 if (true_expression_)
 true_expression_->set_parent(*this);
 }

 void set_false_expression(ASTExpression *false_expression) {
 if (false_expression_)
 delete false_expression_;

 false_expression_ = false_expression;

 if (false_expression_)
 false_expression_->set_parent(*this);
 }

 bool accept(ASTVisitor& v) const;

 ASTConditionalExpression* clone() const {
 return new ASTConditionalExpression(*this);
 }

 bool equals(const ASTExpression *expression) const {
 const ASTConditionalExpression *cond_expr =
 dynamic_cast<const ASTConditionalExpression*>(expression);

 if (cond_expr != 0) {

 bool eq = (
 condition_ != 0 ?
 condition_->equals(cond_expr->condition_) :
 (cond_expr->condition_ == 0));

 if (!eq)
 return false;

 eq = (true_expression_ != 0 ?
 true_expression_->equals(cond_expr->true_expression_) :
 (cond_expr->true_expression_ == 0));

 if (!eq)
 return false;

 eq = (false_expression_ != 0 ?
 false_expression_->equals(cond_expr->false_expression_) :
 (cond_expr->false_expression_ == 0));

 if (!eq)
 return false;

 return true;
 }
 return false;
 }

 ~ASTConditionalExpression() {
 if (condition_)
 delete condition_;

 if (true_expression_)
 delete true_expression_;

 if (false_expression_)
 delete false_expression_;
 }
 };
 // class ASTConditionalExpression
 * */

class ASTExpressionList: public ASTExpression {

	typedef std::vector<ASTExpression*> expressions_t;
	typedef expressions_t::iterator iterator;

	expressions_t expressions_;

public:

	explicit ASTExpressionList() {
	}

	explicit ASTExpressionList(const ASTExpressionList&);

	ASTExpressionList& operator=(const ASTExpressionList&);

	const ASTExpression* expression(unsigned int pos) const {
		if (pos < expressions_.size())
			return expressions_[pos];

		return 0;
	}

	typedef expressions_t::const_iterator const_iterator;

	const_iterator begin() const {
		return expressions_.begin();
	}
	const_iterator end() const {
		return expressions_.end();
	}

	unsigned int size() const {
		return expressions_.size();
	}
	bool empty() const {
		return expressions_.empty();
	}

	ASTExpressionList& add_expression(ASTExpression *expression) {
		if (expression) {
			expression->set_parent(*this);
			expressions_.push_back(expression);
		}
		return (*this);
	}

	bool set_expression(ASTExpression* expression, unsigned int pos) {
		if (pos < expressions_.size()) {

			ASTExpression *old_expression = expressions_[pos];

			if (old_expression)
				delete old_expression;

			expressions_[pos] = expression;

			return true;
		}

		return false;
	}

	bool accept(ASTVisitor& v) const;

	ASTExpressionList* clone() const {
		return new ASTExpressionList(*this);
	}

	bool equals(const ASTExpression *expression) const {
		const ASTExpressionList *expr_list =
				dynamic_cast<const ASTExpressionList*>(expression);

		if (expr_list != 0) {
			unsigned int this_size = size();
			if (this_size == expr_list->size()) {
				for (unsigned int i = 0; i < this_size; ++i) {
					ASTExpression *e = expressions_[i];
					ASTExpression *oe = expr_list->expressions_[i];

					bool eq = (e != 0 ? e->equals(oe) : (oe == 0));

					if (!eq)
						return false;
				}

				return true;
			}
		}

		return false;
	}

	~ASTExpressionList();
};
// class ASTExpressionList

//////////////////////////////////// Statement /////////////////////////////

class ASTStatement: public ASTNode {

public:

	explicit ASTStatement() {
	}

	explicit ASTStatement(const ASTStatement& statement) :
			ASTNode(statement) {
	}

	ASTStatement& operator=(const ASTStatement& statement) {
		if (this != &statement)
			ASTNode::operator=(statement);

		return *this;
	}

	virtual ASTStatement* clone() const = 0;

	virtual bool equals(const ASTStatement *statement) const = 0;

	virtual ~ASTStatement() {
	}

};
// class ASTStatement

class ASTExpressionStatement: public ASTStatement {

	ASTExpression *expression_;

public:

	explicit ASTExpressionStatement() :
			expression_(0) {
	}

	explicit ASTExpressionStatement(ASTExpression *expression) :
			expression_(expression) {
		if (expression_)
			expression_->set_parent(*this);
	}

	explicit ASTExpressionStatement(const ASTExpressionStatement&);

	ASTExpressionStatement& operator=(const ASTExpressionStatement&);

	const ASTExpression* expression() const {
		return expression_;
	}

	void set_expression(ASTExpression *expression) {
		if (expression_)
			delete expression_;

		expression_ = expression;

		if (expression_)
			expression_->set_parent(*this);

	}

	bool accept(ASTVisitor& v) const;

	ASTExpressionStatement* clone() const {
		return new ASTExpressionStatement(*this);
	}

	virtual bool equals(const ASTStatement *stmt) const {
		const ASTExpressionStatement *expr_stmt =
				dynamic_cast<const ASTExpressionStatement*>(stmt);

		if (expr_stmt != 0) {

			bool eq = (
					expression_ != 0 ?
							expression_->equals(expr_stmt->expression_) :
							(expr_stmt->expression_ == 0));

			if (!eq)
				return false;

			return true;
		}

		return false;
	}

	~ASTExpressionStatement() {
		if (expression_)
			delete expression_;

	}

};
// class ASTExpressionStatement

class ASTIfStatement: public ASTStatement {

	ASTExpression *condition_;
	ASTStatement *then_clause_;
	ASTStatement *else_clause_;

public:

	explicit ASTIfStatement() :
			condition_(0), then_clause_(0), else_clause_(0) {
	}

	explicit ASTIfStatement(ASTExpression *condition, ASTStatement *then_clause) :
			condition_(condition), then_clause_(then_clause), else_clause_(0) {
		if (condition_)
			condition_->set_parent(*this);

		if (then_clause_)
			then_clause_->set_parent(*this);

	}

	explicit ASTIfStatement(ASTExpression *condition, ASTStatement *then_clause,
			ASTStatement *else_clause) :
			condition_(condition), then_clause_(then_clause), else_clause_(
					else_clause) {
		if (condition_)
			condition_->set_parent(*this);

		if (then_clause_)
			then_clause_->set_parent(*this);

		if (else_clause_)
			else_clause_->set_parent(*this);
	}

	explicit ASTIfStatement(const ASTIfStatement&);

	ASTIfStatement& operator=(const ASTIfStatement&);

	const ASTExpression* condition() const {
		return condition_;
	}
	const ASTStatement* then_clause() const {
		return then_clause_;
	}
	const ASTStatement* else_clause() const {
		return else_clause_;
	}

	void set_condition(ASTExpression *condition) {
		if (condition_)
			delete condition_;

		condition_ = condition;

		if (condition_)
			condition_->set_parent(*this);

	}

	void set_then_clause(ASTStatement *then_clause) {
		if (then_clause_)
			delete then_clause_;

		then_clause_ = then_clause;

		if (then_clause_)
			then_clause_->set_parent(*this);

	}

	void set_else_clause(ASTStatement *else_clause) {
		if (else_clause_)
			delete else_clause_;

		else_clause_ = else_clause;

		if (else_clause_)
			else_clause_->set_parent(*this);

	}

	bool accept(ASTVisitor& v) const;

	ASTIfStatement* clone() const {
		return new ASTIfStatement(*this);
	}

	bool equals(const ASTStatement *stmt) const {
		const ASTIfStatement *if_stmt =
				dynamic_cast<const ASTIfStatement*>(stmt);

		if (if_stmt != 0) {

			bool eq = (
					condition_ != 0 ?
							condition_->equals(if_stmt->condition_) :
							(if_stmt->condition_ == 0));

			if (!eq)
				return false;

			eq = (then_clause_ != 0 ?
					then_clause_->equals(if_stmt->then_clause_) :
					(if_stmt->then_clause_ == 0));

			if (!eq)
				return false;

			eq = (else_clause_ != 0 ?
					else_clause_->equals(if_stmt->else_clause_) :
					(if_stmt->else_clause_ == 0));

			if (!eq)
				return false;

			return true;
		}

		return false;
	}

	~ASTIfStatement() {
		if (condition_)
			delete condition_;

		if (then_clause_)
			delete then_clause_;

		if (else_clause_)
			delete else_clause_;
	}

};
// ASTIfStatement

class ASTCompoundStatement: public ASTStatement {

	typedef std::vector<ASTStatement*> statements_t;
	typedef statements_t::iterator iterator;

	statements_t statements_;

public:

	explicit ASTCompoundStatement() {
	}

	explicit ASTCompoundStatement(const ASTCompoundStatement&);

	ASTCompoundStatement& operator=(const ASTCompoundStatement&);

	typedef statements_t::const_iterator const_iterator;

	const_iterator begin() const {
		return statements_.begin();
	}
	const_iterator end() const {
		return statements_.end();
	}

	unsigned int size() const {
		return statements_.size();
	}
	bool empty() const {
		return statements_.empty();
	}

	ASTCompoundStatement& add_statement(ASTStatement *statement) {
		if (statement) {
			statement->set_parent(*this);
			statements_.push_back(statement);
		}

		return (*this);
	}

	bool accept(ASTVisitor& v) const;

	ASTCompoundStatement* clone() const {
		return new ASTCompoundStatement(*this);
	}

	bool equals(const ASTStatement *stmt) const {
		const ASTCompoundStatement *comp_stmt =
				dynamic_cast<const ASTCompoundStatement*>(stmt);

		if (comp_stmt != 0) {

			unsigned int this_size = size();

			if (this_size == comp_stmt->size()) {

				for (unsigned int i = 0; i < this_size; ++i) {

					ASTStatement *s = statements_[i];
					ASTStatement *os = comp_stmt->statements_[i];

					bool eq = (s != 0 ? s->equals(os) : (os == 0));

					if (!eq)
						return false;
				}
				return true;
			}
		}
		return false;
	}

	~ASTCompoundStatement();
};
// class ASTCompoundStatement

/* base class for transition relation, it is abstract and can not be instantiated.*/
class ASTTransition: public ASTNode {

public:

	explicit ASTTransition() {
	}

	explicit ASTTransition(const ASTTransition& transition) :
			ASTNode(transition) {
	}

	ASTTransition& operator=(const ASTTransition& transition) {
		if (this != &transition)
			ASTNode::operator=(transition);

		return *this;
	}

	virtual ASTTransition* clone() const = 0;

	virtual bool equals(const ASTTransition* transition) const = 0;

	~ASTTransition() {
	}
};

class ASTInitialTransition: public ASTTransition {

	ASTIdExpression* location_;
	ASTStatement* action_;

public:
	explicit ASTInitialTransition(ASTIdExpression* location) :
			location_(location), action_(0) {
		if (location_)
			location_->set_parent(*this);
	}

	explicit ASTInitialTransition(ASTIdExpression* location, ASTStatement* action) :
			location_(location), action_(action) {
		if (location_) {
			location_->set_parent(*this);
		}
		if (action_)
			action_->set_parent(*this);
	}

	explicit ASTInitialTransition(const ASTInitialTransition& transition) :
			ASTTransition(transition) {
		location_ = 0;
		action_ = 0;

		if (transition.action_)
			set_action(transition.action_->clone());
		if (transition.location_)
			set_location(transition.location_->clone());
	}

	ASTInitialTransition& operator=(const ASTInitialTransition& transition) {

		if (this != &transition) {
			if (location_) {
				delete location_;
				location_ = 0;
			}
			if (action_) {
				delete action_;
				location_ = 0;
			}
			ASTTransition::operator=(transition);

			if (transition.action_)
				set_action(transition.action_->clone());
			if (transition.location_)
				set_location(transition.location_->clone());
		}
		return *this;
	}

	void set_location(ASTIdExpression* location) {
		if (location_)
			delete location_;
		location_ = location;
		if (location_)
			location_->set_parent(*this);
	}

	void set_action(ASTStatement* action) {
		if (action_)
			delete action_;
		action_ = action;
		if (action_)
			action_->set_parent(*this);
	}

	const ASTIdExpression* location() const {
		return location_;
	}

	const ASTStatement* action() const {
		return action_;
	}

	bool accept(ASTVisitor& v) const;

	ASTInitialTransition* clone() const {
		return new ASTInitialTransition(*this);
	}

	bool equals(const ASTTransition* transition) const {
		const ASTInitialTransition* temp =
				dynamic_cast<const ASTInitialTransition*>(transition);
		if (temp != 0) {
			bool eq_location =
					location_ != 0 ?
							(location_->equals(temp->location_)) :
							(temp->location_ == 0);
			if (!eq_location)
				return false;
			bool eq_action =
					action_ != 0 ?
							(action_->equals(temp->action_)) :
							(temp->action_ == 0);
			if (!eq_action)
				return false;
			return true;
		}
		return false;
	}

	~ASTInitialTransition() {
		if (location_)
			delete location_;
		if (action_)
			delete action_;
	}
};

/* class for a single transition */
class ASTSingleTransition: public ASTTransition {

	ASTIdExpression* label_;
	ASTIdExpression* source_;
	ASTIdExpression* target_;

	ASTExpression* guard_;

	ASTStatement* action_;
	bool is_internal_;

public:

	explicit ASTSingleTransition(ASTIdExpression* label, ASTIdExpression* source,
			ASTIdExpression* target) :
			label_(label), source_(source), target_(target), guard_(0), action_(
					0), is_internal_(false) {
		if (label_)
			label_->set_parent(*this);
		if (source_)
			source_->set_parent(*this);
		if (target_)
			target_->set_parent(*this);
	}

	explicit ASTSingleTransition(ASTIdExpression* label, ASTIdExpression* source,
			ASTIdExpression* target, ASTExpression* guard) :
			label_(label), source_(source), target_(target), guard_(guard), action_(
					0), is_internal_(false) {
		if (label_)
			label_->set_parent(*this);
		if (source_)
			source_->set_parent(*this);
		if (target_)
			target_->set_parent(*this);

		if (guard_)
			guard_->set_parent(*this);

	}

	explicit ASTSingleTransition(ASTIdExpression* label, ASTIdExpression* source,
			ASTIdExpression* target, ASTStatement* action) :
			label_(label), source_(source), target_(target), guard_(0), action_(
					action), is_internal_(false) {
		if (label_)
			label_->set_parent(*this);
		if (source_)
			source_->set_parent(*this);
		if (target_)
			target_->set_parent(*this);

		if (action_)
			action_->set_parent(*this);

	}

	explicit ASTSingleTransition(ASTIdExpression* label, ASTIdExpression* source,
			ASTIdExpression* target, ASTExpression* guard, ASTStatement* action) :
			label_(label), source_(source), target_(target), guard_(guard), action_(
					action), is_internal_(false) {
		if (label_)
			label_->set_parent(*this);
		if (source_)
			source_->set_parent(*this);
		if (target_)
			target_->set_parent(*this);

		if (guard_)
			guard_->set_parent(*this);

		if (action_)
			action_->set_parent(*this);
	}

	explicit ASTSingleTransition(const ASTSingleTransition& transition) :
			ASTTransition(transition) {
		label_ = 0;
		source_ = 0;
		target_ = 0;
		guard_ = 0;
		action_ = 0;

		if (transition.label_) {
			set_label(transition.label_->clone());
		}

		if (transition.source_) {
			set_source(transition.source_->clone());
		}

		if (transition.target_) {
			set_target(transition.target_->clone());
		}

		if (transition.guard_)
			set_guard(transition.guard_->clone());

		if (transition.action_)
			set_action(transition.action_->clone());
		is_internal_ = transition.is_internal_;
	}

	ASTSingleTransition& operator=(const ASTSingleTransition& transition);

	bool accept(ASTVisitor& v) const;

	ASTSingleTransition* clone() const {
		return new ASTSingleTransition(*this);
	}

	bool equals(const ASTTransition* transition) const {
		const ASTSingleTransition* temp =
				dynamic_cast<const ASTSingleTransition*>(transition);
		if (temp != 0) {

			if(is_internal_ != temp->is_internal_)
				return false;

			bool eq_label =
					(label_ != 0) ?
							(label_->equals(temp->label_)) :
							(temp->label_ == 0);

			if (!eq_label)
				return false;

			bool eq_source =
					(source_ != 0) ?
							source_->equals(temp->source_) :
							(temp->source_ == 0);

			if (!eq_source)
				return false;

			bool eq_target =
					(target_ != 0) ?
							target_->equals(temp->target_) :
							(temp->target_ == 0);

			if (!eq_target)
				return false;

			bool eq_guard =
					(guard_ != 0) ?
							guard_->equals(temp->guard_) : (temp->guard_ == 0);

			if (!eq_guard)
				return false;

			bool eq_action =
					(action_ != 0) ?
							action_->equals(temp->action_) :
							(temp->action_ == 0);

			if (!eq_action)
				return false;

			return true;
		}
		return false;
	}

	const ASTIdExpression* label() const {
		return label_;
	}
	;

	const ASTIdExpression* source() const {
		return source_;
	}

	const ASTIdExpression* target() const {
		return target_;
	}

	const ASTExpression* guard() const {
		return guard_;
	}

	const ASTStatement* action() const {
		return action_;
	}

	bool is_internal() const {return is_internal_;}

	void set_label(ASTIdExpression* label) {
		if (label_)
			delete label_;

		label_ = label;

		if (label_)
			label_->set_parent(*this);
	}

	void set_source(ASTIdExpression* source) {
		if (source_)
			delete source_;

		source_ = source;

		if (source_)
			source_->set_parent(*this);
	}

	void set_target(ASTIdExpression* target) {
		if (target_)
			delete target_;

		target_ = target;

		if (target_)
			target_->set_parent(*this);
	}

	void set_guard(ASTExpression* guard) {
		if (guard_)
			delete guard_;
		guard_ = guard;
		if (guard_)
			guard_->set_parent(*this);
	}

	void set_action(ASTStatement* action) {
		if (action_)
			delete action_;
		action_ = action;
		if (action_)
			action_->set_parent(*this);
	}

	void set_internal(bool internal){
		is_internal_=internal;
	}

	~ASTSingleTransition() {
		if (label_)
			delete label_;

		if (source_)
			delete source_;

		if (target_)
			delete target_;

		if (guard_)
			delete guard_;

		if (action_)
			delete action_;
	}
};

class ASTInteraction: public ASTTransition {

	ASTExpression* ports_; // connected ports
	ASTExpression* guard_;
	ASTStatement* action_;

public:
	explicit ASTInteraction(ASTExpression* ports) :
			ports_(ports), guard_(0), action_(0) {
		if (ports_)
			ports_->set_parent(*this);
	}

	explicit ASTInteraction(const ASTInteraction& interaction) :
			ASTTransition(interaction) {
		ports_ = 0;
		guard_ = 0;
		action_ = 0;
		if (interaction.ports_)
			set_ports(interaction.ports_->clone());
		if (interaction.guard_)
			set_guard(interaction.guard_->clone());
		if (interaction.action_)
			set_action(interaction.action_->clone());
	}

	ASTInteraction& operator=(const ASTInteraction& interaction) {
		if (this != &interaction) {
			if (ports_) {
				delete ports_;
				ports_ = 0;
			}
			if (guard_) {
				delete guard_;
				guard_ = 0;
			}
			if (action_) {
				delete action_;
				action_ = 0;
			}
			ASTTransition::operator =(interaction);
			if (interaction.ports_)
				set_ports(interaction.ports_->clone());
			if (interaction.guard_)
				set_guard(interaction.guard_->clone());
			if (interaction.action_)
				set_action(interaction.action_->clone());
		}
		return *this;
	}

	void set_ports(ASTExpression* ports) {
		if (ports_)
			delete ports_;
		ports_ = ports;
		if (ports_)
			ports_->set_parent(*this);
	}

	void set_guard(ASTExpression* guard) {
		if (guard_)
			delete guard_;
		guard_ = guard;
		if (guard_)
			guard_->set_parent(*this);
	}

	void set_action(ASTStatement* action) {
		if (action_)
			delete action_;
		action_ = action;
		if (action_)
			action_->set_parent(*this);
	}

	const ASTExpression* connected_ports() const {
		return ports_;
	}
	const ASTExpression* guard() const {
		return guard_;
	}
	const ASTStatement* action() const {
		return action_;
	}

	bool accept(ASTVisitor& v) const;
	bool equals(const ASTTransition* interaction) const {
		const ASTInteraction* temp =
				dynamic_cast<const ASTInteraction*>(interaction);
		if (temp != 0) {
			bool eq_ports =
					ports_ != 0 ?
							(ports_->equals(temp->ports_)) :
							(temp->ports_ == 0);
			if (!eq_ports)
				return false;
			bool eq_guard =
					guard_ != 0 ?
							(guard_->equals(temp->guard_)) :
							(temp->guard_ == 0);
			if (!eq_guard)
				return false;
			bool eq_action =
					action_ != 0 ?
							(action_->equals(temp->action_)) :
							(temp->action_ == 0);
			if (!eq_action)
				return false;
			return true;
		}
		return false;
	}

	ASTInteraction* clone() const {
		return new ASTInteraction(*this);
	}

	~ASTInteraction() {
		if (ports_)
			delete ports_;
		if (guard_)
			delete guard_;
		if (action_)
			delete action_;
	}
};

/* class for a list of transitions */
class ASTTransitionList: public ASTTransition {

	typedef std::vector<ASTTransition*> transitions_t;
	typedef transitions_t::iterator iterator;

	transitions_t transitions_;

public:
	typedef transitions_t::const_iterator const_iterator;

	explicit ASTTransitionList() {
	}

	// copy constructor
	explicit ASTTransitionList(const ASTTransitionList&);

	// copy assignment
	ASTTransitionList& operator=(const ASTTransitionList&);

	unsigned int size() const {
		return transitions_.size();
	}

	bool empty() const {
		return transitions_.empty();
	}

	const_iterator begin() const {
		return transitions_.begin();
	}

	const_iterator end() const {
		return transitions_.end();
	}

	const ASTTransition* transition(unsigned int pos) const {
		if (pos < transitions_.size()) {
			return transitions_[pos];
		}
		return 0;
	}

	ASTTransitionList& add_transition(ASTTransition* transition) {
		if (transition) {
			transition->set_parent(*this);
			transitions_.push_back(transition);
		}
		return *this;
	}

	bool set_transition(ASTTransition* transition, unsigned int pos) {
		if (pos < transitions_.size()) {
			ASTTransition* old_tran = transitions_[pos];
			if (old_tran)
				delete old_tran;
			transitions_[pos] = transition;
			return true;
		}
		return false;
	}

	bool accept(ASTVisitor& v) const;

	ASTTransitionList* clone() const {
		return new ASTTransitionList(*this);
	}

	bool equals(const ASTTransition* transition) const {
		const ASTTransitionList* temp =
				dynamic_cast<const ASTTransitionList*>(transition);

		if (temp != 0) {
			unsigned int t_size = size();
			if (t_size == temp->size()) {
				for (unsigned int i = 0; i < t_size; i++) {
					ASTTransition* t1 = transitions_[i];
					ASTTransition* t2 = temp->transitions_[i];

					bool eq_t = (t1 != 0) ? t1->equals(t2) : (t2 == 0);
					if (!eq_t)
						return false;

				}
				return true;
			}
		}

		return false;
	}

	~ASTTransitionList() {
		for (iterator it = transitions_.begin(); it < transitions_.end();
				++it) {

			if (*it)
				delete *it;
		}

		transitions_.clear();
	}
};

/**
 *  declaration base class will have the following subclasses:
 *  	native data declaration
 *  	port declaration
 *  	connector declaration
 *  	component declaration
 *  	declaration list
 */
class ASTDeclaration: public ASTNode {

public:

	explicit ASTDeclaration() {
	}

	explicit ASTDeclaration(const ASTDeclaration& declaration) :
			ASTNode(declaration) {
	}

	ASTDeclaration& operator=(const ASTDeclaration& declaration) {
		if (this != &declaration)
			ASTNode::operator=(declaration);

		return *this;
	}

	virtual ASTDeclaration* clone() const = 0;

	virtual bool equals(const ASTDeclaration *declaration) const = 0;

	virtual ~ASTDeclaration() {
	}

};
// class ASTDeclaration

// Note: in BIP, data declaration has no initial value.
class ASTDataDeclaration: public ASTDeclaration {

public:
	enum Type {

		UNSPECIFIED, FLOAT, INT, BOOL
	};

private:

	Type type_;
	ASTIdExpression* name_;

	bool is_parameter_;

public:

	explicit ASTDataDeclaration(ASTIdExpression* name) :
			type_(UNSPECIFIED), name_(name), is_parameter_(false) {
		if (name_)
			name_->set_parent(*this);
	}

	explicit ASTDataDeclaration(const ASTDataDeclaration& data_declaration) :
			ASTDeclaration(data_declaration) {
		type_ = data_declaration.type_;
		is_parameter_ = data_declaration.is_parameter_;
		if (data_declaration.name_)
			set_name(data_declaration.name_->clone());
	}

	void set_name(ASTIdExpression* name) {
		if (name_)
			delete name_;
		name_ = name;
		if (name_)
			name_->set_parent(*this);
	}

	void set_type(Type type) {
		type_ = type;
	}

	void set_is_parameter(bool parameter){
		is_parameter_ = parameter;
	}

	const ASTIdExpression* name() const {
		return name_;
	}

	Type type() const {
		return type_;
	}

	bool is_parameter() const {
		return is_parameter_;
	}

	bool is_int() const {
		return type_ == INT ? true : false;
	}
	bool is_float() const {
		return type_ == FLOAT ? true : false;
	}
	bool is_bool() const {
		return type_ == BOOL ? true : false;
	}

	ASTDataDeclaration& operator=(const ASTDataDeclaration& data_declaration) {
		if (this != &data_declaration) {
			if (name_) {
				delete name_;
				name_ = 0;
			}
			ASTDeclaration::operator=(data_declaration);
			if (data_declaration.name_) {
				set_name(data_declaration.name_->clone());
			}
			type_ = data_declaration.type_;
			is_parameter_= data_declaration.is_parameter_;
		}
		return *this;
	}

	bool equals(const ASTDeclaration* declaration) const {
		const ASTDataDeclaration* data_declaration =
				dynamic_cast<const ASTDataDeclaration*>(declaration);
		if (data_declaration != 0) {
			if (type_ != data_declaration->type_)
				return false;
			if(is_parameter_ != data_declaration->is_parameter_)
				return false;
			bool eq =
					(name_ != 0) ?
							(name_->equals(data_declaration->name_)) :
							(data_declaration->name_ == 0);
			if (!eq)
				return false;

			return true;
		}
		return false;
	}

	bool accept(ASTVisitor& v) const;

	ASTDataDeclaration* clone() const {
		return new ASTDataDeclaration(*this);
	}

	~ASTDataDeclaration() {
		if (name_)
			delete name_;
	}
};

/**
 *  port declaration:
 *  	name of the port
 *  	and the list of parameters
 *
 */
class ASTPortDeclaration: public ASTDeclaration {

	ASTIdExpression* type_; // the name of the port definition
	ASTIdExpression* name_;

	ASTExpression* params_;
	bool is_exported_;
	bool is_parameter_;

public:
	explicit ASTPortDeclaration(ASTIdExpression* type, ASTIdExpression* name) :
			type_(type), name_(name), params_(0), is_exported_(false),
			is_parameter_(false){
		if (type_)
			type_->set_parent(*this);
		if (name_)
			name_->set_parent(*this);

	}

	explicit ASTPortDeclaration(ASTIdExpression* type, ASTIdExpression* name,
			ASTExpression* params) :
			type_(type), name_(name), params_(params), is_exported_(false),
			is_parameter_(false) {
		if (type_)
			type_->set_parent(*this);
		if (name_)
			name_->set_parent(*this);
		if (params_)
			params_->set_parent(*this);
	}

	explicit ASTPortDeclaration(const ASTPortDeclaration& declaration) :
			ASTDeclaration(declaration) {
		type_ = 0;
		name_ = 0;
		params_ = 0;

		if (declaration.type_)
			set_type(declaration.type_->clone());
		if (declaration.name_)
			set_name(declaration.name_->clone());
		if (declaration.params_)
			set_parameters(declaration.params_->clone());
		set_is_exported(declaration.is_exported_);
		set_is_parameter(declaration.is_parameter_);
	}

	void set_type(ASTIdExpression* type) {
		if (type_)
			delete type_;
		type_ = type;
		if (type_)
			type_->set_parent(*this);
	}

	void set_name(ASTIdExpression* name) {
		if (name_)
			delete name_;
		name_ = name;
		if (name_)
			name_->set_parent(*this);
	}

	void set_parameters(ASTExpression* params) {
		if (params_)
			delete params_;
		params_ = params;
		if (params_)
			params_->set_parent(*this);
	}

	void set_is_exported(bool exported) {
		is_exported_ = exported;
	}

	void set_is_parameter(bool parameter){
		is_parameter_ = parameter;
	}

	bool is_exported() const {
		return is_exported_;
	}

	bool is_parameter() const{
		return is_parameter_;
	}

	ASTIdExpression* type() const {
		return type_;
	}

	ASTIdExpression* name() const {
		return name_;
	}

	ASTExpression* parameters() const {
		return params_;
	}

	ASTPortDeclaration& operator=(const ASTPortDeclaration& declaration) {
		if (this != &declaration) {
			if (type_) {
				delete type_;
				type_ = 0;
			}
			if (name_) {
				delete name_;
				name_ = 0;
			}
			if (params_) {
				delete params_;
				params_ = 0;
			}

			ASTDeclaration::operator=(declaration);

			if (declaration.type_)
				set_type(declaration.type_->clone());
			if (declaration.name_)
				set_name(declaration.name_->clone());
			if (declaration.params_)
				set_parameters(declaration.params_->clone());

			is_exported_ = declaration.is_exported_;
			is_parameter_ = declaration.is_parameter_;
		}
		return *this;
	}

	bool accept(ASTVisitor& v) const;
	bool equals(const ASTDeclaration* declaration) const {
		const ASTPortDeclaration* port_declaration =
				dynamic_cast<const ASTPortDeclaration*>(declaration);

		if (port_declaration != 0) {
			if (is_exported_ != port_declaration->is_exported_)
				return false;

			if(is_parameter_ != port_declaration->is_parameter_)
				return false;

			bool eq_name =
					(name_ != 0) ?
							(name_->equals(port_declaration->name_)) :
							(port_declaration->name_ == 0);
			if (!eq_name)
				return false;

			bool eq_type =
					(type_ != 0) ?
							(type_->equals(port_declaration->type_)) :
							(port_declaration->type_ == 0);
			if (!eq_type)
				return false;

			bool eq_params =
					(params_ != 0) ?
							(params_->equals(port_declaration->params_)) :
							(port_declaration->params_ == 0);
			if (!eq_params)
				return false;

			return true;
		}
		return false;
	}

	ASTPortDeclaration* clone() const {
		return new ASTPortDeclaration(*this);
	}

	~ASTPortDeclaration() {
		if (type_)
			delete type_;
		if (name_)
			delete name_;
		if (params_)
			delete params_;
	}

};

class ASTConnectorDeclaration: public ASTDeclaration {

	ASTIdExpression* type_;
	ASTIdExpression* name_;
	ASTExpression* params_; //! it should be a single qualifiedId expression or a list

public:

	explicit ASTConnectorDeclaration(ASTIdExpression* type,
			ASTIdExpression* name, ASTExpression* params) :
			type_(type), name_(name), params_(params) {
		if (type_)
			type_->set_parent(*this);
		if (name_)
			name_->set_parent(*this);
		if (params_)
			params_->set_parent(*this);
	}

	explicit ASTConnectorDeclaration(const ASTConnectorDeclaration& declaration) :
			ASTDeclaration(declaration) {
		type_ = 0;
		name_ = 0;
		params_ = 0;
		if (declaration.type_)
			set_type(declaration.type_->clone());
		if (declaration.name_)
			set_name(declaration.name_->clone());
		if (declaration.params_)
			set_parameters(declaration.params_->clone());
	}

	ASTConnectorDeclaration& operator=(
			const ASTConnectorDeclaration& declaration) {
		if (this != &declaration) {
			if (type_) {
				delete type_;
				type_ = 0;
			}
			if (name_) {
				delete name_;
				name_ = 0;
			}
			if (params_) {
				delete params_;
				params_ = 0;
			}
			ASTDeclaration::operator=(declaration);
			if (declaration.name_)
				set_name(declaration.name_->clone());
			if (declaration.type_)
				set_type(declaration.type_->clone());
			if (declaration.params_)
				set_parameters(declaration.params_->clone());
		}
		return *this;
	}

	bool accept(ASTVisitor& v) const;

	void set_type(ASTIdExpression* type) {
		if (type_)
			delete type_;
		type_ = type;
		if (type_)
			type_->set_parent(*this);
	}

	void set_name(ASTIdExpression* name) {
		if (name_)
			delete name_;
		name_ = name;
		if (name_)
			name_->set_parent(*this);
	}

	void set_parameters(ASTExpression* params) {
		if (params_)
			delete params_;
		params_ = params;
		if (params_)
			params_->set_parent(*this);
	}

	ASTIdExpression* type() const {
		return type_;
	}

	ASTIdExpression* name() const {
		return name_;
	}

	ASTExpression* parameters() const {
		return params_;
	}

	bool equals(const ASTDeclaration* declaration) const {
		const ASTConnectorDeclaration* c_declaration =
				dynamic_cast<const ASTConnectorDeclaration*>(declaration);

		if (c_declaration != 0) {

			bool eq_name =
					(name_ != 0) ?
							(name_->equals(c_declaration->name_)) :
							(c_declaration->name_ == 0);
			if (!eq_name)
				return false;

			bool eq_type =
					(type_ != 0) ?
							(type_->equals(c_declaration->type_)) :
							(c_declaration->type_ == 0);
			if (!eq_type)
				return false;

			bool eq_params =
					(params_ != 0) ?
							(params_->equals(c_declaration->params_)) :
							(c_declaration->params_ == 0);
			if (!eq_params)
				return false;

			return true;
		}
		return false;
	}

	ASTConnectorDeclaration* clone() const {
		return new ASTConnectorDeclaration(*this);
	}

	~ASTConnectorDeclaration() {
		if (type_)
			delete type_;
		if (name_)
			delete name_;
		if (params_)
			delete params_;

	}
};

class ASTAtomDeclaration: public ASTDeclaration {

	ASTIdExpression* type_;
	ASTIdExpression* name_;
	ASTExpression* params_;

public:
	explicit ASTAtomDeclaration(ASTIdExpression* type, ASTIdExpression* name) :
			type_(type), name_(name), params_(0) {
		if (type_)
			type_->set_parent(*this);
		if (name_)
			name_->set_parent(*this);

	}

	explicit ASTAtomDeclaration(ASTIdExpression* type, ASTIdExpression* name,
			ASTExpression* params) :
			type_(type), name_(name), params_(params) {
		if (type_)
			type_->set_parent(*this);
		if (name_)
			name_->set_parent(*this);

		if (params_)
			params_->set_parent(*this);
	}

	explicit ASTAtomDeclaration(const ASTAtomDeclaration& declaration) :
			ASTDeclaration(declaration) {
		type_ = 0;
		name_ = 0;
		params_ = 0;
		if (declaration.type_)
			set_type(declaration.type_->clone());
		if (declaration.name_)
			set_name(declaration.name_->clone());
		if (declaration.params_)
			set_parameters(declaration.params_->clone());
	}

	ASTAtomDeclaration& operator=(const ASTAtomDeclaration& declaration) {
		if (this != &declaration) {
			if (type_) {
				delete type_;
				type_ = 0;
			}
			if (name_) {
				delete name_;
				name_ = 0;
			}
			if (params_) {
				delete params_;
				params_ = 0;
			}
			ASTDeclaration::operator=(declaration);
			if (declaration.name_)
				set_name(declaration.name_->clone());
			if (declaration.type_)
				set_type(declaration.type_->clone());
			if (declaration.params_)
				set_parameters(declaration.params_->clone());
		}
		return *this;
	}

	bool accept(ASTVisitor& v) const;

	void set_type(ASTIdExpression* type) {
		if (type_)
			delete type_;
		type_ = type;
		if (type_)
			type_->set_parent(*this);
	}

	void set_name(ASTIdExpression* name) {
		if (name_)
			delete name_;
		name_ = name;
		if (name_)
			name_->set_parent(*this);
	}

	void set_parameters(ASTExpression* params) {
		if (params_)
			delete params_;
		params_ = params;
		if (params_)
			params_->set_parent(*this);
	}

	ASTIdExpression* type() const {
		return type_;
	}

	ASTIdExpression* name() const {
		return name_;
	}

	ASTExpression* parameters() const {
		return params_;
	}

	bool equals(const ASTDeclaration* declaration) const {
		const ASTAtomDeclaration* c_declaration =
				dynamic_cast<const ASTAtomDeclaration*>(declaration);

		if (c_declaration != 0) {

			bool eq_name =
					(name_ != 0) ?
							(name_->equals(c_declaration->name_)) :
							(c_declaration->name_ == 0);
			if (!eq_name)
				return false;

			bool eq_type =
					(type_ != 0) ?
							(type_->equals(c_declaration->type_)) :
							(c_declaration->type_ == 0);
			if (!eq_type)
				return false;

			bool eq_params =
					(params_ != 0) ?
							(params_->equals(c_declaration->params_)) :
							(c_declaration->params_ == 0);
			if (!eq_params)
				return false;

			return true;
		}
		return false;
	}

	ASTAtomDeclaration* clone() const {
		return new ASTAtomDeclaration(*this);
	}

	~ASTAtomDeclaration() {
		if (type_)
			delete type_;
		if (name_)
			delete name_;
		if (params_)
			delete params_;
	}
};

class ASTDeclarationList: public ASTDeclaration {

	typedef std::vector<ASTDeclaration*> declarations_t;
	declarations_t declarations_;
	typedef declarations_t::iterator iterator;

public:
	typedef declarations_t::const_iterator const_iterator;

	explicit ASTDeclarationList() {
	}

	explicit ASTDeclarationList(const ASTDeclarationList& declarations);

	ASTDeclarationList& operator=(const ASTDeclarationList&);

	bool accept(ASTVisitor& v) const;

	ASTDeclarationList* clone() const {
		return new ASTDeclarationList(*this);
	}

	unsigned int size() const {
		return declarations_.size();
	}

	bool empty() const {
		return declarations_.empty();
	}

	const_iterator begin() const {
		return declarations_.begin();
	}

	const_iterator end() const {
		return declarations_.end();
	}

	const ASTDeclaration* declaration(unsigned int pos) const {
		if (pos < declarations_.size()) {
			return declarations_[pos];
		}
		return 0;
	}

	ASTDeclarationList& add_declaration(ASTDeclaration* declaration) {
		if (declaration) {
			declaration->set_parent(*this);
			declarations_.push_back(declaration);
		}
		return *this;
	}

	bool set_declaration(ASTDeclaration* declaration, unsigned int pos) {
		if (pos < declarations_.size()) {
			ASTDeclaration* old_tran = declarations_[pos];
			if (old_tran)
				delete old_tran;
			declarations_[pos] = declaration;
			return true;
		}
		return false;
	}

	bool equals(const ASTDeclaration* declaration) const {
		const ASTDeclarationList* temp =
				dynamic_cast<const ASTDeclarationList*>(declaration);

		if (temp != 0) {
			unsigned int t_size = size();
			if (t_size == temp->size()) {
				for (unsigned int i = 0; i < t_size; i++) {
					ASTDeclaration* t1 = declarations_[i];
					ASTDeclaration* t2 = temp->declarations_[i];

					bool eq_t = (t1 != 0) ? t1->equals(t2) : (t2 == 0);
					if (!eq_t)
						return false;
				}
				return true;
			}
		}
		return false;
	}

	~ASTDeclarationList() {
		for (declarations_t::iterator it = declarations_.begin();
				it != declarations_.end(); ++it) {
			if (*it) {
				delete (*it);
			}
		}
		declarations_.clear();
	}

};

/**
 *  definition abstract class will have the four following subclasses:
 *  port type definition
 *  atom type definition
 *  connector type definition
 *  compound type definition
 *
 **/
class ASTDefinition: public ASTNode {

public:

	explicit ASTDefinition() {
	}

	explicit ASTDefinition(const ASTDefinition& definition) :
			ASTNode(definition) {
	}

	ASTDefinition& operator=(const ASTDefinition& definition) {
		if (this != &definition)
			ASTNode::operator=(definition);

		return *this;
	}

	virtual ASTDefinition* clone() const = 0;

	virtual bool equals(const ASTDefinition *definition) const = 0;

	virtual ~ASTDefinition() {
	}

};
// class ASTDefinition

/**
 *  class for the port type definition
 *  	port type name
 *  	and the list of parameters
 *
 */
class ASTPortDefinition: public ASTDefinition {

	ASTIdExpression* name_;
	ASTDeclaration* params_; // it could be a single data declaration or a list.

public:

	explicit ASTPortDefinition(ASTIdExpression* name) :
			name_(name), params_(0) {
		if(name_)
			name_->set_parent(*this);
	}

	explicit ASTPortDefinition(ASTIdExpression* name, ASTDeclaration* params) :
			name_(name), params_(params) {
		if(params_)
					params_->set_parent(*this);
				if(name_)
					name_->set_parent(*this);

	}

	explicit ASTPortDefinition(const ASTPortDefinition& definition) :
			ASTDefinition(definition) {
		name_ = 0;
		params_ = 0;
		if (definition.name_)
			set_name(definition.name_->clone());
		if (definition.params_)
			set_parameters(definition.params_->clone());
	}

	ASTPortDefinition& operator=(const ASTPortDefinition& definition) {
		if (this != &definition) {
			if (name_) {
				delete name_;
				name_ = 0;
			}
			if (params_) {
				delete params_;
				params_ = 0;
			}
			ASTDefinition::operator =(definition);
			if (definition.name_)
				set_name(definition.name_->clone());
			if (definition.params_)
				set_parameters(definition.params_->clone());
		}
		return *this;
	}

	void set_name(ASTIdExpression* name) {
		if (name_)
			delete name_;
		name_ = name;
		if (name_)
			name_->set_parent(*this);
	}

	void set_parameters(ASTDeclaration* params) {
		if (params_)
			delete params_;
		params_ = params;
		if (params_)
			params_->set_parent(*this);
	}

	const ASTIdExpression* name() const {
		return name_;
	}

	const ASTDeclaration* parameters() const {
		return params_;
	}

	bool accept(ASTVisitor& v) const;

	bool equals(const ASTDefinition* definition) const {
		const ASTPortDefinition* temp =
				dynamic_cast<const ASTPortDefinition*>(definition);
		if (temp != 0) {
			bool eq_name =
					name_ != 0 ?
							(name_->equals(temp->name_)) : (temp->name_ == 0);
			if (!eq_name)
				return false;
			bool eq_params =
					params_ != 0 ?
							(params_->equals(temp->params_)) :
							(temp->params_ == 0);
			if (!eq_params)
				return false;
			return true;
		}
		return false;
	}

	ASTPortDefinition* clone() const {
		return new ASTPortDefinition(*this);
	}

	~ASTPortDefinition() {
		if (name_)
			delete name_;
		if (params_)
			delete params_;
	}

};

class ASTAtomDefinition: public ASTDefinition {

	ASTIdExpression* name_;
	ASTDeclaration* params_; //optional
	ASTDeclaration* data_decls_; //optional
	ASTDeclaration* port_decls_; //optional
	ASTExpression* control_locs_;
	ASTInitialTransition* initial_tran_;
	ASTTransition* transitions_;

public:
	explicit ASTAtomDefinition(ASTIdExpression* name, ASTExpression* locs,
			ASTInitialTransition* init, ASTTransition* tran) :
			name_(name), params_(0), data_decls_(0), port_decls_(0),
			control_locs_(locs), initial_tran_(init), transitions_(tran)
	{
		if(name_)
			name_->set_parent(*this);
		if(control_locs_)
			control_locs_->set_parent(*this);
		if(initial_tran_)
			initial_tran_->set_parent(*this);
		if(transitions_)
			transitions_->set_parent(*this);
	}

	void set_parameters(ASTDeclaration* params) {
		if (params_)
			delete params_;
		params_ = params;
		if (params_)
			params_->set_parent(*this);
	}

	void set_name(ASTIdExpression* name) {
		if (name_)
			delete name_;
		name_ = name;
		if (name_)
			name_->set_parent(*this);
	}

	void set_data_declarations(ASTDeclaration* data_decls) {
		if (data_decls_)
			delete data_decls_;
		data_decls_ = data_decls;
		if (data_decls_)
			data_decls_->set_parent(*this);
	}

	void set_port_declarations(ASTDeclaration* port_decls) {
		if (port_decls_)
			delete port_decls_;
		port_decls_ = port_decls;
		if (port_decls_)
			port_decls_->set_parent(*this);
	}

	void set_locations(ASTExpression* locs) {
		if (control_locs_)
			delete control_locs_;
		control_locs_ = locs;
		if (control_locs_)
			control_locs_->set_parent(*this);
	}

	void set_init_transition(ASTInitialTransition* init) {
		if (initial_tran_)
			delete initial_tran_;
		initial_tran_ = init;
		if (initial_tran_)
			initial_tran_->set_parent(*this);
	}

	void set_transitions(ASTTransition* trans) {
		if (transitions_)
			delete transitions_;
		transitions_ = trans;
		if (transitions_)
			transitions_->set_parent(*this);
	}

	const ASTIdExpression* name() const {
		return name_;
	}
	const ASTDeclaration* parameters() const {
		return params_;
	}
	const ASTDeclaration* data_declarations() const {
		return data_decls_;
	}
	const ASTDeclaration* port_declarations() const {
		return port_decls_;
	}
	const ASTExpression* control_location() const {
		return control_locs_;
	}
	const ASTInitialTransition* initial_transition() const {
		return initial_tran_;
	}
	const ASTTransition* transitions() const {
		return transitions_;
	}

	explicit ASTAtomDefinition(const ASTAtomDefinition& definition) :
			ASTDefinition(definition) {
		if (definition.name_)
			set_name(definition.name_->clone());
		if (definition.params_)
			set_parameters(definition.params_->clone());
		if (definition.data_decls_)
			set_data_declarations(definition.data_decls_->clone());
		if (definition.port_decls_)
			set_port_declarations(definition.port_decls_->clone());
		if (definition.control_locs_)
			set_locations(definition.control_locs_->clone());
		if (definition.initial_tran_)
			set_init_transition(definition.initial_tran_->clone());
		if (definition.transitions_)
			set_transitions(definition.transitions_->clone());
	}

	ASTAtomDefinition& operator=(const ASTAtomDefinition& definition) {
		if (this != &definition) {
			if (name_) {
				delete name_;
				name_ = 0;
			}
			if (params_) {
				delete params_;
				params_ = 0;
			}
			if (data_decls_) {
				delete data_decls_;
				data_decls_ = 0;
			}
			if (port_decls_) {
				delete port_decls_;
				port_decls_ = 0;
			}
			if (control_locs_) {
				delete control_locs_;
				control_locs_ = 0;
			}
			if (initial_tran_) {
				delete initial_tran_;
				initial_tran_ = 0;
			}
			if (transitions_) {
				delete transitions_;
				transitions_ = 0;
			}
			ASTDefinition::operator =(definition);
			if (definition.name_)
				set_name(definition.name_->clone());
			if (definition.params_)
				set_parameters(definition.params_->clone());
			if (definition.data_decls_)
				set_data_declarations(definition.data_decls_->clone());
			if (definition.port_decls_)
				set_port_declarations(definition.port_decls_->clone());
			if (definition.control_locs_)
				set_locations(definition.control_locs_->clone());
			if (definition.initial_tran_)
				set_init_transition(definition.initial_tran_->clone());
			if (definition.transitions_)
				set_transitions(definition.transitions_->clone());
		}
		return *this;
	}

	bool accept(ASTVisitor& v) const;
	bool equals(const ASTDefinition* definition) const {
		const ASTAtomDefinition* temp =
				dynamic_cast<const ASTAtomDefinition*>(definition);
		if (temp != 0) {
			bool eq_name =
					name_ != 0 ?
							(name_->equals(temp->name_)) : (temp->name_ == 0);
			if (!eq_name)
				return false;
			bool eq_params =
					params_ != 0 ?
							(params_->equals(temp->params_)) :
							(temp->params_ == 0);
			if (!eq_params)
				return false;
			bool eq_data =
					data_decls_ != 0 ?
							(data_decls_->equals(temp->data_decls_)) :
							(temp->data_decls_ == 0);
			if (!eq_data)
				return false;
			bool eq_port =
					port_decls_ != 0 ?
							(port_decls_->equals(temp->port_decls_)) :
							(temp->port_decls_ == 0);
			if (!eq_port)
				return false;
			bool eq_contrl =
					control_locs_ != 0 ?
							(control_locs_->equals(temp->control_locs_)) :
							(temp->control_locs_ == 0);
			if (!eq_contrl)
				return false;
			bool eq_init =
					initial_tran_ != 0 ?
							(initial_tran_->equals(temp->initial_tran_)) :
							(temp->initial_tran_ == 0);
			if (!eq_init)
				return false;
			bool eq_trans =
					transitions_ != 0 ?
							(transitions_->equals(temp->transitions_)) :
							(temp->transitions_ == 0);
			if (!eq_trans)
				return false;
		}
		return false;
	}

	ASTAtomDefinition* clone() const {
		return new ASTAtomDefinition(*this);
	}

	~ASTAtomDefinition() {
		if (name_)
			delete name_;
		if (params_)
			delete params_;
		if (data_decls_)
			delete data_decls_;
		if (port_decls_)
			delete port_decls_;
		if (control_locs_)
			delete control_locs_;
		if (initial_tran_)
			delete initial_tran_;
		if (transitions_)
			delete transitions_;
	}
};

class ASTConnectorDefinition: public ASTDefinition {

	ASTIdExpression* name_;
	ASTDeclaration* params_; // it should be a single port declaration or a list. note that this declaration does not contain the data parameters.

	ASTExpression* ports_; // it consists of the ports participating the interaction
	ASTTransition* interactions_; // it should be a single ASTInteraction or a list

public:
	explicit ASTConnectorDefinition(ASTIdExpression* name,
			ASTDeclaration* params, ASTExpression* ports) :
			name_(name), params_(params), ports_(ports), interactions_(0) {
		if(name_)
			name_->set_parent(*this);
		if(params_)
			params_->set_parent(*this);
		if(ports_)
			ports_->set_parent(*this);
	}

	explicit ASTConnectorDefinition(const ASTConnectorDefinition& connector) :
			ASTDefinition(connector) {
		name_ = 0;
		params_ = 0;
		ports_ = 0;
		interactions_ = 0;
		if (connector.name_)
			set_name(connector.name_->clone());
		if (connector.params_)
			set_parameters(connector.params_->clone());
		if (connector.ports_)
			set_ports(connector.ports_->clone());
		if (connector.interactions_)
			set_interactions(connector.interactions_->clone());
	}

	ASTConnectorDefinition& operator=(const ASTConnectorDefinition& connector) {
		if (this != &connector) {
			if (name_) {
				delete name_;
				name_ = 0;
			}
			if (params_) {
				delete params_;
				params_ = 0;
			}
			if (ports_) {
				delete ports_;
				ports_ = 0;
			}
			if (interactions_) {
				delete interactions_;
				interactions_ = 0;
			}
			ASTDefinition::operator =(connector);
			if (connector.name_)
				set_name(connector.name_->clone());
			if (connector.params_)
				set_parameters(connector.params_->clone());
			if (connector.ports_)
				set_ports(connector.ports_->clone());
			if (connector.interactions_)
				set_interactions(connector.interactions_->clone());
		}
		return *this;
	}

	void set_name(ASTIdExpression* name) {
		if (name_)
			delete name_;
		name_ = name;
		if (name_)
			name_->set_parent(*this);
	}

	void set_parameters(ASTDeclaration* params) {
		if (params_)
			delete params_;
		params_ = params;
		if (params_)
			params_->set_parent(*this);
	}

	void set_ports(ASTExpression* ports) {
		if (ports_)
			delete ports_;
		ports_ = ports;
		if (ports_)
			ports_->set_parent(*this);
	}

	void set_interactions(ASTTransition* interaction) {
		if (interactions_)
			delete interactions_;
		interactions_ = interaction;
		if (interactions_)
			interactions_->set_parent(*this);
	}

	const ASTIdExpression* name() const {
		return name_;
	}
	const ASTDeclaration* parameters() const {
		return params_;
	}
	const ASTExpression* connected_ports() const {
		return ports_;
	}
	const ASTTransition* interactions() const {
		return interactions_;
	}

	bool accept(ASTVisitor& v) const;
	bool equals(const ASTDefinition* definition) const {
		const ASTConnectorDefinition* temp =
				dynamic_cast<const ASTConnectorDefinition*>(definition);
		if (temp != 0) {
			bool eq_name =
					name_ != 0 ?
							(name_->equals(temp->name_)) : (temp->name_ == 0);
			if (!eq_name)
				return false;

			bool eq_params =
					params_ != 0 ?
							(params_->equals(temp->params_)) :
							(temp->params_ == 0);
			if (!eq_params)
				return false;

			bool eq_ports =
					ports_ != 0 ?
							(ports_->equals(temp->ports_)) :
							(temp->ports_ == 0);
			if (!eq_ports)
				return false;

			bool eq_ia =
					interactions_ != 0 ?
							(interactions_->equals(temp->interactions_)) :
							(temp->interactions_ == 0);
			if (!eq_ia)
				return false;

			return true;
		}
		return false;
	}

	ASTConnectorDefinition* clone() const {
		return new ASTConnectorDefinition(*this);
	}

	~ASTConnectorDefinition() {
		if (name_)
			delete name_;
		if (params_)
			delete params_;
		if (ports_)
			delete ports_;
		if (interactions_)
			delete interactions_;
	}
};

class ASTCompoundDefinition: public ASTDefinition {

	ASTIdExpression* name_;

	ASTDeclaration* components_;
	ASTDeclaration* connectors_;

public:
	explicit ASTCompoundDefinition(ASTIdExpression* name,
			ASTDeclaration* components, ASTDeclaration* connectors) :
			name_(name), components_(components), connectors_(connectors) {
		if(name_)
			name_->set_parent(*this);
		if(components_)
			components_->set_parent(*this);
		if(connectors_)
			connectors_->set_parent(*this);
	}

	explicit ASTCompoundDefinition(const ASTCompoundDefinition& compound) :
			ASTDefinition(compound) {
		components_ = 0;
		connectors_ = 0;
		name_ = 0;
		if (compound.name_)
			set_name(compound.name_->clone());
		if (compound.components_)
			set_components(compound.components_->clone());
		if (compound.connectors_)
			set_connectors(compound.connectors_->clone());
	}

	ASTCompoundDefinition& operator=(const ASTCompoundDefinition& compound) {
		if (this != &compound) {
			if (components_) {
				delete components_;
				components_ = 0;
			}
			if (connectors_) {
				delete connectors_;
				connectors_ = 0;
			}
			if (name_) {
				delete name_;
				name_ = 0;
			}
			ASTDefinition::operator =(compound);
			if (compound.name_)
				set_name(compound.name_->clone());
			if (compound.components_)
				set_components(compound.components_->clone());
			if (compound.connectors_)
				set_connectors(compound.connectors_->clone());
		}
		return *this;
	}

	void set_name(ASTIdExpression* name) {
		if (name_)
			delete name_;
		name_ = name;
		if (name_)
			name_->set_parent(*this);
	}

	void set_components(ASTDeclaration* components) {
		if (components_)
			delete components_;
		components_ = components;
		if (components_)
			components_->set_parent(*this);
	}

	void set_connectors(ASTDeclaration* connectors) {
		if (connectors_)
			delete connectors_;
		connectors_ = connectors;
		if (connectors_)
			connectors_->set_parent(*this);
	}

	const ASTIdExpression* name() const {
		return name_;
	}
	const ASTDeclaration* components() const {
		return components_;
	}
	const ASTDeclaration* connectors() const {
		return connectors_;
	}

	bool accept(ASTVisitor& v) const;
	bool equals(const ASTDefinition* definition) const {
		const ASTCompoundDefinition* temp =
				dynamic_cast<const ASTCompoundDefinition*>(definition);
		if (temp != 0) {
			bool eq_name =
					name_ != 0 ?
							(name_->equals(temp->name_)) : (temp->name_ == 0);
			if (!eq_name)
				return false;

			bool eq_comp =
					components_ != 0 ?
							(components_->equals(temp->components_)) :
							(temp->components_ == 0);
			if (!eq_comp)
				return false;

			bool eq_cnt =
					connectors_ != 0 ?
							(connectors_->equals(temp->connectors_)) :
							(temp->connectors_ == 0);
			if (!eq_cnt)
				return false;

			return true;
		}
		return false;
	}

	ASTCompoundDefinition* clone() const {
		return new ASTCompoundDefinition(*this);
	}

	~ASTCompoundDefinition() {
		if (name_)
			delete name_;
		if (components_)
			delete components_;
		if (connectors_)
			delete connectors_;
	}

};

/**
 *  the parsing result will be a list of definitions:
 *  port type definition
 *  connector type definition
 *  atom type definition
 *  compound type definition
 *
 */
class ASTTranslationUnit: public ASTNode {
	typedef std::vector<ASTDefinition*> definitions_t;
	typedef definitions_t::iterator iterator;

	definitions_t definitions_;

	ASTName* name_; // name of the package

	//! it is the list of qualified target locations to be searched
	ASTExpression* target_state_;

public:
	explicit ASTTranslationUnit() :
			name_(0), target_state_(0) {
	}

	explicit ASTTranslationUnit(ASTName* name, ASTExpression* target) :
			name_(name), target_state_(target) {
		if(name_)
			name_->set_parent(*this);

		if(target_state_)
			target_state_->set_parent(*this);
	}

	explicit ASTTranslationUnit(const ASTTranslationUnit&);

	ASTTranslationUnit& operator=(const ASTTranslationUnit&);

	ASTTranslationUnit* translation_unit() {
		return this;
	}

	//! this function checks the component passed as the parameter
	//! is involved into the list of target locations
	bool component_involved(std::string component_name) const {
		bool involved = false;

		ASTQualifiedIdExpression* id_expr =
				dynamic_cast<ASTQualifiedIdExpression*>(target_state_);
		ASTExpressionList* id_list=
				dynamic_cast<ASTExpressionList*>(target_state_);

		if(id_expr != 0){
			if(id_expr->qualifier()->name() == component_name)
				involved = true;
		} else if(id_list != 0){
			for(ASTExpressionList::const_iterator cit = id_list->begin();
					cit != id_list->end() && !involved; ++cit){
				ASTQualifiedIdExpression* temp_id = dynamic_cast<ASTQualifiedIdExpression*>(*cit);
				if(temp_id->qualifier()->name() == component_name)
					involved = true;
			}
		}

		return involved;
	}

	typedef definitions_t::const_iterator const_iterator;

	const_iterator begin() const {
		return definitions_.begin();
	}
	const_iterator end() const {
		return definitions_.end();
	}

	unsigned int size() const {
		return definitions_.size();
	}
	bool empty() const {
		return definitions_.empty();
	}

	ASTTranslationUnit& add_definition(ASTDefinition *definition) {
		if (definition) {
			definition->set_parent(*this);
			definitions_.push_back(definition);
		}
		return (*this);
	}

	const ASTName* package_name() const {
		return name_;
	}

	void set_package_name(ASTName* name) {

		if (name_)
			delete name_;
		name_ = name;
		if (name_)
			name_->set_parent(*this);
	}

	const ASTExpression* target_state() const {
		return target_state_;
	}

	void set_target_state(ASTExpression* target) {
		if(target_state_)
			delete target_state_;
		target_state_ = target;
		if(target_state_)
			target_state_->set_parent(*this);
	}

	bool accept(ASTVisitor& v) const;

	bool equals(const ASTTranslationUnit *tu) const {
		if (tu != 0) {

			unsigned int this_size = size();

			if (this_size == tu->size()) {

				bool eq_name =
						(name_ != 0) ?
								(name_->equals(tu->name_)) : (tu->name_ == 0);
				if (!eq_name)
					return false;

				bool eq_target =
						(target_state_ != 0)?
								(target_state_->equals(tu->target_state_)):(tu->target_state_ == 0);

				if(!eq_target)
					return false;

				for (unsigned int i = 0; i < this_size; ++i) {

					ASTDefinition *d = definitions_[i];
					ASTDefinition *od = tu->definitions_[i];

					bool eq = (d != 0 ? d->equals(od) : (od == 0));

					if (!eq)
						return false;
				}

				return true;
			}
		}

		return false;
	}

	~ASTTranslationUnit();
};
// class ASTTranslationUnit

}

#endif /* BIP_AST_H_ */
