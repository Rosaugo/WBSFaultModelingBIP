/*
 * refiner.h
 *
 *  Created on: Dec 15, 2016
 *      Author: wangqiang
 */

#ifndef REFINER_H_
#define REFINER_H_

#include "bip_cegar/cex.h"
#include "bip_trans_builder/transition_builder.h"
#include "bip_cegar/abs_domain.h"

namespace bipchecker{

//! Base class for refinement.
/*!
 * The refinement is based on (or driven by) counterexamples.
 */
class Refiner {

protected:

    //! Transition builder.
    /*!
     * Transition builder is needed as it carries the environment.
     */
    TransitionBuilder& trans_builder_;

public:

    //! Class constructor.
    /*!
     * \param trans_builder a transition builder.
     */
    explicit Refiner(TransitionBuilder& trans_builder): trans_builder_(trans_builder){ }

    //! Refines a precision given an abstract counter example.
    /*!
     * \param cex an infeasible counter-example.
     * \return True iff refinement is successful.
     */
    virtual bool refine(ART& art, CEx& cex, AbsDomain& domain, ART::work_list_t& work_list) = 0;


    //! Gets the transition builder.
    /*!
     * \return The transition builder.
     */
    TransitionBuilder& trans_builder() const { return trans_builder_; }


    //! Class virtual destructor.
    virtual ~Refiner(){ }

}; // class Refiner

}

#endif /* REFINER_H_ */
