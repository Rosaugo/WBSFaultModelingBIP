/*
 * cexbuilder.h
 *
 *  Created on: Dec 15, 2016
 *      Author: wangqiang
 */

#ifndef CEXBUILDER_H_
#define CEXBUILDER_H_

#include "bip_cegar/cex.h"
#include "bip_trans_builder/transition_builder.h"

namespace bipchecker {

//! Base class for building counterexamples.

class CExBuilder {

protected:
    //! Transition builder.
    TransitionBuilder& trans_builder_;

public:
    //! Class constructor.
    /*!
     * \param trans_builder a transition builder.
     */
    explicit CExBuilder(TransitionBuilder& trans_builder)
	: trans_builder_(trans_builder){ }

    //! Gets the transition builder.
    /*!
     * \return The transition builder.
     */
    TransitionBuilder& trans_builder() const { return trans_builder_; }

    //! Build an abstract counter example.
    /*!
     * \param node an ART node.
     * \return The abstract counterexample.
     */
    virtual CEx* build_cex(ART::ARTNode& node) const = 0;

    virtual ~CExBuilder(){}

private:
    DISALLOW_COPY_AND_ASSIGN(CExBuilder);

}; // class CExBuilder.

}

#endif /* CEXBUILDER_H_ */
