/*
 * impact.h
 *
 *  Created on: Dec 15, 2016
 *      Author: wangqiang
 */

#ifndef CONC_CEGAR_H_
#define CONC_CEGAR_H_

#include "util/util.h"
#include <queue>
#include <utility>

#include "bip_art/art.h"
#include "bip_cegar/cexbuilder.h"
#include "bip_cegar/refiner.h"
#include "bip_cegar/cex.h"

namespace bipchecker{

//! Class for CEGAR result.
class ConcCEGARResult {
public:

	//! Enumeration for CEGAR result status.
	enum Status {
		ERROR, /*!< Error state is reachable. */
		SAFE, /*!< System is safe. */
		UNKNOWN, /*!< Unknown result. */
		TIMEOUT, /*!< Out of time. */
		MEMORYOUT /*!< Out of memory. */
	};

private:

	//! Resulting (final) ART.
	ART *art_;

	//! Result status.
	Status status_;

	//! Counter example.
	CEx *cex_;

	//! Flag indicating if search is complete.
	bool complete_search_;

public:

	//! Class constructor.
	/*!
	 * \param art an ART.
	 * \param status a result status.
	 */
	explicit ConcCEGARResult(ART *art, Status status)
	: art_(art), status_(status),
	  cex_(0), complete_search_(true) {
	}

	//! Class constructor.
	/*!
	 * \param art an ART.
	 */
	explicit ConcCEGARResult(ART *art)
	: art_(art), status_(UNKNOWN),
	  cex_(0), complete_search_(true) {
	}

	//! Gets the ART.
	/*!
	 * \return The ART.
	 */
	const ART& art() const {
		return *art_;
	}

	//! Gets the status.
	/*!
	 * \return The result status.
	 */
	Status status() const {
		return status_;
	}

	//! Sets the status.
	/*!
	 * \param status a new status.
	 */
	void set_status(Status status) {
		status_ = status;
	}

	//! Gets the counter example.
	/*!
	 * \return The counter example.
	 */
	const CEx* cex() const {
		return cex_;
	}

	//! Sets the counter example.
	/*!
	 * \param cex a counter example.
	 */
	void set_cex(CEx *cex) {
		if (cex_ != 0)
			delete cex_;

		cex_ = cex;
	}

	//! Checks if search is complete.
	/*!
	 * \return True iff the search is complete.
	 */
	bool is_search_complete() const {
		if (!complete_search_
				|| status_ == UNKNOWN
				|| status_ == TIMEOUT
				|| status_ == MEMORYOUT)
			return false;

		return true;
	}

	//! Sets the flag of complete search.
	/*!
	 * \param complete_search a flag for complete search.
	 */
	void set_complete_search(bool complete_search) {
		complete_search_ = complete_search;
	}

	//! Gets the string representation of status.
	/*!
	 * \return The string representation of status.
	 */
	std::string str_status() const;

	//! Prints CEGAR result.
	/*!
	 * \param out an output stream.
	 */
	void print(std::ostream& out) const;

	//! Class destructor.
	~ConcCEGARResult() {
		if (cex_ != 0)
			delete cex_;

		if (art_ != 0)
			delete art_;
	}

private:
	DISALLOW_COPY_AND_ASSIGN(ConcCEGARResult);
};

//! Prints CEGAR result.
/*!
 * \param out an output stream.
 * \param result a CEGAR result.
 * \return The input output stream.
 */
std::ostream& operator<<(std::ostream& out, const ConcCEGARResult& result);


class ConcCEGAR {

protected:

	//! Counter-example builder.
	CExBuilder& cex_builder_;

	//! Refiner.
	Refiner& refiner_;

	//! Time limit.
	/*!
	 * Time limit -1.0 means no time limit.
	 */
	double time_limit_;

	//! Memory limit.
	/*!
	 * Memory limit -1.0 means no memory limit.
	 */
	double mem_limit_;

public:

	explicit ConcCEGAR(CExBuilder& cex_builder, Refiner& refiner):
	cex_builder_(cex_builder), refiner_(refiner),
	time_limit_(-1.0), mem_limit_(-1.0){
	}

	//! Performs reachability analysis.
	/*!
	 * \param analysis a program analysis.
	 * \param init_state an initial abstract state.
	 * \return The CEGAR result consisting of an ART and status (ERROR, SAFE, or UNKNOWN).
	 */
	virtual ConcCEGARResult* reach(ConcAbstractState *init_state) const = 0;

	//! Gets the counter-example builder.
	/*!
	 * \return The counter-example builder.
	 */
	CExBuilder& cex_builder() const { return cex_builder_; }

	//! Gets the counter-example builder.
	/*!
	 * \return The counter-example builder.
	 */
	Refiner& refiner() const { return refiner_; }

    //! Checks if an abstract state is an error state.
    /*!
     * \param s an abstract state.
     * \return True iff the abstract state is an error state.
     */
    bool is_error(const ConcAbstractState& s) const;

	//! Sets time limit.
	/*!
	 * \param time_limit a time limit.
	 */
	void set_time_limit(double time_limit) { time_limit_ = time_limit; }

	//! Sets memory limit.
	/*!
	 * \param mem_limit a memory limit.
	 */
	void set_mem_limit(double mem_limit) { mem_limit_ = mem_limit; }


	typedef ART::work_list_t work_list_t;

	//! Chooses a node from the work list.
	/*!
	 * \param work_list a work list.
	 * \return The chosen node.
	 */
	virtual ART::ARTNode* choose_node(work_list_t& work_list) const;


	//! Perform covering check.
	/*!
	 * \param node an ART node
	 * \param art the ART tree that contains the above node
	 * \return True if the node can be covered
	 */
    virtual bool is_covered(const ART::ARTNode& node, const ART& art) const = 0;


	//! Expands ART node.
	/*!
	 * \param node an ART node.
	 * \param analysis a program analysis.
	 * \param work_list an ART work list.
	 */
	virtual void expand_node(ART::ARTNode& node, work_list_t& work_list) const = 0;

	//! Adds nodes to the work list.
	/*!
	 * \param nodes a list of nodes.
	 * \param work_list a work list.
	 */
	void add_nodes_to_work_list(const std::vector<ART::ARTNode*>& nodes, ART::work_list_t& work_list) const;

	//! Adds the children nodes to the work list.
	/*!
	 * \param node an ART node.
	 * \param work_list a work list.
	 */
	void add_children_to_work_list(ART::ARTNode& node, ART::work_list_t& work_list) const;

	//! Class destructor.
	virtual ~ConcCEGAR() {
	}

private:
	DISALLOW_COPY_AND_ASSIGN(ConcCEGAR);
};

}

#endif
