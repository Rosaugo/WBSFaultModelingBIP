/*
 * cex.h
 *
 *  Created on: Dec 15, 2016
 *      Author: wangqiang
 */

#ifndef CEX_H_
#define CEX_H_

#include "util/util.h"

#include "bip_art/art.h"
#include "bip_art/art_path.h"


namespace bipchecker{

//! Counterexample class.
/*
 *  A counterexample is an ARTPath from the error node to the root
 *
 */
class CEx: public ARTPath {

public:

	//! Enumeration of kinds of counter example.
	enum CExKind {
		CONCRETE, /*!< Concrete (or real) counter example. */
		ABSTRACT, /*!< Abstract (or spurious) counter example. */
		UNKNOWN /*!< Unknown (can be concrete or abstract). */
	};

private:

	//! Kind of counter example.
	CExKind cex_kind_;

public:

	//! Class constructor.
	/*!
	 * \param start the start of the counter-example path.
	 */
	explicit CEx(ART::ARTNode& start): cex_kind_(UNKNOWN), ARTPath(start) { }


	//! Checks if the counter example is spurious.
	/*!
	 * \return True iff the counter example is spurious.
	 */
	bool is_abstract() const {
		return (cex_kind_ == ABSTRACT);
	}

	//! Checks if the counter example is concrete.
	/*!
	 * \return True iff the counter example is concrete.
	 */
	bool is_concrete() const {
		return (cex_kind_ == CONCRETE);
	}

	//! Sets the kind of counter example.
	/*!
	 * \param cex_kind a kind of counter example (ABSTRACT, CONCRETE, UNKNOWN).
	 */
	void set_kind(CExKind cex_kind) {
		cex_kind_ = cex_kind;
	}

	//! Prints cex.
	/*!
	 * \param out an output stream.
	 */
	virtual void print_cex(std::ostream& out) const;

	//! Class destructor.
	virtual ~CEx() {}

private:

	DISALLOW_COPY_AND_ASSIGN(CEx);

};
// class CEx

std::ostream& operator<<(std::ostream&, const CEx&);

}


#endif /* CEX_H_ */
