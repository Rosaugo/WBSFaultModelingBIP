/*
 * conc_impact.cc
 *
 *  Created on: Dec 15, 2016
 *      Author: wangqiang
 */


#include <assert.h>
#include "bip_cegar/conc_cegar.h"
#include "util/logger.h"

namespace bipchecker {

std::string ConcCEGARResult::str_status() const {
    std::string res("");

    if (status_ == ConcCEGARResult::ERROR)
	res = "Not safe.";
    else if (status_ == ConcCEGARResult::SAFE)
	res = "Safe.";
    else if (status_ == ConcCEGARResult::UNKNOWN)
	res = "Unknown.";
    else if (status_ == ConcCEGARResult::TIMEOUT)
	res = "Out of time.";
    else if (status_ == ConcCEGARResult::MEMORYOUT)
	res = "Out of memory.";
    return res;
}

void ConcCEGARResult::print(std::ostream& out) const {
    out << "Status : " << str_status() << std::endl;
    if (art_ != 0){
    	out << "ART size : " << art_->size() << std::endl;
    	out << "Total number of nodes being created: " << art_->total_number() << std::endl;
    	out << "Total number of nodes being remvoed: " << art_->removed_numer() << std::endl;
    }
    out << "Search completeness : " << ( ( is_search_complete() ) ? "yes" : "no" ) << std::endl;
}


std::ostream& operator<<(std::ostream& out, const ConcCEGARResult& result) {
	result.print(out);
	return out;
}


bool ConcCEGAR::is_error(const ConcAbstractState& state) const {

	bool is_target = true;

	for (ConcAbstractState::const_iterator it = state.thread_begin();
			it != state.thread_end(); ++it) {

		const AbstractState *pa_state = ((*it).second);

		assert(pa_state != 0);

		const CFANode *location = pa_state->control_location();

		if (location) {

			const CFA& cfa = location->cfa();

			if (cfa.has_error_location() && !location->is_error())
				is_target = false;
		}
	}

	return is_target;
}

ART::ARTNode* ConcCEGAR::choose_node(ART::work_list_t& work_list) const {

	ART::ARTNode *chosen_node = 0;

	if (!work_list.empty()) {

		chosen_node = work_list.back();
		work_list.pop_back();

	}
	return chosen_node;
}


void ConcCEGAR::add_nodes_to_work_list(const std::vector<ART::ARTNode*>& nodes,
		ART::work_list_t& work_list) const {

	if(nodes.size() > 0){
		Logger::log << Logger::level(2)
			<< "CEGAR: Add new ART nodes in the following order: "
			<< Logger::end;
	}

	std::vector<ART::ARTNode*> error_nodes;

	for (size_t i = 0; i < nodes.size(); ++i) {
		// Get the node.
		ART::ARTNode *node = nodes[i];

		// Get the labeling abstract state.
		const ConcAbstractState& node_state = node->abstract_state();

		if (is_error(node_state)) {

			error_nodes.push_back(node);

		} else {

			/// DEBUG HERE
			Logger::log << Logger::level(2)
				<< "CEGAR: - ART node "
				<< (node)->node_id() << "."
				<< Logger::end;

			work_list.push_back(node);
		}
	}

	for (size_t i = 0; i < error_nodes.size(); ++i) {

		/// DEBUG HERE
		Logger::log << Logger::level(2)
			<< "CEGAR: - Error node "
			<< (error_nodes[i])->node_id() << "."
			<< Logger::end;

		work_list.push_back(error_nodes[i]);
	}
}

void ConcCEGAR::add_children_to_work_list(ART::ARTNode& node,
		ART::work_list_t& work_list) const {

	if(node.has_child()){
		Logger::log << Logger::level(2)
			<< "CEGAR: Add new ART nodes in the following order: "
			<< Logger::end;
	}


	std::vector<ART::ARTNode*> error_nodes;

	for (ART::ARTNode::child_iterator it = node.child_begin();
			it != node.child_end(); ++it) { // For each child node.

		// Get child node , (the first element is the edge)
		ART::ARTNode *child = (*it).second;

		// Get the labeling abstract state.
		const ConcAbstractState& child_state = child->abstract_state();

		if (is_error(child_state)) {

			error_nodes.push_back(child);

		} else {

			/// DEBUG HERE
			Logger::log << Logger::level(2)
				<< "CEGAR: - ART node "
				<< (child)->node_id() << "."
				<< Logger::end;

			work_list.push_back(child);
		}
	}

	for (size_t i = 0; i < error_nodes.size(); ++i) {

		/// DEBUG HERE
		Logger::log << Logger::level(2)
			<< "CEGAR: - Error node "
			<< (error_nodes[i])->node_id() << "."
			<< Logger::end;

		work_list.push_back(error_nodes[i]);
	}
}


}
