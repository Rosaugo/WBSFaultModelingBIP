/*
 * abs_domain.h
 *
 *  Created on: May 17, 2017
 *      Author: wangqiang
 */

#ifndef ABS_DOMAIN_H_
#define ABS_DOMAIN_H_


namespace bipchecker {

class AbsDomain {

public:
	explicit AbsDomain() {
	}

	virtual ~AbsDomain() {
	}
};

}


#endif /* ABS_DOMAIN_H_ */
