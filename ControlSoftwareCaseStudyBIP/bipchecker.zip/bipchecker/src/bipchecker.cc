/*
 * bipchecker.cc
 *
 *  Created on: Dec 16, 2016
 *      Author: wangqiang
 */


#include <iostream>
#include <fstream>

#include "util/options.h"
#include "util/util.h"
#include "util/logger.h"

#include "bip_frontend/bip_interaction/interaction_extractor.h"
#include "bip_frontend/bip_interaction/interference_builder.h"
#include "bip_frontend/bip_ast/bip_ast.h"
#include "bip_frontend/bip_type_system/bip_type_system.h"
#include "bip_frontend/bip_parser/driver.h"
#include "bip_frontend/bip_parser/parse_context.h"
#include "bip_frontend/bip_ast/ast_printer.h"
#include "bip_frontend/bip_type_system/type_checker.h"
#include "bip_cfa/cfa_builder.h"
#include "bip_cfa/dot_builder.h"
#include "bip_trans_builder/transition_builder.h"

#include "bip_solver/expression.h"
#include "bip_solver/solver_z3.h"
#include "bip_impact/conc_impact.h"
#include "bip_impact/itp_refiner.h"
#include "bip_impact/cexbuilder_impact.h"
#include "bip_impact/impact_dpor.h"
#include "bip_impact/impact_spor.h"
#include "bip_ic3/conc_ic3.h"


using namespace bipchecker;

//! Struct for main components.
struct MainComponents {
	//! Translation unit.
	ASTTranslationUnit *tu;

	//! Symbol table.
	Scope *symbol_table;

	//! CFA.
	std::vector<CFA*> cfas;

	//! bip interaction model
	InteractionModel* bip_im;

	//! bip interference relation
	BIPInterferenceRelation* interference_relation_;

	//! Transition builder.
	TransitionBuilder* trans_builder;

	//! CEGAR Algorithm.
	ConcCEGAR *cegar;

	//! Refiner.
	Refiner* refiner;

	//! Counter-example builder.
	CExBuilder* cex_builder;

	//! abstract domain
	AbsDomain* domain;

	//! CEGAR result.
	ConcCEGARResult *cegar_result;

	//! Base filename.
	std::string base_filename;

	//! Constructor.
	explicit MainComponents() :
			tu(0),
			symbol_table(0),
			bip_im(0),
			interference_relation_(0),
			trans_builder(0),
			cegar(0),
			refiner(0),
			cex_builder(0),
			domain(0),
			cegar_result(0),
			base_filename("") {
	}

	//! Destructor.
	~MainComponents() { }

};
// struct MainComponents


void encode_cfa(const CFA& cfa, TransitionBuilder* encoder);

void print_version(std::ostream& out);

//! Initializes options.
void init_options(Options& options);

//! Checks type.
Scope* type_check(const ASTTranslationUnit& tu); //MainStat& stat

//! Builds CFA.
std::vector<CFA*> build_cfa(const ASTTranslationUnit& tu, Scope& symbol_table);

//! Quits gracefully.
void quit_gracefully(MainComponents& );

//! Dumps CFA.
void dump_cfa_dot(const std::string& dot_filename, std::vector<CFA*> cfas);

//! Create initial abstract state
ConcAbstractStateImpact* create_init_state_impact(std::vector<CFA*> cfas) ;

//! Create initial abstract state
ConcAbstractStateIC3* create_init_state_ic3(std::vector<CFA*> cfas) ;


int main(int argc, char *argv[]){

	MainComponents main_components;

	// Get options.
	Options& options = Options::get_instance();

	// Init options.
	init_options(options);

	// Parse options
	int index = options.parse_options(argc, argv);

	if (options.get_bool_option("help")) {
		std::cout << options;
		return 0;
	}

	if (options.get_bool_option("version")) {
		print_version(std::cout);
		return 0;
	}

	if ((index < 1) || (argc - index) != 1) {
		std::cerr << "Usage: " << argv[0] << " [options] <input file>"
				<< std::endl;
		std::cerr << "Option --help for help" << std::endl;
		return -1;
	}

	// We keep track until where we parsed command line arguments.
	argc = index;

	// Init logger.
	Logger::log.set_output_level(options.get_unsigned_option("verbosity_level"));

	Logger::log << "Main: Log time is " << get_local_time() << Logger::end;

	// Get input file name and its base version.
	std::string filename = argv[argc];

	size_t file_pos = filename.find_last_of("/\\");
	std::string base_filename = filename.substr(file_pos + 1);
	main_components.base_filename = base_filename;

	// Open input file.
	std::fstream infile(filename.c_str());

	if (!infile.good()) {
		Logger::log << "Main: File " << filename << " could not be opened." << Logger::end;
		return -1;
	}

	ParseContext ctx;
	Driver driver(ctx);

	//////////////////////////////////////////////////////////////////////////////
	/////////////////////// Parsing the BIP model ////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////
	Logger::log << "Main: Parse input file " << filename << "." << Logger::end;

	bool parse_result = driver.parse_stream(infile, filename);
	if (!parse_result) {
		Logger::log << "Main: Parse error. " << Logger::end;
		return -1;
	}

	// Get the resulting translation unit.
	ASTTranslationUnit *tu = ctx.translation_unit();
	main_components.tu = tu;

	///////////////////////////////////////////////////////////////////////////////
	///////////////////// Type check the BIP model ////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////

	Logger::log << "Main: Type check AST." << Logger::end;

	Scope* tc_result = type_check(*tu);
	Scope *symbol_table = tc_result;
	//symbol_table->print_scope(std::cout);

	if (symbol_table == 0) {
		Logger::log << "Main: Type errors." << Logger::end;
		quit_gracefully(main_components);
		return -1;
	}
	main_components.symbol_table = symbol_table;

	////////////////////////////////////////////////////////////////////////////////
	//////////////////// Build CFA from the parsing result /////////////////////////
	////////////////////////////////////////////////////////////////////////////////

	Logger::log << "Main: Build CFA." << Logger::end;
	std::vector<CFA*> cfa_result = build_cfa(*tu, *symbol_table);
	if(cfa_result.empty()){
		Logger::log << "Main: building CFA error." << Logger::end;
		quit_gracefully(main_components);
		return -1;
	}
	main_components.cfas = cfa_result;

	//////////////////////////////////////////////////////////////////////////////////
	//////////////////// Extract the interaction Model from the parsing result ///////
	//////////////////////////////////////////////////////////////////////////////////

	Logger::log << "Main: Build interaction model." << Logger::end;
	InteractionExtractor* ia_extractor = new InteractionExtractor();
	tu->accept(*ia_extractor);

	InteractionModel* bip_im = ia_extractor->InteractionMode();
	if(bip_im == 0){
		Logger::log << "Main: building interaction model error." << Logger::end;
		quit_gracefully(main_components);
		return -1;
	}
	main_components.bip_im = bip_im;
	delete ia_extractor;


	/////////////////////////////////////////////////////////////////////////////////
	///////////////////// Dump CFA if requested /////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////

	bool dump_cfa = (options.get_bool_option("dump_cfa"));

	if (dump_cfa) {
		std::string dot_filename = base_filename + std::string(".dot");
		Logger::log << "Main: Dump CFA into file "
				<< dot_filename
				<< "." << Logger::end;

		std::vector<CFA*> cfas;
		for(InteractionModel::const_iterator cit = bip_im->const_interaction_begin();
				cit != bip_im->const_interaction_end(); ++cit) {
			if (*cit) {
				CFA* tmp_cfa = (*cit)->get_cfa();
				if(tmp_cfa != 0)
					cfas.push_back(tmp_cfa);
			}
		}

		for(auto cfa : cfa_result) {
			cfas.push_back(cfa);
		}

		dump_cfa_dot(dot_filename, cfas);
		cfas.clear();
	}

	//////////////////////////////////////////////////////////////////////////////////
	//////////////////// Build BIP Interaction Interference Relation ///////// ///////
	//////////////////////////////////////////////////////////////////////////////////
	Logger::log << "Main: Build BIP interaction interference relation." << Logger::end;

	BIPInterferenceBuilder* interference_builder = new BIPInterferenceBuilder(*bip_im);
	interference_builder->build_interferences();

	BIPInterferenceRelation* interference_relation = interference_builder->get_interference_relation();

	if(interference_relation == 0){
		Logger::log << "Main: building interference relation error." << Logger::end;
		quit_gracefully(main_components);
		return -1;
	}
	main_components.interference_relation_ = interference_relation;
	delete interference_builder;


	///////////////////////////////////////////////////////////////////////////////////
	///////////////////////// Create transition builder ///////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////

	Logger::log << "Main: Build transition builder." << Logger::end;
	TransitionBuilder *trans_builder = new TransitionBuilder(*symbol_table);
	main_components.trans_builder = trans_builder;


	//! Test transition builder
//	encode_cfa(*cfa_result[0], trans_builder);

	//! Test z3 interpolation
//	test_interpolation();

	///////////////////////////////////////////////////////////////////////////////////
	/////////////////// Create predicate abstraction domain ///////////////////////////
	///////////////////////////////////////////////////////////////////////////////////
	AbsDomain* abs_domain = new PredDomain();
	main_components.domain = abs_domain;


	///////////////////////////////////////////////////////////////////////////////////
	/////////////////////////// Create CEGAR //////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////////
	CExBuilder* cex_builder = 0;
	Refiner* abs_refiner = 0;
	ConcCEGAR* conc_cegar = 0;
	ConcAbstractState* init_state = 0;


	bool impact = options.get_bool_option("impact");
	bool ic3 = options.get_bool_option("ic3");
	bool fc = options.get_bool_option("force-covering");
	bool dpsr = options.get_bool_option("dpsr");
	bool spsr = options.get_bool_option("spsr");

	if(!impact && !ic3) {
		Logger::log << "Main: No CEGAR algorithm is selected. Quit." << Logger::end;
		quit_gracefully(main_components);
		return -1;
	}

	if(dpsr and spsr) {
		Logger::log << "Main: Two POR enabled at the same time. Quit." << Logger::end;
		quit_gracefully(main_components);
		return -1;
	}

	if(impact){
		Logger::log << "Main: Create IMPACT CEGAR." << Logger::end;

		cex_builder = new CExBuilderImpact(*trans_builder);
		abs_refiner = new ITPRefiner(*trans_builder);

		if(dpsr){

			conc_cegar = new ConcImpactDPOR(*cex_builder, *abs_refiner, *abs_domain, bip_im, interference_relation);

		} else if(spsr) {

			conc_cegar = new ConcImpactSPOR(*cex_builder, *abs_refiner, *abs_domain, bip_im, interference_relation);

		} else {

			conc_cegar = new ConcImpact(*cex_builder, *abs_refiner, *abs_domain, bip_im);

		}

		if(fc) {

		  ConcImpact* cimpact = dynamic_cast<ConcImpact*>(conc_cegar);
		  cimpact->enable_force_covering();

		}

		init_state = create_init_state_impact(cfa_result);
	}

	if(ic3){
		Logger::log << "Main: Create IC3 CEGAR." << Logger::end;

		cex_builder = new CExBuilderIC3(*trans_builder);
		abs_refiner = new IC3Refiner(*trans_builder);
		conc_cegar = new ConcIC3(*cex_builder, *abs_refiner, *abs_domain, bip_im);

		if(fc) {
			ConcIC3* cic3 = dynamic_cast<ConcIC3*>(conc_cegar);
			cic3->enable_force_covering();
		}

		init_state = create_init_state_ic3(cfa_result);
	}

	int space_limit = options.get_int_option("space_limit");
	if(space_limit > 0) {
		conc_cegar->set_mem_limit(space_limit);
	}

	float time_limit = options.get_float_option("time_limit");
	if(time_limit > 0.0) {
		conc_cegar->set_time_limit(time_limit);
	}

	double init_time = bipchecker::get_cpu_time();

	//! perform the reachability analysis
	Logger::log << "Main: Start abstract reachability analysis." << Logger::end;
	ConcCEGARResult* cegar_result = conc_cegar->reach(init_state);

	double check_time = bipchecker::get_cpu_time() - init_time;
	
	main_components.cegar_result = cegar_result;
	main_components.cex_builder = cex_builder;
	main_components.refiner = abs_refiner;
	main_components.cegar = conc_cegar;

	bool dump_art = (options.get_bool_option("dump_art"));
	if(dump_art){
		std::string artdot_filename = base_filename + std::string("_art.dot");
		std::ofstream dot_file;
		dot_file.open(artdot_filename.c_str());
		cegar_result->art().build_dot(dot_file);
		dot_file.close();
	}

	Logger::log << "Main: Verification result:" << Logger::end;
	Logger::log << Logger::end;
	Logger::log << *cegar_result << Logger::end;

	Logger::log << "Analysis time: " << check_time << Logger::end;

	if(cegar_result->status() == ConcCEGARResult::ERROR){
		Logger::log << *(cegar_result->cex()) << Logger::end;
	}

	quit_gracefully(main_components);
	return 0;
}

////////////////////////////////////////////////////////
void init_options(Options& options) {

	options.add_option("version", false, "Print version and quit (default false)");

	options.add_option("help", false, "Print options and quit (default false)");

	options.add_option("time_limit", -1.0F, "Set the time limit; < 0.0 for no limit (default -1.0)");

	options.add_option("space_limit", 0, "Set the space limit;  0 for no limit (default 0)");

	options.add_option("dump_cfa", false, "Dump the CFA dot file");

	options.add_option("dump_art", false, "Dump the ART dot file");

	options.add_option("verbosity_level", 0, "Set verbosity level to <arg> (default 0)");

	options.add_option("print_default_setting", false, "Print the default setting of BIPChecker 1.0");

	options.add_option("impact", false, "Enable impact algorithm (lazy abstraction with interpolant)");

	options.add_option("ic3", false, "Enable IC3 algorithm");

	options.add_option("force-covering", false, "Enable force covering in IMPACT");

	options.add_option("dpsr", false, "Enable dynamic persistent reduction");

	options.add_option("spsr", false, "Enable static persistent reduction");

}

////////////////////////////////////////////////////////
Scope* type_check(const ASTTranslationUnit& tu) {

	Scope *symbol_table = 0;
	TypeChecker *type_checker = new TypeChecker();

	tu.accept(*type_checker);

	unsigned int num_type_errors = type_checker->number_of_errors();
	symbol_table = type_checker->symbol_table();

	if (num_type_errors != 0 || symbol_table == 0) {
		if (symbol_table != 0)
			delete symbol_table;
		symbol_table = 0;
	}

	delete type_checker;

	return symbol_table;
}

////////////////////////////////////////////////////////
std::vector<CFA*> build_cfa(const ASTTranslationUnit& tu, Scope& symbol_table) {

	CFABuilder *cfa_builder = new CFABuilder(symbol_table);

	tu.accept(*cfa_builder);

	std::vector<CFA*> cfas = cfa_builder->cfas();

	delete cfa_builder;

	return cfas;
}

////////////////////////////////////////////////////////
void dump_cfa_dot(const std::string& dot_filename, std::vector<CFA*> cfas) {

	std::ofstream dot_file;
	dot_file.open(dot_filename.c_str());
	DotBuilder *dot_builder = new DotBuilder(dot_file);
	for (std::vector<CFA*>::iterator it = cfas.begin();
			it != cfas.end(); ++it) {

		if (*it) {
			dot_builder->build_dot_cfa(**it);
		}
	}

	delete dot_builder;
	dot_file.close();
}

void encode_cfa(const CFA& cfa, TransitionBuilder* encoder) {

	std::vector<const CFANode*> work_list;
	std::map<size_t, const CFANode*> visited_nodes;

	std::vector<Transition*> trans;

	// Put in the work list.
	work_list.push_back(&(cfa.entry()));

	std::cout << cfa.name() << std::endl;

	while (!work_list.empty()) {

		const CFANode* node = work_list.back();
		work_list.pop_back();

		// Mark as visited.
		visited_nodes[node->node_id()] = node;

		for (CFANode::const_iterator it = node->out_begin();
				it != node->out_end(); ++it) {
			if (*it) {

				const CFAEdge *edge = *it;

//				std::cout << edge->label()->name()->name() << std::endl;

				// encode the edge.
				Transition* tran = encoder->build_transition(*edge);
				trans.push_back(tran);

				std::cout << "Transition guard: ";
//				tran->guard()->pretty_print(std::cout);
//				std::cout << std::endl;

				expression* simp_guard = simplify(tran->guard());
				simp_guard->pretty_print(std::cout);
//				std::cout << std::endl;
				delete simp_guard;

				std::cout << "		Transition action: ";
//				tran->get_expression()->pretty_print(std::cout);
//				std::cout << std::endl;

				expression* simp_expr = simplify(tran->get_expression());
				simp_expr->pretty_print(std::cout);
				std::cout << std::endl;
				delete simp_expr;

				CFANode& to = (*it)->to();
				if (visited_nodes.find(to.node_id()) == visited_nodes.end()) {
					// Put in the work list.
					work_list.push_back(&to);
				}

			}
		}
	}

	for(std::vector<Transition*>::iterator it = trans.begin();
			it != trans.end(); ++it){

		delete (*it);
//		expression* texpr = (*it)->get_expression();
//		texpr->pretty_print(std::cout);
	}
}


////////////////////////////////////////////////////////
void quit_gracefully(MainComponents& components) {

	if(components.cegar_result != 0)
		delete components.cegar_result;

	if(components.cegar != 0)
		delete components.cegar;

	if (components.trans_builder != 0)
		delete components.trans_builder;

	if(!components.cfas.empty()){
		for(std::vector<CFA*>::iterator it = components.cfas.begin();
				it != components.cfas.end(); ++it){
			if(*it) delete (*it);
		}
		components.cfas.clear();
	}

	if(components.interference_relation_ != 0)
		delete components.interference_relation_;

	if(components.bip_im != 0)
		delete components.bip_im;

	if (components.symbol_table != 0)
		delete components.symbol_table;

	if (components.tu != 0)
		delete components.tu;

	if(components.cex_builder != 0)
		delete components.cex_builder;

	if(components.refiner != 0)
		delete components.refiner;

	if(components.domain != 0)
		delete components.domain;

	Options::release_options();
}

////////////////////////////////////////////////////////
void print_version(std::ostream& out) {
	out << "BIPChecker 1.0" << std::endl;
	out << "Please write to qiang.wang@epfl.ch for reporting bugs." << std::endl;
}

////////////////////////////////////////////////////////
ConcAbstractStateImpact* create_init_state_impact(std::vector<CFA*> cfas) {

	ConcAbstractStateImpact *state = new ConcAbstractStateImpact();

	// Create a thread state for each thread in the kernel state.
	for (std::vector<CFA*>::const_iterator tit = cfas.begin();
			tit != cfas.end(); ++tit) {

		if (*tit) {
			// Find CFA function.
			const CFA *t_cfa = *tit;

			std::string cfa_name = t_cfa->name();
			const Symbol *t_id = &Symbol::symbol(cfa_name);

			// Create a thread state.
			expression *True = new true_constant();
			AbstractStateImpact *t_state = new AbstractStateImpact(t_cfa->entry(), True);

			// Add thread state into the resulting state.
			state->add_thread_state(*t_id, t_state);
		}
	}
	return state;
}


////////////////////////////////////////////////////////
ConcAbstractStateIC3* create_init_state_ic3(std::vector<CFA*> cfas) {

	ConcAbstractStateIC3 *state = new ConcAbstractStateIC3();

	// Create a thread state for each thread in the kernel state.
	for (std::vector<CFA*>::const_iterator tit = cfas.begin();
			tit != cfas.end(); ++tit) {

		if (*tit) {
			// Find CFA function.
			const CFA *t_cfa = *tit;

			std::string cfa_name = t_cfa->name();
			const Symbol *t_id = &Symbol::symbol(cfa_name);

			// Create a thread state.
			AbstractState *t_state = new AbstractState(t_cfa->entry());

			// Add thread state into the resulting state.
			state->add_thread_state(*t_id, t_state);
		}
	}

//	expression *True = new true_constant();
//	state->add_literal(0, True);

	return state;
}
