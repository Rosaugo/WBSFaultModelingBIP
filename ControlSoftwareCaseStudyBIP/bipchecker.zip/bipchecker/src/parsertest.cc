// $Id: exprtest.cc 18 2007-08-19 19:51:52Z tb $

#include <iostream>
#include <fstream>

#include "bip_frontend/bip_parser/driver.h"
#include "bip_frontend/bip_parser/parse_context.h"
#include "bip_frontend/bip_ast/ast_printer.h"
#include "bip_frontend/bip_type_system/type_checker.h"

#include "bip_solver/solver_z3.h"

using namespace bipchecker;


int main(int argc, char *argv[]) {

	if (argc != 2){

		std::cerr << "Usage: parse <file_name>" << std::endl;

	} else {
		std::fstream infile(argv[1]);


		if (!infile.good()) {
			std::cerr << "Could not open file:  " << argv[1] << std::endl;

		} else {

			ParseContext ctx;
			Driver driver(ctx);

			std::string name = argv[1];
			bool result = driver.parse_stream(infile, name);

			if (result) {

				ASTPrinter printer(std::cout);

				std::cout << "Translation Unit:" << std::endl;

				ASTTranslationUnit *tu = ctx.translation_unit();

				//////////// Type check.

				TypeChecker type_checker;

				tu->accept(type_checker);

				const Scope *symbol_table = type_checker.symbol_table();

				if (type_checker.number_of_errors() != 0 || symbol_table == 0) {
					delete tu;
					return -1;
				}

				// tu->accept(printer);

				symbol_table->print_scope(std::cout);

				delete tu;

				if (symbol_table != 0)
					delete symbol_table;

			} else {
				std::cerr << "Parsing Error!" << std::endl;
			}

		}

	}

	return 0;
}

