/*
 * ic3_refiner.h
 *
 *  Created on: Apr 5, 2017
 *      Author: wangqiang
 */

#ifndef IC3_REFINER_H_
#define IC3_REFINER_H_


#include "bip_cegar/refiner.h"
#include "bip_solver/expression.h"
#include "bip_ic3/pred_domain.h"
#include "bip_solver/solver_z3.h"
#include "bip_ic3/structures.h"


namespace bipchecker {

class IC3Refiner : public Refiner {

    static size_t counter;

public:
    //! Class constructor.
    /*!
     * \param trans_builder a transition builder.
     */
    explicit IC3Refiner(TransitionBuilder& trans_builder): Refiner(trans_builder){ }

    //! Refines a precision given an abstract counter example.
    /*!
     * \param cex an infeasible counter-example.
     * \return True iff refinement is successful.
     */
    virtual bool refine(ART& art, CEx& cex, AbsDomain& domain, ART::work_list_t& work_list);


    //! Extract new predicates from interpolants and add into the domain
    void refine_pred_domain(CEx& cex, PredDomain& domain);


    //! Recursively block the counterexample until it is blocked
    size_t block_cex(CEx& cex, AbsDomain& domain, Z3Solver&, ART::work_list_t&);


    //! Check if the path is blocked or not.
    bool blocked(CEx& cex, size_t, AbsDomain& domain, Z3Solver&);


    //! TODO: why such a function?
    void propagate(CEx& cex, ProofObligation& po, AbsDomain& domain, Z3Solver&);


    //! generate fresh names for boolean variables
    std::string fresh_bvar() const { return "bvar" + std::to_string(counter++); }

    //! Class virtual destructor.
    virtual ~IC3Refiner(){ }
};

}


#endif /* IC3_REFINER_H_ */
