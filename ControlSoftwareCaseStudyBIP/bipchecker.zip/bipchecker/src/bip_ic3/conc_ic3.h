/*
 * conc_ic3.h
 *
 *  Created on: Apr 5, 2017
 *      Author: wangqiang
 */

#ifndef CONC_IC3_H_
#define CONC_IC3_H_

#include "bip_frontend/bip_interaction/interaction_model.h"
#include "bip_cegar/conc_cegar.h"
#include "bip_ic3/conc_abstract_state_ic3.h"
#include "bip_ic3/cexbuilder_ic3.h"
#include "bip_ic3/ic3_refiner.h"

namespace bipchecker {

class ConcIC3 : public ConcCEGAR{

    //! BIP interaction model
    const InteractionModel* bim_;

    //! predicate abstraction domain
    AbsDomain& domain_;

    //! force covering
    bool fc_;

	typedef std::list<const BIPInteraction*> interactions_t;

	typedef std::vector<const CFAEdge*> cfa_edges_t;

	typedef hash_map<std::string, std::set<std::string>,
			hash_fun<std::string>, EqStr> sym_ports_t;


public:
    explicit ConcIC3(CExBuilder& cex_builder,
		     Refiner& refiner,
		     AbsDomain& domain,
		     const InteractionModel* ia_model): 
		     ConcCEGAR(cex_builder, refiner),
		     bim_(ia_model), domain_(domain),
		     fc_(false){ }

    //! Performs reachability analysis.
	/*!
	 * \param analysis a program analysis.
	 * \param init_state an initial abstract state.
	 * \return The CEGAR result consisting of an ART and status (ERROR, SAFE, or UNKNOWN).
	 */
    virtual ConcCEGARResult* reach(ConcAbstractState *init_state) const;


    //! Expands ART node.
	/*!
	 * \param node an ART node.
	 * \param analysis a program analysis.
	 * \param work_list an ART work list.
	 */
    virtual void expand_node(ART::ARTNode& node, work_list_t& work_list) const;


    //! Compute an successor of an abstract state.
	/*!
	 * \param state the given current abstract state
	 * \param edges the set of CFG edges for one interaction
	 * \return a successor abstract state following the CFG edges
	 */
    ConcAbstractStateIC3* transfer(const ConcAbstractStateIC3& state,
    		std::vector<const CFAEdge*>& edges) const;


    //! Propagate clauses from one node to another
    void propagate(const ConcAbstractStateIC3& state,
    		ConcAbstractStateIC3& next,
    		std::vector<const CFAEdge*>& edges) const;

    //! Perform covering check.
	/*!
	 * \param node an ART node
	 * \param art the ART tree that contains the above node
	 * \return True if the node can be covered
	 */
    virtual bool is_covered(const ART::ARTNode& node, const ART& art) const;


    bool force_covering(ART::ARTNode& node, ART& art) const;

    void build_path_expr(std::vector<std::vector<const CFAEdge*>>& edges,
        		std::vector<expression*>& path_expressions) const;

    //! Compute the set of enabled interactions in an ART node
    /*!
     * \param node an ART node
     * \param interactions the set of enabled interactions
     * \param edges the set of initial edges
     */
    void compute_interactions(ART::ARTNode& node,
    		interactions_t& enabled_interactions,
    		cfa_edges_t& edges) const;


    //! Get the set of CFA edges of a BIP interaction
    /*!
     * \param location the given control location
     * (since an edge may have different starting location)
     * \param ia the given BIP interaction
     * \param edges the set of corresponding CFA edges
     */
    void get_cfa_edges(const ConcLoc* location,
    		const BIPInteraction* ia,
    		cfa_edges_t& edges) const ;


    void enable_force_covering() {
    	fc_ = true;
    }

    virtual ~ConcIC3() { 
    }
};

}

#endif /* CONC_IC3_H_ */
