/*
 * cexbuilder_ic3.h
 *
 *  Created on: Apr 5, 2017
 *      Author: wangqiang
 */

#ifndef CEXBUILDER_IC3_H_
#define CEXBUILDER_IC3_H_


#include "bip_cegar/cexbuilder.h"

namespace bipchecker {

class CExBuilderIC3 : public CExBuilder {

public:
    explicit CExBuilderIC3(TransitionBuilder& trans_builder)
    : CExBuilder(trans_builder){ }

    //! Build the trace formula of the counterexample path
    //! Compute the sequence interpolant if the trace formula is UNSAT
    virtual CEx* build_cex(ART::ARTNode& node) const;

    //! Build the abstract counterexample,
    //! which is an ART path from node to the root
    CEx* build_path(ART::ARTNode& node) const;

    virtual ~CExBuilderIC3(){}
};

}


#endif /* CEXBUILDER_IC3_H_ */
