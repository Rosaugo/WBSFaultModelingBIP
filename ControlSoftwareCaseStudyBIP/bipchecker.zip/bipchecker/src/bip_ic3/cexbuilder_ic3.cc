/*
 * cexbuilder_ic3.cc
 *
 *  Created on: Apr 5, 2017
 *      Author: wangqiang
 */


#include "bip_ic3/cexbuilder_ic3.h"
#include "bip_ic3/cex_ic3.h"
#include "bip_ic3/conc_abstract_state_ic3.h"

namespace bipchecker {

CEx* CExBuilderIC3::build_path(ART::ARTNode& node) const {

	// Create an ART path (CEx) starting from the last node.
	CExIC3 *cex = new CExIC3(node);

	// Get ART.
	ART& art = node.art();

	// Get ART root.
	ART::ARTNode& root = art.root();

	ART::ARTNode *walk = &node;

	// Build CEx path to the root.
	while (&root != walk) {

		const BIPInteraction *edge = walk->label();
		assert(edge != 0);

		// first put the interaction into the front
		// so the first interaction will be at the bottom
		cex->push_front(*edge);

		//! then get the sequence of the abstract states
		const ConcAbstractState& state = walk->abstract_state();
		const ConcAbstractStateIC3& state_ic3 = dynamic_cast<const ConcAbstractStateIC3&>(state);
		ConcAbstractStateIC3& state_ic3_nonc = const_cast<ConcAbstractStateIC3&>(state_ic3);
		cex->add_state_front(&state_ic3_nonc);

		// Advance walking node to parent.
		walk = walk->parent();

		//! then get the set of CFG edges of this interaction
		std::vector<const CFAEdge*>* edges = new std::vector<const CFAEdge*>();
		for(ART::ARTNode::const_edge_iterator cti = walk->transition_begin(*edge);
				cti != walk->transition_end(*edge); ++cti){
			if(*cti){
				edges->push_back(*cti);
			}
		}
		cex->add_transitions_front(edges);
	}

	//! add the root state
	const ConcAbstractState& root_state = root.abstract_state();
	const ConcAbstractStateIC3& root_state_ic3 = dynamic_cast<const ConcAbstractStateIC3&>(root_state);
	ConcAbstractStateIC3& root_state_ic3_nonc = const_cast<ConcAbstractStateIC3&>(root_state_ic3);
	cex->add_state_front(&root_state_ic3_nonc);

	return cex;
}

CEx* CExBuilderIC3::build_cex(ART::ARTNode& node) const {

	//! build the counterexample
	//! check if it is real.
	//! in this implementation,
	//! we check the satisfiability of the trace formula
	//! and also compute the interpolants if UNSAT
	//! the interpolants are used to drive new predicates


	//! there is another way to check if this path is blocked:
	//!   \exists j, F[j] \wedge T_j is UNSAT

	//! first build an abstract counterexample path
	CEx* path = build_path(node);
	CExIC3* path_ic3 = dynamic_cast<CExIC3*>(path);

	// Get path's length.
	int path_length = path->length();

	// Create path expressions: sequence of expressions along the path.
	std::vector<expression*> path_expressions(path_length);

	// Traverse the CEx forward.
	int current = 0;

	//! maintain the set of domain variables
	//! that have been seen during building the SSA in the forward manner
	Transition::domain_t vars_seen;

	//! maintain the set of transitions
	//! deleted after building the SSA form of the path
	std::vector<Transition*> back_transitions;

	do {
		// Get the edges.
		std::vector<const CFAEdge*>* temp_edges = path->transitions(current);

		//! NOTE that the domain of the transition is
		//! the set of variables occurring in the transitions
		Transition* temp_tran = trans_builder_.build_transition(*temp_edges);
		expression* temp_tran_expr = temp_tran->get_expression();
		expression* temp_tran_guard = temp_tran->guard();

		expression* trans_expr = new binary_expression(binary_expression::AND,
				*(temp_tran_expr->clone()), *(temp_tran_guard->clone()));


		path_ic3->add_path_expression(simplify(trans_expr));


		for(Transition::domain_t::iterator vit = vars_seen.begin();
				vit != vars_seen.end(); ++vit){

			expression* vexpr = *vit;
	    	variable* v_var = dynamic_cast<variable*>(vexpr);
	    	std::string v_var_name = v_var->get_name();

			bool seen = false;
			for(Transition::const_domain_iterator dit = temp_tran->domain_begin();
					dit != temp_tran->domain_end() && !seen; ++dit){

				expression* dexpr = *dit;
		    	variable* d_var = dynamic_cast<variable*>(dexpr);
		    	std::string d_var_name = d_var->get_name();
		    	if(d_var_name == v_var_name)
		    		seen = true;
			}

			//! for each variable that was seen before, but not in the current domain,
			//! then add an equality frame
			if(!seen){
				expression* shifted_var = new timed_expression( *(vexpr->clone()), 1);
				expression* eq = new binary_expression(binary_expression::EQ, (*shifted_var), *(vexpr->clone()) );
				trans_expr = new binary_expression(binary_expression::AND, *trans_expr, *eq);
			}
		}

		for(Transition::const_domain_iterator dit = temp_tran->domain_begin();
				dit != temp_tran->domain_end(); ++dit){
			expression* dexpr = *dit;
	    	variable* d_var = dynamic_cast<variable*>(dexpr);
	    	std::string d_var_name = d_var->get_name();

	    	bool seen = false;
			for(Transition::domain_t::iterator vit = vars_seen.begin();
					vit != vars_seen.end(); ++vit){

				expression* vexpr = *vit;
		    	variable* v_var = dynamic_cast<variable*>(vexpr);
		    	std::string v_var_name = v_var->get_name();
		    	if(d_var_name == v_var_name)
		    		seen = true;
			}

			//! for each new domain variable, add to the seen set
			if(!seen)
				vars_seen.insert(dexpr);
		}

		expression* timed_trans_expr = new timed_expression(*trans_expr, current);
		expression* simplified_expr = simplify(timed_trans_expr);
		path_expressions[current] = simplified_expr;

		++current;
		back_transitions.push_back(temp_tran);
		delete timed_trans_expr;

	} while (current != path_length);

	//! compute the interpolants, that use timed variables
	std::vector<expression*> timed_interps;

	z3::config config;
	Z3Solver solver(config, z3::context::interpolation());
	z3::check_result result = solver.compute_interpolant(path_expressions, timed_interps);

	if(result == z3::unsat){

		path->set_kind(CEx::ABSTRACT);

		for(std::vector<expression*>::iterator eit = timed_interps.begin();
				eit != timed_interps.end(); eit++){
			expression* texpr = (*eit);
			//! untime the interpolants
			expression* interp = untimed_expression(texpr);
			path_ic3->add_interpolants(interp);
		}
	} else {
		path->set_kind(CEx::CONCRETE);
	}


//	for(auto expr : path_expressions) {
//		 std::cout << expr << std::endl;
//	}

	//! Clean up
	for (unsigned int i = 0; i < path_expressions.size(); ++i)
		delete path_expressions[i];

	for(std::vector<Transition*>::iterator tit = back_transitions.begin();
			tit != back_transitions.end(); ++tit)
		delete (*tit);

	for(std::vector<expression*>::iterator eit = timed_interps.begin();
			eit != timed_interps.end(); eit++){
		delete (*eit);
	}

	vars_seen.clear();

	return path;
}

}
