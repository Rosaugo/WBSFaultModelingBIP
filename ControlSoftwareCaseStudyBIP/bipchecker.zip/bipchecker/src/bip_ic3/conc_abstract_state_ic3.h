/*
 * abstract_state_ic3.h
 *
 *  Created on: Apr 5, 2017
 *      Author: wangqiang
 */

#ifndef CONC_ABSTRACT_STATE_IC3_H_
#define CONC_ABSTRACT_STATE_IC3_H_


#include "bip_art/conc_abstract_state.h"
#include "bip_ic3/structures.h"

namespace bipchecker {

class ConcAbstractStateIC3 : public ConcAbstractState{

	//! The abstract state is a conjunction of clauses
	//! A clause is a disjunction of literals
	//! A literal is a boolean variable for a predicate
	//! (an abstract state is a CNF of boolean variables for predicates)
	Frame clauses_;

	bool bottom;

public:

	//! Class constructor.
	explicit ConcAbstractStateIC3(): bottom(false){
	}

	//! Class copy constructor
	explicit ConcAbstractStateIC3(const ConcAbstractStateIC3& state)
	: ConcAbstractState(state)
	{
		for(auto cl : state.clauses_) {
			clauses_.push_back(Clause());
			for (auto l : cl) {
				if(l)	clauses_.back().push_back(l->clone());
			}
		}

		bottom = state.bottom;
	}

	Frame& get_clauses() { return clauses_; }

	const Frame& get_clauses() const { return clauses_; }

	void set_clauses(Frame& c) { clauses_ = c; }

	void add_clause(Clause& cl) { clauses_.push_back(cl); }

	void set_bottom(bool b){ bottom = b;}

	bool is_bottom() {return bottom;}

	//! Return the number of clauses in the frame
	size_t frame_size() { return clauses_.size(); }

	void add_literal(size_t pos, expression* l) {
		clauses_.insert(clauses_.begin()+pos, Clause());
		clauses_[pos].push_back(l);
	}

	//! Clones state.
	/*!
	 * \return The cloned state.
	 */
	virtual ConcAbstractState* clone() const {
		return new ConcAbstractStateIC3(*this);
	}

	virtual std::string to_string() const {

		std::string result = "<";

		//! translate the abstract data state

		for(Frame::const_iterator fit = clauses_.begin();
				fit != clauses_.end(); fit++) {

			result += "[";
			for(Clause::const_iterator cit = (*fit).begin();
					cit != (*fit).end(); ++cit){

				std::stringstream ss;
				(*cit)->pretty_print(ss);
				result += ss.str();
				if(cit != (*fit).end() - 1) {
					result += ", ";
				}
			}
			result += "], ";
		}

		for(const_iterator cit = thread_begin();
				cit != thread_end(); ){

			const Symbol* th = (*cit).first;
			AbstractState* th_state = (*cit).second;

			std::string th_name = th->to_string();
			result += th_name;
			result += ": ";
			result += th_state->to_string();

			cit++;
			if(cit != thread_end())
				result += ", ";
		}

		result += ">";
		return result;
	}

	virtual ~ConcAbstractStateIC3(){
		//! delete all the literals in the Frame
		for(auto cl : clauses_) {
			for(auto l : cl) {
				if(l) delete l;
			}
			cl.clear();
		}
		clauses_.clear();
	}
};

}


#endif /* ABSTRACT_STATE_IC3_H_ */
