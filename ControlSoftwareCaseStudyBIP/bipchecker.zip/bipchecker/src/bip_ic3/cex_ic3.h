/*
 * cex_ic3.h
 *
 *  Created on: Apr 6, 2017
 *      Author: wangqiang
 */

#ifndef CEX_IC3_H_
#define CEX_IC3_H_


#include "bip_cegar/cex.h"
#include "bip_ic3/structures.h"
#include "bip_ic3/conc_abstract_state_ic3.h"


namespace bipchecker {

class CExIC3 : public CEx {

	typedef std::deque<ConcAbstractStateIC3*> abstract_state_t;

	//! Sequence of abstract states
	abstract_state_t states_;

	typedef std::vector<expression*> expression_sequence;

	//! Untimed path expressions (NOT in SSA form).
	expression_sequence path_expressions_;

	//! Sequence of interpolants
	expression_sequence interps_;

public:
	explicit CExIC3(ART::ARTNode& start): CEx(start) {}


	typedef expression_sequence::const_iterator expr_iterator;

	//! Gets the start iterator of path expressions.
	/*!
	 * \return The start iterator of path expressions.
	 */
	expr_iterator path_expr_begin() const { return path_expressions_.begin(); }

	//! Gets the end iterator of path expressions.
	/*!
	 * \return The end iterator of path expressions.
	 */
	expr_iterator path_expr_end() const { return path_expressions_.end(); }

	//! Adds path expressions.
	/*!
	 * \param path_expression a path expression.
	 */
	void add_path_expression(expression* path_expr) { path_expressions_.push_back(path_expr); }

	//! Get the path expression at the given position
	expression* path_expression(size_t pos) { return path_expressions_[pos]; }

	//! Returns the length of path
	size_t path_length() {	return path_expressions_.size(); }

	//! Adds interpolants
	/*!
	 * \param expr an interpolant
	 */
	void add_interpolants(expression* expr) { interps_.push_back(expr); }

	//! Gets the start iterator of interpolants expressions.
	/*!
	 * \return The start iterator of interpolants expressions.
	 */
	expr_iterator interp_begin() const { return interps_.begin();}

	//! Gets the end iterator of interpolants expressions.
	/*!
	 * \return The end iterator of interpolants expressions.
	 */
	expr_iterator interp_end() const { return interps_.end(); }

	//! Return the number of interpolants
	size_t numb_of_interp() { return interps_.size(); }

	//!
	void add_state_front(ConcAbstractStateIC3* state) { states_.push_front(state); }

	//!
	void add_state_back(ConcAbstractStateIC3* state) { states_.push_back(state); }

	//! Gets the abstract state at a certain position
	ConcAbstractStateIC3* abstract_state(size_t pos) { return states_[pos]; }

	//! Return the number of states along the the path
	size_t numb_of_states() {return states_.size(); }

	//! Prints cex.
	/*!
	 * \param out an output stream.
	 */
	virtual void print_cex(std::ostream& out) const;

	virtual ~ CExIC3();
};

}


#endif /* CEX_IC3_H_ */
