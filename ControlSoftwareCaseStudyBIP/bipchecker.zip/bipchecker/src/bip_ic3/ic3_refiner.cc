/*
 * ic3_refiner.cc
 *
 *  Created on: Apr 5, 2017
 *      Author: wangqiang
 */

#include "bip_ic3/ic3_refiner.h"
#include "bip_ic3/cex_ic3.h"
#include "util/logger.h"

namespace bipchecker {

size_t IC3Refiner::counter = 0;

bool IC3Refiner::refine(ART& art, CEx& cex, AbsDomain& domain,
		ART::work_list_t& work_list) {

	CExIC3& cex_ic3 = dynamic_cast<CExIC3&>(cex);
	PredDomain& pred_domain = dynamic_cast<PredDomain&>(domain);

	//! num_of_states = path_length + 1
	size_t num_of_states = cex_ic3.numb_of_states();
	size_t path_length = cex_ic3.path_length();
	assert(num_of_states == path_length + 1);

	//! pv_node points to the node from which the trace becomes infeasible
	//! TODO:
	//!  in this implementation, pv_node points to the latest node being changed
	size_t pv_node = path_length;

	//! first create a boolean variable for each new predicate extracted from the interpolants
	refine_pred_domain(cex, pred_domain);

	Z3Solver solver;
	size_t res_pv = 0;
	//! then check if it is blocked
	//! TODO: optimize it
	while (!blocked(cex, res_pv, domain, solver)) {
		//! then block this path
		//! build F[n-1] \wedge Trans[n-1] and compute the abstract preimage,
		//! where n is the path length

		//! the return value 'res_pv' points to the earliest node being updated
		res_pv = block_cex(cex, domain, solver, work_list);
		if(res_pv < pv_node)
			pv_node = res_pv;
	}

	//! TODO:
	//! add updated nodes to the worklist and delete the subtree
	/*
	if(pv_node < path_length){

		//! first find the pivok node
		ART::ARTNode* pnode = &cex.start();
		for(size_t pos = 0; pos < pv_node; pos++) {
			pnode = pnode->child( *(cex.label(pos)) );
		}

		Logger::log << Logger::level(2)
			<< "IC3: Delete the subtree from node "
			<< pnode->node_id()
			<< Logger::end;

		//! then delete the subtree from pv_node
		std::vector<ART::ARTNode*> children;
		for(ART::ARTNode::child_iterator ci = pnode->child_begin();
				ci != pnode->child_end(); ci++) {
			children.push_back( ((*ci).second) );
		}

		for(std::vector<ART::ARTNode*>::iterator ci = children.begin();
				ci != children.end(); ci++) {

			Logger::log << Logger::level(3)
				<< "IC3: Delete ART node "
				<< (*ci)->node_id()
				<< Logger::end;

			delete (*ci);
		}

		pnode->unmark();
		work_list.push_back(pnode);
	}
	*/

	return true;
}

void IC3Refiner::refine_pred_domain(CEx& cex, PredDomain& domain) {

	Logger::log << Logger::level(3)
			<< "IC3: Refine the predicate domain using interpolants."
			<< Logger::end;


	CExIC3& cex_ic3 = dynamic_cast<CExIC3&>(cex);

	for (CExIC3::expr_iterator eit = cex_ic3.interp_begin();
			eit != cex_ic3.interp_end(); ++eit) {

		//! TODO:
		//! Make sure that each interpolant is a single predicate
		//! if it is not an atom, then extract the atoms
		expression* interp = *eit;

		//! exclude the constant predicate
		true_constant* tc = dynamic_cast<true_constant*>(interp);
		false_constant* fc = dynamic_cast<false_constant*>(interp);

		if (tc == 0 && fc == 0) {
			//! check if this predicate exists in the domain
			//!    syntactic check is not enough
			//!    x == 1 is equivalent to 1 == x, but have difference syntax


			if (!domain.contains(interp)) {

				std::string var_name = fresh_bvar();
				expression* bv = new boolean(var_name);
				domain.add(interp->clone(), bv);

				Logger::log << Logger::level(3)
					<< "IC3: Add new predicate: "
					<< var_name << " --> " << interp << Logger::end;
			}
		}
	}
}


bool IC3Refiner::blocked(CEx& cex, size_t pv,
		AbsDomain& domain, Z3Solver& solver) {

	Logger::log << Logger::level(3)
			<< "IC3: Check if the counterexample is blocked."
			<< Logger::end;

	solver.reset();

	CExIC3& cex_ic3 = dynamic_cast<CExIC3&>(cex);
	PredDomain& pred_domain = dynamic_cast<PredDomain&>(domain);

	//! traversal forwards
	bool blocked = false;
	size_t num_of_states = cex_ic3.numb_of_states();

	for (size_t pos = pv; pos < num_of_states - 1 && !blocked; pos++) {

		expression* abs_state = frame2expression(cex_ic3.abstract_state(pos)->get_clauses());

		expression* texpr = cex_ic3.path_expression(pos);

		expression* conj_fr_tr = new binary_expression(binary_expression::AND,
				*abs_state, *texpr->clone());

		conj_fr_tr = new binary_expression(binary_expression::AND,
				*conj_fr_tr, *(pred_domain.abstraction_relation()));

		Logger::log << Logger::level(4)
			<< "IC3: Check blocking at position " << pos << " "
			<< conj_fr_tr << Logger::end;

		solver.assert_expr(conj_fr_tr);
		z3::check_result res = solver.solve();

		//! if the current abstract state does not allow the transition
		if (res == z3::unsat) {
			blocked = true;

			Logger::log << Logger::level(3)
					<< "IC3: Counterexample is blocked."
					<< Logger::end;
		}

		delete conj_fr_tr;
		solver.reset();
	}

	return blocked;
}

size_t IC3Refiner::block_cex(CEx& cex, AbsDomain& domain,
		Z3Solver& solver, ART::work_list_t& work_list) {

	Logger::log << Logger::level(3)
			<< "IC3: Block the counterexample."
			<< Logger::end;

	CExIC3& cex_ic3 = dynamic_cast<CExIC3&>(cex);
	PredDomain& pred_domain = dynamic_cast<PredDomain&>(domain);

	solver.reset();

	//! path_length is the number of interactions (transitions)
	//! num_of_states = path_length + 1
	size_t num_of_states = cex_ic3.numb_of_states();
	size_t path_length = cex_ic3.path_length();
	assert(num_of_states == path_length + 1);

	//! pv_node points to the node from which the execution is infeasible
	size_t pv_node  = path_length;

	expression* abs_state = frame2expression(cex_ic3.abstract_state(path_length - 1)->get_clauses());
	expression* trans_expr = cex_ic3.path_expression(path_length - 1);
	expression* conj_fr_tr = new binary_expression(binary_expression::AND,
			*abs_state, *trans_expr->clone());
	conj_fr_tr = new binary_expression(binary_expression::AND,
			*conj_fr_tr, *(pred_domain.abstraction_relation()));

	solver.assert_expr(conj_fr_tr);
	z3::check_result res = solver.solve();

	//! the result must be sat,
	//! since the trace is not blocked.
	assert(res == z3::sat);

	//! obtain a satisfying model first,
	//! which is a state leading to the error location,
	//! thus should be blocked.
	//! Since there may be an infinite set of satisfying models,
	//! we will use abstraction and block the abstract state instead.
	z3::model m = solver.getModel();

	//! an abstract state is a cube
	Cube bad;
	ProofQueue queue_;
	std::vector<Cube> cubes; //caching cubes for later deleting

	//! to compute the abstract state from the satisfying model,
	//! we will evaluate each predicate in the domain on the satisfying model.
	for (PredDomain::preds_map_iterator pm = pred_domain.preds_map_begin();
			pm != pred_domain.preds_map_end(); pm++) {

		expression* bv = (*pm).first;
		expression* res_bv = solver.evaluate(bv, m);

		if (is_true_constant(res_bv)) {

			bad.push_back(bv->clone());

		} else if (is_false_constant(res_bv)) {

			bad.push_back(new unary_expression(unary_expression::NOT, *bv->clone()));

		}
		delete res_bv;
	}

	//! add the bad cube into the proof obligation queue
	queue_.push_new(bad, path_length - 1);

	Logger::log << Logger::level(4)
		<< "IC3: Adding a cube into the proof queue at position "
		<< path_length - 1 << ": ";

	for (auto cl : bad) {
		Logger::log << cl << " ";
	}

 	Logger::log << Logger::end;

 	//! cache the bad cube
 	cubes.push_back(bad);

	//! then try to block all the bad cubes in the queue
	while (!queue_.empty()) {

		solver.reset();

		ProofObligation* po = queue_.top();

		Logger::log << Logger::level(4)
			<< "IC3: Blocking the cube at position " << po->idx << ": ";

		for (auto cl : po->cube) {
			Logger::log << cl << " ";
		}

		Logger::log << Logger::end;

		//! check the abstract inductiveness:
		//! first create the abstract state
		expression* temp_abs_state = frame2expression(
				cex_ic3.abstract_state(po->idx - 1)->get_clauses());
		temp_abs_state = new binary_expression(binary_expression::AND,
				*temp_abs_state, *(pred_domain.abstraction_relation()));

		//! then create the transition relation
		expression* temp_trans_expr = cex_ic3.path_expression(po->idx - 1);

		//! add the frame condition here
		expression* framed_trans_expr = temp_trans_expr->clone();
		std::vector<expression*> vars_in_transition;
		std::vector<expression*> vars_in_predicates;

		vars_in_expression(temp_trans_expr, vars_in_transition);

		for (PredDomain::preds_map_iterator pm = pred_domain.preds_map_begin();
				pm != pred_domain.preds_map_end(); pm++) {

			vars_in_expression((*pm).second, vars_in_predicates);
		}

		//! add frame condition for variables in predicates, but not in the transition
		for (auto var : vars_in_predicates) {
			variable* v_var = dynamic_cast<variable*>(var);
			std::string v_var_name = v_var->get_name();

			bool seen = false;
			for (std::vector<expression*>::iterator dit =
					vars_in_transition.begin();
					dit != vars_in_transition.end() && !seen; ++dit) {

				expression* dexpr = *dit;
				variable* d_var = dynamic_cast<variable*>(dexpr);
				std::string d_var_name = d_var->get_name();
				if (d_var_name == v_var_name)
					seen = true;
			}

			if (!seen) {
				expression* shifted_var = new timed_expression(*(var->clone()),
						1);
				expression* eq = new binary_expression(binary_expression::EQ,
						(*shifted_var), *(var->clone()));
				framed_trans_expr = new binary_expression(
						binary_expression::AND, *framed_trans_expr, *eq);
			}
		}

		for (auto var : vars_in_predicates) {
			delete var;
		}

		for (auto var : vars_in_transition) {
			delete var;
		}

		expression* temp_conj_fr_tr = new binary_expression(
				binary_expression::AND, *temp_abs_state, *framed_trans_expr);

		expression* bad_cube = cube2expression(po->cube);
		expression* timed_cube = new timed_expression(*bad_cube, 1);
		expression* timed_rel = new timed_expression(
				*(pred_domain.abstraction_relation()), 1);
		timed_cube = new binary_expression(binary_expression::AND,
				*timed_cube, *timed_rel);

		expression* impl = new binary_expression(binary_expression::AND,
				*temp_conj_fr_tr, *timed_cube);

		solver.assert_expr(impl);
		res = solver.solve();

		if (res == z3::unsat) {
			//! inductiveness check succeeds
			//! the bad cube is blocked, add the negation to the abstract state

			Logger::log << Logger::level(4)
				<< "IC3: Cube is blocked at position " << po->idx << ": ";

			for (auto cl : po->cube) {
				Logger::log << cl << " ";
			}

			Logger::log << Logger::end;

			queue_.pop();

			//! update the clauses of the abstract state at po->idx
			Clause temp_cl;
			for (auto tl : po->cube) {
				expression* neg_tl = new unary_expression(unary_expression::NOT,
						*tl->clone());
				expression* simp_tl = simplify(neg_tl);
				temp_cl.push_back(simp_tl);
				delete neg_tl;
			}
			cex_ic3.abstract_state(po->idx)->add_clause(temp_cl);

			//! set the pivok node
			if(po->idx < pv_node)
				pv_node = po->idx;

			//! propagate the clauses
//			if(po->idx != path_length - 1)
//				propagate(cex_ic3, *po, pred_domain, solver);

			//! if the node covers some other one,
			//! then check if the covering relation still holds
			//! after refinement.

			ART::ARTNode* pnode = &cex_ic3.start();
			ARTPath::label_iterator pia = cex_ic3.label_begin();
			for (size_t index = 0; index < po->idx; index++) {
				pnode = pnode->child(*(*pia));
				pia++;
			}

			std::vector<ART::ARTNode*> node_its;
			for(ART::ARTNode::covered_node_iterator cit = pnode->covered_nodes_begin();
				cit != pnode->covered_nodes_end(); ++cit) {

			    ART::ARTNode* cnode = *cit;
			    assert(cnode->mark() == ART::ARTNode::MARKED_COVERED);

			    //! check if the covering still holds
				const ConcAbstractStateIC3& state_ic3 =
						dynamic_cast<const ConcAbstractStateIC3&>(cnode->abstract_state());
				const ConcAbstractStateIC3& other_state_ic3 =
						dynamic_cast<const ConcAbstractStateIC3&>(pnode->abstract_state());

				const Frame& state_clauses = state_ic3.get_clauses();
				const Frame& other_state_clauses = other_state_ic3.get_clauses();

				bool is_covered = false;
				if(imply_frame(state_clauses, other_state_clauses))
					is_covered = true;

			    if(!is_covered){
			      //! covering relation does not hold
			      //! unmark the node and add it into the worklist
			      cnode->unmark();
			      cnode->set_covering_node(0);
			      work_list.push_back(cnode);
			      node_its.push_back(cnode);
			    }
			  }

			  //! remove some covering information from this node
			  for(std::vector<ART::ARTNode*>::iterator iit = node_its.begin();
			      iit != node_its.end(); ++iit) {
				  pnode->remove_covered_node(*iit);
			  }

			  node_its.clear();

		} else {
			//! inductiveness check fails
			//! then get the pre-image of the bad cube
			Cube temp_bad;

			z3::model m = solver.getModel();

			//! then compute an abstraction of the preimage
			//! TODO: do we have to compute an over-approximation?
			for (PredDomain::preds_map_iterator pm = pred_domain.preds_map_begin();
					pm != pred_domain.preds_map_end(); pm++) {

				expression* bv = (*pm).first;
				expression* res_bv = solver.evaluate(bv, m);

				if (is_true_constant(res_bv)) {
					temp_bad.push_back(bv->clone());

				} else if (is_false_constant(res_bv)) {
					temp_bad.push_back(
							new unary_expression(unary_expression::NOT, *bv->clone()));

				}
				delete res_bv;
			}

			cubes.push_back(temp_bad);
			queue_.push_new(temp_bad, po->idx - 1, po);

			Logger::log << Logger::level(4)
				<< "IC3: Adding a cube into the proof queue at position "
				<< po->idx - 1 << ": ";

			for (auto cl : temp_bad) {
				Logger::log << cl << " ";
			}

			Logger::log << Logger::end;
		}

		delete impl;
	}

	//! Clean up
	delete conj_fr_tr;

	for (auto cb : cubes)
		for (auto expr : cb)
			delete expr;

	return pv_node;
}

void IC3Refiner::propagate(CEx& cex, ProofObligation& po,
		AbsDomain& domain, Z3Solver& solver) {

	Logger::log << Logger::level(3)
		<< "Propagate clauses."
		<< Logger::end;

	CExIC3& cex_ic3 = dynamic_cast<CExIC3&>(cex);
	PredDomain& pred_domain = dynamic_cast<PredDomain&>(domain);

	size_t pos = po.idx;

	//! check the abstract inductiveness:
	//! first create the abstract state
	expression* temp_abs_state = frame2expression(
			cex_ic3.abstract_state(pos)->get_clauses());
	temp_abs_state = new binary_expression(binary_expression::AND,
			*temp_abs_state, *(pred_domain.abstraction_relation()));

	//! then create the transition relation
	expression* temp_trans_expr = cex_ic3.path_expression(pos);

	//! add the frame condition here
	expression* framed_trans_expr = temp_trans_expr->clone();
	std::vector<expression*> vars_in_transition;
	std::vector<expression*> vars_in_predicates;

	vars_in_expression(temp_trans_expr, vars_in_transition);

	for (PredDomain::preds_map_iterator pm = pred_domain.preds_map_begin();
			pm != pred_domain.preds_map_end(); pm++) {

		vars_in_expression((*pm).second, vars_in_predicates);
	}

	//! add frame condition for variables in predicates, but not in the transition
	for (auto var : vars_in_predicates) {
		variable* v_var = dynamic_cast<variable*>(var);
		std::string v_var_name = v_var->get_name();

		bool seen = false;
		for (std::vector<expression*>::iterator dit = vars_in_transition.begin();
				dit != vars_in_transition.end() && !seen; ++dit) {

			expression* dexpr = *dit;
			variable* d_var = dynamic_cast<variable*>(dexpr);
			std::string d_var_name = d_var->get_name();
			if (d_var_name == v_var_name)
				seen = true;
		}

		if (!seen) {
			expression* shifted_var = new timed_expression(*(var->clone()), 1);
			expression* eq = new binary_expression(binary_expression::EQ,
					(*shifted_var), *(var->clone()));
			framed_trans_expr = new binary_expression(binary_expression::AND,
					*framed_trans_expr, *eq);
		}
	}

	for (auto var : vars_in_predicates) {
		delete var;
	}

	for (auto var : vars_in_transition) {
		delete var;
	}

	expression* temp_conj_fr_tr = new binary_expression(binary_expression::AND,
			*temp_abs_state, *framed_trans_expr);

	expression* bad_cube = cube2expression(po.cube);
	expression* timed_cube = new timed_expression(*bad_cube, 1);
	expression* timed_rel = new timed_expression(*(pred_domain.abstraction_relation()), 1);
	timed_cube = new binary_expression(binary_expression::AND, *timed_cube, *timed_rel);

	expression* impl = new binary_expression(binary_expression::AND, *temp_conj_fr_tr, *timed_cube);

	solver.assert_expr(impl);
	z3::check_result res = solver.solve();

	if(res == z3::unsat) {
		//! update the clauses of the next abstract state
		Clause temp_cl;
		for (auto tl : po.cube) {
			expression* neg_tl = new unary_expression(unary_expression::NOT, *tl->clone());
			expression* simp_tl = simplify(neg_tl);
			temp_cl.push_back(simp_tl);
			delete neg_tl;
		}
		cex_ic3.abstract_state(pos+1)->add_clause(temp_cl);
	}

	delete impl;
}


}
