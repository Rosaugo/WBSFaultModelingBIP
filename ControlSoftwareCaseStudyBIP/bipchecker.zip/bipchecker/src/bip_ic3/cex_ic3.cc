/*
 * cex_ic3.cc
 *
 *  Created on: Apr 6, 2017
 *      Author: wangqiang
 */



#include "bip_ic3/cex_ic3.h"

namespace bipchecker {


void CExIC3::print_cex(std::ostream& out) const {
	unsigned int index = 1;

	const ART::ARTNode& start_art_node = start();
	const ConcAbstractState& start_state = start_art_node.abstract_state();
	const ConcAbstractStateIC3& start_state_ic3 = dynamic_cast<const ConcAbstractStateIC3&>(start_state);
//	const ConcLoc *start_cfa_node = &start_state.conc_location();
//	assert(start_cfa_node != 0);

	out << "Counterexample path:" << std::endl;
	out << "ART node " << start_art_node.node_id() << ": ";
	out << start_state_ic3.to_string() << std::endl << std::endl;

	const ART::ARTNode *walk_art_node = &start_art_node;
	for (ARTPath::label_iterator lit = label_begin(); lit != label_end();
			++lit) {

		const BIPInteraction *edge = *lit;
		assert(edge != 0);

		out << "Interaction: ";
		out	<< edge->get_name();
		out << std::endl << std::endl;

		walk_art_node = walk_art_node->child(*edge);
		assert(walk_art_node != 0);

		const ConcAbstractState& walk_state = walk_art_node->abstract_state();
		const ConcAbstractStateIC3& walk_state_ic3 = dynamic_cast<const ConcAbstractStateIC3&>(walk_state);
//		const ConcLoc *walk_cfa_node = &walk_state.conc_location();
//		assert(walk_cfa_node != 0);
		++index;

		out << "ART node " << walk_art_node->node_id() << ": ";
		out << walk_state_ic3.to_string() << std::endl << std::endl;
	}
}

std::ostream& operator<<(std::ostream& out, const CExIC3& cex) {
	cex.print_cex(out);
	return out;
}

CExIC3::~CExIC3() {

	states_.clear();

	for (expr_iterator it = path_expressions_.begin();
			it != path_expressions_.end(); ++it) {

		if (*it)
			delete *it;
	}
	path_expressions_.clear();

	for (expr_iterator it = interps_.begin();
			it != interps_.end(); ++it) {

		if (*it)
			delete *it;
	}
	interps_.clear();
}


}
