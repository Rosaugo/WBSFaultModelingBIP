/*
 * pred_domain.cc
 *
 *  Created on: May 17, 2017
 *      Author: wangqiang
 */


#include "bip_ic3/pred_domain.h"


namespace bipchecker {

bool PredDomain::contains(expression* pred) {
	bool flag = false;

	//! first perform syntactic check
	for(auto p : preds_) {
		if(p->equal(pred)){
			flag = true;
			break;
		}
	}

	//! then perform semantic check
	if(!flag) {
		for(auto p : preds_) {
			if(imply(p, pred) and imply(pred, p)) {
				flag = true;
				break;
			}
		}
	}
	return flag;
}

expression* PredDomain::abstraction_relation() {
	expression* result = new true_constant();

	for(auto mp : b2p_) {
		expression* bv = mp.first;
		expression* pred = mp.second;
		expression* equal_rel =
				new binary_expression(binary_expression::EQ, *bv->clone(), *pred->clone());
		result = new binary_expression(binary_expression::AND, *result, *equal_rel);
	}

	return result;
}

}



