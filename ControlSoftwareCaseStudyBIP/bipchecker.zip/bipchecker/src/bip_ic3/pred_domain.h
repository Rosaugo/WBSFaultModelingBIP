/*
 * pred_domain.h
 *
 *  Created on: May 17, 2017
 *      Author: wangqiang
 */

#ifndef PRED_DOMAIN_H_
#define PRED_DOMAIN_H_

#include "util/hash_map.h"
#include "bip_cegar/abs_domain.h"
#include "bip_solver/expression.h"

namespace bipchecker {

class PredDomain : public AbsDomain {

	//! the set of predicates
	typedef std::vector<expression*> predst;

	predst preds_;

	//! Mapping from a boolean (kept as a string) to a predicate
	typedef hash_map<expression*,
			expression*,
			eq_expr> b2p_map;

	b2p_map b2p_;

public:
	explicit PredDomain() {
	}


	typedef b2p_map::iterator preds_map_iterator;

	typedef predst::iterator preds_iterator;

	b2p_map::iterator preds_map_begin() {
		return b2p_.begin();
	}

	b2p_map::iterator preds_map_end() {
		return b2p_.end();
	}

	predst::iterator preds_begin() {
		return preds_.begin();
	}

	predst::iterator preds_end() {
		return preds_.end();
	}

	//! return the predicate abstraction relation
	expression* abstraction_relation();


	//! check if the given predicate already exists
	bool contains(expression* pred);

	//! add a new predicate to the domain, and the map
	//! pred is the predicate, and bv is the corresponding boolean
	void add(expression* pred, expression* bv) {
		 preds_.push_back(pred);
		 b2p_[bv] = pred->clone();
	}

	~PredDomain() {

		for(auto p : preds_) {
			delete p;
		}

		std::vector<expression*> expr1;
		std::vector<expression*> expr2;

		for(b2p_map::iterator mit = b2p_.begin();
				mit != b2p_.end(); ++mit) {
			expr1.push_back((*mit).first);
			expr2.push_back((*mit).second);
		}
		b2p_.clear();

		for(auto e : expr1)
		{ delete e; }

		for(auto e : expr2)
		{ delete e; }

		expr1.clear();
		expr2.clear();
	}
};

}


#endif /* PRED_DOMAIN_H_ */
