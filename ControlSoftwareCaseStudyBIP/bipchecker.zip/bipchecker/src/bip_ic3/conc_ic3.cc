/*
 * conc_ic3.cc
 *
 *  Created on: Apr 5, 2017
 *      Author: wangqiang
 */


#include "util/logger.h"
#include "bip_ic3/conc_ic3.h"

namespace bipchecker {

ConcCEGARResult* ConcIC3::reach(ConcAbstractState *init_state) const {

	// Init time.
	double init_time = get_cpu_time();

	// Create an ART whose root is labelled with the initial abstract state.
	ART *art = new ART(init_state);

	// Prepare result.
	ConcCEGARResult *cegar_result = new ConcCEGARResult(art);

	// Get the root of ART.
	ART::ARTNode& root = art->root();
	assert(root.mark() == ART::ARTNode::UNMARKED);

	// Get a work list that is synchronized with the ART.
	work_list_t& work_list = art->create_work_list();

	// Place the root in the work list.
	work_list.push_back(&root);

	while(!work_list.empty()){

		if (time_limit_ >= 0.0) { // Time limit is enabled.
			if ((get_cpu_time() - init_time) > time_limit_) { // Out of time.
				Logger::log << "IC3: Timeout." << Logger::end;
				cegar_result->set_complete_search(false);
				work_list.clear();
				return cegar_result;
			}
		}

		if(mem_limit_ > 0) {
			if(art->size() >= mem_limit_ ) {
				Logger::log << "IC3: space limit." << Logger::end;
				cegar_result->set_complete_search(false);
				work_list.clear();
				return cegar_result;
			}
		}

		// Pick a node.
		ART::ARTNode *node = choose_node(work_list);
		assert(node != 0);
		assert(node->mark() == ART::ARTNode::UNMARKED);

		// Get the labeling abstract state.
		const ConcAbstractState& state = node->abstract_state();

		  Logger::log << Logger::level(1)
			      << "IC3: Choose node "
			      << node->node_id() << ": "
			      << state.to_string()
			      << Logger::end;

		//! First check if it is an error node
		if(is_error(state)){
			//! build the abstract counterexample
			//! check right away if it is real.
			//! compute the sequence interpolants if it is spurious.

			Logger::log << Logger::level(1)
				    << "IC3: ART node "
				    << node->node_id()
				    << " is an error location."
				    << Logger::end;

			Logger::log << Logger::level(1)
				    << "IC3: Build an abstract counterexample."
				    << Logger::end;

			CEx *cex = cex_builder_.build_cex(*node);
			assert(cex != 0);

			if(cex->is_abstract()){

				Logger::log << Logger::level(1)
					    << "IC3: Counterexample is spurious."
					    << Logger::end;

				Logger::log << Logger::level(3)
					    << "IC3: Print counterexample. \n"
					    << *cex << Logger::end;

				Logger::log << Logger::level(1)
					    << "IC3: Do refinement."
					    << Logger::end;

				//! block the abstract counterexample using ic3
				//! update the abstract states
				refiner_.refine(*art, *cex, domain_, work_list);

			} else {

				Logger::log << Logger::level(1)
					    << "IC3: Counterexample is concrete."
					    << Logger::end;

				//! find a real counterexample
				//! and output it

				cegar_result->set_status(ConcCEGARResult::ERROR);
				work_list.clear();
				cegar_result->set_cex(cex);
				return cegar_result;
			}

			delete cex;

		} //! Then check if this node can be covered
		else if (is_covered(*node, *art)){

			Logger::log << Logger::level(1)
				    << "IC3: ART node "
				    << node->node_id()
				    << " is covered."
				    << Logger::end;

			//! check if node can be covered
			//! register the covering information if covered
		    //! and uncover the covered nodes of this one
		    //! and add the uncovered nodes into the worklist

		    std::vector<ART::ARTNode*> node_its;
		    for(ART::ARTNode::covered_node_iterator cit = node->covered_nodes_begin();
		    		cit != node->covered_nodes_end(); ++cit) {
		    	ART::ARTNode* cnode = *cit;
		    	node_its.push_back(cnode);
		    }

		    for(auto nd: node_its) {
		    	node->remove_covered_node(nd);
		    	nd->set_covering_node(0);
		    	nd->unmark();
		    	work_list.push_back(nd);
		    }

			node->mark_covered();

		}
		else if (fc_ && force_covering(*node, *art)) {

			  Logger::log << Logger::level(1)
				      << "IC3: Node "
				      << node->node_id()
				      << " is forcely covered."
				      << Logger::end;

			    std::vector<ART::ARTNode*> node_its;
			    for(ART::ARTNode::covered_node_iterator cit = node->covered_nodes_begin();
			    		cit != node->covered_nodes_end(); ++cit) {
			    	ART::ARTNode* cnode = *cit;
			    	node_its.push_back(cnode);
			    }

			    for(auto nd: node_its) {
			    	node->remove_covered_node(nd);
			    	nd->set_covering_node(0);
			    	nd->unmark();
			    	work_list.push_back(nd);
			    }

			    //! mark it as covered
			    //! NOTE it is a leaf node
			    node->mark_covered();
		}
		//! Then expand this node
		else {

			  Logger::log << Logger::level(1)
				      << "IC3: Expand node "
				      << node->node_id()
				      << Logger::end;

			//! expand the node
			//! forward propagate the clauses to children nodes
			//! mark it as uncovered

			expand_node(*node, work_list);
		}

	}

	if (cegar_result->status() == ConcCEGARResult::UNKNOWN)
		cegar_result->set_status(ConcCEGARResult::SAFE);

	return cegar_result;
}

void ConcIC3::expand_node(ART::ARTNode& node, work_list_t& work_list) const {

	// Get the labeling abstract state.
	const ConcAbstractState* state = &node.abstract_state();

	// Get the node location. delete it later
	const ConcLoc* location = &state->conc_location();

	//! this list contains the enabled interactions
	interactions_t enabled_interactions;

	//! this set contains the internal transitions
	cfa_edges_t internal_edges;

	//! then compute the set of interactions in the given node
	compute_interactions(node, enabled_interactions, internal_edges);

	interactions_t::iterator ia_begin = enabled_interactions.begin();
	interactions_t::iterator ia_end = enabled_interactions.end();

	///////////////////////////////////////////////////////////////////////////////////
	////////////////// compute the successors of the enabled interactions /////////////
	///////////////////////////////////////////////////////////////////////////////////
	for(interactions_t::iterator iit = ia_begin; iit != ia_end; ++iit){

		//! for each enabled interaction,
		const BIPInteraction* temp_ia = *iit;

		//! create a successor node
		ConcAbstractState *new_state = 0;

		//! get the original state
		const ConcAbstractState* original_state = state;
		const ConcAbstractStateIC3* original_state_ic3 =
				dynamic_cast<const ConcAbstractStateIC3*>(original_state);

		cfa_edges_t temp_trans;

		Logger::log << Logger::level(2)
			<< "IC3: Compute post image of interaction "
			<< temp_ia->get_name() << Logger::end;

		get_cfa_edges(location, temp_ia, temp_trans);

		assert(!temp_trans.empty());

		//! then compute the image given the set of transitions temp_trans
		new_state = transfer(*original_state_ic3, temp_trans);
		assert(new_state != 0);

		ConcAbstractStateIC3* new_state_ic3 = dynamic_cast<ConcAbstractStateIC3*>(new_state);

		if(!new_state_ic3->is_bottom()) {

			//! create a successor node, and set the label to be the set of edges
			node.add_child(*temp_ia, new_state);

			for(std::vector<const CFAEdge*>::const_iterator cit = temp_trans.begin();
					cit != temp_trans.end(); ++cit){
				node.add_transition(*temp_ia, *cit);
			}

		} else {

			delete new_state;
		}

	}

	////////////////////////////////////////////////////////////////////////////////////////
	///////////// compute the successor of internal transitions, if it exists //////////////
	////////////////////////////////////////////////////////////////////////////////////////
	if(!internal_edges.empty()){
		//! create successor node
		ConcAbstractState *new_state = 0;

		//!get the original state
		const ConcAbstractState* original_state = state;
		const ConcAbstractStateIC3* original_state_ic3 =
				dynamic_cast<const ConcAbstractStateIC3*>(original_state);

		/// DEBUG HERE
		Logger::log << Logger::level(2)
			<< "IC3: Compute post image of internal transitions. "
			<< Logger::end;

		new_state = transfer(*original_state_ic3, internal_edges);

		assert(new_state != 0);

		ConcAbstractStateIC3* new_state_ic3 = dynamic_cast<ConcAbstractStateIC3*>(new_state);

		if(!new_state_ic3->is_bottom()) {

			//! this interaction is not in the interaction model, how to delete it??
			//! TODO: add it to the interaction model
			BIPInteraction* temp_ia = new BIPInteraction(std::string("BIP_Internal_Interaction"));

			node.add_child(*temp_ia, new_state);

			for(cfa_edges_t::const_iterator cit = internal_edges.begin();
					cit != internal_edges.end(); ++cit){
				node.add_transition(*temp_ia, *cit);
			}

		} else {
			delete new_state;
		}

	}

	add_children_to_work_list(node, work_list);

	enabled_interactions.clear();

	// Mark expanded node as UNCOVERED.
	node.mark_uncovered();
}


void ConcIC3::compute_interactions(ART::ARTNode& node,
		interactions_t& enabled_interactions,
		cfa_edges_t& internal_edges) const {

	// Get the labeling abstract state.
	const ConcAbstractState* state = &node.abstract_state();

	// Get the node location. delete it later
	const ConcLoc* location = &state->conc_location();

	//! this map tracks the set of enabled ports by each component
	sym_ports_t enabled_ports;

	////////////////////////////////////////////////////////////////////////////////////////////
	//////////////// step 1: compute the enabled ports, and internal transitions ///////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	for(ConcLoc::const_iterator lit = location->begin();
			lit != location->end(); ++lit){

			//! the component name
			const Symbol* comp_id = (*lit).first;
			std::string comp_name = comp_id->to_string();
			//! the control location
			const CFANode* comp_loc = (*lit).second;

			std::set<std::string> temp_ports;
			//! for each out-going edge, collect the set of ports
			for(CFANode::const_iterator nit = comp_loc->out_begin();
					nit != comp_loc->out_end(); ++nit){

				if(*nit){
					const CFAEdge* temp_edge = (*nit);
					//! check if it is an internal transition
					if(temp_edge->is_internal()){

						internal_edges.push_back(temp_edge);

					} else {
						assert(temp_edge->label() != 0);
						std::string temp_name = temp_edge->label()->name()->name();
						temp_ports.insert(temp_name);
					}
				}
			}

			enabled_ports[comp_name] = temp_ports;
	}

	//////////////////////////////////////////////////////////////////////////////////
	///////////////////////// compute enabled interactions ///////////////////////////
	//////////////////////////////////////////////////////////////////////////////////

	for(InteractionModel::const_iterator mit = bim_->const_interaction_begin();
			mit != bim_->const_interaction_end(); ++mit){
		if(*mit){
			//! for each interaction, check if it is enabled;
			const BIPInteraction* temp_ia =*mit;
			bool enabled = true;
			for(BIPInteraction::const_iterator bit = temp_ia->const_begin();
					bit != temp_ia->const_end() && enabled; ++bit){
				if(*bit){
					//! for each port, check if it is enabled
					const BIPPort* temp_port = *bit;
					std::string comp_name = temp_port->get_threadName();
					std::string port_name = temp_port->get_PortName();
					sym_ports_t::iterator temp_it = enabled_ports.find(comp_name);
					if(temp_it == enabled_ports.end()){
						enabled = false;
					} else{
						enabled = (*temp_it).second.find(port_name) == (*temp_it).second.end()? false:true;
					}
				}
			}
			if(enabled){
				//! this interaction is enabled, and store them in an ordered way
				enabled_interactions.push_back(temp_ia);
			}
		}
	}

	/// DEBUG HERE
	Logger::log << Logger::level(2)
		<< "IC3: Compute possible interactions: "
		<< enabled_interactions.size() << Logger::end;

	enabled_ports.clear();
}


void ConcIC3::get_cfa_edges(const ConcLoc* location,
		const BIPInteraction* ia,
		cfa_edges_t& edges) const {

	///////////////////////////////////////////////////////////////
	//////////////// check if there is message passing ////////////
	///////////////////////////////////////////////////////////////
	if(ia->has_data_transfer()){
		//! if there is data transfer, get the CFAEdge
		const CFA* ia_cfa = ia->get_cfa();
		const CFANode& entry_node = ia_cfa->entry();
		assert(entry_node.out_degree() == 1);
		const CFAEdge* entry_edge = *(entry_node.out_begin());
		assert(entry_edge != 0);
		edges.push_back(entry_edge);
	}

	for(BIPInteraction::const_iterator pit = ia->const_begin();
		pit != ia->const_end(); ++pit){
		//! for each port, expand the corresponding edge
		const BIPPort* temp_port = *pit;
		std::string temp_comp_name = temp_port->get_threadName();
		std::string temp_port_name = temp_port->get_PortName();

		//! find the current control location of this component
		const CFANode* temp_cfa_node = 0;
		for(ConcLoc::const_iterator lit = location->begin();
				lit != location->end(); ++lit){

			const Symbol* comp_id = (*lit).first;
			std::string temp_name = comp_id->to_string();
			if(temp_name == temp_comp_name){
				temp_cfa_node = (*lit).second;
			}

		}
		assert(temp_cfa_node != 0);

		const CFAEdge* temp_cfa_edge = 0;
		//! find the edge corresponding to the port
		for(CFANode::const_iterator eit = temp_cfa_node->out_begin();
				eit != temp_cfa_node->out_end(); ++eit){
			if(*eit){
				std::string temp_edge_name = (*eit)->label()->name()->name();
				if(temp_edge_name == temp_port_name){
					temp_cfa_edge = *eit;
				}
			}
		}
		assert(temp_cfa_edge != 0);

		edges.push_back(temp_cfa_edge);
	}
}

ConcAbstractStateIC3* ConcIC3::transfer(const ConcAbstractStateIC3& state,
		std::vector<const CFAEdge*>& edges) const {

	// Prepare a new abstract state.
	ConcAbstractStateIC3 *new_state = new ConcAbstractStateIC3();

	//! Update global state
	//! propagate the clauses that are relatively inductive
	propagate(state, *new_state, edges);

	////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////// update the thread states then /////////////////////////
	////////////////////////////////////////////////////////////////////////////////////

	//! find the components which participate the interaction
	for (ConcAbstractStateIC3::const_iterator it = state.thread_begin();
			it != state.thread_end(); ++it) {

		const Symbol *t_id = (*it).first;
		const AbstractState *t_state = ((*it).second);
		assert(t_state != 0);

		//! find the corresponding edge
		bool found = false;
		const CFAEdge* edge = 0;
		for(std::vector<const CFAEdge*>::const_iterator eit = edges.begin();
				eit != edges.end() && !found; ++eit){
			const CFAEdge* temp_edge = (*eit);
			const CFANode& from = temp_edge->from();
			const CFA& cfa = from.cfa();
			const Symbol& cfa_id = Symbol::symbol(cfa.name());
			if(&cfa_id == t_id){
				found = true;
				edge = temp_edge;
			}
		}

		if(edge != 0){
			/// DEBUG HERE
			Logger::log << Logger::level(3)
				<< "IC3: Perform transfer relation in component "
				<< t_id->to_string() << " on component state." << Logger::end;

			// Create a new abstract state.
			AbstractState *rt_new_state = new AbstractState(edge->to());

			// Add the new state of running thread into the successor state.
			new_state->add_thread_state(*t_id, rt_new_state);
		} else {
			//! then this component does not participate, copy the component state
			AbstractState *t_new_state = new AbstractState(*t_state);
			new_state->add_thread_state(*t_id, t_new_state);
		}

	}//! end for all component

	return new_state;
}

void ConcIC3::propagate(const ConcAbstractStateIC3& state,
		ConcAbstractStateIC3& next,
		std::vector<const CFAEdge*>& edges) const {

	TransitionBuilder& trans_builder = refiner_.trans_builder();

	PredDomain& pred_domain = dynamic_cast<PredDomain&>(domain_);

	ConcAbstractStateIC3& abs_state = const_cast<ConcAbstractStateIC3&>(state);

	expression* abs_state_expr = frame2expression(abs_state.get_clauses());

	abs_state_expr = new binary_expression(binary_expression::AND, *abs_state_expr,
			*(pred_domain.abstraction_relation()));

	Transition* temp_tran = trans_builder.build_transition(edges);
	expression* temp_tran_expr = temp_tran->get_expression();
	expression* temp_tran_guard = temp_tran->guard();

	expression* trans_expr = new binary_expression(binary_expression::AND,
			*(temp_tran_expr->clone()), *(temp_tran_guard->clone()));

	delete temp_tran;

	//! add the frame condition here
	expression* framed_trans_expr = trans_expr;
	std::vector<expression*> vars_in_transition;
	std::vector<expression*> vars_in_predicates;

	vars_in_expression(trans_expr, vars_in_transition);

	for (PredDomain::preds_map_iterator pm = pred_domain.preds_map_begin();
			pm != pred_domain.preds_map_end(); pm++) {

		vars_in_expression((*pm).second, vars_in_predicates);
	}

	//! add frame condition for variables in predicates, but not in the transition
	for (auto var : vars_in_predicates) {
		variable* v_var = dynamic_cast<variable*>(var);
		std::string v_var_name = v_var->get_name();

		bool seen = false;
		for (std::vector<expression*>::iterator dit =
				vars_in_transition.begin();
				dit != vars_in_transition.end() && !seen; ++dit) {

			expression* dexpr = *dit;
			variable* d_var = dynamic_cast<variable*>(dexpr);
			std::string d_var_name = d_var->get_name();
			if (d_var_name == v_var_name)
				seen = true;
		}

		if (!seen) {
			expression* shifted_var = new timed_expression(*(var->clone()),
					1);
			expression* eq = new binary_expression(binary_expression::EQ,
					(*shifted_var), *(var->clone()));
			framed_trans_expr = new binary_expression(
					binary_expression::AND, *framed_trans_expr, *eq);
		}
	}

	for (auto var : vars_in_predicates) {
		delete var;
	}

	for (auto var : vars_in_transition) {
		delete var;
	}

	expression* conj_fr_tr = new binary_expression(binary_expression::AND,
			*abs_state_expr, *framed_trans_expr);

	Z3Solver solver;
	z3::check_result res;

	solver.assert_expr(conj_fr_tr);
	res = solver.solve();

	if(res == z3::unsat) {
		next.set_bottom(true);

		delete conj_fr_tr;
		return;
	}

	//! iterate over the set of clauses
	Frame& clauses = abs_state.get_clauses();
	for(auto cl: clauses) {
		expression* cl_expr = clause2expression(cl);
		expression* ng_cl = new unary_expression(unary_expression::NOT, *cl_expr);
		expression* timed_cube = new timed_expression(*ng_cl, 1);
		expression* timed_rel = new timed_expression(*(pred_domain.abstraction_relation()), 1);
		timed_cube = new binary_expression(binary_expression::AND, *timed_cube, *timed_rel);
		expression* impl = new binary_expression(binary_expression::AND,
				*(conj_fr_tr->clone()), *timed_cube);

		solver.reset();
		solver.assert_expr(impl);
		res = solver.solve();

		if(res == z3::unsat) {
			//! update the clauses of the next abstract state
			Clause temp_cl;
			for(auto ec : cl) {
				temp_cl.push_back(ec->clone());
			}
			next.add_clause(temp_cl);
		}

		delete impl;
	}
	delete conj_fr_tr;
}


bool ConcIC3::is_covered(const ART::ARTNode& node, const ART& art) const {

	const ConcAbstractState& state = node.abstract_state();
	const ConcLoc *loc = &state.conc_location();
	assert(loc != 0);

	bool is_covered = false;
	//! Go through the nodes with the same control location
	ART::const_nodes_iterator it = art.loc_begin(*loc);
	ART::const_nodes_iterator end_it = art.loc_end(*loc);

	for (; it != end_it && !is_covered; ++it) {
		const ART::ARTNode *other_node = *it;

		if (other_node != &node  && other_node->node_id() < node.node_id() &&
				other_node->mark() == ART::ARTNode::MARKED_UNCOVERED) {

			const ConcAbstractState &other_state = other_node->abstract_state();

			//! do the covering check
			const ConcAbstractStateIC3& state_ic3 =
					dynamic_cast<const ConcAbstractStateIC3&>(state);
			const ConcAbstractStateIC3& other_state_ic3 =
					dynamic_cast<const ConcAbstractStateIC3&>(other_state);

			const Frame& state_clauses = state_ic3.get_clauses();
			const Frame& other_state_clauses = other_state_ic3.get_clauses();

			if(imply_frame(state_clauses, other_state_clauses))
				is_covered = true;

			if(is_covered){
				ART::ARTNode* other_node_c = const_cast<ART::ARTNode*>(other_node);
				ART::ARTNode& node_c = const_cast<ART::ARTNode&>(node);
				other_node_c->add_covered_node(&node_c);
				node_c.set_covering_node(other_node_c);
			}

		}
	}

	return is_covered;
}


//! TODO: propagate each clause individually, not a frame
bool ConcIC3::force_covering(ART::ARTNode& node, ART& art) const {

	//! node to be covered
    ConcAbstractState& state = node.abstract_state();
    ConcAbstractStateIC3& cstate = dynamic_cast<ConcAbstractStateIC3&>(state);
//    Frame& state_clauses = cstate.get_clauses();

    const ConcLoc* loc = &state.conc_location();
    assert(loc != 0);

    Logger::log << Logger::level(2)
    	<< "IC3: Check force covering of ART node "
		<< node.node_id() << ". " << node.abstract_state().to_string()
		<< Logger::end;


    //! Find a node with the same control location,
    //! Test whether its state interpolant holds in this node
    //!   find the common ancestor,
    //!   build the path from this ancestor to this node
    //!   check the relative inductiveness

    ART::const_nodes_iterator it = art.loc_begin(*loc);
    ART::const_nodes_iterator end_it = art.loc_end(*loc);

    bool covered = false;

    for(; it != end_it &&
	  ((*it)->node_id() < node.node_id()) &&
	  ((*it)->mark() == ART::ARTNode::MARKED_UNCOVERED) &&
	  !covered; ++it) {

      //! backtrack from the two nodes to root
      //! keep track of the node ids
      //! find the common node id

      ART::ARTNode* root = &(art.root());
      ART::ARTNode* walk = &node;

      std::set<int> node_ids;

      //! go backwards from current node to root
      //! and collect all the predecessor nodes along the path
      while(walk != root) {
    	  node_ids.insert(walk->node_id());
    	  walk = walk->parent();
      }

      //! walk backwards from another node with the same location
      const ART::ARTNode* walk2_c = (*it);
      ART::ARTNode* walk2 = const_cast<ART::ARTNode*>(walk2_c);

      bool flag = false;
      while(walk2 != &node && walk2 != root && !flag) {

    	  int walk2_id = walk2->node_id();
    	  std::set<int>::iterator idit = node_ids.find(walk2_id);

    	  if(idit != node_ids.end()) {
    		  //! find a common ancestor, which is walk2
    		  //! between (*it) and (node)
    		  flag = true;

    		  const ConcAbstractState& cstate_walk = walk2->abstract_state();
    		  ConcAbstractState& cstate_walk_ = const_cast<ConcAbstractState&>(cstate_walk);
    		  ConcAbstractStateIC3& cstate_ic3_walk = dynamic_cast<ConcAbstractStateIC3&>(cstate_walk_);
    		  Frame& cstate_walk_clauses = cstate_ic3_walk.get_clauses();
    		  expression* cstate_walk_expr = frame2expression(cstate_walk_clauses);

    		  //! check if the state of (*it),
    		  //! which has the same control location with node,
    		  //! holds in node
    		  const ConcAbstractState& state2 = (*it)->abstract_state();
    		  ConcAbstractState& cstate2_ = const_cast<ConcAbstractState&>(state2);
    		  ConcAbstractStateIC3& cstate2 = dynamic_cast<ConcAbstractStateIC3&>(cstate2_);
    		  Frame& cstate2_clauses = cstate2.get_clauses();
//    		  expression* cstate2_expr = frame2expression(cstate2_clauses);

    		  //! build the path from walk2 to node
    		  std::vector<std::vector<const CFAEdge*>> edge_vec;

    		  walk = &node;
    		  while(walk != walk2) {
    			  //! get the label leading to walk
    			  const BIPInteraction *edge_label = walk->label();

    			  walk = walk->parent();

    			  std::vector<const CFAEdge*> edges;
    			  for(ART::ARTNode::const_edge_iterator cti = walk->transition_begin(*edge_label);
    					  cti != walk->transition_end(*edge_label); ++cti)
    				  edges.push_back(*cti);

    			  edge_vec.insert(edge_vec.begin(), edges);
    		  }

    		  std::vector<expression*> path_expressions(edge_vec.size());

    		  //! build the path expression
    		  build_path_expr(edge_vec, path_expressions);

    		  size_t path_length = path_expressions.size();

    		  expression* path_expr = new true_constant();
    		  for(auto expr : path_expressions ) {
    			  path_expr = new binary_expression(binary_expression::AND, *path_expr, *expr);
    		  }

    		  //! build the implication
    		  PredDomain& pred_domain = dynamic_cast<PredDomain&>(domain_);

    		  expression* cstate_abs = new binary_expression(binary_expression::AND,
    				  *cstate_walk_expr, *(pred_domain.abstraction_relation()));
    		  expression* conj = new binary_expression(binary_expression::AND,
    				  *cstate_abs, *path_expr);
    		  expression* abs_t = new timed_expression(*(pred_domain.abstraction_relation()), path_length);

    		  expression* conj_abs_t = new binary_expression(binary_expression::AND,
    				  *conj, *abs_t);

//    		  expression* timed_expr = new timed_expression(*cstate2_expr, path_length);
//    		  std::cout << conj_abs_t << std::endl;
//    		  std::cout << timed_expr << std::endl;

    		  if(sat(conj_abs_t)) {

    			  //! the path is feasible
        		  //! check the validity

    			  //! for each clause in the state, check if it can be propagated
    			  for(auto cl : cstate2_clauses) {

    				  expression* timed_cl = new timed_expression(*clause2expression(cl),
    						  path_length);

            		  covered = imply(conj_abs_t, timed_cl);

            		  delete timed_cl;

            		  if(covered) {
            			  //! add clauses in cstate2 into that of cstate
            			  /*
            			  for(auto cl2 : cstate2_clauses) {
            			  }
            			  */

        				  Clause temp_cl;
        				  for(auto l: cl) {
        					  temp_cl.push_back(l->clone());
        				  }
        				  cstate.add_clause(temp_cl);

            			  //! then record this covering information:
            			  //! node_c is covered by other_node_c
            			  ART::ARTNode* other_node_c = const_cast<ART::ARTNode*>(*it);

            			  other_node_c->add_covered_node(&node);
            			  node.set_covering_node(other_node_c);

            			  break;
            		  }
    			  }

        		  delete conj;
//        		  delete timed_expr;
    		  }

    	  } //! if

    	  walk2 = walk2->parent();
      }

    }
    return covered;
}


void ConcIC3::build_path_expr(std::vector<std::vector<const CFAEdge*>>& edges,
    		std::vector<expression*>& path_expressions) const {

	int current = 0;

	Transition::domain_t vars_seen;
	std::vector<Transition*> back_transitions;

	std::vector<expression*> vars_in_predicates;

	PredDomain& pred_domain = dynamic_cast<PredDomain&>(domain_);
	for (PredDomain::preds_map_iterator pm = pred_domain.preds_map_begin();
			pm != pred_domain.preds_map_end(); pm++) {

		vars_in_expression((*pm).second, vars_in_predicates);
	}

	for(auto e : vars_in_predicates) {
		vars_seen.insert(e);
	}

	for(std::vector<std::vector<const CFAEdge*>>::iterator it = edges.begin();
	      it != edges.end(); ++it) {

		std::vector<const CFAEdge*> temp_edges = (*it);

		Transition* temp_tran = cex_builder_.trans_builder().build_transition(temp_edges);
		expression* temp_tran_expr = temp_tran->get_expression();
		expression* temp_tran_guard = temp_tran->guard();

		expression* trans_expr =
				new binary_expression(binary_expression::AND, *(temp_tran_expr->clone()), *(temp_tran_guard->clone()));

		for(Transition::domain_t::iterator vit = vars_seen.begin();
				vit != vars_seen.end(); ++vit){

			expression* vexpr = *vit;
			variable* v_var = dynamic_cast<variable*>(vexpr);
			std::string v_var_name = v_var->get_name();

			bool seen = false;
			for(Transition::const_domain_iterator dit = temp_tran->domain_begin();
					dit != temp_tran->domain_end() && !seen; ++dit){

				expression* dexpr = *dit;
				variable* d_var = dynamic_cast<variable*>(dexpr);
				std::string d_var_name = d_var->get_name();
				if(d_var_name == v_var_name)
					seen = true;
			}

			if(!seen){
				expression* shifted_var = new timed_expression( *(vexpr->clone()), 1);
				expression* eq = new binary_expression(binary_expression::EQ, (*shifted_var), *(vexpr->clone()) );

				expression* temp_trans_expr = trans_expr;
				trans_expr = new binary_expression(binary_expression::AND, *temp_trans_expr, *eq);
			}
		}

		for(Transition::const_domain_iterator dit = temp_tran->domain_begin();
				dit != temp_tran->domain_end(); ++dit){
			expression* dexpr = *dit;
			variable* d_var = dynamic_cast<variable*>(dexpr);
			std::string d_var_name = d_var->get_name();

			bool seen = false;
			for(Transition::domain_t::iterator vit = vars_seen.begin();
					vit != vars_seen.end(); ++vit){

				expression* vexpr = *vit;
				variable* v_var = dynamic_cast<variable*>(vexpr);
				std::string v_var_name = v_var->get_name();
				if(d_var_name == v_var_name)
					seen = true;
			}

			if(!seen)
				vars_seen.insert(dexpr);
		}

		expression* timed_trans_expr = new timed_expression(*trans_expr, current);
		expression* simplified_expr = simplify(timed_trans_expr);
		path_expressions[current] = simplified_expr;

		++current;
		back_transitions.push_back(temp_tran);
		delete timed_trans_expr;
	}

	for(auto e : vars_in_predicates) {
		delete e;
	}

	vars_seen.clear();

	for(std::vector<Transition*>::iterator tit = back_transitions.begin();
	    tit != back_transitions.end(); ++tit)
	  delete (*tit);
}

}
