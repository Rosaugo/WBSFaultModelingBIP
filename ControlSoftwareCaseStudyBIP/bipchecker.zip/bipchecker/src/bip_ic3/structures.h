/*
 * structures.h
 *
 *  Created on: Apr 4, 2017
 *      Author: wangqiang
 */

#ifndef STRUCTURES_H_
#define STRUCTURES_H_

/*
 *  Data structures for IC3 algorithm
 */

#include "bip_solver/expression.h"
#include "bip_solver/solver_z3.h"
#include <queue>

namespace bipchecker{

typedef std::vector<expression*> Cube;
///< a cube is a conjunction of literals, represented as a vector

typedef std::vector<expression*> Clause;
///< a clause is a disjunction of literals, also represented as a vector

typedef std::vector<Clause> Frame;
///< a Frame (an element of the trace F) is a vector of clauses

typedef std::vector<Frame> FrameList;
///< the trace F is a vector of frames


//! Return the CNF form of the frame (a set of clauses)
inline expression* frame2expression(Frame& fr) {
	expression* cnf = new true_constant();

	if(!fr.empty()) {

		for(auto cl : fr) {
			expression* dj = new false_constant();
			for( auto e : cl) {
				dj = new binary_expression(binary_expression::OR, *dj, *(e->clone()));
			}
			cnf = new binary_expression(binary_expression::AND, *cnf, *dj);
		}

	}
	return cnf;
}

//! Return the expression of a clause
inline expression* clause2expression(Clause& cl) {
	expression* dj = new false_constant();
	for( auto e : cl) {
		dj = new binary_expression(binary_expression::OR, *dj, *(e->clone()));
	}
	return dj;
}

//! Return the expression of a cube
inline expression* cube2expression(Cube& c) {
	expression* cj = new true_constant();
	for( auto e : c) {
		cj = new binary_expression(binary_expression::AND, *cj, *(e->clone()));
	}
	return cj;
}

inline bool imply_clause(const Clause& cl1, const Clause& cl2) {

	if(cl2.empty()){ // cl2 is true
		return true;
	}

	if(cl1.empty() && !cl2.empty()){ // cl1 is true, while cl2 is not
		return false;
	}


	//! first make the disjunction, then check if cl1 implies cl2

	expression* cnf1 = new false_constant();
	for(auto e : cl1) {
		cnf1 = new binary_expression(binary_expression::OR, *cnf1, *(e->clone()));
	}

	expression* cnf2 = new false_constant();
	for(auto e : cl2) {
		cnf2 = new binary_expression(binary_expression::OR, *cnf2, *(e->clone()));
	}

	expression* imp = new binary_expression(binary_expression::IMPLY, *cnf1, *cnf2);

	bool implied = false;
	false_constant* fc = dynamic_cast<false_constant*>(cnf1);
	if(fc != 0){
		implied = true;
	} else {
		// call the smt solver to check the validity
		Z3Solver solver;
		solver.assert_neg_expr(imp);
		if(solver.solve() == z3::unsat){
			implied = true;
		}
	}

	delete imp;
	return implied;
}

inline bool imply_frame(const Frame& fr1, const Frame& fr2) {

	if(fr2.empty()){ // fr2 is true
		return true;
	}

	if(fr1.empty() && !fr2.empty()){ // fr1 is true, while fr2 is not
		return false;
	}

	//! first make the CNF, then check if fr1 implied fr2

	expression* cnf1 = new true_constant();
	for(auto cl1 : fr1) {
		expression* dj1 = new false_constant();
		for( auto e : cl1) {
			dj1 = new binary_expression(binary_expression::OR, *dj1, *(e->clone()));
		}
		cnf1 = new binary_expression(binary_expression::AND, *cnf1, *dj1);
	}

	expression* cnf2 = new true_constant();
	for(auto cl2 : fr2) {
		expression* dj2 = new false_constant();
		for( auto e : cl2) {
			dj2 = new binary_expression(binary_expression::OR, *dj2, *(e->clone()));
		}
		cnf2 = new binary_expression(binary_expression::AND, *cnf2, *dj2);
	}

	expression* imp = new binary_expression(binary_expression::IMPLY, *cnf1, *cnf2);

	bool implied = false;

	// call the smt solver to check the validity
	Z3Solver solver;
	solver.assert_neg_expr(imp);
	if(solver.solve() == z3::unsat){
		implied = true;
	}

	delete imp;
	return implied;
}

/**
 * A proof obligation is a pair <C,k> where C is a bad cube to block and k
 * is a position in the current trace. The pair represents the relative
 * induction query:
 *    ~C & F[k] & T |= ~C'
 * where F is the current trace and T the transition relation.
 *
 * Proof obligations are linked together (via the next field) to form a
 * counterexample trace
 */
struct ProofObligation {
    Cube cube;
    unsigned int idx;
    ProofObligation *next;

    ProofObligation(Cube c, unsigned int t, ProofObligation *n=NULL):
        cube(c), idx(t), next(n) {}

    bool operator<(const ProofObligation &other) const { return idx < other.idx; }
};

/**
 * Ordering for proof obligations in the priority queue (see below)
 */
struct ProofObligationOrder {
    bool operator()(const ProofObligation *a, const ProofObligation *b) const { return (*b) < (*a);}
};

/**
 * Priority queue of proof obligations
 */
class ProofQueue {
public:
    ~ProofQueue()
    {
        for (auto p : store_) {
            delete p;
        }
    }

    void push_new(const Cube &c, unsigned int t, ProofObligation *n=NULL)
    {
        ProofObligation *po = new ProofObligation(c, t, n);
        push(po);
        store_.push_back(po);
    }

    void push(ProofObligation *p) { queue_.push(p); }
    ProofObligation *top() { return queue_.top(); }
    void pop() { queue_.pop(); }
    bool empty() const { return queue_.empty(); }

private:
    typedef std::priority_queue<ProofObligation *,
                                std::vector<ProofObligation *>,
                                ProofObligationOrder> Queue;
    Queue queue_;
    std::vector<ProofObligation *> store_;
};


}

#endif /* STRUCTURES_H_ */
