/*
 * options.h
 *
 *  Created on: Dec 16, 2016
 *      Author: wangqiang
 */

#ifndef OPTIONS_H_
#define OPTIONS_H_


#include <map>
#include <string>

#include "util/util.h"

namespace bipchecker {

class Options {

public:

    typedef std::map<const std::string, void*>::const_iterator iterator;

    static Options& get_instance();

    static void release_options();

    void add_option(const std::string& name,
                    int value,
                    const std::string& help);

    void add_option(const std::string& name,
                    const std::string& value,
                    const std::string& help);

    void add_option(const std::string& name,
                    unsigned value,
                    const std::string& help);

    void add_option(const std::string& name,
                    bool value,
                    const std::string& help);

    void add_option(const std::string& name,
                    float value,
                    const std::string& help);

    void add_enum_option(const std::string& name,
                         int default_value,
                         const std::string& help);


    void update_option(const std::string& name, int value);

    void update_option(const std::string& name, const std::string& value);

    void update_option(const std::string& name, unsigned value);

    void update_option(const std::string& name, bool value);

    void update_option(const std::string& name, float value);


    void add_enumerand(const std::string& opt_name,
                       int enum_value,
                       const std::string& enum_name);


    bool is_option_bool(const std::string& name) const;

    bool is_option_int(const std::string& name) const;

    bool is_option_unsigned(const std::string& name) const;

    bool is_option_float(const std::string& name) const;

    bool is_option_string(const std::string& name) const;

    bool is_option_enum(const std::string& name) const;


    bool get_bool_option(const std::string& name) const;

    int get_int_option(const std::string& name) const;

    unsigned get_unsigned_option(const std::string& name) const;

    float get_float_option(const std::string& name) const;

    const std::string& get_string_option(const std::string& name) const;


//     std::string get_help(const std::string& name) const;

    bool has_option(const std::string& name) const;


    // Deprecated.
    void print_help(std::ostream& stream) const;

    void print(std::ostream& stream) const;

    int parse_options(int argc, char* argv[]);

private:

    enum OptType
    {
	BOOLEAN = 1,
	INTEGER,
	FLOAT,
	UNSIGNED,
	STRING,
	ENUM
    };

    // typedef OptType opt_type;

    explicit Options();

    virtual ~Options();

    void initialize();

    template<typename T> void add_option(const std::string& name,
                                         const T& value,
                                         const std::string& help);

    template<typename T> void update_option(const std::string& name,
                                             const T& value);

    template<typename T> T& get_option(const std::string& name) const;

    // Simple functor to compare strings
    typedef struct ltstr
    {
      bool operator()(const std::string& s1, const std::string& s2) const
      {
        return s1.compare(s2) < 0;
      }
    } ltstr;

    std::map<const std::string, void*> options_map;

    std::map<const std::string, std::string, ltstr> help_map;

    std::map<const std::string, OptType> options_type_map;

    std::map<const std::string, std::map<const std::string, int> > enums;

    unsigned opt_max_len;

    static Options* instance;

    bool has_option_type(const std::string& name, OptType type) const;


    DISALLOW_COPY_AND_ASSIGN(Options);
};

std::ostream& operator<<(std::ostream& out, const Options& options);

}



#endif /* OPTIONS_H_ */
