/*
 * symbol.h
 *
 *  Created on: Dec 15, 2016
 *      Author: wangqiang
 */

#ifndef SYMBOL_H_
#define SYMBOL_H_


#include <ostream>

#include "util/util.h"
#include "util/hash_map.h"

namespace bipchecker{

//! Symbol class.
/*!
 * In the future this class might be moved into symbol table
 * package.
 */
class Symbol
{
    typedef hash_map<std::string,
		     Symbol*,
		     hash_fun<std::string>,
		     EqStr> symbols_t;


    //! Symbol-map class.
    /*!
     * This class represents an internal mapping from
     * hash code of a string to a symbol. So that
     * every string that represents a symbol will be
     * represented by a unique symbol.
     */
    class SymbolMap {
	//! The internal (or actual) mapping.
	symbols_t symbols_;

    public:
		//! Class constructor.
		explicit SymbolMap() {}

		//! Gets the actual mapping.
		/*!
		 * Internal mapping is purposedly leaked
		 * for simplicity.
		 */
		symbols_t& symbols() { return symbols_; }

		//! Class destructor.
		~SymbolMap();

    private:
		DISALLOW_COPY_AND_ASSIGN(SymbolMap);
    }; // class SymbolMap

    //! Mapping from strings to symbols.
    static SymbolMap symbol_map;

    //! Name for arbitrary symbol.
    static std::string symbol_name;

    //! Unique id for arbitrary symbol.
    static size_t fresh_id;

    //! The string representation of symbol.
    std::string symbol_;

    //! Symbol id.
    size_t symbol_id_;

public:

    //! Gets the unique symbol representing a string.
    /*!
     * \param symbol a string representation of symbol.
     * \return The symbol.
     */
    static const Symbol& symbol(const std::string& symbol);

    //! Crates a fresh symbol.
    /*!
     * \return A fresh symbol.
     */
    // static const Symbol& fresh_symbol();

    //! Gets the string representation of a symbol.
    /*!
     * \return The string representation of a symbol.
     */
    const std::string& to_string() const { return symbol_; }

    //! Gets symbol's id.
    /*!
     * \return The id of the symbol.
     */
    size_t symbol_id() const { return symbol_id_; }

private:

    //! Class constructor.
    /*!
     * \param symbol a string representation of symbol.
     */
    explicit Symbol(const std::string& symbol)
      : symbol_(symbol), symbol_id_(Symbol::fresh_id++) {
    }

    //! Calculates hash code of a string.
    /*!
     * \param symbol a string representation of symbol.
     * \return The hash code of the string.
     */
    // static int hash_code(const std::string& symbol);


    //! Class destructor.
    ~Symbol() {
    }

    DISALLOW_COPY_AND_ASSIGN(Symbol);

}; // class Symbol


struct EqSymbol
{
    bool operator() (const Symbol *s1, const Symbol *s2) const
    {
	if (s1 && !s2)
	    return false;
	if (!s1 && s2)
	    return false;
	if ( (!s1 && !s2)
	     || (s1 && s2 && s1->symbol_id() == s2->symbol_id()) )
	    return true;

	return false;
    }
}; // struct EqSymbol


struct LtSymbol
{
    bool operator() (const Symbol *s1, const Symbol *s2) const
    {
	if (!s1 && !s2)
	    return false;
	if (!s1 && s2)
	    return true;
	if (s1 && !s2)
	    return false;
	if (s1 && s2 && s1->symbol_id() < s2->symbol_id())
	    return true;

	return false;

    }
}; // struct LtSymbol

std::ostream& operator<< (std::ostream&, const Symbol&);

} // namespace bipchecker

hash_fun_namespace_open {

  // Hash function for symbols.
    template<> struct hash<const bipchecker::Symbol*>
    {
	size_t operator() (const bipchecker::Symbol *s) const
	{
	    return s->symbol_id();
	}
    };

}
hash_fun_namespace_close;



#endif /* SYMBOL_H_ */
