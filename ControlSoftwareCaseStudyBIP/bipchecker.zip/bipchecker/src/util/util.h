

#ifndef SWCHECKER_UTIL_UTIL_H
#define SWCHECKER_UTIL_UTIL_H

#include <iostream>
#include <string>
#include <sstream>

#include <cstdlib>


namespace bipchecker
{


//! A macro to disallow the copy constructor and operator= function.
/*!
 * This macro should be used in the private: declaration for a class.
 */
#define DISALLOW_COPY_AND_ASSIGN(TypeName) \
    TypeName(const TypeName&);             \
    TypeName& operator=(const TypeName&)


//! A macro to disallow the copy constructor.
/*!
 * This macro should be used in the private: declaration for a class.
 */
#define DISALLOW_COPY(TypeName) \
    TypeName(const TypeName&)


//! A macro to disallow the operator= function.
/*!
 * This macro should be used in the private: declaration for a class.
 */
#define DISALLOW_ASSIGN(TypeName) \
    TypeName& operator=(const TypeName&)


//! Converts to string.
/*!
 * \param t an object.
 * \return The string representation of the object.
 */
template<class T>
std::string to_string(const T& t)
{
     std::ostringstream stream;
     stream << t;
     return stream.str();
}

//! Converts from string.
/*!
 * This function cannot convert hexadecimal or octal string representation
 * of an integer to the integer itself. To this end, an IOS base has to be
 * specified. 
 *
 * \param s a string representation of an object.
 * \return The object.
 * \se from_string.
 */
template<class T>
T from_string(const std::string& s)
{
     std::istringstream stream(s);
     T t;
     stream >> t;
     return t;
}

//! Converts from string.
/*!
 * This function is useful when integers are represented in hexadecimal 
 * or octal. 
 *
 * \param s a string representation of an object.
 * \param f an IOS base (std::dec, std::oct, or std::hex).
 * \return The object.
 */
template <class T>
bool from_string(T& t, 
                 const std::string& s, 
                 std::ios_base& (*f)(std::ios_base&))
{
    std::istringstream iss(s);
    return !(iss >> f >> t).fail();
}


//! Gets CPU time.
/*!
 * \return The CPU time.
 */
double get_cpu_time();


//! Gets string representation of local time.
/*!
 * \return The string representation of local time.
 */
std::string get_local_time();


//! Gets the maximal resident (i.e. physical) memory used so far, in megabytes.
long get_max_mem();


//! Gets the value of an environment variable.
/*!
 * \param k an environment variable name.
 * \return The value of an environment variable.
 */
std::string get_environment_variable(const std::string& k);

//! Sets the value of an environment variable.
/*!
 * This function adds the environment variable if it does
 * not exist, otherwise it overwrites the existing one.
 * To unset the variable, pass an empty value.
 *
 * \param k an environment variable name.
 * \param v a value for the environment variable.
 * \return Zero on success; otherwise non-zero.
 */
int set_environment_variable(const std::string& k, 
			     const std::string& v);


//! Class for wrapping unique id.
class UId
{

public:

    static size_t id;

    static size_t fresh_id();
};


//! Three-valued Booleans
//! (useful e.g. for flags with an undefined initial value)
enum lbool {
    L_UNDEF,
    L_FALSE,
    L_TRUE
};


}

#endif
