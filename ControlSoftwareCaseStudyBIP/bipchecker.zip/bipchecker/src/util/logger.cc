// $$KRATOS_LICENSE_COPYRIGHT$$

// Authors:
//   - Iman Narasamdya <narasamdya@fbk.eu>


#include "util/logger.h"

namespace bipchecker
{

Logger Logger::log;
Logger::EndLog Logger::end;

Logger::LogLevel Logger::level(int level)
{
    LogLevel llevel(level);

    return llevel;
}

Logger& Logger::operator<<(LogLevel level)
{
    curr_output_level_ = level.level_;

    return *this;
}


Logger& Logger::operator<<(const EndLog&)
{
    if (output_level_ >= curr_output_level_) {
        (*out_) << std::endl;
    }
    curr_output_level_ = -1;

    return *this;
}


Logger& Logger::flush()
{
    if (output_level_ >= curr_output_level_) {
        out_->flush();
    }

    return *this;
}


} // namespace swchecker
