/*
 * options.cc
 *
 *  Created on: Dec 16, 2016
 *      Author: wangqiang
 */


#include <cassert>
#include <iomanip>

#include <getopt.h>
#include <cstdlib>
#include <sstream>
#include <cstdlib>
#include <cerrno>
#include <climits>

#include "options.h"

#define _S(str) std::string(str)

namespace bipchecker {

  std::ostream& operator<<(std::ostream& out, const Options& options)
  {
    options.print(out);
    return out;
  }

  static std::string to_lower_case(const std::string & str) {
    const char* cstr = str.c_str();
    std::ostringstream oss;

    while (*cstr != '\0') {
      oss << std::tolower(*cstr);
#warning Are you sure about the "*cstr++"?
      *cstr++;
    }

    return oss.str();
  }

  Options* Options::instance = (Options*) NULL;

  template<typename T>
  void Options::add_option(const std::string& name,
                           const T& value,
                           const std::string& help)
  {
    help_map[name] = help;
    unsigned len = name.length();

    if (len > opt_max_len) {
      opt_max_len = len;
    }

    update_option<T>(name, value);
  }

  template<typename T>
  void Options::update_option(const std::string& name,
                              const T& value)
  {
    void* mem = options_map[name];
    T* cell;

    if (NULL != mem) {
      delete (T*)mem;
    }

    cell = new T(value);
    options_map[name] = (void*)cell;
  }

  void Options::add_enum_option(const std::string& name,
                                int default_value,
                                const std::string& help)
  {
    options_type_map[name] = ENUM;

    add_option<int>(name, default_value, help);
  }

  void Options::add_enumerand(const std::string& opt_name,
                              int enum_value,
                              const std::string& enum_name)
  {
    /* No override */
    assert(enums[opt_name].end() ==
           enums[opt_name].find(to_lower_case(enum_name)));
    enums[opt_name][to_lower_case(enum_name)] = enum_value;
  }

  void Options::add_option(const std::string& name,
                           int value,
                           const std::string& help)
  {
    assert(!has_option(name) ||
           (options_type_map[name] == INTEGER) );
    options_type_map[name] = INTEGER;

    add_option<int>(name, value, help);
  }

  void Options::add_option(const std::string& name,
                           const std::string& value,
                           const std::string& help)
  {
    assert(!has_option(name) ||
           (options_type_map[name] == STRING));

    options_type_map[name] = STRING;

    add_option<const std::string>(name, value, help);
  }

  void Options::add_option(const std::string& name,
                           unsigned value,
                           const std::string& help)
  {
    assert(!has_option(name) ||
           (options_type_map[name] == UNSIGNED));
    options_type_map[name] = UNSIGNED;

    add_option<unsigned>(name, value, help);
  }

  void Options::add_option(const std::string& name,
                           bool value,
                           const std::string& help)
  {
    assert(!has_option(name) ||
           (options_type_map[name] == BOOLEAN) );
    options_type_map[name] = BOOLEAN;

    add_option<bool>(name, value, help);
  }

  void Options::add_option(const std::string& name,
                           float value,
                           const std::string& help)
  {
    assert(!has_option(name) ||
           (options_type_map[name] == FLOAT));
    options_type_map[name] = FLOAT;

    add_option<float>(name, value, help);
  }


  void Options::update_option(const std::string& name,
                              int value)
  {
    update_option<int>(name, value);
  }

  void Options::update_option(const std::string& name,
                              const std::string& value)
  {
    update_option<const std::string>(name, value);
  }

  void Options::update_option(const std::string& name,
                              unsigned value)
  {
    update_option<unsigned>(name, value);
  }

  void Options::update_option(const std::string& name,
                              bool value)
  {
    update_option<bool>(name, value);
  }

  void Options::update_option(const std::string& name,
                              float value)
  {
    update_option<float>(name, value);
  }


  template<typename T> T& Options::get_option(const std::string& name) const
  {

    typedef std::map<const std::string, void*> options_map_t;

    options_map_t::const_iterator cit = options_map.find(name);

    if (cit == options_map.end())
      assert(false);

    void *mem = (*cit).second;

    return *((T*)mem);
  }

  bool Options::get_bool_option(const std::string& name) const
  {
    return get_option<bool>(name);
  }

  int Options::get_int_option(const std::string& name) const
  {
    return get_option<int>(name);
  }

  unsigned Options::get_unsigned_option(const std::string& name) const
  {
    return get_option<unsigned>(name);
  }

  float Options::get_float_option(const std::string& name) const
  {
    return get_option<float>(name);
  }

  const std::string& Options::get_string_option(const std::string& name) const
  {
    return get_option<const std::string>(name);
  }

  Options::Options() {
    opt_max_len = 0;
    initialize();
  }

  Options& Options::get_instance()
  {
    if (NULL == instance) {
      instance = new Options();
    }
    return *instance;
  }

  bool Options::is_option_bool(const std::string& name) const
  {
    return has_option_type(name,BOOLEAN); // (options_type_map[name] == BOOLEAN);
  }

  bool Options::is_option_enum(const std::string& name) const
  {
    return has_option_type(name,ENUM); // (options_type_map[name] == ENUM);
  }

  bool Options::is_option_unsigned(const std::string& name) const
  {
    return has_option_type(name,UNSIGNED); // (options_type_map[name] == UNSIGNED);
  }

  bool Options::is_option_float(const std::string& name) const
  {
    return has_option_type(name,FLOAT); // (options_type_map[name] == FLOAT);
  }

  bool Options::is_option_int(const std::string& name) const {
    return has_option_type(name,INTEGER); // (options_type_map[name] == INTEGER);
  }

  bool Options::is_option_string(const std::string& name) const {
    return has_option_type(name,STRING); // (options_type_map[name] == STRING);
  }

  void Options::initialize() {
    // Initialize useful API options here!
  }

  bool Options::has_option(const std::string& name) const
  {
    return (options_map.find(name) != options_map.end());
  }

  bool Options::has_option_type(const std::string& name,
				OptType type) const
  {

    if (options_map.find(name) != options_map.end()) {

      typedef std::map<const std::string, OptType> type_map_t;

      type_map_t::const_iterator cit = options_type_map.find(name);

      if (cit != options_type_map.end())
	return ((*cit).second == type);
    }

    return false;

  }

  void Options::print(std::ostream& stream) const
  {
    stream << "Options:" <<  std::endl;
    for (std::map<const std::string, std::string>::const_iterator i =
           help_map.begin();
         i != help_map.end();
         i++)
    {
      std::string name = _S((*i).first);
      if (!is_option_bool(name)) {
        name += " <arg> ";
      }
      else {
        name += " [=true/false] ";
      }

      stream << "   --" << std::left << std::setw(opt_max_len + 15) << name;
      stream << std::endl << "      ";
      stream << "  " << (*i).second << std::endl << std::endl;
    }

  }


  int Options::parse_options(int argc, char* argv[])
  {
    struct option* long_options = new struct option[help_map.size() + 2];
    int res = 0;

    unsigned idx = 0;
    for (std::map<const std::string, std::string>::const_iterator i =
           help_map.begin();
         i != help_map.end();
         i++)
    {
      std::string name = _S((*i).first);

      long_options[idx].name = name.c_str();
      long_options[idx].has_arg = is_option_bool(name) ? 2 : 1;
      long_options[idx].flag = NULL;
      long_options[idx].val = 0;
      idx ++;
    }

//     long_options[idx].name = "help";
//     long_options[idx].has_arg = false;
//     long_options[idx].flag = NULL;
//     long_options[idx].val = 0;

//     idx ++;

    long_options[idx].name = NULL;
    long_options[idx].has_arg = false;
    long_options[idx].flag = NULL;
    long_options[idx].val = 0;

    while (true) {
      /* getopt_long stores the option index here. */
      int option_index = 0;
      int c;

      c = getopt_long (argc, argv, "", long_options, &option_index);

      /* Detect the end of the options. */
      if (c == -1) {
        break;
      }
      if (c == '?') {
        res = -1;
        break;
      }

      std::string optname = _S(long_options[option_index].name);

      //std::cout << "Recognized option: " << optname << std::endl;

//       if (_S("help").compare(optname) == 0) {
//         res = -1;
//         break;
//       }
//       else
      if (is_option_bool(optname)) {
        if (NULL != optarg) {
          update_option(optname, (!_S(optarg).compare("true") ||
                                  !_S(optarg).compare("1")));
        }
        else {
          update_option(optname, true);
        }
      }
      else if (is_option_string(optname)) {
        if (NULL == optarg) {
          res = -1;
          break;
        }

        std::string arg = _S(optarg);
        update_option(optname, arg);
      }
      else if(is_option_int(optname)) {
        if (NULL == optarg) {
          res = -1;
          break;
        }

        char * endptr;
        long val = (long) strtol(optarg, &endptr, 10);

        if ((endptr == optarg) ||
            ((errno == ERANGE) && (val == LONG_MAX || val == LONG_MIN))) {
          std::cerr << "Wrong argument for option --" << optname << std::endl
                    << "Expected integer: got \"" << optarg << "\"" << std::endl;
          res = -1;
          break;
        }
        update_option(optname, (int)val);
      }
      else if(is_option_unsigned(optname)) {
        if (NULL == optarg) {
          res = -1;
          break;
        }

        char * endptr;
        long val = (long) strtol(optarg, &endptr, 10);

        if ((endptr == optarg) ||
            ((errno == ERANGE) && (val == LONG_MAX || val == LONG_MIN)) ||
            (errno != 0 && val < 0)) {
          std::cerr << "Wrong argument for option --" << optname << std::endl
                    << "Expected integer greater or equal to zero: got \""
                    << optarg << "\"" << std::endl;
          res = -1;
          break;
        }
        update_option(optname, (unsigned)val);
      }
      else if(is_option_float(optname)) {
        if (NULL == optarg) {
          res = -1;
          break;
        }

        char * endptr;
        float val = strtof(optarg, &endptr);

        if ((endptr == optarg) ||(errno == ERANGE)) {
          std::cerr << "Wrong argument for option --" << optname << std::endl
                    << "Expected real number: got \""
                    << optarg << "\"" << std::endl;
          res = -1;
          break;
        }
        update_option(optname, val);
      }
      else if(is_option_enum(optname)) {
        if (NULL == optarg) {
          res = -1;
          break;
        }

        bool found = false;
        std::string arg = to_lower_case(_S(optarg));

        for (std::map<const std::string, int>::iterator i =
               enums[optname].begin();
             i != enums[optname].end();
             i++) {
          if (0 == (*i).first.compare(arg)) {
            update_option(optname, (*i).second);
            found = true;
            break;
          }
        }

        if (!found) {
          std::cerr << "Wrong argument for option --" << optname << std::endl
                    << "Expected valid enumerand: got \""
                    << optarg << "\"" << std::endl;
          res = -1;
          break;
        }
      }
      else {
        assert(false);
      }
    }

    delete[] long_options;

    if (res == 0) {
      return optind;
    }
    else {
      return res;
    }
  }

  void Options::release_options() {

    if(instance != NULL) {
      delete instance;
    }
  }

  Options::~Options() {
    for (std::map<const std::string, void*>::iterator i =
           options_map.begin();
         i != options_map.end();
         i++) {
      delete (*i).second;
    }
  }
}
