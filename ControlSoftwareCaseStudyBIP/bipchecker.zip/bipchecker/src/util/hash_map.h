

#ifndef UTIL_HASH_MAP_H
#define UTIL_HASH_MAP_H

#include "config.h"

#include <cstring>
#include <string>

// Define hash_map and hash_set macro according to available libraries and
// preferences
#if defined HAVE_EXT_HASH_MAP && !(defined PREFER_TR1_MAP && defined HAVE_TR1_MAP)

  #include <ext/hash_map>
  #include <ext/hash_set>

  namespace __gnu_cxx {

    //! Generic hash function for pointers.
    template<class T> struct hash<T *>
      {
        size_t operator()(const T *p) const
        {
          return reinterpret_cast<size_t>(p);
        }
      };

    //! Hash function for string.
    template<> struct hash<std::string>
      {
        size_t operator() (const std::string& s) const
        {
          return hash<const char*> () (s.c_str());
        }
      };

  } // namespace __gnu_cxx

  //Define easier names
  #define hash_map __gnu_cxx::hash_map
  #define hash_set __gnu_cxx::hash_set
  #define hash_fun __gnu_cxx::hash
  #define hash_fun_namespace_open namespace __gnu_cxx
  #define hash_fun_namespace_close

#else

  #ifdef HAVE_TR1_MAP

    #include <tr1/unordered_map>
    #include <tr1/unordered_set>

    namespace swchecker {

      inline size_t hash_c_string(const char *s)
      {
        size_t ret = 0;
        for (; *s; ++s) {
          ret = 5 * ret + *s;
        }
        return ret;
      }

    } // namespace swchecker


    namespace std {

      namespace tr1 {

        // add missing hash functions for C strings
        template<> struct hash<const char *> {
          size_t operator()(const char *s) const
          {
            return swchecker::hash_c_string(s);
          }
        };

        template<> struct hash<char *> {
          size_t operator()(const char *s) const
          {
            return swchecker::hash_c_string(s);
          }
        };

      }
    } // namespace std::tr1

    //Define easier names
    #define hash_map std::tr1::unordered_map
    #define hash_set std::tr1::unordered_set
    #define hash_fun std::tr1::hash
    #define hash_fun_namespace_open namespace std { namespace tr1
    #define hash_fun_namespace_close }

  #else
    #error "Unable to find a suitable hash map implementation"
  #endif
#endif


namespace bipchecker{

//! Class for string equality.
struct EqStr
{
  bool operator() (const std::string& s1, const std::string& s2) const
  {
    return s1 == s2;
  }
};

//! Class for pointer-to-char equality.
struct EqCharPtr
{
  bool operator() (const char *s1, const char *s2) const
  {
    return (std::strcmp(s1,s2) == 0);
  }
};

}


#endif // UTIL_HASH_MAP_H
