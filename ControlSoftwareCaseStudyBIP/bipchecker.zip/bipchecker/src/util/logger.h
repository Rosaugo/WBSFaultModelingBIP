

#ifndef SWCHECKER_UTIL_LOGGER_H
#define SWCHECKER_UTIL_LOGGER_H

#include <iostream>

#include "util/util.h"

namespace bipchecker
{

//! Class for logging messages (lazily).
/*!
 * Expected usage:
 *   Logger::log << Logger::level(7) 
 *               << "This is a level-7 message."
 *               << Logger::end;
 */
class Logger
{

    //! Marker to start message and and set message level.
    struct LogLevel
    {
	int level_;
	
	explicit LogLevel(int level) 
	    : level_(level) 
	{
	}

    }; // struct LogLevel

    
    //! Marker to end messages (print a new line and reset output level).
    struct EndLog{
    	explicit EndLog() {}
    }; // struct EndLog


public:


    //! Instance of a logger.
    static Logger log;

    //! Instance of end-log marker.
    static EndLog end;

private:

    //! The output level.
    int output_level_;

    //! The output level set by the current message.
    int curr_output_level_;

    //! Output stream.
    std::ostream *out_;

    //! Default ouput level.
    static const int DEFAULT_OUTPUT_LEVEL = 2;

public:

    //! Class constructor.
    /*!
     * \param out an output stream.
     */
    explicit Logger(std::ostream& out = std::cout)
	: output_level_(DEFAULT_OUTPUT_LEVEL),
	  curr_output_level_(-1),
	  out_(&out)
    {
    }

    
    //! Creates log level.
    /*!
     * \param level a log level.
     * \return The created log level.
     */
    static LogLevel level(int level);


    //! Gets the output level.
    /*!
     * \return The output level.
     */
    int output_level() const { return output_level_; }

    //! Sets the output level.
    /**
     * \param output_level a new output level.
     */
    void set_output_level(int output_level) 
    {
	output_level_ = output_level;
    }

    //! Gets the output stream.
    /*!
     * \return The output stream.
     */
    std::ostream& out() { return *out_; }

    //! Sets the output stream.
    /*!
     * \param out a new output stream.
     */
    void set_out(std::ostream& out) 
    {
	out_ = &out;
    }

    //! Template for operator << for various types of object.
    /*!
     * \param msg an object contaning the message.
     */
    template<class T> Logger &operator<<(const T &msg);


    //! Operator << for setting the current output level.
    /*!
     * \param level an output level for the current output level.
     * \return This logger.
     */
    Logger& operator<<(LogLevel level);

    //! Operator << for ending the message.
    /**
     * \param end a marker for ending the message.
     * \return This logger.
     */
    Logger& operator<<(const EndLog& end);


    //! Flush output stream.
    /*!
     * \return This logger.
     */
    Logger& flush(); 
    

    //! Class virtual destructor.
    virtual ~Logger()
    {
    }


private:

    DISALLOW_COPY_AND_ASSIGN(Logger);

}; // class Logger


template<class T>
Logger &Logger::operator<<(const T& msg)
{
    if (output_level_ >= curr_output_level_) {
        (*out_) << msg;
    }
    return *this;
}

}

#endif
