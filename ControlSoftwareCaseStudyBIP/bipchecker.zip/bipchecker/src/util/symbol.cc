/*
 * symbol.cc
 *
 *  Created on: Dec 15, 2016
 *      Author: wangqiang
 */


#include "util/symbol.h"
#include <assert.h>

namespace bipchecker {

std::string Symbol::symbol_name("__SYM__");
size_t Symbol::fresh_id = 0;
Symbol::SymbolMap Symbol::symbol_map;

Symbol::SymbolMap::~SymbolMap() {
	for (symbols_t::iterator it = symbols_.begin(); it != symbols_.end();
			++it) {

		if ((*it).second)
			delete (*it).second;
	}
	symbols_.clear();
}

const Symbol& Symbol::symbol(const std::string& symbol) {

	// Get the internal (actual) map.
	symbols_t& map = symbol_map.symbols();

	// Find symbol on the map based on its hash code.
	symbols_t::const_iterator cit = map.find(symbol);

	if (cit != map.end() && (*cit).second) { // Symbol is found.

		if (((*cit).second)->to_string() != symbol)
			assert(false && "Symbols clash.");

		return *((*cit).second);

	} else {

		// Create a new symbol.
		Symbol *new_symbol = new Symbol(symbol);

		// Insert the new symbol to the map based on its hash code.
		map[symbol] = new_symbol;

		return *new_symbol;
	}

}

std::ostream& operator<<(std::ostream& out, const Symbol& s) {
	out << s.to_string();
	return out;
}

}
