

#include "util/util.h"

#include <cstdlib>
#include <sys/time.h>
#include <sys/resource.h>


namespace bipchecker
{

double get_cpu_time()
{
    double res;
    struct rusage usage;

    getrusage(RUSAGE_SELF, &usage);

    res = usage.ru_utime.tv_usec + usage.ru_stime.tv_usec;
    res *= 1e-6;
    res += usage.ru_utime.tv_sec + usage.ru_stime.tv_sec; 
	
    return res;
}


std::string get_local_time()
{
    time_t rawtime;
    
    time(&rawtime);

    return std::string(ctime(&rawtime));
}



long get_max_mem()
{
    struct rusage usage;

    getrusage(RUSAGE_SELF, &usage);

    return usage.ru_maxrss / 1024;
}



std::string get_environment_variable(const std::string& k)
{
    char *cv = 0;
    std::string v = "";

    cv = getenv(k.c_str());

    if (cv != 0) 
	v = cv;                                                                    

    return v;  

}


int set_environment_variable(const std::string& k, 
			     const std::string& v)
{
    int success = -1;

    if (v.empty()) { // Unset variable.

	std::string old_v = get_environment_variable(k);
	
	if (!old_v.empty())
	    success = unsetenv(k.c_str());
	else
	    success = 0;

    } else { // Set variable.

	success = setenv(k.c_str(),v.c_str(),1);
    }

    return success;
}


size_t UId::id = 0;

size_t UId::fresh_id() {
    return (id++);
}


}
