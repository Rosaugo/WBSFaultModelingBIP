/*
 * cfa.h
 *
 *  Created on: Nov 11, 2014
 *      Author: wangqiang
 */

#ifndef CFA_H_
#define CFA_H_

#include "util/hash_map.h"
#include "util/util.h"

#include "bip_cfa/cfa_node.h"
#include "bip_cfa/cfa_edge.h"

namespace bipchecker {

class CFAEdge;

class CFA {

	//! CFA name.
	std::string name_;

	//! Entry node.
	CFANode *entry_;

	//! we do not have Exit node !!
	// CFANode *exit_;

	typedef hash_set<CFANode*,
	hash_fun<CFANode*>,
	EqCFANode> nodes_t;

	//! Set of CFA nodes.
	nodes_t nodes_;

	//! flag to indicate if it contains error locations
	bool error_location;

public:

	explicit CFA(const std::string& name)
	: name_(name), error_location(false) {
		entry_ = &create_node();
	}

	//! Gets the name of CFA.
	/*!
	 * \return The name of CFA.
	 */
	virtual const std::string& name() const {return name_;}

	//! Sets the name of CFA.
	/*!
	 * \param name a name.
	 */
	virtual void set_name(const std::string& name)
	{
		name_ = name;
	}

	bool has_error_location() const {return error_location;}

	void set_error_location(bool error){
		error_location = error;
	}

	//! Creates node.
	/*!
	 * \return The new node.
	 */
	virtual CFANode& create_node();

	//! Removes node.
	/*!
	 * A node of a CFA can be removed if the node is owned by
	 * the CFA and it is not the entry of the CFA.
	 *
	 * This function destroy the argument node passed to it.
	 *
	 *
	 * \param node a CFA node to remove.
	 */
	virtual void remove_node(CFANode *node);

	//! Gets the entry of CFA.
	/*!
	 * \return The entry of CFA.
	 */
	const CFANode& entry() const {return *entry_;}

	//! Gets the entry of CFA.
	/*!
	 * \return The entry of CFA.
	 */
	CFANode& entry() {return *entry_;}

	//! Sets the entry node.
	/*!
	 * A node can be set as the entry of a CFA
	 * if the node is owned by the CFA.
	 *
	 * \param node a CFA node.
	 */
	virtual void set_entry(CFANode& node);

	//! Gets the exit of CFA.
	/*!
	 * A CFA can have no exit node, so the return node
	 * can be null.
	 *
	 * \return The exit of CFA.
	 */
	//const CFANode* exit() const {return exit_;}

	//! Gets the exit of CFA.
	/*!
	 * A CFA can have no exit node, so the return node
	 * can be null.
	 *
	 * \return The exit of CFA.
	 */
	//CFANode* exit() {return exit_;}

	//! Sets the exit of CFA.
	/*!
	 * A node can be set as the exit of a CFA
	 * if the node is owned by the CFA.
	 *
	 * To make the exit of CFA absent, pass null
	 * as the argument of this function.
	 *
	 * \param node a CFA node.
	 */
	//virtual void set_exit(CFANode *node);

	typedef nodes_t::iterator iterator;

	typedef nodes_t::const_iterator const_iterator;

	//! Gets the start iterator of the set of nodes.
	/*!
	 * \return The start iterator of the set of nodes.
	 */
	const_iterator begin() const {return nodes_.begin();}

	//! Gets the end iterator of the set of nodes.
	/*!
	 * \return The end iterator of the set of nodes.
	 */
	const_iterator end() const {return nodes_.end();}

	//! Gets the start iterator of the set of nodes.
	/*!
	 * \return The start iterator of the set of nodes.
	 */
	const_iterator begin() {return nodes_.begin();}

	//! Gets the end iterator of the set of nodes.
	/*!
	 * \return The end iterator of the set of nodes.
	 */
	const_iterator end() {return nodes_.end();}

	//! Gets the size of the CFA.
	/*!
	 * The size of CFA is the number of nodes it owns.
	 *
	 * \return The size of the CFA.
	 */
	size_t size() const {return nodes_.size();}

	//! Adds assume edge.
	/*!
	 * To add an edge, the source and target nodes must be owned
	 * by the CFA.
	 *
	 * \param from a CFA node.
	 * \param expression an AST expression.
	 * \param to a CFA node.
	 */
	//virtual void add_assume_edge(CFANode& from,
	//		ASTExpression *expression,
	//		CFANode& to);

	//! Adds assign edge.
	/*!
	 * To add an edge, the source and target nodes must be owned
	 * by the CFA.
	 *
	 * \param from a CFA node.
	 * \param left_expression an AST expression.
	 * \param right_expression an AST expression.
	 * \param to a CFA node.
	 */
	//virtual void add_assign_edge(CFANode& from,
	//		ASTExpression *left_expression,
	//		ASTExpression *right_expression,
	//		CFANode& to);

	//! Adds blank (or goto) edge.
	/*!
	 * To add an edge, the source and target nodes must be owned
	 * by the CFA.
	 *
	 * \param from a CFA node.
	 * \param to a CFA node.
	 */
	//virtual void add_blank_edge(CFANode& from, CFANode& to);

	virtual void add_edge(CFANode& from,ASTIdExpression* label,
			ASTExpression* guard, ASTStatement* action,
			CFANode& to, bool internal);

	//! Removes edge.
	/*!
	 * Edge can be removed if the source and target nodes are
	 * owned by the CFA.
	 *
	 * Removing an edge is also destroying it.
	 *
	 * \param edge a CFA edge.
	 */
	virtual void remove_edge(CFAEdge *edge);

	//! Sets a new source node for an edge.
	/*!
	 * Given an edge e and a node n as arguments,
	 * this function sets the source of e to n.
	 *
	 * \param edge a CFA edge.
	 * \paran new_from a CFA node.
	 */
	virtual void move_edge_from(CFAEdge& edge, CFANode& new_from);

	//! Sets a new target node for an edge.
	/*!
	 * Given an edge e and a node n as arguments,
	 * this function sets the target of e to n.
	 *
	 * \param edge a CFA edge.
	 * \paran new_to a CFA node.
	 */
	virtual void move_edge_to(CFAEdge& edge, CFANode& new_to);

	//! Removes unreachable nodes from the set of nodes.
	/*!
	 * A node is said to be unreachable iff it is unreachable
	 * from the entry node.
	 */
	virtual void remove_unreachable_nodes();

	//! Inserts a node into the set of nodes.
	/*!
	 * A node can be added into the set of nodes of a CFA
	 * if the owner of the node is the CFA. The CFA is then
	 * claims the ownership of the node.
	 *
	 * \param node a CFA node.
	 */
	void insert_node(CFANode *node)
	{
		if ( node && this == &(node->cfa()) )
		nodes_.insert(node);
	}

	//! Checks if a node is owned by the CFA.
	/*!
	 * \param node a CFA node.
	 * \return True iff the node is owned by the CFA.
	 */
	bool check_node(const CFANode& node) const
	{
		return ( this != &(node.cfa()) ) ? false : true;
	}

	//! Class destructor.
	virtual ~CFA();

private:
	DISALLOW_COPY_AND_ASSIGN(CFA);

	//! Removes node.
	/*!
	 * This function is an auxiliary function for
	 * removing a node.
	 *
	 * \param node a CFA node.
	 */
	void remove_node_aux(CFANode *node);

};

}

#endif /* CFA_H_ */
