/*
 * dot_builder.h
 *
 *  Created on: Nov 12, 2014
 *      Author: wangqiang
 */

#ifndef DOT_BUILDER_H_
#define DOT_BUILDER_H_


#include <iostream>
#include <string>

#include "bip_frontend/bip_ast/ast_printer.h"
#include "util/util.h"

namespace bipchecker{

class CFA;
class CFANode;
class CFAEdge;

class DotBuilder{

    std::ostream& out_;
    ASTPrinter ast_printer_;

public:
    explicit DotBuilder(std::ostream& out = std::cout)
	: out_(out), ast_printer_(out) {}

    void build_dot_cfa(const CFA&);

    virtual ~DotBuilder() {}

protected:

    DISALLOW_COPY_AND_ASSIGN(DotBuilder);

    virtual void draw_cfa_node(const CFANode&);
    virtual void draw_cfa_edge(const CFAEdge&);

    std::string node_label(size_t);

};

}



#endif /* DOT_BUILDER_H_ */
