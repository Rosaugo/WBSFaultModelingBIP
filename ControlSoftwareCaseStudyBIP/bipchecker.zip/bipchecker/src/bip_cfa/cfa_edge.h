/*
 * cfa_edge.h
 *
 *  Created on: Nov 11, 2014
 *      Author: wangqiang
 */

#ifndef CFA_EDGE_H_
#define CFA_EDGE_H_

#include "bip_frontend/bip_ast/bip_ast.h"
#include "util/hash_map.h"
#include "util/util.h"

namespace bipchecker {

class CFANode;

class CFAEdge {

	//! Fresh id for edges.
	static size_t fresh_id;

	//! Edge id.
	size_t edge_id_;

	//! Edge source.
	CFANode *from_;

	//! Edge target.
	CFANode *to_;

	//! port label, if this pointer is null, then
	//! this edge is initial transition.
	//! how about the internal transition?
	ASTIdExpression* label_;

	//! guard and statement are owned by the edge,
	//! so they should be deleted when edge is deleted
	ASTExpression* guard_;

	//! Edge statement
	ASTStatement* action_;

	// We keep pointers to nodes instead of references because
	// during the construction of CFA, we allow edges to be set
	// with different sources or targets.

	//! Optional annotation.
	std::string annotation_;

	bool internal_;

public:
	//! Class constructor.
	/*!
	 * The source and target of the edge are passed as refrences
	 * for the following reasons:
	 * - They must exist (or cannot be null).
	 * - The edge does not own the source and target.
	 *
	 * \param from a CFA node for edge source.
	 * \param to a CFA node for edge target.
	 */
	explicit CFAEdge(CFANode& from, CFANode& to) :
		edge_id_(fresh_id++), from_(&from), to_(&to),
		label_(0), guard_(0), action_(0), annotation_(""), internal_(false) {}

	//! Gets the edge id.
	/*!
	 * \return The edge id.
	 */
	size_t edge_id() const {
		return edge_id_;
	}

	//! Gets the source of the edge.
	/*!
	 * \return The source of the edge.
	 */
	const CFANode& from() const {
		return *from_;
	}

	//! Gets the source of the edge.
	/*!
	 * \return The source of the edge.
	 */
	CFANode& from() {
		return *from_;
	}

	//! Gets the target of the edge.
	/*!
	 * \return The target of the edge.
	 */
	const CFANode& to() const {
		return *to_;
	}

	//! Gets the target of the edge.
	/*!
	 * \return The target of the edge.
	 */
	CFANode& to() {
		return *to_;
	}

	const ASTStatement* action() const {
		return action_;
	}

	ASTStatement* action(){
		return action_;
	}

	void set_action(ASTStatement* action){
		if(action_)
			delete action_;
		action_= action;
	}

	const ASTExpression* guard() const{
		return guard_;
	}

	ASTExpression* guard(){
		return guard_;
	}

	void set_guard(ASTExpression* guard){
		if(guard_)
			delete guard_;
		guard_ = guard;
	}

	ASTIdExpression* label() {
		return label_;
	}

	const ASTIdExpression* label() const{
		return label_;
	}

	void set_label(ASTIdExpression* l){
		if(label_)
			delete label_;
		label_ = l;
	}

	void set_internal(bool internal_edge){
		internal_ = internal_edge;
	}

	bool is_internal() const{
		return internal_;
	}

	//! Sets the source of the edge.
	/*!
	 * \param node a CFA node.
	 */
	void set_from(CFANode& node);

	//! Sets the target of the edge.
	/*!
	 * \param node a CFA node.
	 */
	void set_to(CFANode& node);

	//! Gets annotation.
	/*!
	 * \return The annotation.
	 */
	const std::string& annotation() const {
		return annotation_;
	}

	//! Sets annotation.
	/*!
	 * \param annotation an annotation.
	 */
	void set_annotation(const std::string& annotation) {
		annotation_ = annotation;
	}

	//! Class destructor.
	virtual ~CFAEdge();

private:

	DISALLOW_COPY_AND_ASSIGN(CFAEdge);
};

//! Struct for CFA edge id equality.
struct EqCFAEdge {
	//! Checks if CFA edges have the same id.
	/*!
	 * \param e1 a CFA edge.
	 * \param e2 a CFA edge.
	 * \return True iff e1's id equals e2's id.
	 */
	bool operator()(const CFAEdge *e1, const CFAEdge *e2) const {
		if (e1 && !e2)
			return false;
		if (!e1 && e2)
			return false;
		if ((!e1 && !e2) || (e1 && e2 && e1->edge_id() == e2->edge_id()))
			return true;

		return false;
	}

};
// struct EqCFAEdge

//! Struct for CFA edge less-than inequality.
struct LtCFAEdge {

	//! Checks if a CFA edge id is less than another CFA edge id.
	/*!
	 * \param e1 a CFA edge.
	 * \param e2 a CFA edge.
	 * \return True iff e1's id is less than e2's id.
	 */
	bool operator()(const CFAEdge *e1, const CFAEdge *e2) const {
		return (e1->edge_id() < e2->edge_id());
	}

};
// struct LtCFAEdge

}

hash_fun_namespace_open {

//! Struct for CFA edge hash function.
	template<> struct hash<const bipchecker::CFAEdge*>
	{

		//! Gets hash code of a CFA edge.
		/*!
		 * \param e a CFA edge.
		 * \return The hash code (edge id) of e.
		 */
		size_t operator() (const bipchecker::CFAEdge *e) const
		{
			return e->edge_id();
		}

	}; // struct hash<const swchecker::CFAEdge*>

}
hash_fun_namespace_close;

#endif /* CFA_EDGE_H_ */
