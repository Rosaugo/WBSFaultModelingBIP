/*
 * cfa_node.cc
 *
 *  Created on: Nov 11, 2014
 *      Author: wangqiang
 */

#include "bip_cfa/cfa_node.h"
#include "bip_cfa/cfa_edge.h"

namespace bipchecker {

size_t CFANode::fresh_id = 0;

bool CFANode::EdgeLt::operator()(const CFAEdge* e1, const CFAEdge* e2) const {
	return (e1->edge_id() < e2->edge_id());
}

CFANode& CFANode::add_in_edge(CFAEdge& edge) {
	if (this == &(edge.to())) {

		in_edges_.insert(&edge);
	}

	return *this;
}

CFANode& CFANode::add_out_edge(CFAEdge& edge) {
	if (this == &(edge.from())) {

		out_edges_.insert(&edge);

	}

	return *this;
}

void CFANode::remove_in_edge(CFAEdge& edge) {
	if (this == &(edge.to())) {

		in_edges_.erase(&edge);

	}

}

void CFANode::remove_out_edge(CFAEdge& edge) {
	if (this == &(edge.from())) {

		out_edges_.erase(&edge);

	}
}

}
