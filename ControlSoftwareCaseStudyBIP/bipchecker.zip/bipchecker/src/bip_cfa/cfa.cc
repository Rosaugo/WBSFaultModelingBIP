/*
 * cfa.cc
 *
 *  Created on: Nov 11, 2014
 *      Author: wangqiang
 */

#include "bip_cfa/cfa.h"

namespace bipchecker {

CFANode& CFA::create_node() {

	CFANode* node = new CFANode(*this);

	nodes_.insert(node);

	return *node;
}

void CFA::remove_node_aux(CFANode* node) {
	//! if the node exits and owned by the caller
	if (node && check_node(*node)) {

		//! collect all edges to be deleted
		std::set<CFAEdge*> edges_to_delete;

		for (CFANode::const_iterator cit = node->in_begin();
				cit != node->in_end(); ++cit) {
			if (*cit) {
				edges_to_delete.insert(*cit);
			}
		}

		for (CFANode::const_iterator cit = node->out_begin();
				cit != node->out_end(); ++cit) {
			if (*cit)
				edges_to_delete.insert(*cit);
		}

		// Now, delete all edges.
		for (std::set<CFAEdge*>::iterator it = edges_to_delete.begin();
				it != edges_to_delete.end(); ++it) {

			if (*it)
				delete *it;

		}

		nodes_.erase(node);

		//! then delete the node (simply clear the container of in and out edges)
		delete node;

	}
}

//! remove the node passed as parameter,
//! it will delete the node, as well as the set of in and out-coming edges
void CFA::remove_node(CFANode* node) {
	if (node != entry_) {
		remove_node_aux(node);
	}
}

void CFA::set_entry(CFANode& node) {
	if (check_node(node)) {
		entry_ = &node;
	}
}

/*
 void CFA::add_assign_edge(CFANode& from, ASTExpression* left,
 ASTExpression* right, CFANode& to) {

 if (check_node(from) && check_node(to)) {

 CFAEdge* edge = new CFAAssignEdge(from, left, right, to);
 from.add_out_edge(*edge);
 to.add_in_edge(*edge);
 }
 }

 void CFA::add_assume_edge(CFANode& from, ASTExpression* expression,
 CFANode& to) {

 if (check_node(from) && check_node(to)) {

 CFAAssumeEdge* assume = new CFAAssumeEdge(from, expression, to);
 from.add_out_edge(*assume);
 to.add_in_edge(*assume);
 }
 }

 void CFA::add_blank_edge(CFANode& from, CFANode& to) {

 if (check_node(from) && check_node(to)) {
 CFABlankEdge* blank = new CFABlankEdge(from, to);
 from.add_out_edge(*blank);
 to.add_in_edge(*blank);
 }
 }
 */

void CFA::add_edge(CFANode& from,ASTIdExpression* label,
		ASTExpression* guard, ASTStatement* action,
		CFANode& to, bool internal) {
	if(check_node(from) && check_node(to)){
		CFAEdge* edge = new CFAEdge(from, to);

		if(label != 0)
			edge->set_label(label);

		if(guard != 0)
			edge->set_guard(guard);

		if(action != 0)
			edge->set_action(action);

		from.add_out_edge(*edge);
		to.add_in_edge(*edge);
		edge->set_internal(internal);
	}
}

//! remove the edge if it exits and owned by the caller
void CFA::remove_edge(CFAEdge* edge) {

	if (edge) {
		CFANode& from = edge->from();
		CFANode& to = edge->to();

		if (check_node(from) && check_node(to)) {
			//! deleting the edge simply remove itself from
			//! the out-edges of from , and in-edges of to
			delete edge;
		}
	}

}

//! set the new from-location of the edge
void CFA::move_edge_from(CFAEdge& edge, CFANode& new_from) {
	CFANode& from = edge.from();

	if (check_node(from) && check_node(new_from)) {
		edge.set_from(new_from);
	}

}

void CFA::move_edge_to(CFAEdge& edge, CFANode& new_to) {
	CFANode& to = edge.to();

	if (check_node(to) && check_node(new_to)) {
		edge.set_to(new_to);
	}
}

void CFA::remove_unreachable_nodes() {
	std::vector<CFANode*> worklist;
	nodes_t reachable_nodes;

	//! collect all reachable nodes
	worklist.push_back(entry_);
	while (!worklist.empty()) {
		CFANode* temp_node = worklist.back();
		worklist.pop_back();

		reachable_nodes.insert(temp_node);

		for (CFANode::const_iterator cit = temp_node->out_begin();
				cit != temp_node->out_end(); ++cit) {
			if (*cit) {
				CFANode& to = (*cit)->to();
				if (reachable_nodes.find(&to) == reachable_nodes.end()) {
					worklist.push_back(&to);
				}
			}
		}
	}			//! end while

	// Delete all unreachable nodes.
	std::vector<CFANode*> unreachable_nodes;

	for (iterator it = nodes_.begin(); it != nodes_.end(); ++it) {
		if (*it && reachable_nodes.find(*it) == reachable_nodes.end()) {
			unreachable_nodes.push_back(*it);
		}
	}

	// for (iterator it = unreachable_nodes.begin();
	for (std::vector<CFANode*>::iterator it = unreachable_nodes.begin();
			it != unreachable_nodes.end(); ++it)
		remove_node(*it);

	unreachable_nodes.clear();

	// Swap content
	nodes_.clear();

	for (nodes_t::iterator it = reachable_nodes.begin();
			it != reachable_nodes.end(); ++it) {
		if (*it)
			nodes_.insert(*it);
	}
	reachable_nodes.clear();
}

CFA::~CFA() {
	// Remove non-entry nodes.
	// nodes_t removed_nodes;
	std::vector<CFANode*> removed_nodes;

	for (iterator it = nodes_.begin(); it != nodes_.end(); ++it) {
		if (*it)
			removed_nodes.push_back(*it);
	}

	//for (iterator it = removed_nodes.begin();
	for (std::vector<CFANode*>::iterator it = removed_nodes.begin();
			it != removed_nodes.end(); ++it)
		remove_node_aux(*it);

	removed_nodes.clear();
	nodes_.clear();
}

}
