/*
 * cfa_builder.h
 *
 *  Created on: Nov 11, 2014
 *      Author: wangqiang
 */

#ifndef CFA_BUILDER_H_
#define CFA_BUILDER_H_

#include "bip_frontend/bip_ast/ast_visitor.h"
#include "bip_cfa/cfa.h"
#include "bip_frontend/bip_type_system/scope.h"

namespace bipchecker {

class CFABuilder: public ASTVisitor {

	// Resulting CFAs.
	std::vector<CFA*> cfas_;

	// Symbol table.
	const Scope *scope_;

public:

	explicit CFABuilder(const Scope& scope)
	: ASTVisitor(true), scope_(&scope) {
		current_cfa_ = 0;
		components_ = 0;
		targets_ = 0;
	}

	std::vector<CFA*> cfas();

	// visit functions
	int visit(const ASTExpression*) { return ASTVisitor::SKIP; }
	int visit(const ASTName*) { return ASTVisitor::SKIP; }
	int visit(const ASTStatement*)  { return ASTVisitor::SKIP; }
	int visit(const ASTTransition*)  { return ASTVisitor::SKIP; }
	int visit(const ASTDeclaration*)  { return ASTVisitor::SKIP; }
	int visit(const ASTDefinition*);
	int visit(const ASTTranslationUnit*);

	// leave functions
	int leave(const ASTExpression*) { return ASTVisitor::CONTINUE; }
	int leave(const ASTName*) { return ASTVisitor::CONTINUE; }
	int leave(const ASTStatement*) { return ASTVisitor::CONTINUE; }
	int leave(const ASTTransition*) { return ASTVisitor::CONTINUE; }
	int leave(const ASTDeclaration*) { return ASTVisitor::CONTINUE; }
	int leave(const ASTDefinition*) { return ASTVisitor::CONTINUE; }
	int leave(const ASTTranslationUnit*) { return ASTVisitor::CONTINUE; }

	~CFABuilder() {
		for (std::vector<CFA*>::iterator it = cfas_.begin(); it < cfas_.end();
				++it) {
			if (*it)
				delete *it;
		}

		cfas_.clear();
	}

private:

	//! variable holding the temporal result
	CFA* current_cfa_;

	const ASTExpression* targets_;

	//! pointers holding the component declarations
	const ASTDeclaration* components_;

	CFA* create_cfa(const std::string&) const;

	void visit_atom(const ASTAtomDeclaration* atom, const ASTAtomDefinition* atom_def);

	void visit_initial_transition(const ASTInitialTransition* init, ASTStatement* initialization);

	void visit_transition(const ASTSingleTransition* trans);

	void set_line_no(CFANode& cfa_node, const ASTNode& ast_node) const;

	void set_line_no(CFANode& cfa_node, unsigned int line_no) const;

};

}

#endif /* CFA_BUILDER_H_ */
