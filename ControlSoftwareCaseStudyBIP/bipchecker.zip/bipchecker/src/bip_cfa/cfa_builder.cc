/*
 * cfa_builder.cc
 *
 *  Created on: Nov 11, 2014
 *      Author: wangqiang
 */

#include "bip_cfa/cfa_builder.h"
#include <assert.h>

namespace bipchecker {

std::vector<CFA*> CFABuilder::cfas() {

	std::vector<CFA*> temp_cfas = cfas_;

	cfas_.clear();

	return temp_cfas;
}

CFA* CFABuilder::create_cfa(const std::string& name) const {
	CFA *cfa = new CFA(name);

	return cfa;
}

int CFABuilder::visit(const ASTDefinition* definition) {

	// std::cout << "visit definition" << std::endl;

	const ASTPortDefinition* port_def =
			dynamic_cast<const ASTPortDefinition*>(definition);
	const ASTConnectorDefinition* cnt_def =
			dynamic_cast<const ASTConnectorDefinition*>(definition);
	const ASTAtomDefinition* atom_def =
			dynamic_cast<const ASTAtomDefinition*>(definition);
	const ASTCompoundDefinition* comp_def =
			dynamic_cast<const ASTCompoundDefinition*>(definition);

	if (port_def != 0) {

		return ASTVisitor::SKIP;

	} else if (cnt_def != 0) {

		//! TODO : extract the interaction for the kernel, as well as the CFA of the action

		return ASTVisitor::SKIP;

	} else if (atom_def != 0) {

		//! first find the list of atom declarations corresponding to this atom type
		assert(components_ != 0);

		//! components_ should be a ASTAtomDeclaration or a list of ASTAtomDeclaration
		//! this is checked by a type checked
		const ASTAtomDeclaration* atom =
				dynamic_cast<const ASTAtomDeclaration*>(components_);
		const ASTDeclarationList* atom_list =
				dynamic_cast<const ASTDeclarationList*>(components_);

		if (atom != 0) {

			visit_atom(atom, atom_def);

		} else if (atom_list != 0) {

			std::string atom_def_name = atom_def->name()->name()->name();

			std::vector<const ASTAtomDeclaration*> temp_atom_list;
			for (ASTDeclarationList::const_iterator cit = atom_list->begin();
					cit != atom_list->end(); ++cit) {
				if (*cit) {
					//! typechecker will ensure this pointer is valid
					const ASTAtomDeclaration* temp_atom =
							dynamic_cast<const ASTAtomDeclaration*>(*cit);

					//! get the list of declarations corresponding to this atom type
					std::string temp_atom_name = temp_atom->type()->name()->name();
					if(temp_atom_name == atom_def_name){
						temp_atom_list.push_back(temp_atom);
					}

				}
			}

			assert(temp_atom_list.size() != 0);

			for(std::vector<const ASTAtomDeclaration*>::iterator it = temp_atom_list.begin();
					it != temp_atom_list.end(); ++it){
				if(*it){
					visit_atom(*it, atom_def);
				}
			}

		} else {
			//! no atom definition found
			assert(false);
		}

		return ASTVisitor::SKIP;

	} else if (comp_def != 0) {

		return ASTVisitor::SKIP;

	} else {
		return ASTVisitor::ABORT;
	}

	return ASTVisitor::SKIP;
}

int CFABuilder::visit(const ASTTranslationUnit* unit) {

	//std::cout << "visit translation unit" << std::endl;

	targets_ = unit->target_state();

	for(ASTTranslationUnit::const_iterator cit = unit->begin(); cit != unit->end(); ++cit){
		if(*cit){
			const ASTCompoundDefinition* comp_def =
					dynamic_cast<const ASTCompoundDefinition*>(*cit);

			if(comp_def != 0){
				//! get the component declarations
				components_ = comp_def->components();
			}

		}
	}

	return ASTVisitor::CONTINUE;
}

void CFABuilder::visit_atom(const ASTAtomDeclaration* atom,
		const ASTAtomDefinition* atom_def) {

	std::string atom_def_name = atom_def->name()->name()->name();

	//! get the type name first, which is the name of atom definition and its CFA
	std::string atom_type_name = atom->type()->name()->name();
	assert(atom_type_name == atom_def_name);

	std::string atom_instance_name = atom->name()->name()->name();
	ASTExpression* actual_para = atom->parameters();

	ASTStatement* res_statement = 0;

	if(actual_para != 0){
		//! since there is only one atom, and one atom type, they must match each other
		const ASTDeclaration* formal_para = atom_def->parameters();

		const ASTDataDeclaration* formal_data =
				dynamic_cast<const ASTDataDeclaration*>(formal_para);
		const ASTDeclarationList* formal_list =
				dynamic_cast<const ASTDeclarationList*>(formal_para);

		const ASTLiteralExpression* actual_data =
				dynamic_cast<const ASTLiteralExpression*>(actual_para);
		const ASTExpressionList* actual_list =
				dynamic_cast<const ASTExpressionList*>(actual_para);

		if (formal_data != 0) {
			assert(actual_data != 0);

			ASTIdExpression* para = formal_data->name()->clone();
			ASTLiteralExpression* value = actual_data->clone();

			ASTBinaryExpression* assign = new ASTBinaryExpression(para,
					ASTBinaryExpression::OP_ASSIGN, value);
			//! create a statement
			res_statement = new ASTExpressionStatement(assign);

		} else if (formal_list != 0) {
			assert(actual_list != 0);
			ASTCompoundStatement* comp_statement = new ASTCompoundStatement();
			ASTExpressionList::const_iterator cit1 = actual_list->begin();
			for (ASTDeclarationList::const_iterator cit2 = formal_list->begin();
					cit2 != formal_list->end(); ++cit2) {
				//! for each formal parameter
				const ASTDataDeclaration* temp_data_decl =
						dynamic_cast<const ASTDataDeclaration*>(*cit2);
				const ASTLiteralExpression* lit_decl =
						dynamic_cast<const ASTLiteralExpression*>(*cit1);
				ASTIdExpression* temp_para = temp_data_decl->name()->clone();
				ASTLiteralExpression* temp_value = lit_decl->clone();

				ASTBinaryExpression* temp_assign = new ASTBinaryExpression(
						temp_para, ASTBinaryExpression::OP_ASSIGN, temp_value);
				//! create a statement
				ASTExpressionStatement* temp_statement =
						new ASTExpressionStatement(temp_assign);
				comp_statement->add_statement(temp_statement);

				cit1 = cit1 +1;
			}
			res_statement = comp_statement;
		}
		assert(res_statement != 0);
	}

	if (!current_cfa_) {
		current_cfa_ = create_cfa(atom_instance_name);
	}

	//! visit the initialization transition first
	const ASTInitialTransition* init = atom_def->initial_transition();
	visit_initial_transition(init, res_statement);

	const ASTTransition* trans = atom_def->transitions();

	const ASTTransitionList* tran_list =
			dynamic_cast<const ASTTransitionList*>(trans);
	const ASTSingleTransition* single =
			dynamic_cast<const ASTSingleTransition*>(trans);
	const ASTInteraction* interaction =
			dynamic_cast<const ASTInteraction*>(trans);

	if (tran_list != 0) {

		for (ASTTransitionList::const_iterator cit = tran_list->begin();
				cit != tran_list->end(); ++cit) {
			ASTTransition* temp = *cit;
			ASTSingleTransition* temp_single =
					dynamic_cast<ASTSingleTransition*>(temp);
			if (temp_single != 0) {
				visit_transition(temp_single);
			} else {
				assert(false);
			}
		}

	} else if (single != 0) {
		visit_transition(single);
	} else {
		assert(false);
	}

	cfas_.push_back(current_cfa_);
	current_cfa_ = 0;


	/*
	//! get the type name first, which is the name of atom definition and its CFA
	std::string atom_type_name = atom->type()->name()->name();
	std::string atom_name = atom->name()->name()->name();
	ASTExpression* actual_para = atom->parameters();

	//! there is only one declared component, then find the corresponding CFA
	bool found = false;
	CFA* atom_cfa = 0;
	for (CFA::iterator it = cfas_.begin(); it != cfas_.end() && !found; ++it) {
		if (*it) {
			std::string temp_name = (*it)->name();
			if (temp_name == atom_type_name) {
				found = true;
				atom_cfa = *it;
			}
		}
	}

	//! change the CFA name to be the component name
	atom_cfa->set_name(atom_name);

	//! if there are some parameters, then add an initialization edge
	//! which assigns all actual parameters to the formal ones
	//! however, the correspondence between formal and actual parameters is checked by type checker

	if (actual_para != 0) {

		//! find the atom definition, and the formal parameters
		found = false;
		const ASTAtomDefinition* atom_def = 0;
		for (ASTTranslationUnit::const_iterator cit = unit->begin();
				cit != unit->end() && !found; ++cit) {
			const ASTAtomDefinition* temp_def =
					dynamic_cast<const ASTAtomDefinition*>(*cit);
			if (temp_def != 0) {
				std::string temp_name = temp_def->name()->name()->name();
				if (temp_name == atom_type_name) {
					found = true;
					atom_def = temp_def;
				}
			}
		}

		const ASTDeclaration* formal_para = atom_def->parameters();

		const ASTDataDeclaration* formal_data =
				dynamic_cast<const ASTDataDeclaration*>(formal_para);
		const ASTDeclarationList* formal_list =
				dynamic_cast<const ASTDeclarationList*>(formal_para);

		const ASTLiteralExpression* actual_data =
				dynamic_cast<const ASTLiteralExpression*>(actual_para);
		const ASTExpressionList* actual_list =
				dynamic_cast<const ASTExpressionList*>(actual_para);

		ASTStatement* res_statement = 0;

		if (formal_data != 0) {
			assert(actual_data != 0);

			ASTIdExpression* para = formal_data->name()->clone();
			ASTLiteralExpression* value = actual_data->clone();

			ASTBinaryExpression* assign = new ASTBinaryExpression(para,
					ASTBinaryExpression::OP_ASSIGN, value);
			//! create a statement
			res_statement = new ASTExpressionStatement(assign);

		} else if (formal_list != 0) {
			assert(actual_list != 0);
			ASTCompoundStatement* comp_statement = new ASTCompoundStatement();
			ASTExpressionList::const_iterator cit1 = actual_list->begin();
			for (ASTDeclarationList::const_iterator cit2 = formal_list->begin();
					cit2 != formal_list->end(); ++cit2) {
				//! for each formal parameter
				const ASTDataDeclaration* temp_data_decl =
						dynamic_cast<const ASTDataDeclaration*>(*cit1);
				const ASTLiteralExpression* lit_decl =
						dynamic_cast<const ASTLiteralExpression*>(*cit2);
				ASTIdExpression* temp_para = temp_data_decl->name()->clone();
				ASTLiteralExpression* temp_value = lit_decl->clone();

				ASTBinaryExpression* temp_assign = new ASTBinaryExpression(
						temp_para, ASTBinaryExpression::OP_ASSIGN, temp_value);
				//! create a statement
				ASTExpressionStatement* temp_statement =
						new ASTExpressionStatement(temp_assign);
				comp_statement->add_statement(temp_statement);

				++cit1;
			}
			res_statement = comp_statement;
		}
		assert(res_statement != 0);

		//! now create a new CFA edge
		CFANode& inter_node = atom_cfa->create_node();

		//! move all incoming edge of initial location to this inter_node
		CFANode& entry = atom_cfa->entry();
		assert(entry.out_degree() == 1);
		CFAEdge* out = *(entry.out_begin());
		atom_cfa->move_edge_from(*out, inter_node);
		atom_cfa->add_edge(entry, 0, res_statement, inter_node);
	}
	*/

}

void CFABuilder::visit_initial_transition(const ASTInitialTransition* init, ASTStatement* initialization) {

	//! create a new CFA node corresponding to the BIP initial control location
	CFANode& init_loc = current_cfa_->create_node();
	set_line_no(init_loc, *(init->location()));

	//! set the name of the location, assume we have only one initial location
	const ASTIdExpression* loc_name =
			dynamic_cast<const ASTIdExpression*>(init->location());
	if (loc_name != 0) {
		init_loc.set_name(loc_name->name()->name());
	}

	//! check if the location is the target location
	std::string cfa_name = current_cfa_->name();
	std::string location_name = loc_name->name()->name();

	assert(targets_ != 0);
	const ASTQualifiedIdExpression* single_loc =
			dynamic_cast<const ASTQualifiedIdExpression*>(targets_);
	const ASTExpressionList* list_loc =
			dynamic_cast<const ASTExpressionList*>(targets_);

	if(single_loc != 0){
		std::string temp_comp_name = single_loc->qualifier()->name();
		std::string temp_loc_name = single_loc->name()->name();

		if(temp_comp_name == cfa_name && temp_loc_name == location_name){
			init_loc.set_as_error(true);
			current_cfa_->set_error_location(true);
		}

	} else if(list_loc != 0){
		bool found_loc = false;
		for(ASTExpressionList::const_iterator cit = list_loc->begin();
				cit != list_loc->end() && !found_loc; ++cit){
			if(*cit){
				const ASTQualifiedIdExpression* temp_loc =
						dynamic_cast<const ASTQualifiedIdExpression*>(*cit);
				std::string temp_loc_comp_name = temp_loc->qualifier()->name();
				std::string temp_loc_loc_name = temp_loc->name()->name();
				if(temp_loc_comp_name == cfa_name && temp_loc_loc_name == location_name)
					found_loc = true;
			}
		}

		if(found_loc){
			init_loc.set_as_error(true);
			current_cfa_->set_error_location(true);
		}
	}

	const ASTStatement* action = init->action();
	assert(&current_cfa_->entry() != 0);

	//! we set the entry of the cfa as the initial control location.
	current_cfa_->entry().set_name(std::string("Init"));

	ASTIdExpression* label = new ASTIdExpression(new ASTName(std::string("BIPInitialization")));

	if (action != 0 && initialization == 0){
		current_cfa_->add_edge(current_cfa_->entry(),label, 0, action->clone(), init_loc, true);
	}
	else if(action != 0 && initialization != 0){
		ASTCompoundStatement* new_action = new ASTCompoundStatement();
		new_action->add_statement(initialization);
		new_action->add_statement(action->clone());
		current_cfa_->add_edge(current_cfa_->entry(),label, 0, new_action, init_loc, true);
	}
	else if(action ==0 && initialization != 0){
		current_cfa_->add_edge(current_cfa_->entry(),label,0,initialization, init_loc, true);
	}
	else if(action == 0 && initialization == 0)
		current_cfa_->add_edge(current_cfa_->entry(), label,0, 0, init_loc, true);

}

void CFABuilder::visit_transition(const ASTSingleTransition* trans) {

	const ASTIdExpression* source = trans->source();
	std::string source_name = source->name()->name();

	//! find the CFANode with source_name
	bool found = false;
	CFANode* snode = 0;
	for (CFA::iterator cit = current_cfa_->begin();
			cit != current_cfa_->end() && !found; ++cit) {
		CFANode* temp_node = *cit;
		std::string temp_name = temp_node->name();
		if (temp_name == source_name) {
			found = true;
			snode = temp_node;
		}
	}

	//! when it does not exists, create a new CFANode
	if (snode == 0) {
		CFANode& source_loc = current_cfa_->create_node();
		set_line_no(source_loc, *source);
		source_loc.set_name(source_name);
		snode = &source_loc;
	}

	//! check if source location is the target location
	std::string cfa_name = current_cfa_->name();
	assert(targets_ != 0);
	const ASTQualifiedIdExpression* single_loc =
			dynamic_cast<const ASTQualifiedIdExpression*>(targets_);
	const ASTExpressionList* list_loc =
			dynamic_cast<const ASTExpressionList*>(targets_);

	if(single_loc != 0){
		std::string temp_comp_name = single_loc->qualifier()->name();
		std::string temp_loc_name = single_loc->name()->name();

		if(temp_comp_name == cfa_name && temp_loc_name == source_name){
			snode->set_as_error(true);
			current_cfa_->set_error_location(true);
		}

	} else if(list_loc != 0){
		bool found_loc = false;
		for(ASTExpressionList::const_iterator cit = list_loc->begin();
				cit != list_loc->end() && !found_loc; ++cit){
			if(*cit){
				const ASTQualifiedIdExpression* temp_loc =
						dynamic_cast<const ASTQualifiedIdExpression*>(*cit);
				std::string temp_loc_comp_name = temp_loc->qualifier()->name();
				std::string temp_loc_loc_name = temp_loc->name()->name();
				if(temp_loc_comp_name == cfa_name && temp_loc_loc_name == source_name)
					found_loc = true;
			}
		}
		if(found_loc){
			snode->set_as_error(true);
			current_cfa_->set_error_location(true);
		}
	}


	const ASTIdExpression* target = trans->target();
	std::string target_name = target->name()->name();

	found = false;
	CFANode* tnode = 0;
	for (CFA::iterator cit = current_cfa_->begin();
			cit != current_cfa_->end() && !found; ++cit) {
		CFANode* temp_node = *cit;
		std::string temp_name = temp_node->name();
		if (temp_name == target_name) {
			found = true;
			tnode = temp_node;
		}
	}

	if (tnode == 0) {
		CFANode& target_loc = current_cfa_->create_node();
		set_line_no(target_loc, *target);
		target_loc.set_name(target_name);
		tnode = &target_loc;
	}

	//! check if target location is the target location

	if(single_loc != 0){
		std::string temp_comp_name = single_loc->qualifier()->name();
		std::string temp_loc_name = single_loc->name()->name();
		if(temp_comp_name == cfa_name && temp_loc_name == target_name){
			tnode->set_as_error(true);
			current_cfa_->set_error_location(true);
		}
	} else if(list_loc != 0){
		bool found_loc = false;
		for(ASTExpressionList::const_iterator cit = list_loc->begin();
				cit != list_loc->end() && !found_loc; ++cit){
			if(*cit){
				const ASTQualifiedIdExpression* temp_loc =
						dynamic_cast<const ASTQualifiedIdExpression*>(*cit);
				std::string temp_loc_comp_name = temp_loc->qualifier()->name();
				std::string temp_loc_loc_name = temp_loc->name()->name();
				if(temp_loc_comp_name == cfa_name && temp_loc_loc_name == target_name)
					found_loc = true;
			}
		}
		if(found_loc){
			tnode->set_as_error(true);
			current_cfa_->set_error_location(true);
		}
	}

	assert(snode != 0);
	assert(tnode != 0);


	const ASTIdExpression* label = trans->label();
	const ASTExpression* guard = trans->guard();
	const ASTStatement* action = trans->action();
	ASTExpression* new_g = 0;
	ASTStatement* new_a = 0;
	ASTIdExpression* new_l = 0;

	if(label != 0)
		new_l = label->clone();

	if (guard != 0) {
		new_g = guard->clone();
	}

	if (action != 0) {
		new_a = action->clone();
	}

	current_cfa_->add_edge(*snode, new_l, new_g, new_a, *tnode, trans->is_internal());

}

void CFABuilder::set_line_no(CFANode& cfa_node, const ASTNode& ast_node) const {
	set_line_no(cfa_node, ast_node.node_location().start_line_number());
}

void CFABuilder::set_line_no(CFANode& cfa_node, unsigned int line_no) const {
	cfa_node.set_line_no(line_no);
}

}

