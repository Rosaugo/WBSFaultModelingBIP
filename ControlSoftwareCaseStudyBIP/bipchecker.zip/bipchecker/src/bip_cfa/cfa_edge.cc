/*
 * cfa_edge.cc
 *
 *  Created on: Nov 11, 2014
 *      Author: wangqiang
 */

#include "bip_cfa/cfa_edge.h"
#include "bip_cfa/cfa_node.h"

namespace bipchecker{

size_t CFAEdge::fresh_id = 0;


void CFAEdge::set_from(CFANode& from)
{
    from_->remove_out_edge(*this);
    from_ = &from;
    from_->add_out_edge(*this);
}

void CFAEdge::set_to(CFANode& to)
{
    to_->remove_in_edge(*this);
    to_ = &to;
    to_->add_in_edge(*this);
}


CFAEdge::~CFAEdge()
{
    from_->remove_out_edge(*this);
    to_->remove_in_edge(*this);

    if(label_)
    	delete label_;

    if(guard_)
    	delete guard_;

    if(action_)
    	delete action_;
}


}


