/*
 * dot_builder.cc
 *
 *  Created on: Nov 12, 2014
 *      Author: wangqiang
 */

#include "bip_cfa/dot_builder.h"
#include "bip_cfa/cfa.h"
#include "bip_cfa/cfa_node.h"
#include "bip_cfa/cfa_edge.h"

#include <cassert>
#include <sstream>
#include <vector>
#include <map>

namespace bipchecker {

void DotBuilder::build_dot_cfa(const CFA& cfa) {

	out_ << "digraph " << cfa.name() << " { " << std::endl;

	std::vector<const CFANode*> work_list;
	std::map<size_t, const CFANode*> visited_nodes;

	// Draw entry node.
	draw_cfa_node(cfa.entry());
	out_ << std::endl;

	// Put in the work list.
	work_list.push_back(&(cfa.entry()));

	while (!work_list.empty()) {

		const CFANode* node = work_list.back();
		work_list.pop_back();

		// Mark as visited.
		visited_nodes[node->node_id()] = node;

		for (CFANode::const_iterator it = node->out_begin();
				it != node->out_end(); ++it) {
			if (*it) {
				CFAEdge *edge = *it;

				//  Get target node.
				const CFANode& to = edge->to();
				if (visited_nodes.find(to.node_id()) == visited_nodes.end()) {
					// Draw target node.
					draw_cfa_node(to);
					out_ << std::endl;
					// Put in the work list.
					work_list.push_back(&to);
					visited_nodes[to.node_id()] = &to;
				}

				// Draw connecting edge.
				draw_cfa_edge(*edge);
				out_ << std::endl;

			}
		}
	}
	out_ << "}" << std::endl;
}


void DotBuilder::draw_cfa_node(const CFANode& node)
{
    const CFA& cfa = node.cfa();

    // Determine shape.
    std::string shape = "circle";

    if (&(cfa.entry()) == &node)
	shape = "doublecircle";
    else if (node.is_error())
	shape = "Mcircle";

    //std::string label = node_label(node.node_id());
    std::string label = node.name();

    out_ << node.node_id()
	 << " [ shape=" << shape
	 << ", label=\"" << label << "\" ];";

}


std::string DotBuilder::node_label(size_t id)
{
    std::stringstream stream;

    stream << id;

    return stream.str();

}

void DotBuilder::draw_cfa_edge(const CFAEdge& edge)
{

    // Draw edge.
    out_ << edge.from().node_id();
    out_ << " -> ";
    out_ << edge.to().node_id();

    // Draw edge's label.
    out_ << " [ label=\"";

    const CFAEdge *edge_ptr = &edge;
    const ASTStatement* action = edge_ptr->action();
    const ASTExpression* guard = edge_ptr->guard();
    const ASTIdExpression* label = edge_ptr->label();

    if(label != 0){
    	label->accept(ast_printer_);
    	//out_ << std::endl;
    }

    if(guard != 0){
    	out_ << "[";
    	guard->accept(ast_printer_);
    	out_ << "]";
    	//out_ << std::endl;
    }

    if(action != 0)
    	action->accept(ast_printer_);


    out_ << "\" ];";

/*
    if ((assume_edge = dynamic_cast<const CFAAssumeEdge*> (edge_ptr)) != 0) {

	out_ << "[";
	(assume_edge->expression()).accept(ast_printer_);
	out_ << "]";

    } else if ((assign_edge = dynamic_cast<const CFAAssignEdge*> (edge_ptr)) != 0) {

	(assign_edge->left_expression()).accept(ast_printer_);
	out_ << " = ";
	(assign_edge->right_expression()).accept(ast_printer_);

    } else if ((call_edge = dynamic_cast<const CFACallEdge*> (edge_ptr)) != 0)
	(call_edge->expression()).accept(ast_printer_);
*/
}


}
