/*
 * cfa_node.h
 *
 *  Created on: Nov 11, 2014
 *      Author: wangqiang
 */

#ifndef CFA_NODE_H_
#define CFA_NODE_H_

#include <set>
#include "util/hash_map.h"
#include "util/util.h"

namespace bipchecker {

class CFA;
class CFAEdge;

class CFANode {

	//! Fresh id for nodes.
	static size_t fresh_id;

	//! Node id.
	size_t node_id_;

	//! location name
	std::string name_;

	//! flag to indicate if this node is an error node
	bool is_error_;

	//! Internal struct for CFA edge ordering.
	struct EdgeLt {
		//! CFA edge less-than (<) ordering.
		/*!
		 * \param e1 a CFA edge.
		 * \param e2 a CFA edge.
		 * \return True iff e1 < e2.
		 */
		bool operator()(const CFAEdge *e1, const CFAEdge *e2) const;
	};

	//! Ordered set.
	/*!
	 * The edges are ordered based on its id.
	 * The earlier the creation of the edge the smaller
	 * the id.
	 *
	 * The set container internally keeps its elements ordered
	 * from lower to higher. Thus, enumerating the set of edges
	 * results in a list of edges sorted by their ids or equally by
	 * their creation times in ascending order.
	 *
	 * Such an above order is important in controlling the search
	 * or traversal of CFA, as the iterations of incoming or outgoing
	 * edges depend on the order.
	 *
	 * Do not change this set representation to unordered container
	 * like hash set.
	 */
	typedef std::set<CFAEdge*, EdgeLt> edges_t;

	//! Set of incoming edges.
	edges_t in_edges_;

	//! Set of outgoing edges.
	edges_t out_edges_;

	//! CFA that owns the node..
	/*!
	 * Every CFA node is owned by a CFA.
	 */
	CFA& cfa_;

	//! Source code line number (optional).
	unsigned int line_no_;

public:
	//! Class constructor.
	/*!
	 * Calling this constructor directly for creating a CFA node
	 * is not recommended because, although the CFA that owns the node
	 * is set, the node is not inserted into the CFA.
	 *
	 * For a proper node creation, use the function create_node
	 * in CFA class.
	 */
	explicit CFANode(CFA& cfa) :
		node_id_(fresh_id++), name_(std::string("")),
		is_error_(false), cfa_(cfa), line_no_(0) { }

	//! Gets node id.
	/*!
	 * \return The node id.
	 */
	size_t node_id() const {
		return node_id_;
	}

	//! Gets the CFA that owns this node.
	/*!
	 * \return The CFA that owns this node.
	 */
	const CFA& cfa() const {
		return cfa_;
	}

	//! Gets the CFA that owns this node.
	/*!
	 * \return The CFA that owns this node.
	 */
	CFA& cfa() {
		return cfa_;
	}

	//! get the location name
	const std::string& name() const {
		return name_;
	}

	void set_name(const std::string & name){
		name_ = name;
	}

	bool is_error() const {return is_error_;}

	void set_as_error(bool error) {is_error_ = error ; }

	typedef edges_t::const_iterator const_iterator;

	//! Gets the start iterator of the set of incoming edges.
	/*!
	 * \return The start iterator of the set of incoming edges.
	 */
	const_iterator in_begin() const {
		return in_edges_.begin();
	}

	//! Gets the end iterator of the set of incoming edges.
	/*!
	 * \return The end iterator of the set of incoming edges.
	 */
	const_iterator in_end() const {
		return in_edges_.end();
	}

	//! Gets the start iterator of the set of outgoing edges.
	/*!
	 * \return The start iterator of the set of outgoing edges.
	 */
	const_iterator out_begin() const {
		return out_edges_.begin();
	}

	//! Gets the end iterator of the set of outgoing edges.
	/*!
	 * \return The end iterator of the set of outgoing edges.
	 */
	const_iterator out_end() const {
		return out_edges_.end();
	}

	typedef edges_t::const_iterator iterator;

	//! Gets the start iterator of the set of incoming edges.
	/*!
	 * \return The start iterator of the set of incoming edges.
	 */
	iterator in_begin() {
		return in_edges_.begin();
	}

	//! Gets the end iterator of the set of incoming edges.
	/*!
	 * \return The end iterator of the set of incoming edges.
	 */
	iterator in_end() {
		return in_edges_.end();
	}

	//! Gets the start iterator of the set of outgoing edges.
	/*!
	 * \return The start iterator of the set of outgoing edges.
	 */
	iterator out_begin() {
		return out_edges_.begin();
	}

	//! Gets the end iterator of the set of outgoing edges.
	/*!
	 * \return The end iterator of the set of outgoing edges.
	 */
	iterator out_end() {
		return out_edges_.end();
	}

	//! Gets the in-degree of the node.
	/*!
	 * The in-degree of a node is the number of incoming edges
	 * of the node.
	 *
	 * \return The in-degree of the node.
	 */
	unsigned int in_degree() const {
		return in_edges_.size();
	}

	//! Gets the out-degree of the node.
	/*!
	 * The out-degree of a node is the number of outgoing edges
	 * of the node.
	 *
	 * \return The out-degree of the node.
	 */
	unsigned int out_degree() const {
		return out_edges_.size();
	}

	//! Gets the degree of the node.
	/*!
	 * The degree of a node is the sum of the numbers of incoming
	 * and outgoing edges.
	 *
	 * \return The degree of the node.
	 */
	unsigned int degree() const {
		return in_degree() + out_degree();
	}

	//! Adds incoming edge.
	/*!
	 * An edge can be added as an incoming edge of a node
	 * if the node is the target of the edge.
	 *
	 * Adding an incoming edge by calling this function directly
	 * is not recommended. The most recommended way for adding
	 * edges is by calling functions for adding edges in CFA.
	 *
	 * In adding the edge the node does not take the ownership
	 * of the edge. The edge is simply inserted into the set of
	 * incoming edges (or attached to the node).
	 *
	 * TODO(IN): Why should this function return this node?
	 *
	 * \param edge a CFA edge.
	 * \return This node.
	 */
	CFANode& add_in_edge(CFAEdge& edge);

	//! Adds outgoing edge.
	/*!
	 * An edge can be added as an outgoing edge of a node
	 * if the node is the source of the edge.
	 *
	 * Adding an outgoing edge by calling this function directly
	 * is not recommended. The most recommended way for adding
	 * edges is by calling functions for adding edges in CFA.
	 *
	 * In adding the edge the node does not take the ownership
	 * of the edge. The edge is simply inserted into the set of
	 * outgoing edges (or attached to the node).
	 *
	 * TODO(IN): Why should this function return this node?
	 *
	 * \param edge a CFA edge.
	 * \return This node.
	 */
	CFANode& add_out_edge(CFAEdge& edge);

	//! Removes incoming edge.
	/*!
	 * Removing an incoming edge simply removes the edge from
	 * the set of incoming edges without destroying the edge.
	 * Recall that the node has no ownership of the edge.
	 *
	 * \param edge a CFA edge.
	 */
	void remove_in_edge(CFAEdge& edge);

	//! Removes outgoing edge.
	/*!
	 * Removing an outgoing edge simply removes the edge from
	 * the set of outgoing edges without destroying the edge.
	 * Recall that the node has no ownership of the edge.
	 *
	 * \param edge a CFA edge.
	 */
	void remove_out_edge(CFAEdge& edge);

	//! Gets the source line number.
	/*!
	 * A CFA node can have a correspondence with a source line
	 * number. Such a correspondence was established during the
	 * CFA construction.
	 *
	 * \return The source line number.
	 */
	virtual unsigned int line_no() const {
		return line_no_;
	}

	//! Sets the source line number
	/*!
	 * \param line_no a source line number.
	 */
	virtual void set_line_no(unsigned int line_no) {
		line_no_ = line_no;
	}

	virtual ~CFANode() {
		in_edges_.clear();
		out_edges_.clear();
	}

private:
	DISALLOW_COPY_AND_ASSIGN(CFANode);
};

//! Struct for CFA node id equality.
struct EqCFANode {
	//! Checks if CFA nodes have the same id.
	/*!
	 * \param n1 a CFA node.
	 * \param n2 a CFA node.
	 * \return True iff n1's id equals n2's id.
	 */
	bool operator()(const CFANode *n1, const CFANode *n2) const {
		if (n1 && !n2)
			return false;
		if (!n1 && n2)
			return false;
		if ((!n1 && !n2) || (n1 && n2 && n1->node_id() == n2->node_id()))
			return true;

		return false;
	}

};
// struct EqCFANode

//! Struct for CFA node id less-than inequality.
struct LtCFANode {

	//! Checks if a CFA node id is less than another CFA node id.
	/*!
	 * \param n1 a CFA node.
	 * \param n2 a CFA node.
	 * \return True iff n1's id is less than n2's id.
	 */
	bool operator()(const CFANode *n1, const CFANode *n2) const {
		return (n1->node_id() < n2->node_id());
	}

};
// struct LtCFANode

}

hash_fun_namespace_open {

//! Struct for CFA node hash function.
template<> struct hash<const bipchecker::CFANode*> {
	//! Gets hash code of a CFA node.
	/*!
	 * \param n a CFA node.
	 * \return The hash code (node id) of n.
	 */
	size_t operator()(const bipchecker::CFANode *n) const {
		return n->node_id();
	}

};
// struct hash<const swchecker::CFANode*>

}
hash_fun_namespace_close;

hash_fun_namespace_open {

//! Struct for CFA node (const version) hash function.
template<> struct hash<bipchecker::CFANode*> {
	//! Gets hash code of a CFA node.
	/*!
	 * \param n a CFA node.
	 * \return The hash code (node id) of n.
	 */
	size_t operator()(const bipchecker::CFANode *n) const {
		return n->node_id();
	}

};
// struct hash<swchecker::CFANode*>

}
hash_fun_namespace_close;

#endif /* CFA_NODE_H_ */
