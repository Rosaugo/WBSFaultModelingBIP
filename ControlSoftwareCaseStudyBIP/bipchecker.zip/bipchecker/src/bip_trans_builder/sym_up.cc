/*
 * sym_up.cc
 *
 *  Created on: Dec 15, 2016
 *      Author: wangqiang
 */


#include "bip_trans_builder/sym_up.h"
#include "bip_frontend/bip_type_system/bip_type_system.h"
#include <assert.h>

namespace bipchecker {

void SymUp::update(const Scope& scope,
		LvalMap& lval_map,
		const ASTExpression& ast_expression,
		expression* expr) {

	scope_ = &scope;
	lval_map_ = &lval_map;
	expression_ = expr;

	bool accept = ast_expression.accept(*this);
	assert(accept);

	reset();
}

int SymUp::visit(const ASTExpression *expr) {

	assert(scope_ != 0);
	assert(lval_map_ != 0);

	const ASTBinaryExpression *bin = 0;
	const ASTExpressionList *list = 0;
	const ASTIdExpression *id = 0;
	const ASTQualifiedIdExpression* qualified_id = 0;
	const ASTLiteralExpression *lit = 0;
	const ASTUnaryExpression *un = 0;

	if ((bin = dynamic_cast<const ASTBinaryExpression*>(expr)) != 0)
		return visit_binary_expression(bin);
	else if ((list = dynamic_cast<const ASTExpressionList*>(expr)) != 0)
		return visit_expression_list(list);
	else if ((id = dynamic_cast<const ASTIdExpression*>(expr)) != 0)
		return visit_id_expression(id);
	else if ((lit = dynamic_cast<const ASTLiteralExpression*>(expr)) != 0)
		return visit_literal_expression(lit);
	else if ((un = dynamic_cast<const ASTUnaryExpression*>(expr)) != 0)
		return visit_unary_expression(un);
	else if ((qualified_id = dynamic_cast<const ASTQualifiedIdExpression*>(expr))
			!= 0)
		return visit_qualified_id_expression(qualified_id);

	return ASTVisitor::ABORT;

}

int SymUp::visit_id_expression(const ASTIdExpression *id) {

	std::string id_name = id->name()->name();
	// Find binding.
	const Binding *id_bind = scope_->find(id_name);

	// We assume that this binding is a variable binding.
	// TODO(IN): check this assumption again.
	const DataVariable *var_bind = dynamic_cast<const DataVariable*>(id_bind);
	assert(var_bind != 0);

	// Set a well-scoped name.
	std::string ws_name = id->name()->name();

	// Get the scope of variable binding.
	const Scope *var_scope = &(var_bind->scope());

	// Check if the scope is a function scope.
	const ComponentScope *comp_scope = 0;

	if ((comp_scope = dynamic_cast<const ComponentScope*>(var_scope)) != 0) {

		// Get the function.
		const Component& comp = comp_scope->component();

		// Get function name.
		const std::string& comp_name = comp.name();

		if(!var_bind->is_global()){
			// Construct well-scoped name.
			ws_name = ws_name + std::string("$") + comp_name;
		} else{
			// Construct well-scoped name.
			ws_name = ws_name + std::string("_global_") + comp_name;
		}
	}

	// Create an lvalue.
	const Symbol& sym_id = Symbol::symbol(ws_name);
	Lval *lval = new Lval(sym_id);

	expression* lval_expr = expression_->clone();

	lval_map_->update(lval, lval_expr);

	return ASTVisitor::SKIP;
}

int SymUp::visit_qualified_id_expression(const ASTQualifiedIdExpression *id) {

	std::string component_name = id->qualifier()->name();
	std::string var_name = id->name()->name();

	std::string ws_name = var_name;
	ws_name = ws_name + std::string("_global_") + component_name;

	// Create an lvalue.
	const Symbol& sym_id = Symbol::symbol(ws_name);
	Lval *lval = new Lval(sym_id);

	expression* lval_expr = expression_->clone();

	lval_map_->update(lval, lval_expr);

	return ASTVisitor::SKIP;
}


}
