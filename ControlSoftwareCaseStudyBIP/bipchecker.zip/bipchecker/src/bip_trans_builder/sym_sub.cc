/*
 * sym_sub.cc
 *
 *  Created on: Dec 15, 2016
 *      Author: wangqiang
 */


#include <assert.h>
#include "bip_trans_builder/sym_sub.h"
#include "bip_frontend/bip_type_system/bip_type_system.h"
#include "util/util.h"

namespace bipchecker {

expression* SymSub::substitute(const Scope& scope,
		LvalMap& lval_map,
		const ASTExpression& ast_expression) {

	scope_ = &scope;
	lval_map_ = &lval_map;

	bool accept = ast_expression.accept(*this);
	assert(accept);
	assert(expressions_.size() == 1);

	expression* temp = expressions_.back();
	expressions_.pop_back();

	reset();
	return temp;
}

int SymSub::visit(const ASTExpression *expr) {

	assert(scope_ != 0);
	assert(lval_map_ != 0);

	const ASTBinaryExpression *bin = 0;
	const ASTExpressionList *list = 0;
	const ASTIdExpression *id = 0;
	const ASTQualifiedIdExpression* qualify_id = 0;
	const ASTLiteralExpression *lit = 0;
	const ASTUnaryExpression *un = 0;

	if ((bin = dynamic_cast<const ASTBinaryExpression*>(expr)) != 0)
		return visit_binary_expression(bin);
	else if ((list = dynamic_cast<const ASTExpressionList*>(expr)) != 0)
		return visit_expression_list(list);
	else if ((id = dynamic_cast<const ASTIdExpression*>(expr)) != 0)
		return visit_id_expression(id);
	else if ((lit = dynamic_cast<const ASTLiteralExpression*>(expr)) != 0)
		return visit_literal_expression(lit);
	else if ((un = dynamic_cast<const ASTUnaryExpression*>(expr)) != 0)
		return visit_unary_expression(un);
	else if ((qualify_id = dynamic_cast<const ASTQualifiedIdExpression*>(expr))
			!= 0)
		return visit_qualified_id_expression(qualify_id);

	return ASTVisitor::ABORT;

}

int SymSub::leave(const ASTExpression *expr) {

	assert(scope_ != 0);
	assert(lval_map_ != 0);

	const ASTBinaryExpression *bin = 0;
	const ASTExpressionList *list = 0;
	const ASTIdExpression *id = 0;
	const ASTQualifiedIdExpression* qualify_id = 0;
	const ASTLiteralExpression *lit = 0;
	const ASTUnaryExpression *un = 0;

	if ((bin = dynamic_cast<const ASTBinaryExpression*>(expr)) != 0)
		return leave_binary_expression(bin);
	else if ((list = dynamic_cast<const ASTExpressionList*>(expr)) != 0)
		return leave_expression_list(list);
	else if ((id = dynamic_cast<const ASTIdExpression*>(expr)) != 0)
		return leave_id_expression(id);
	else if ((lit = dynamic_cast<const ASTLiteralExpression*>(expr)) != 0)
		return leave_literal_expression(lit);
	else if ((un = dynamic_cast<const ASTUnaryExpression*>(expr)) != 0)
		return leave_unary_expression(un);
	else if ((qualify_id = dynamic_cast<const ASTQualifiedIdExpression*>(expr))
			!= 0)
		return leave_qualified_id_expression(qualify_id);

	return ASTVisitor::ABORT;

}

int SymSub::visit_binary_expression(const ASTBinaryExpression*) {
	return ASTVisitor::CONTINUE;
}

int SymSub::visit_expression_list(const ASTExpressionList*) {
	//! Expression list exists only as control location declaration in atom definition
	//! or interaction declaration in connector definition. In transition, we do not
	//! have expression list.
	return ASTVisitor::ABORT;
}

int SymSub::leave_expression_list(const ASTExpressionList*) {
	return ASTVisitor::ABORT;
}

int SymSub::visit_id_expression(const ASTIdExpression*) {
	return ASTVisitor::CONTINUE;
}

int SymSub::visit_qualified_id_expression(const ASTQualifiedIdExpression*) {
	return ASTVisitor::CONTINUE;
}


int SymSub::visit_literal_expression(const ASTLiteralExpression*) {
	return ASTVisitor::CONTINUE;
}

int SymSub::visit_unary_expression(const ASTUnaryExpression*) {
	return ASTVisitor::CONTINUE;
}

int SymSub::leave_binary_expression(const ASTBinaryExpression *bin) {

	assert(expressions_.size() >= 2);

	// Get operand 2 (right) expression.
	expression* op2 = expressions_.back();
	expressions_.pop_back();

	// Get operand 1 (left) expression.
	expression* op1 = expressions_.back();
	expressions_.pop_back();

	assert(op1 != 0 && op2 != 0);

	// Set the resulting expression.
	expression* expr = 0;

	switch (bin->bin_operator()) {

	case ASTBinaryExpression::OP_ASSIGN:
		// Such binary expressions should have been removed beforehand.
		assert(false);
		break;

	case ASTBinaryExpression::OP_DIV:
		assert(false);
		break;

	case ASTBinaryExpression::OP_EQ:
		expr = new binary_expression(binary_expression::EQ, *op1, *op2);
		break;

	case ASTBinaryExpression::OP_GE:
		expr = new binary_expression(binary_expression::GE, *op1, *op2);
		break;

	case ASTBinaryExpression::OP_GT:
		expr = new binary_expression(binary_expression::GT, *op1, *op2);
		break;

	case ASTBinaryExpression::OP_LE:
		expr = new binary_expression(binary_expression::LE, *op1, *op2);
		break;

	case ASTBinaryExpression::OP_LT:
		expr = new binary_expression(binary_expression::LT, *op1, *op2);
		break;

	case ASTBinaryExpression::OP_AND:
		expr = new binary_expression(binary_expression::AND, *op1, *op2);
		break;

	case ASTBinaryExpression::OP_OR:
		expr = new binary_expression(binary_expression::OR, *op1, *op2);
		break;

	case ASTBinaryExpression::OP_MINUS:
		expr = new binary_expression(binary_expression::MINUS, *op1, *op2);
		break;

	case ASTBinaryExpression::OP_MULT:
		expr = new binary_expression(binary_expression::MULT, *op1, *op2);
		break;

	case ASTBinaryExpression::OP_NE:
		expr = new binary_expression(binary_expression::NE, *op1, *op2);
		break;

	case ASTBinaryExpression::OP_PLUS:
		expr = new binary_expression(binary_expression::PLUS, *op1, *op2);
		break;
	}

	expressions_.push_back(expr);
	return ASTVisitor::CONTINUE;
}

int SymSub::leave_id_expression(const ASTIdExpression *id) {

	expression* result = 0;

	std::string id_name = id->name()->name();

	// Find binding.
	const Binding *id_bind = scope_->find(id_name);
	// Make sure that the binding exists.
	assert(id_bind != 0);

	const DataVariable* data_var =
			dynamic_cast<const DataVariable*>(id_bind);
	assert(data_var != 0);

	Type* var_type = data_var->type();
	DataType* d_type = dynamic_cast<DataType*>(var_type);

	// Set a well-scoped name.
	std::string ws_name = id->name()->name();

	// Get the scope of variable binding.
	const Scope *binding_scope = &(id_bind->scope());

	// Check if the scope is a function scope.
	const ComponentScope *comp_scope =
			dynamic_cast<const ComponentScope*>(binding_scope);

	assert(comp_scope != 0);

	//if (comp_scope != 0)
	{
		// Get function name.
		const Component& comp = comp_scope->component();
		const std::string& comp_name = comp.name();

		if(!data_var->is_global()){
			// Construct well-scoped name.
			ws_name = ws_name + std::string("$") + comp_name;
		} else{
			// Construct well-scoped name.
			ws_name = ws_name + std::string("_global_") + comp_name;
		}
	}

	// Create an lvalue.
	const Symbol& sym_id = Symbol::symbol(ws_name);
	Lval *lval = new Lval(sym_id);

	// Check if lvalue is already on the map.
	expression* temp = lval_map_->select(*lval);

	if (temp != 0) { // lvalue is already on the map.
		result = temp->clone();
	} else {
		// Create lvalue expression.
		expression* lval_expr = 0;

		switch(d_type->type()){
		case DataType::BOOL :
			assert(false); // TODO
			lval_expr = new boolean(ws_name);
			break;
		case DataType::INT:
			// Create lvalue expression.
			lval_expr = new variable(ws_name);
			break;
		default:
			assert(false);
			lval_expr = new variable(ws_name);
			break;
		}

		// put lvalue expression in the lvalue map.
		lval_map_->update(lval, lval_expr->clone());

		// Create a copy of lvalue expression as the resulting expression.
		result = lval_expr;
	}

	expressions_.push_back(result);

	return ASTVisitor::CONTINUE;
}

int SymSub::leave_qualified_id_expression(const ASTQualifiedIdExpression* qualified_id) {

	expression* result = 0;

	std::string comp_name = qualified_id->qualifier()->name();
	std::string var_name = qualified_id->name()->name();

	// Construct well-scoped name.
	std::string ws_name = var_name;
	ws_name = ws_name + std::string("_global_") + comp_name;

	// Create an lvalue.
	const Symbol& sym_id = Symbol::symbol(ws_name);
	Lval *lval = new Lval(sym_id);

	// Check if lvalue is already on the map.
	expression* temp = lval_map_->select(*lval);

	if (temp != 0){ // lvalue is already on the map.
		result = temp->clone();
	} else {

		// Create lvalue expression.
		expression* lval_expr = new variable(ws_name);

		// put lvalue expression in the lvalue map.
		lval_map_->update(lval, lval_expr);

		// Create a copy of lvalue expression as the resulting expression.
		result = lval_expr->clone();
	}

	expressions_.push_back(result);

	return ASTVisitor::CONTINUE;
}

int SymSub::leave_literal_expression(const ASTLiteralExpression *lit) {

	const std::string& val = lit->value();

	expression* expr = 0;

	std::string num("");

	long double f;

	switch (lit->kind()) {

	case ASTLiteralExpression::INT_LIT:

		// Unbounded string normalization (work directly with the string)
		num = remove_arith_literal_suffix(val);

		// Build an expression.
		expr = new literal(std::atoi(num.c_str()));

		break;

	case ASTLiteralExpression::BOOL_LIT:

		if(val == "true")
			expr = new true_constant();
		else if (val == "false")
			expr = new false_constant();

		break;

	case ASTLiteralExpression::FLOAT_LIT:

		break;
		//! TODO: add other data types
	}

	assert(expr != 0);

	expressions_.push_back(expr);

	return ASTVisitor::CONTINUE;
}

int SymSub::leave_unary_expression(const ASTUnaryExpression *un) {

	assert(expressions_.size() >= 1);

	// Get operand expression.
	expression* op = expressions_.back();
	expressions_.pop_back();

	// Set the resulting expression.
	expression* expr = 0;

	switch (un->un_operator()) {

	case ASTUnaryExpression::OP_MINUS:
		expr = new unary_expression(unary_expression::MINUS, *op);
		break;

	case ASTUnaryExpression::OP_NOT:
		expr = new unary_expression(unary_expression::NOT, *op);
		break;

	case ASTUnaryExpression::OP_PLUS:
		expr = op;
		break;
	}

	expressions_.push_back(expr);
	return ASTVisitor::CONTINUE;

}

void SymSub::reset() {
	scope_ = 0;
	lval_map_ = 0;

	for (expressions_t::iterator it = expressions_.begin();
			it != expressions_.end(); ++it) {

		if (*it)
			delete *it;
	}
	expressions_.clear();
}

SymSub::~SymSub() { reset(); }

std::string SymSub::remove_arith_literal_suffix(const std::string& s) {

	int current_pos = s.size() - 1;

	while (current_pos > 0 && !std::isdigit(s.at(current_pos)))
		--current_pos;

	return s.substr(0, current_pos + 1);
}

}

