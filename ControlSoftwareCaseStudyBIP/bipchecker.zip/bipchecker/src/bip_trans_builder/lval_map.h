/*
 * lval_map.h
 *
 *  Created on: Dec 15, 2016
 *      Author: wangqiang
 */

#ifndef LVAL_MAP_H_
#define LVAL_MAP_H_

#include <map>

#include "bip_trans_builder/lval.h"
#include "bip_solver/expression.h"

#include "util/hash_map.h"
#include "util/util.h"

namespace bipchecker{

//! Comparator class for pointer to lvalues.
struct LvalPtrComp
{
    //! Comparison function.
    /*!
     * \param lhs the left-hand pointer to lvalue.
     * \param rhs the right-hand pointer to lvalue.
     * \return True iff lhs < rhs.
     */
    bool operator() (Lval* const& lhs, Lval* const& rhs) const;

}; // struct LvalComp


//! Lvalue-mapping class.
class LvalMap
{
    typedef hash_map<Lval*, expression*,
		     hash_fun<Lval*>,
		     EqLval> lval_map_t;

    //! Internal mapping from lvalues to expressions.
    /*!
     * This mapping generalizes SSA mapping.
     */
    lval_map_t lval_map_;

public:

    //! Class constructor.
    explicit LvalMap() {
    }

    //! Class copy constructor.
    explicit LvalMap(const LvalMap& lm);


    //! Select operator.
    /*!
     * \param lval an lvalue.
     * \return The image expression or 0 if none.
     */
    expression* select(const Lval& lval);

    //! Update operator.
    /*!
     * \param lval an lvalue.
     * \param expression a expression.
     */
    void update(Lval *lval, expression* expr);


    typedef lval_map_t::const_iterator const_iterator;

    //! Gets the start iterator of the internal map.
    /*!
     * \return The start iterator of the internal map.
     */
    const_iterator begin() const { return lval_map_.begin(); }


    //! Gets the end iterator of the internal map.
    /*!
     * \return The end iterator of the internal map.
     */
    const_iterator end() const { return lval_map_.end(); }

    //! Class destructor.
    ~LvalMap();

private:
    DISALLOW_ASSIGN(LvalMap);

}; // class LvalMap

}

#endif /* LVAL_MAP_H_ */
