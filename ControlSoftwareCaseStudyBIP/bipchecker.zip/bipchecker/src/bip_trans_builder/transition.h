/*
 * transition.h
 *
 *  Created on: Dec 15, 2016
 *      Author: wangqiang
 */

#ifndef TRANSITION_H_
#define TRANSITION_H_

#include <map>

#include "bip_solver/expression.h"
#include "util/util.h"

namespace bipchecker {

//! Transition class.
class Transition {

public:

	typedef std::set<expression*> domain_t;

	typedef std::map<expression*, expression*> update_t;

private:

	//! Internal expression of transition.
	expression* expression_;

	//! Domain variables.
	domain_t domain_;

	//! Guard expression.
	expression* guard_;

	//! Update expressions.
	update_t update_;

public:

	explicit Transition(expression* expr): expression_(expr), guard_(0) { }

	//! Class copy constructor.
	explicit Transition(const Transition& transition) {
		expression_ = 0;

		if(transition.expression_)
			expression_ = (transition.expression_->clone());

		for (domain_t::const_iterator cit = transition.domain_begin();
				cit != transition.domain_end(); ++cit) {
			domain_.insert((*cit)->clone());
		}

		guard_ = 0;

		if (transition.guard_)
			guard_ = (transition.guard_->clone());

		if (!transition.update_.empty()) {

			for (update_t::const_iterator cit = transition.update_begin();
					cit != transition.update_end(); ++cit) {

				update_[(*cit).first->clone()] = (*cit).second->clone();
			}
		}
	}

	expression* get_expression() { return expression_;}

	//! Adds domain variable.
	/*!
	 * \param var a variable.
	 * \return True if variable is added into the domain.
	 */
	bool add_domain_variable(expression* var) {

		return (domain_.insert(var)).second;
	}

	typedef domain_t::const_iterator const_domain_iterator;

	//! Gets the start iterator of domain.
	/*!
	 * \return The start iterator of domain.
	 */
	const_domain_iterator domain_begin() const {
		return domain_.begin();
	}

	//! Gets the end iterator of domain.
	/*!
	 * \return The end iterator of domain.
	 */
	const_domain_iterator domain_end() const {
		return domain_.end();
	}

	//! Gets the guard expression.
	/*!
	 * \return The guard expression.
	 */
	expression* guard() {
		return guard_;
	}

	//! Sets the guard expression.
	/*!
	 * \param guard an expression.
	 */
	void set_guard(expression* guard) {

		if (guard_)
			delete guard_;

		guard_ = guard;
	}

	typedef update_t::const_iterator const_update_iterator;

	//! Gets the start iterator of update.
	/*!
	 * \return The start iterator of update.
	 */
	const_update_iterator update_begin() const {
		return update_.begin();
	}

	//! Gets the end iterator of update.
	/*!
	 * \return The end iterator of update.
	 */
	const_update_iterator update_end() const {
		return update_.end();
	}

	//! Adds update clause.
	/*!
	 * \param var an expression variable.
	 * \param update an update clause expression.
	 */
	void add_update(expression* var, expression* update) {

		update_t::iterator it = update_.find(var);

		if (it != update_.end()) {

			expression *v = (*it).first;
			expression *u = (*it).second;

			update_.erase(it);

			if (v)
				delete v;

			if (u)
				delete u;
		}

		update_[var] = update;

	}

	//! Clones transition.
	/*!
	 * \return The clone of transition.
	 */
	virtual Transition* clone() const {
		return new Transition(*this);
	}

	//! Class destructor.
	virtual ~Transition() {
		if (expression_)
			delete expression_;

		for (domain_t::iterator it = domain_.begin(); it != domain_.end();
				++it) {

			if (*it)
				delete *it;
		}

		if (guard_)
			delete guard_;

		if (!update_.empty()) {

			for (update_t::iterator it = update_.begin(); it != update_.end();
					++it) {

				if ((*it).first)
					delete (*it).first;

				if ((*it).second)
					delete (*it).second;
			}

		}
	}

private:

	DISALLOW_ASSIGN(Transition);

};
// class Transition

}



#endif /* TRANSITION_H_ */
