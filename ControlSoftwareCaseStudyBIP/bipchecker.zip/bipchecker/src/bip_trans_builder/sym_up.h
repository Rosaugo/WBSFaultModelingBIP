/*
 * sym_up.h
 *
 *  Created on: Dec 15, 2016
 *      Author: wangqiang
 */

#ifndef SYM_UP_H_
#define SYM_UP_H_


#include "bip_trans_builder/lval_map.h"
#include "bip_solver/expression.h"
#include "bip_frontend/bip_ast/ast_visitor.h"
#include "bip_trans_builder/sym_sub.h"
#include "util/util.h"

namespace bipchecker {

class SymUp: public ASTVisitor {

	//! Symbolic substitutor.
	/*!
	 * We need a symbolic substitutor to evaluate
	 * sub-expressions of lvalue expression.
	 */
	SymSub& sym_sub_;

	//! Current symbol table.
	const Scope *scope_;

	//! Current lvalue map.
	LvalMap *lval_map_;

	//! Current expression.
	expression* expression_;


public:
	//! Class constructor.
	/*!
	 * \param sym_sub a symbolic substitutor.
	 */
	explicit SymUp(SymSub& sym_sub) :
	ASTVisitor(false), sym_sub_(sym_sub)
	{
		visit_expression = true;
		reset();
	}

	//! Updates lvalue mapping from an AST expression to an expression.
	/*!
	 * \param scope a symbol table.
	 * \param lval_map an lvalue map.
	 * \param ast_expression an AST expression.
	 * \param an expression.
	 */
	void update(const Scope& scope, LvalMap& lval_map,
			const ASTExpression& ast_expression,
			expression* expr);

	int visit(const ASTExpression*);
	int leave(const ASTExpression*) {return ASTVisitor::SKIP;}

	//! Class destructor.
	~SymUp() {reset();}

private:

	DISALLOW_COPY_AND_ASSIGN(SymUp);

	void reset() {
		scope_ = 0;
		lval_map_ = 0;
		expression_ = 0;
	}

	int visit_binary_expression(const ASTBinaryExpression*) {
		// Lvalue cannot be a binary expression.
		return ASTVisitor::ABORT;
	}

	int visit_expression_list(const ASTExpressionList*) {
		// Lvalue cannot be a binary expression.
		return ASTVisitor::ABORT;
	}

	int visit_id_expression(const ASTIdExpression*);

	int visit_qualified_id_expression(const ASTQualifiedIdExpression*);

	int visit_literal_expression(const ASTLiteralExpression*) {
		// Lvalue cannot be a binary expression.
		return ASTVisitor::ABORT;
	}

	int visit_unary_expression(const ASTUnaryExpression*) {
		// Lvalue cannot be a binary expression.
		return ASTVisitor::ABORT;
	}

};

}

#endif /* SYM_UP_H_ */
