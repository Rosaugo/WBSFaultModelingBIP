/*
 * lval.h
 *
 *  Created on: Dec 15, 2016
 *      Author: wangqiang
 */

#ifndef LVAL_H_
#define LVAL_H_

#include "util/symbol.h"
#include "util/util.h"
#include "util/hash_map.h"

namespace bipchecker{


//! Simple lvalue class.
/*!
 * This class wraps the representation of simple lvalues,
 * which are simple variables. We represent it as symbol.
 */
class Lval
{
    //! Variable represented by symbol.
   const Symbol *var_;

public:

    //! Class constructor.
    explicit Lval(const Symbol& var): var_(&var){
    }

    //! Class copy constructor.
    explicit Lval(const Lval& slval) {
	var_ = slval.var_;
    }


    //! Gets the variable representation of lvalue.
    /*!
     * \return The variable representation of lvalue.
     */
    const Symbol& symbol() const { return *var_; }


    //! Calculates hash code.
    /*!
     * \return The hash code.
     */
    size_t hash_code() const
    {
	// return reinterpret_cast<size_t>(var_);
	return var_->symbol_id();
    }

    //! Checks equality.
    /*!
     * \param lval an lvalue.
     * \return True iff the lvalue equals to this.
     */
    bool equals(const Lval& lval) const {
    	const Lval *slval = (&lval);

    	if (slval != 0)
    		return (var_ == slval->var_);

    	return false;
    }


    //! Clones lvalue.
    /*!
     * \return The clone of lvalue.
     */
    Lval* clone() const { return new Lval(*this); }


    //! Class destructor.
    ~Lval(){
    }


private:

    DISALLOW_ASSIGN(Lval);
}; // class SimpLVal


struct EqLval
{
    bool operator() (const Lval *v1, const Lval *v2) const
    {
	if (v1 && !v2)
	    return false;
	if (!v1 && v2)
	    return false;
	if ( (!v1 && !v2)
	     || (v1 && v2 && v1->equals(*v2)) )
	    return true;

	return false;
    }
};
}

hash_fun_namespace_open {

  // Hash function for lval key.
  template<> struct hash<bipchecker::Lval*>
  {
      size_t operator() (const bipchecker::Lval *v) const
      {
        return v->hash_code();
      }
  };

  // Hash function for lval key.
  template<> struct hash<const bipchecker::Lval*>
  {
      size_t operator() (const bipchecker::Lval *v) const
      {
        return v->hash_code();
      }
  };

}
hash_fun_namespace_close;


#endif /* LVAL_H_ */
