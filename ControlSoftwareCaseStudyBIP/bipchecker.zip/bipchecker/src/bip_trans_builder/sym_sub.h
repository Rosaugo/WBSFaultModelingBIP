/*
 * sym_sub.h
 *
 *  Created on: Dec 15, 2016
 *      Author: wangqiang
 */

#ifndef SYM_SUB_H_
#define SYM_SUB_H_

#include "bip_frontend/bip_type_system/scope.h"
#include "bip_frontend/bip_ast/ast_visitor.h"
#include "util/util.h"
#include "bip_trans_builder/lval_map.h"
#include "bip_solver/expression.h"

namespace bipchecker{

class SymSub : public ASTVisitor{

    //! Current symbol table.
    const Scope *scope_;

    //! Current lvalue map.
    LvalMap *lval_map_;

    typedef std::vector<expression*> expressions_t;

    //! Expression stack.
    expressions_t expressions_;

public:
    //! Class constructor.
    /*!
     * \param environment a environment.
     * \param type_checker a type checker.
     */
    explicit SymSub(): ASTVisitor(false), lval_map_(0) {
        visit_expression = true;
        scope_ = 0;
    }

    expression* substitute(const Scope& scope,
    		LvalMap& lval_map,
    		const ASTExpression& ast_expression);

    int visit(const ASTExpression*);
    int leave(const ASTExpression*);

    //! Class destructor.
    ~SymSub();

private:

    DISALLOW_COPY_AND_ASSIGN(SymSub);

    void reset();

    int visit_binary_expression(const ASTBinaryExpression*);
    int visit_expression_list(const ASTExpressionList*);
    int visit_id_expression(const ASTIdExpression*);
    int visit_qualified_id_expression(const ASTQualifiedIdExpression*);
    int visit_literal_expression(const ASTLiteralExpression*);
    int visit_unary_expression(const ASTUnaryExpression*);


    int leave_binary_expression(const ASTBinaryExpression*);
    int leave_expression_list(const ASTExpressionList*);
    int leave_id_expression(const ASTIdExpression*);
    int leave_qualified_id_expression(const ASTQualifiedIdExpression*) ;
    int leave_literal_expression(const ASTLiteralExpression*);
    int leave_unary_expression(const ASTUnaryExpression*);

    std::string remove_arith_literal_suffix(const std::string& s);

};

}

#endif /* SYM_SUB_H_ */
