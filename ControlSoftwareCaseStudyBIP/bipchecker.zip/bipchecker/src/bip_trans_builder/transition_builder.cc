/*
 * transition_builder.cc
 *
 *  Created on: Dec 15, 2016
 *      Author: wangqiang
 */


#include "bip_trans_builder/transition_builder.h"
#include "bip_frontend/bip_type_system/bip_type_system.h"
#include "bip_cfa/cfa.h"
#include <assert.h>

namespace bipchecker {

Transition* TransitionBuilder::build_transition(const CFAEdge& edge) {

	Transition* result_tran = 0;

	{
		// Get the source node.
		const CFANode& from = edge.from();

		// Get the CFA.
		const CFA& cfa = from.cfa();

		// Get the name of CFA.
		std::string name = cfa.name();

		// Set an appropriate scope.
		const Scope *scope = &scope_;

		if (name != std::string("")) { // Edge is inside a component.

			// Get the component scope.
			const Binding *name_bind = scope->find(name);

			// Ensure that the binding is a component.
			const Component *comp = dynamic_cast<const Component*>(name_bind);
			assert(comp != 0);

			// Set scope to the function scope.
			scope = &(comp->component_scope());
		} else{ //! edge is inside an interaction

			//! this interaction edge has no label,
			//! it has action, and may have guard
			//! then do not change the scope
		}

		// Prepare an lvalue map.
		LvalMap *lval_map = new LvalMap();

		//! prepare a pair, whose first element represents the guard of the edge
		//! and the second one represents the action of the edge
		std::pair<expression*, expression*> result;

		//! symbolically evaluate the edge
		result = process_cfa_edge(edge, *scope, *lval_map);

//		result.first->pretty_print(std::cout);
//		result.second->pretty_print(std::cout);
//		std::cout << std::endl;

		// Create transition from the result of symbolic evaluation.
		result_tran = complete_transition(*lval_map, result.second);

		result_tran->set_guard(result.first);

		delete lval_map;

//		result_tran->get_expression()->pretty_print(std::cout);
//		std::cout << std::endl;
	}

	return result_tran;
}

Transition* TransitionBuilder::build_transition(const edge_list_t & edges){

	//! prepare a result
	Transition* result = 0;

	//! prepare an lvalue map, which maps a variable to a nusmv variable
	LvalMap* lval_map = new LvalMap();

	expression* guard_res = new true_constant();
	expression* action_res = new true_constant();

	//! first compute the guard of the transitions
	for(edge_list_t::const_iterator cit = edges.begin();
			cit != edges.end(); ++cit){

		const CFAEdge* edge = (*cit);

		const CFANode& from = edge->from();

		const CFA& cfa = from.cfa();
		std::string name = cfa.name();

		// Set an appropriate scope.
		const Scope *scope = &scope_;

		if (name != std::string("")) { // Edge is inside a component.

			// Get the component scope.
			const Binding *name_bind = scope->find(name);

			// Ensure that the binding is a component.
			const Component *comp = dynamic_cast<const Component*>(name_bind);
			assert(comp != 0);

			// Set scope to the function scope.
			scope = &(comp->component_scope());
		}

		//! process the transition guard if it exists
		if (edge->guard() != 0) {

			expression* temp = guard_res;

			// Substitute expression of the edge.
			expression* temp_guard = sym_sub_.substitute(*scope, *lval_map, *edge->guard());

			guard_res = new binary_expression(binary_expression::AND, *temp, *temp_guard);
		}
	}

	for(edge_list_t::const_iterator cit = edges.begin();
			cit != edges.end(); ++cit){

		const CFAEdge* edge = (*cit);

		// Get the source node.
		const CFANode& from = edge->from();

		// Get the CFA.
		const CFA& cfa = from.cfa();

		// Get the name of CFA.
		std::string name = cfa.name();

		// Set an appropriate scope.
		const Scope *scope = &scope_;

		if (name != std::string("")) { // Edge is inside a component.

			// Get the component scope.
			const Binding *name_bind = scope->find(name);

			// Ensure that the binding is a component.
			const Component *comp = dynamic_cast<const Component*>(name_bind);
			assert(comp != 0);

			// Set scope to the function scope.
			scope = &(comp->component_scope());
		}

		//! ignore the guard expression here
		std::pair<expression*, expression*> pair_expr;

		pair_expr = process_cfa_edge(*edge, *scope, *lval_map);

		delete pair_expr.first;

		expression* action_expr = pair_expr.second;
		expression* temp_res = action_res;

		action_res = new binary_expression(binary_expression::AND, *temp_res, *action_expr);
	}

	// Create transition from the result of symbolic evaluation.
	result = complete_transition(*lval_map, action_res);

	//! this setter does not clone the expression, so we do not delete it
	result->set_guard(guard_res);

	delete lval_map;

	return result;
}


std::pair<expression*, expression*> TransitionBuilder::process_cfa_edge(const CFAEdge& edge,
		const Scope& scope, LvalMap& map) {

	expression* guard_res = 0;

	//! process the transition guard if it exists
	if (edge.guard() != 0) {
		// Substitute expression of the edge.
		guard_res = sym_sub_.substitute(scope, map, *edge.guard());
	} else{
		guard_res = new true_constant();
	}

	//! process the transition action then
	const ASTStatement* action = edge.action();
	expression* action_res = 0;

	if (action != 0) {

		const ASTExpressionStatement* expr_statement =
				dynamic_cast<const ASTExpressionStatement*>(action);
		const ASTIfStatement* if_statement =
				dynamic_cast<const ASTIfStatement*>(action);
		const ASTCompoundStatement* compound_statement =
				dynamic_cast<const ASTCompoundStatement*>(action);

		if (expr_statement != 0) {

			action_res = process_expression_statement(*expr_statement,
					scope, map);

		} else if (if_statement != 0) {

			action_res = process_if_statement(*if_statement,
					scope, map);

		} else if (compound_statement != 0) {

			action_res = process_compound_statement(*compound_statement,
					scope, map);
		}
	} else {
		// Resulting expression is true expression.
		action_res = new true_constant();
	}

	return std::make_pair(guard_res, action_res);
}

expression* TransitionBuilder::process_expression_statement(const ASTExpressionStatement& statement,
		const Scope& scope, LvalMap& map){

	//! TODO : consider COI reduction

	expression* result = 0;

	//! it should be an assignment
	const ASTBinaryExpression* binary_expr =
			dynamic_cast<const ASTBinaryExpression*>(statement.expression());

	assert(binary_expr != 0);
	assert(binary_expr->bin_operator() == ASTBinaryExpression::OP_ASSIGN);

	// Substitute the right-hand expression of the edge.
	expression* right_res = sym_sub_.substitute(scope, map, *binary_expr->operand2());

	// Update lvalue map based on the left-hand expression of the edge.
	sym_up_.update(scope, map, *binary_expr->operand1(), right_res);

	// Resulting expression is true expression.
	result = new true_constant();

	return result;
}

expression* TransitionBuilder::process_if_statement(const ASTIfStatement& statement,
		const Scope& scope, LvalMap& map){

	expression* result = 0;

	const ASTExpression* condition = statement.condition();

	expression* guard_expr = 0;

	if(condition != 0){
		guard_expr = sym_sub_.substitute(scope, map, *condition);
	} else
		guard_expr = new true_constant();

	expression* then_expr = 0;

	if(statement.then_clause() != 0){

		const ASTExpressionStatement* expr_statement =
				dynamic_cast<const ASTExpressionStatement*>(statement.then_clause());
		const ASTIfStatement* if_statement =
				dynamic_cast<const ASTIfStatement*>(statement.then_clause());
		const ASTCompoundStatement* compound_statement =
				dynamic_cast<const ASTCompoundStatement*>(statement.then_clause());

		if (expr_statement != 0) {

			then_expr = process_expression_statement(*expr_statement,
					scope, map);

		} else if (if_statement != 0) {

			then_expr = process_if_statement(*if_statement,
					scope, map);

		} else if (compound_statement != 0) {

			then_expr = process_compound_statement(*compound_statement,
					scope, map);
		}
	}

	expression* else_expr = 0;

	if(statement.else_clause() != 0){
		const ASTExpressionStatement* expr_statement =
				dynamic_cast<const ASTExpressionStatement*>(statement.else_clause());
		const ASTIfStatement* if_statement =
				dynamic_cast<const ASTIfStatement*>(statement.else_clause());
		const ASTCompoundStatement* compound_statement =
				dynamic_cast<const ASTCompoundStatement*>(statement.else_clause());

		if (expr_statement != 0) {

		else_expr = process_expression_statement(*expr_statement,
					scope, map);

		} else if (if_statement != 0) {

		else_expr = process_if_statement(*if_statement,
					scope, map);

		} else if (compound_statement != 0) {

		else_expr = process_compound_statement(*compound_statement,
					scope, map);
		}
	}

	expression* temp_guard = guard_expr;

	if(then_expr != 0){
		result = new binary_expression(binary_expression::AND, *guard_expr, *then_expr);
	}

	if(else_expr != 0){

		assert(result != 0);

		expression* temp = new unary_expression(unary_expression::NOT, *temp_guard->clone());
		expression* temp_result =
				new binary_expression(binary_expression::AND, *temp, *else_expr);
		expression* temp_then = result;
		result = new binary_expression(binary_expression::OR, *temp_then, *temp_result);
	}

	return result;
}

expression* TransitionBuilder::process_compound_statement(const ASTCompoundStatement& statement,
		const Scope& scope, LvalMap& map){

	expression* result = 0;

	// Resulting expression is true expression.
	result = new true_constant();

	for(ASTCompoundStatement::const_iterator cit = statement.begin();
			cit != statement.end(); ++cit){

		if(*cit){

			expression* temp_res = 0;

			const ASTExpressionStatement* expr_statement =
					dynamic_cast<const ASTExpressionStatement*>(*cit);
			const ASTIfStatement* if_statement =
					dynamic_cast<const ASTIfStatement*>(*cit);
			const ASTCompoundStatement* compound_statement =
					dynamic_cast<const ASTCompoundStatement*>(*cit);

			if (expr_statement != 0) {

				temp_res = process_expression_statement(*expr_statement,
						scope, map);

			} else if (if_statement != 0) {

				temp_res = process_if_statement(*if_statement,
						scope, map);

			} else if (compound_statement != 0) {

				temp_res = process_compound_statement(*compound_statement,
						scope, map);
			}

			assert(temp_res != 0);
			expression* temp = result;

			result = new binary_expression(binary_expression::AND, *result, *temp_res);
		}
	}

	return result;

}

Transition* TransitionBuilder::complete_transition(const LvalMap& map, expression* expr) {

	typedef std::set<expression*> domain_t;

	domain_t domain;

	// Set the transition's expression.
	expression* trans_expr = expr;

	for (LvalMap::const_iterator cit = map.begin(); cit != map.end(); ++cit) {

		const Lval *lval = (*cit).first;
		expression* lexpr = (*cit).second;

		// Get lvalue symbol and type.
		const Symbol& lval_sym = lval->symbol();
		std::string lval_s = lval_sym.to_string();

		expression* org_var = new variable((lval_s));

		// Put original variable in the domain.
		domain.insert(org_var);

		// Create next variable.
		expression* next_var = new timed_expression(*(org_var->clone()), 1);

		// Create next_var = lexpr.
		expression* eq = new binary_expression(binary_expression::EQ, *next_var, *lexpr->clone());

		// Conjunct the equality with the transition's expression.
		expression* temp = trans_expr;

		trans_expr = new binary_expression(binary_expression::AND, *temp, *eq);
	}

	Transition *complete_transition = new Transition(trans_expr);

	// Add domain hook.
	for (domain_t::const_iterator cit = domain.begin();
			cit != domain.end(); ++cit) {
		complete_transition->add_domain_variable(*cit);
	}

	domain.clear();

	return complete_transition;
}

expression* TransitionBuilder::evaluate( const ASTExpression& expr) {
	return evaluate(expr, scope_);
}

expression*  TransitionBuilder::evaluate(const ASTExpression& expr,
		const Scope& scope) {

	// Prepare an lvalue map.
	LvalMap *lval_map = new LvalMap();

	// Substitute expression of the edge.
	expression* result = sym_sub_.substitute(scope, *lval_map, expr);

	delete lval_map;
	return result;
}


TransitionBuilder::~TransitionBuilder() { }

}

