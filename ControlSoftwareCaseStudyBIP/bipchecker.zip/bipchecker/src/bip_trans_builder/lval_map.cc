/*
 * lval_map.cc
 *
 *  Created on: Dec 15, 2016
 *      Author: wangqiang
 */


#include "bip_trans_builder/lval_map.h"
#include <assert.h>
#include <typeinfo>

namespace bipchecker {

bool LvalPtrComp::operator()(Lval* const & lhs,
		Lval* const & rhs) const {

	if (typeid(*lhs) == typeid(*rhs)) {

		Lval *x = dynamic_cast<Lval*>(lhs);
		Lval *y = dynamic_cast<Lval*>(rhs);

		if ((x != 0) && (y != 0)) {
			return (x->symbol()).symbol_id() < (y->symbol()).symbol_id();
		} else
			assert(false);

	}

	return typeid(*lhs).before(typeid(*rhs));
}

LvalMap::LvalMap(const LvalMap& lm) {

	for (lval_map_t::const_iterator cit = lm.lval_map_.begin();
			cit != lm.lval_map_.end(); ++cit) {

		Lval *lval_lm = (*cit).first;
		expression* expr_lm = (*cit).second;

		Lval *lval = 0;
		expression* expr = 0;

		if (lval_lm != 0)
			lval = lval_lm->clone();

		if(expr_lm != 0)
			expr = expr_lm->clone();

		if (lval != 0 && expr_lm != 0)
			lval_map_[lval] = expr;
	}
}

expression* LvalMap::select(const Lval& lval) {

	Lval *temp = const_cast<Lval*>(&lval);

	lval_map_t::const_iterator cit = lval_map_.find(temp);

	if (cit != lval_map_.end() && (*cit).second){
		return (*cit).second;
	} else
		return 0;
}


void LvalMap::update(Lval *lval,
		expression* expr) {

	assert(lval != 0 && expr != 0);

	lval_map_t::iterator it = lval_map_.find(lval);

	if (it != lval_map_.end()) {

		Lval *lval_temp = (*it).first;
		expression* expr_temp = (*it).second;

		lval_map_.erase(it);

		if (lval_temp)
			delete lval_temp;

		if(expr_temp)
			delete expr_temp;
	}

	lval_map_[lval] = expr;
}



LvalMap::~LvalMap() {

	std::vector<Lval*> lval_vec;
	std::vector<expression*> expr_vec;

	for (lval_map_t::iterator it = lval_map_.begin();
			it != lval_map_.end(); ++it) {

		if ((*it).first)
			lval_vec.push_back((*it).first);

		if((*it).second)
			expr_vec.push_back((*it).second);
	}

	for (std::vector<Lval*>::iterator it = lval_vec.begin();
			it < lval_vec.end(); ++it)
		delete *it;

	for (std::vector<expression*>::iterator it = expr_vec.begin();
			it < expr_vec.end(); ++it)
		delete *it;

	lval_vec.clear();
}

}
