/*
 * transition_builder.h
 *
 *  Created on: Dec 15, 2016
 *      Author: wangqiang
 */

#ifndef TRANSITION_BUILDER_H_
#define TRANSITION_BUILDER_H_

#include "bip_cfa/cfa_edge.h"
#include "bip_cfa/cfa_node.h"
#include "util/hash_map.h"
#include "util/util.h"
#include "bip_frontend/bip_type_system/scope.h"
#include "bip_trans_builder/transition.h"
#include "bip_trans_builder/sym_up.h"
#include "bip_trans_builder/sym_sub.h"

namespace bipchecker {

class TransitionBuilder{

protected:

    //! Symbol table.
    const Scope& scope_;

    //! Symbolic substituter.
    //! it is owned by this class
    SymSub sym_sub_;

    //! Symbolic updater.
    SymUp sym_up_;


public:
    typedef std::vector<const CFAEdge*> edge_list_t;

    explicit TransitionBuilder( const Scope& scope):
          scope_(scope),
          sym_sub_(),
          sym_up_( sym_sub_) {}

    //! Builds the transition representing a CFA edge.
    /*!
     * \param edge a CFA edge.
     * \return The transition represented by the CFA edge.
     */
    virtual Transition* build_transition(const CFAEdge& edge);

    //! Builds the transition representing a list of CFA edge.
    /*!
     * \param edges a list of CFA edges.
     * \return The transition represented by the list of CFA edges.
     */
    virtual Transition* build_transition(const edge_list_t& edges);


    //! Evaluates AST expression symbolically wrt the default scope.
    /*!
     * \param expression an AST expression.
     * \return The symbolic representation of the AST expression.
     */
    expression* evaluate(const ASTExpression&);


    //! Evaluates AST expression symbolically wrt a scope.
    /*!
     * \param expression an AST expression.
     * \param scope a symbol table (scope).
     * \return The symbolic representation of the AST expression.
     */
    expression* evaluate(const ASTExpression& , const Scope& );


    //! Gets the scope.
    /*!
     * \return The scope.
     */
    const Scope& scope() const { return scope_; }

    //! Class virtual destructor.
    virtual ~TransitionBuilder();

private:

    std::pair<expression*, expression*> process_cfa_edge(const CFAEdge& edge,
    		const Scope& scope, LvalMap& map);

    expression* process_expression_statement(const ASTExpressionStatement& statement,
    		const Scope& scope, LvalMap& map);

    expression* process_if_statement(const ASTIfStatement& statement,
    		const Scope& scope, LvalMap& map);

    expression* process_compound_statement(const ASTCompoundStatement& statement,
    		const Scope& scope, LvalMap& map);

    Transition* complete_transition(const LvalMap& map,
    		expression* expr);

    DISALLOW_COPY_AND_ASSIGN(TransitionBuilder);

};

}

#endif /* TRANSITION_BUILDER_H_ */
