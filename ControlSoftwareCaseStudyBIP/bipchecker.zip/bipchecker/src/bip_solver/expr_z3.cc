/*
 * expr_z3.cc
 *
 *  Created on: Dec 17, 2016
 *      Author: wangqiang
 */


#include "z3.h"
#include "bip_solver/expr_z3.h"
#include "bip_solver/expression.h"

#include <boost/lexical_cast.hpp>

namespace bipchecker{

expression* Z3Expr::to_expression(z3::expr& expr){

	expression* result = 0;

	Z3_lbool bval = Z3_get_bool_value(expr.ctx(), expr);

	if(bval == Z3_L_TRUE){
		result = new true_constant();

	} else	if(bval == Z3_L_FALSE) {
		result = new false_constant();

	} else	if(expr.is_numeral()){
		//! check if it is a positive or negative integer

		/*
		z3::func_decl decl = expr.decl();
    	Z3_decl_kind decl_kind = decl.decl_kind();

    	if(decl_kind == Z3_OP_ANUM){
	    	size_t num = expr.num_args();
	    	assert(num == 1);

	    	z3::expr arg = expr.arg(0);
	    	expression* arg_expr = toexpression(arg);
	    	result = new unary_expression(unary_expression::MINUS, *arg_expr);
    	}
    	else
    	*/
    	{
    		std::string exprstr = Z3_get_numeral_string(expr.ctx(), expr);
    		std::stringstream ss(exprstr);
    		double exprval;
    		ss >> exprval;
//    		std::cout << exprstr << " " << exprval << std::endl;
    		result = new literal(exprval);
    	}

	} else if (expr.is_app()) {

    	z3::func_decl decl = expr.decl();
    	Z3_decl_kind decl_kind = decl.decl_kind();

    	if(expr.is_const()){
        	std::string decl_name = decl.name().str();

    		if(expr.is_bool()){
    			result = new boolean(decl_name);
    		}

    		if(expr.is_int()){
    			result = new variable(decl_name);
    		}

    	} else {

    		switch (decl_kind) {

    		case Z3_OP_UMINUS: {

    			size_t num = expr.num_args();
    			assert(num == 1);

    			z3::expr arg = expr.arg(0);
    			expression* arg_expr = to_expression(arg);
    			result = new unary_expression(unary_expression::MINUS, *arg_expr);

    			break;
    		}
    		case Z3_OP_NOT: {

    			size_t num = expr.num_args();
    			assert(num == 1);

    			z3::expr arg = expr.arg(0);
    			expression* arg_expr = to_expression(arg);
    			result = new unary_expression(unary_expression::NOT, *arg_expr);
    			break;
    		}
    		case Z3_OP_SELECT: {
    	    	assert(false);
    	    	std::cout << "Cannot handle SELECT." << std::endl;

    			break;
    		}
    		case Z3_OP_UNINTERPRETED: {
    	    	assert(false);
    	    	std::cout << "Cannot handle UNINTERPRETED." << std::endl;

    			break;
    		}
    		case Z3_OP_ITE:{
    	    	assert(false);
    	    	std::cout << "Cannot handle ITE." << std::endl;

    			break;
    		}
    		case Z3_OP_AND: {

    			z3::expr arg1 = expr.arg(0);
    			z3::expr arg2 = expr.arg(1);

    			expression* arg1_expr = to_expression(arg1);
    			expression* arg2_expr = to_expression(arg2);

//    			std::cout << arg1_expr << "  " << arg2_expr << std::endl;

    			result = new binary_expression(binary_expression::AND, *arg1_expr, *arg2_expr);

    			size_t num = expr.num_args();
    			if(num > 2) {
    				for(size_t i = 2; i < num; i++){
    					z3::expr argi = expr.arg(i);
    					expression* argi_expr = to_expression(argi);
    					expression* temp = result;
    					result = new binary_expression(binary_expression::AND, *temp, *argi_expr);
    				}
    			}

    			break;
    		}
    		case Z3_OP_OR: {
    			z3::expr arg1 = expr.arg(0);
    			z3::expr arg2 = expr.arg(1);

    			expression* arg1_expr = to_expression(arg1);
    			expression* arg2_expr = to_expression(arg2);

    			result = new binary_expression(binary_expression::OR, *arg1_expr, *arg2_expr);

    			size_t num = expr.num_args();
    			if(num > 2) {
    				for(size_t i = 2; i < num; i++){
    					z3::expr argi = expr.arg(i);
    					expression* argi_expr = to_expression(argi);
    					expression* temp = result;
    					result = new binary_expression(binary_expression::OR, *temp, *argi_expr);
    				}
    			}

    			break;
    		}
    		case Z3_OP_XOR: {
    	    	assert(false);
    	    	std::cout << "Cannot handle XOR." << std::endl;
    			break;
    		}
    		case Z3_OP_IFF: {
    			size_t num = expr.num_args();
    			assert(num == 2);

    			z3::expr arg1 = expr.arg(0);
    			z3::expr arg2 = expr.arg(1);

    			expression* arg1_expr = to_expression(arg1);
    			expression* arg2_expr = to_expression(arg2);

    			result = new binary_expression(binary_expression::EQ, *arg1_expr, *arg2_expr);

    			break;
    		}
    		case Z3_OP_IMPLIES: {

    			size_t num = expr.num_args();
    			assert(num == 2);

    			z3::expr arg1 = expr.arg(0);
    			z3::expr arg2 = expr.arg(1);

    			expression* arg1_expr = to_expression(arg1);
    			expression* arg2_expr = to_expression(arg2);

    			result = new binary_expression(binary_expression::IMPLY, *arg1_expr, *arg2_expr);

    			break;
    		}
    		case Z3_OP_EQ: {

    			size_t num = expr.num_args();
    			assert(num == 2);

    			z3::expr arg1 = expr.arg(0);
    			z3::expr arg2 = expr.arg(1);

    			expression* arg1_expr = to_expression(arg1);
    			expression* arg2_expr = to_expression(arg2);

    			result = new binary_expression(binary_expression::EQ, *arg1_expr, *arg2_expr);

    			break;
    		}
    		case Z3_OP_LT: {

    			size_t num = expr.num_args();
    			assert(num == 2);

    			z3::expr arg1 = expr.arg(0);
				z3::expr arg2 = expr.arg(1);

				expression* arg1_expr = to_expression(arg1);
				expression* arg2_expr = to_expression(arg2);

				result = new binary_expression(binary_expression::LT, *arg1_expr, *arg2_expr);
				break;
    		}
    		case Z3_OP_GT: {

    			size_t num = expr.num_args();
    			assert(num == 2);

    			z3::expr arg1 = expr.arg(0);
    			z3::expr arg2 = expr.arg(1);

    			expression* arg1_expr = to_expression(arg1);
    			expression* arg2_expr = to_expression(arg2);

    			result = new binary_expression(binary_expression::GT, *arg1_expr, *arg2_expr);
    			break;
    		}
    		case Z3_OP_LE: {

    			size_t num = expr.num_args();
    			assert(num == 2);

    			z3::expr arg1 = expr.arg(0);
    			z3::expr arg2 = expr.arg(1);

    			expression* arg1_expr = to_expression(arg1);
    			expression* arg2_expr = to_expression(arg2);

    			result = new binary_expression(binary_expression::LE, *arg1_expr, *arg2_expr);
    			break;
    		}
    		case Z3_OP_GE: {
    			size_t num = expr.num_args();
    			assert(num == 2);

    			z3::expr arg1 = expr.arg(0);
    			z3::expr arg2 = expr.arg(1);

    			expression* arg1_expr = to_expression(arg1);
    			expression* arg2_expr = to_expression(arg2);

    			result = new binary_expression(binary_expression::GE, *arg1_expr, *arg2_expr);
    			break;
    		}
    		case Z3_OP_ADD: {
    			size_t num = expr.num_args();
    			assert(num == 2);

    			z3::expr arg1 = expr.arg(0);
    			z3::expr arg2 = expr.arg(1);

    			expression* arg1_expr = to_expression(arg1);
    			expression* arg2_expr = to_expression(arg2);

    			result = new binary_expression(binary_expression::PLUS, *arg1_expr, *arg2_expr);
    			break;
    		}
    		case Z3_OP_SUB: {
    			size_t num = expr.num_args();
    			assert(num == 2);

    			z3::expr arg1 = expr.arg(0);
    			z3::expr arg2 = expr.arg(1);

    			expression* arg1_expr = to_expression(arg1);
    			expression* arg2_expr = to_expression(arg2);

    			result = new binary_expression(binary_expression::MINUS, *arg1_expr, *arg2_expr);
    			break;
    		}
    		case Z3_OP_MUL:{
    			size_t num = expr.num_args();
    			assert(num == 2);

    			z3::expr arg1 = expr.arg(0);
    			z3::expr arg2 = expr.arg(1);

    			expression* arg1_expr = to_expression(arg1);
    			expression* arg2_expr = to_expression(arg2);

    			result = new binary_expression(binary_expression::MULT, *arg1_expr, *arg2_expr);
    			break;
    		}
    		case Z3_OP_DIV: {
    			size_t num = expr.num_args();
    			assert(num == 2);

    			z3::expr arg1 = expr.arg(0);
    			z3::expr arg2 = expr.arg(1);

    			expression* arg1_expr = to_expression(arg1);
    			expression* arg2_expr = to_expression(arg2);

    			result = new binary_expression(binary_expression::DIV, *arg1_expr, *arg2_expr);
    			break;
    		}
    		case Z3_OP_MOD: {
    			size_t num = expr.num_args();
    			assert(num == 2);

    			z3::expr arg1 = expr.arg(0);
    			z3::expr arg2 = expr.arg(1);

    			expression* arg1_expr = to_expression(arg1);
    			expression* arg2_expr = to_expression(arg2);

    			result = new binary_expression(binary_expression::MOD, *arg1_expr, *arg2_expr);
    			break;
    		}
    		case Z3_OP_TRUE:
    			break;
    		case Z3_OP_FALSE:
    			break;
    		default: break;
    		}
    	}

    }
    else if (expr.is_quantifier()) {
    	assert(false);
    	std::cout << "Cannot handle quantified formula." << std::endl;
    }
    else {
    	assert(false);
        assert(expr.is_var());
    }

    return result;
}

z3::ast Z3Expr::z3expr_helper(expression* e, size_t t){

	true_constant* val_true = dynamic_cast<true_constant*>(e);
	false_constant* val_false = dynamic_cast<false_constant*>(e);
	variable* var_expr = dynamic_cast<variable*>(e);
	boolean* bool_var = dynamic_cast<boolean*>(e);
	unary_expression* unary_expr = dynamic_cast<unary_expression*>(e);
	binary_expression* binary_expr = dynamic_cast<binary_expression*>(e);
	literal* literal_expr = dynamic_cast<literal*>(e);
	timed_expression* timed_expr = dynamic_cast<timed_expression*>(e);

	z3::ast res(ctx);

	if(val_true != 0){

		res = z3::ast(ctx, Z3_mk_true(ctx));

	} else if(val_false != 0){

		res = z3::ast(ctx, Z3_mk_false(ctx));

	} else if(var_expr != 0){ //! make integer variable

		std::string value = var_expr->get_name();
		if(t > 0){
			std::stringstream sstm;
			sstm << value << "@" << t;
			value = sstm.str();
		}

		cache_type::iterator cit = cache.find(value);

		if(cit != cache.end()){
			//std::cout << z3::ast(ctx, (*cit).second) << std::endl;
			return z3::ast(ctx, (*cit).second);
		}

		res = ctx.int_const(value.c_str());
		//res = z3::ast(ctx, Z3_mk_const (ctx, ctx.str_symbol (value.c_str ()), ctx.int_sort ()));
		Z3_ast temp_res = static_cast<Z3_ast>( z3::ast(ctx, res));
		cache[value] = temp_res;
		Z3_inc_ref(ctx, temp_res);

	} else if(bool_var != 0){

		std::string name = bool_var->get_name();
		if(t > 0){
			std::stringstream sstm;
			sstm << name << "@" << t;
			name = sstm.str();
		}

		cache_type::iterator cit = cache.find(name);

		if(cit != cache.end()){

			//std::cout << z3::ast(ctx, (*cit).second) << std::endl;
			return z3::ast(ctx, (*cit).second);
		}

		res = ctx.bool_const(name.c_str());

		Z3_ast temp_res = static_cast<Z3_ast>( z3::ast(ctx, res));
		cache[name] = temp_res;
		Z3_inc_ref(ctx, temp_res);


	} else if(literal_expr != 0){

//		double lval = literal_expr->get_value();

		std::string value = boost::lexical_cast<std::string>( literal_expr->get_value());

		if(cache.find(value) != cache.end()){
			return z3::ast(ctx, (*cache.find(value)).second);
		}

		//z3::sort int_sort = ctx.int_sort();
		res = ctx.int_val(value.c_str());
//		res = ctx.int_val(lval);
		//res = z3::ast(ctx, Z3_mk_numeral(ctx, value.c_str(), int_sort));

		Z3_ast temp_res = static_cast<Z3_ast>( z3::ast(ctx, res));
		cache[value] = temp_res;
		Z3_inc_ref(ctx, temp_res);

	} else if (unary_expr != 0){

		Z3_ast operand = static_cast<Z3_ast>(z3expr_helper(unary_expr->get_operand(), t));

		if(unary_expr->get_operator() == unary_expression::NOT)
			res = z3::ast(ctx, Z3_mk_not(ctx, operand));
		else if(unary_expr->get_operator() == unary_expression::MINUS)
			res = z3::ast(ctx, Z3_mk_unary_minus(ctx, operand));

	} else if (binary_expr != 0){

		//Z3_ast operand_left =	static_cast<Z3_ast>(basicConverter(ctx, binary_expr->operand1()));
		z3::ast operand_left = (z3expr_helper( binary_expr->get_left_operand(), t));

		//Z3_ast operand_right = static_cast<Z3_ast>(basicConverter(ctx, binary_expr->operand2()));
		z3::ast operand_right = (z3expr_helper( binary_expr->get_right_operand(), t));

		Z3_ast args [2] = {operand_left, operand_right};

		if(binary_expr->get_operator() == binary_expression::EQ)
			res = z3::ast(ctx, Z3_mk_eq(ctx, operand_left, operand_right));
		else if(binary_expr->get_operator() == binary_expression::NE)
			{ z3::ast eq_expr = z3::ast(ctx, Z3_mk_eq(ctx, operand_left, operand_right));
			res = z3::ast(ctx, Z3_mk_not(ctx, eq_expr)); }
		else if (binary_expr->get_operator() == binary_expression::GE)
			res = z3::ast(ctx, Z3_mk_ge(ctx, operand_left, operand_right));
		else if (binary_expr->get_operator() == binary_expression::LE)
			res = z3::ast(ctx, Z3_mk_le(ctx, operand_left, operand_right));
		else if (binary_expr->get_operator() == binary_expression::GT)
			res = z3::ast(ctx, Z3_mk_gt(ctx, operand_left, operand_right));
		else if (binary_expr->get_operator() == binary_expression::LT)
			res = z3::ast(ctx, Z3_mk_lt(ctx, operand_left, operand_right));

		else if (binary_expr->get_operator() == binary_expression::AND)
			res = z3::ast(ctx, Z3_mk_and(ctx, 2, args));
		else if (binary_expr->get_operator() == binary_expression::OR)
			res = z3::ast(ctx, Z3_mk_or(ctx, 2, args));
		else if (binary_expr->get_operator() == binary_expression::IMPLY)
			res = z3::ast(ctx, Z3_mk_implies(ctx, operand_left, operand_right));

		else if (binary_expr->get_operator() == binary_expression::PLUS)
			res  = z3::ast(ctx, Z3_mk_add(ctx, 2, args));
		else if (binary_expr->get_operator() == binary_expression::MINUS)
			res = z3::ast(ctx, Z3_mk_sub(ctx, 2, args));
		else if (binary_expr->get_operator() == binary_expression::MULT)
			res = z3::ast(ctx, Z3_mk_mul(ctx, 2, args));
		else if (binary_expr->get_operator() == binary_expression::DIV)
			res = z3::ast(ctx, Z3_mk_div(ctx, operand_left, operand_right));
		else if (binary_expr->get_operator() == binary_expression::MOD)
			res = z3::ast(ctx, Z3_mk_mod(ctx, operand_left, operand_right));
		else if (binary_expr->get_operator() == binary_expression::ASSIGN)
			res = z3::ast(ctx, Z3_mk_eq(ctx, operand_left, operand_right));

	} else if (timed_expr != 0){
		size_t added_time = t + timed_expr->get_time_frame();
		res = z3expr_helper(timed_expr->get_expression(), added_time);
	}

	return (res);
}

z3::ast Z3Expr::z3expr(expression* e){
	return z3expr_helper(e, 0);
}

}



