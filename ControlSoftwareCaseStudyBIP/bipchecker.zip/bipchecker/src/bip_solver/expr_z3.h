/*
 * expr_z3.h
 *
 *  Created on: Dec 17, 2016
 *      Author: wangqiang
 */

#ifndef EXPR_Z3_H_
#define EXPR_Z3_H_

#include "z3++.h"
#include "util/hash_map.h"

namespace bipchecker{

class expression;

//! Encode the expression into Z3 expr
class Z3Expr {

public:
	typedef hash_map<std::string, Z3_ast,
			hash_fun<std::string>, EqStr> cache_type;

private:
	z3::context & ctx;

	cache_type cache;

public:
	explicit Z3Expr(z3::context& c): ctx(c) {}

	/*
	 *  Translate the given expression into a z3 AST
	 */
	z3::ast z3expr(expression* e);

	/*
	 * Translate a z3 expr into an expression
	 */
	expression* to_expression(z3::expr& );

	/*
	 *  Helper function to translate the timed expressions
	 */
	z3::ast z3expr_helper(expression* e, size_t t);


	~Z3Expr() { cache.clear();}
};

}

#endif /* EXPR_Z3_H_ */
