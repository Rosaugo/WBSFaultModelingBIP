/*
 * expression.cc
 *
 *  Created on: Dec 22, 2016
 *      Author: wangqiang
 */


#include "bip_solver/expression.h"
#include "bip_solver/expr_z3.h"

namespace bipchecker {

size_t expression::id_ = 0;

std::ostream& operator<<(std::ostream& out, expression* expr) {
	expr->pretty_print(out);
	return out;
}

expression* untimed_expression(expression* e) {

	expression* result = 0;

	true_constant* val_true = dynamic_cast<true_constant*>(e);
	false_constant* val_false = dynamic_cast<false_constant*>(e);
	variable* var_expr = dynamic_cast<variable*>(e);
	boolean* bool_var = dynamic_cast<boolean*>(e);
	unary_expression* unary_expr = dynamic_cast<unary_expression*>(e);
	binary_expression* binary_expr = dynamic_cast<binary_expression*>(e);
	literal* literal_expr = dynamic_cast<literal*>(e);
	timed_expression* timed_expr = dynamic_cast<timed_expression*>(e);

	if(val_true) {
		result = new true_constant();
	} else if(val_false) {
		result = new false_constant();
	} else if(var_expr) {
		std::string var_name = var_expr->get_name();

    	//! detect if it is timed variable,
    	//! if yes, then remove the timing marks
		size_t pos = var_name.find('@');
    	if(pos != std::string::npos){
        	var_name = var_name.substr(0, pos);
    	}
    	result = new variable(var_name);
	} else if(bool_var) {
		std::string var_name = bool_var->get_name();

    	//! detect if it is timed variable,
    	//! if yes, then remove the timing marks
		size_t pos = var_name.find('@');
    	if(pos != std::string::npos){
        	var_name = var_name.substr(0, pos);
    	}
    	result = new boolean(var_name);
	} else if(literal_expr) {
		result = literal_expr->clone();
	} else if (unary_expr) {

		expression* expr = untimed_expression(unary_expr->get_operand());
		result = new unary_expression(unary_expr->get_operator(), *expr);

	} else if(binary_expr){

		expression* left = untimed_expression(binary_expr->get_left_operand());
		expression* right = untimed_expression(binary_expr->get_right_operand());
		result = new binary_expression(binary_expr->get_operator(), *left, *right);

	} else if(timed_expr) {

		result = untimed_expression(timed_expr->get_expression());

	}
	return result;
}


void vars_in_expression(expression* e, std::vector<expression*>& vars){

	true_constant* val_true = dynamic_cast<true_constant*>(e);
	false_constant* val_false = dynamic_cast<false_constant*>(e);
	variable* var_expr = dynamic_cast<variable*>(e);
	boolean* bool_var = dynamic_cast<boolean*>(e);
	unary_expression* unary_expr = dynamic_cast<unary_expression*>(e);
	binary_expression* binary_expr = dynamic_cast<binary_expression*>(e);
	literal* literal_expr = dynamic_cast<literal*>(e);
	timed_expression* timed_expr = dynamic_cast<timed_expression*>(e);

	if(val_true) {
		return;
	} else if(val_false) {
		return;
	} else if(var_expr) {
		vars.push_back(var_expr->clone());
	} else if(bool_var) {
		vars.push_back(bool_var->clone());
	} else if(unary_expr) {
		vars_in_expression(unary_expr->get_operand(), vars);
	} else if(binary_expr) {
		vars_in_expression(binary_expr->get_left_operand(), vars);
		vars_in_expression(binary_expr->get_right_operand(), vars);
	} else if(literal_expr) {
		return;
	} else if(timed_expr) {
		vars_in_expression(timed_expr->get_expression(), vars);
	}

}


//! return a simplified version of this expression
expression* simplify(expression* e) {
	z3::context ctx;
	Z3Expr converter(ctx);
	z3::expr expr = z3::expr(ctx, converter.z3expr(e));
	z3::expr simp_expr = expr.simplify();
	expression* simp = converter.to_expression(simp_expr);
	return simp;
}

//! e1 ==> e2
bool imply(expression* e1, expression* e2) {

	bool result = false;
	assert(e1 != 0 && e2 != 0);

	z3::context ctx;
	Z3Expr converter(ctx);
	z3::expr expr1 = z3::expr(ctx, converter.z3expr(e1));
	z3::expr expr2 = z3::expr(ctx, converter.z3expr(e2));
	z3::expr neg_imp_expr = (expr1 && !expr2);

	z3::solver solver(ctx);
	solver.add(neg_imp_expr);
	z3::check_result res = solver.check();
	ctx.check_error ();

	if(res == z3::unsat) {
		result = true;
	} else if (res == z3::sat) {
//		z3::model m = solver.get_model();
//		std::cout << m << std::endl;
		result = false;
	} else {
		result = false;
	}

	return result;
}

bool sat(expression* e) {
	bool result = false;
	assert(e != 0);

	z3::context ctx;
	Z3Expr converter(ctx);
	z3::expr expr = z3::expr(ctx, converter.z3expr(e));

	z3::solver solver(ctx);
	solver.add(expr);
	z3::check_result res = solver.check();
	ctx.check_error ();

	if(res == z3::sat) {
		result = true;
	} else if (res == z3::unsat) {
		result = false;
	} else {
		result = false;
	}

	return result;
}

void timed_expression::print_helper(std::ostream& out, expression* e, size_t t){

	true_constant* val_true = dynamic_cast<true_constant*>(e);
	false_constant* val_false = dynamic_cast<false_constant*>(e);
	variable* var_expr = dynamic_cast<variable*>(e);
	boolean* bool_var = dynamic_cast<boolean*>(e);
	unary_expression* unary_expr = dynamic_cast<unary_expression*>(e);
	binary_expression* binary_expr = dynamic_cast<binary_expression*>(e);
	literal* literal_expr = dynamic_cast<literal*>(e);
	timed_expression* timed_expr = dynamic_cast<timed_expression*>(e);

	if(val_true){
		out << "true";
	} else if (val_false) {
		out << "false";
	} else if(var_expr) {

		std::string var_name = var_expr->get_name();
		out << var_name << "@" << t;

	} else if(bool_var) {

		std::string var_name = bool_var->get_name();
		out << var_name << "@" << t;

	} else if(unary_expr) {

		unary_expression::OP unary_op = unary_expr->get_operator();
		switch(unary_op){
			case unary_expression::NOT: out << "!"; break;
			case unary_expression::MINUS: out << "-"; break;
			default: break;
		}
		print_helper(out, unary_expr->get_operand(), t);

	} else if(binary_expr) {
		out << "(";
		expression* left_operand = binary_expr->get_left_operand();
		print_helper(out, left_operand, t);
		switch(binary_expr->get_operator()){
			case binary_expression::ASSIGN: out << " := "; break;
			case binary_expression::EQ: out << " = "; break;
			case binary_expression::NE: out << " != "; break;
			case binary_expression::GE: out << " >= "; break;
			case binary_expression::GT: out << " > "; break;
			case binary_expression::LE: out << " <= "; break;
			case binary_expression::LT: out << " < "; break;
			case binary_expression::AND: out << " && "; break;
			case binary_expression::OR: out << " || "; break;
			case binary_expression::DIV: out << " | "; break;
			case binary_expression::MINUS: out << " - "; break;
			case binary_expression::MULT: out << " * "; break;
			case binary_expression::PLUS: out << " + "; break;
			case binary_expression::IMPLY: out << " => "; break;
			case binary_expression::MOD: out << " mod "; break;
			default: break;
		}
		expression* right_operand = binary_expr->get_right_operand();
		print_helper(out, right_operand,t);
		out << ")";
	} else if (literal_expr) {
		out << literal_expr->get_value();
	} else if (timed_expr) {
		size_t added_time = t + timed_expr->get_time_frame();
		print_helper(out, timed_expr->get_expression() , added_time);
	}
}



}
