/*
 * solver_z3.h
 *
 *  Created on: Dec 18, 2016
 *      Author: wangqiang
 */

#ifndef SOLVER_Z3_H
#define SOLVER_Z3_H

#include "z3.h"
#include "z3++.h"
#include "bip_solver/expression.h"
#include "bip_solver/expr_z3.h"

namespace bipchecker {

class Z3Solver{

  z3::context ctx;
  z3::solver solver;

public:

  explicit Z3Solver(): solver(ctx){}

  explicit Z3Solver(z3::config& c, z3::context::interpolation):
	  ctx(c, z3::context::interpolation()), solver(ctx){
  }

  void set(const z3::params &p) { solver.set(p); }

  void assert_expr(expression* e) {
//	  Z3Expr * converter = new Z3Expr(ctx);
	  Z3Expr converter(ctx);
	  z3::ast expr = converter.z3expr(e);
	  Z3_solver_assert(ctx, solver, expr);
	  ctx.check_error();
//	  delete converter;
  }

  void assert_neg_expr(expression* e) {
	  unary_expression neg_e( unary_expression::NOT, *(e->clone()));
	  Z3Expr converter(ctx);
	  z3::ast expr = converter.z3expr(&neg_e);
	  Z3_solver_assert(ctx, solver, expr);
	  ctx.check_error();
  }

  void assert_z3_expr(z3::ast& e){
	  Z3_solver_assert(ctx, solver, e);
	  ctx.check_error();
  }

  void assert_neg_z3_expr(z3::ast& e){
	  z3::ast test = z3::ast(ctx, Z3_mk_not(ctx, e));
	  assert_z3_expr(test);
  }

  void push () { solver.push (); }
  void pop (unsigned n = 1) { solver.pop (n); }
  void reset () { solver.reset (); }

  z3::check_result solve() {
	  z3::check_result res = solver.check();
	  ctx.check_error ();
	  return res;
  }

  z3::check_result compute_interpolant(std::vector<expression*>&, std::vector<expression*>&);


  z3::check_result compute_interpolant(expression* expr1, expression* expr2);


  z3::model getModel() const { z3::model m = solver.get_model(); return (m); }

  expression* evaluate(expression* e, z3::model& m) {
	  Z3Expr converter(ctx);
	  z3::ast expr = converter.z3expr(e);
	  z3::expr res = m.eval(z3::expr(ctx, expr));
	  return converter.to_expression(res);
  }

  ~Z3Solver() {}
};


}

#endif
