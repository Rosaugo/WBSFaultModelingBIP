/*
 * solver_z3.cc
 *
 *  Created on: Dec 19, 2016
 *      Author: wangqiang
 */


#include "bip_solver/solver_z3.h"

namespace bipchecker {


z3::check_result Z3Solver::compute_interpolant(expression* expr1,
		expression* expr2) {

	  Z3Expr ir_z3_c(ctx);
	  z3::ast res_ast1 = ir_z3_c.z3expr(expr1);
	  res_ast1.check_error();
	  z3::expr res_expr1 = z3::expr(ctx, res_ast1);

	  z3::ast res_ast2 = ir_z3_c.z3expr(expr2);
	  res_ast2.check_error();
	  z3::expr res_expr2 = z3::expr(ctx, res_ast2);

		z3::expr_vector interps(ctx);
		Z3_model zm = 0;
		z3::model m(ctx, zm);
	    z3::params param(ctx);
	    z3::check_result res;

	    try{

	    	z3::expr marked_formula1 = z3::interpolant(res_expr1);
	    	z3::expr pat = marked_formula1 && res_expr2;

	    	res = ctx.compute_interpolant(pat, param, interps, m);

	        switch(res){
	        case z3::unsat: {
	        	std::cout << interps[0] << std::endl;
	        	break;
	        }
	        case z3::sat:
	        	break;
	        case z3::unknown:
	        	break;
	        }

	    } catch (z3::exception ex) {
	        std::cout << "failed: " << ex << "\n";
	    }

		return res;
}

z3::check_result Z3Solver::compute_interpolant(std::vector<expression*>& exprs,
		std::vector<expression*>& interp_exprs){

	z3::check_result result;
	Z3Expr ir_z3_c(ctx);
	z3::expr_vector z3exprs(ctx);

	for(auto expr : exprs){
		z3::ast res_ast = ir_z3_c.z3expr(expr);
		res_ast.check_error();
		z3::expr res_expr = z3::expr(ctx, res_ast);
		z3exprs.push_back(res_expr);
	}

	size_t num = z3exprs.size();
	z3::expr marked_expr = z3::interpolant(z3exprs[0]);

	for(size_t i = 1; i < z3exprs.size() -1 ; ++i){
		z3::expr temp_conj = marked_expr && z3exprs[i];
		marked_expr = z3::interpolant(temp_conj);
	}

	z3::expr pat = marked_expr && z3exprs[num-1];

	z3::expr_vector interps(ctx);
	Z3_model zm = 0;
	z3::model m(ctx, zm);
    z3::params param(ctx);

	result = ctx.compute_interpolant(pat, param, interps, m);

	if(result == z3::unsat){
		for(size_t i = 0; i < interps.size(); ++i){
			z3::expr temp_interp = interps[i];

			expression* interp_expr = ir_z3_c.to_expression(temp_interp);

			interp_exprs.push_back(interp_expr);
		}
	}

	return result;
}

}
