/*
 * expression.h
 *
 *  Created on: Dec 16, 2016
 *      Author: wangqiang
 */

#ifndef EXPRESSION_H_
#define EXPRESSION_H_


#include <string>
#include <vector>
#include <assert.h>
#include <iostream>
#include "util/hash_map.h"
#include <sstream>

namespace bipchecker{

class expression;

//! Useful functions for manipulating expressions
//! Create an untimed copy
expression* untimed_expression(expression* e);

//! Extract all the variables in the given expression
//! Variables are returned in the second parameter
void vars_in_expression(expression* e, std::vector<expression*>& vars);

//! return a simplified version of the given expression
expression* simplify(expression* e);

//! checks if e1 implied e2
bool imply(expression* e1, expression* e2);

//! checks if e is satisfiable
bool sat(expression* e);

//! print expression
std::ostream& operator<<(std::ostream& out, expression* expr);


//! Expression classes in BIP Intermediate Representation
//! TODO:
//! 	Type classes,
//!		currently only integer variable and literal type is supported

class expression{

public:
	static size_t id_;

	explicit expression() {}

	virtual void pretty_print(std::ostream&) = 0;

	virtual expression* clone() = 0;

	virtual bool equal(expression* e) = 0;

	virtual size_t id() = 0;

	virtual ~expression() {}
};

class true_constant : public expression {

	size_t fresh_id;

public:
	explicit true_constant(): fresh_id(id_++) {}

	void pretty_print(std::ostream& out) {out << "true";}

	bool equal(expression* e) {
		true_constant* ct = dynamic_cast<true_constant*>(e);
		return (ct != 0);
	}

	true_constant* clone() {return new true_constant();}

	size_t id() {return fresh_id;}

	~true_constant() {}
};

class false_constant : public expression{

	size_t fresh_id;

public:
	explicit false_constant(): fresh_id(id_++) {}

	void pretty_print(std::ostream& out) { out << "false";}

	bool equal(expression* e) {
		false_constant* ct = dynamic_cast<false_constant*>(e);
		return (ct != 0);
	}

	false_constant* clone() {return new false_constant();}

	size_t id() {return fresh_id;}

	~false_constant() {}
};

class variable: public expression{

	std::string name;
	size_t fresh_id;

public:
	explicit variable(): fresh_id(id_++) {}

	explicit variable(std::string& n): name(n), fresh_id(id_++){}

	explicit variable(variable& var): name(var.get_name()), fresh_id(var.id()) {}

	std::string& get_name() {return name;}

	void set_name(std::string& n) {name = n;}

	void pretty_print(std::ostream& out) { out << name; }

	bool equal(expression* e) {
		variable* v = dynamic_cast<variable*>(e);
		if(v != 0) {
			if (v->get_name() == name)
				return true;
		}
		return false;
	}

	size_t id() {return fresh_id;}

	variable* clone() {return new variable(*this);}

	~variable() {}
};

//! boolean variable
class boolean: public expression{

	std::string name;

	size_t fresh_id;

public:
	explicit boolean(): fresh_id(id_++) {}
	explicit boolean(std::string n): name(n), fresh_id(id_++) {}
	explicit boolean(boolean& b): name(b.name), fresh_id(b.id()) {}

	std::string get_name() {return name;}

	void set_name(std::string n) {name = n;}

	void pretty_print(std::ostream& out) { out << name; }

	bool equal(expression* e) {
		boolean* v = dynamic_cast<boolean*>(e);
		if(v != 0) {
			if (v->get_name() == name)
				return true;
		}
		return false;
	}

	size_t id() {return fresh_id;}

	boolean* clone() {return new boolean(*this);}

	~boolean() {}
};

class literal: public expression{

	double value;

	size_t fresh_id;

public:
	explicit literal():value(0), fresh_id(id_++) {}

	explicit literal(double v):value(v), fresh_id(id_++){}

	explicit literal(literal& l): value(l.get_value()), fresh_id(l.id()) {}

	double get_value() {return value;}

	void set_value(double v) {value = v;}

	void pretty_print(std::ostream& out) {out << value;}

	bool equal(expression* e) {
		literal* l = dynamic_cast<literal*>(e);
		if(l != 0) {
			if (l->get_value() == value)
				return true;
		}
		return false;
	}

	literal* clone() {return new literal(*this);}

	size_t id() {return fresh_id;}


	~literal() {}
};


class unary_expression : public expression{

public:
	enum OP { NOT , MINUS};

private:
	OP unary_op;

	expression* operand;

	size_t fresh_id;


public:
	explicit unary_expression(): operand(0), fresh_id(id_++) {}
	explicit unary_expression(OP op, expression& e):
			unary_op(op), operand(&e), fresh_id(id_++){}
	explicit unary_expression(unary_expression& e):
			unary_op(e.get_operator()),fresh_id(e.id()) {
		if(e.get_operand())
			operand = e.get_operand()->clone();
		else
			operand = 0;
	}

	OP get_operator() {return unary_op;}

	void set_operator(OP o) {unary_op = o;}

	expression* get_operand() {return operand;}

	void set_operand(expression& e) {if(operand) delete operand; operand = &e;}

	void pretty_print(std::ostream & out) {
		switch(unary_op){
		case NOT: out << "!"; break;
		case MINUS: out << "-"; break;
		default: break;
		}
		operand->pretty_print(out);
	}

	bool equal(expression* e) {
		unary_expression* v = dynamic_cast<unary_expression*>(e);

		if(v != 0) {
			if (v->get_operator() == unary_op && v->get_operand()->equal(operand))
				return true;
		}
		return false;
	}

	unary_expression* clone() {return new unary_expression(*this);}

	size_t id() {return fresh_id;}


	~unary_expression(){if(operand) delete operand;}
};

class binary_expression: public expression{

public:
	enum OP {
		ASSIGN,

		EQ,
		NE,
		GE,
		GT,
		LE,
		LT,

		AND,
		OR,
		IMPLY,

		DIV,
		MINUS,
		MULT,
		PLUS,
		MOD
	};

private:
	OP binary_op;
	expression* left_operand;
	expression* right_operand;
	size_t fresh_id;

public:
	explicit binary_expression():
	left_operand(0), right_operand(0),fresh_id(id_++) {}
	explicit binary_expression(OP op, expression& left, expression& right)
	: binary_op(op), left_operand(&left), right_operand(&right),fresh_id(id_++) {}
	explicit binary_expression(binary_expression& e):
			binary_op(e.get_operator()), fresh_id(e.id()){

		if(e.get_left_operand())
			left_operand = e.get_left_operand()->clone();
		else
			left_operand = 0;

		if(e.get_right_operand())
			right_operand = e.get_right_operand()->clone();
		else
			right_operand = 0;
	}

	OP get_operator() {return binary_op;}

	void set_operator(OP o) {binary_op = o;}

	expression* get_left_operand() {return left_operand;}
	expression* get_right_operand() {return right_operand;}

	void set_left_operand(expression& left) { if(left_operand) delete left_operand; left_operand = &left; }
	void set_right_operand(expression& right) { if(right_operand) delete right_operand; right_operand = &right; }

	void pretty_print(std::ostream& out) {
		out << "(";
		left_operand->pretty_print(out);
		switch(binary_op){
		case ASSIGN: out << " := "; break;
		case EQ: out << " = "; break;
		case NE: out << " != "; break;
		case GE: out << " >= "; break;
		case GT: out << " > "; break;
		case LE: out << " <= "; break;
		case LT: out << " < "; break;
		case AND: out << " && "; break;
		case OR: out << " || "; break;
		case DIV: out << " | "; break;
		case MINUS: out << " - "; break;
		case MULT: out << " * "; break;
		case PLUS: out << " + "; break;
		case IMPLY: out << " => "; break;
		case MOD: out << " mod "; break;
		default: break;
		}
		right_operand->pretty_print(out);
		out << ")";
	}

	bool equal(expression* e) {
		binary_expression* v = dynamic_cast<binary_expression*>(e);

		if(v != 0) {
			if (v->get_operator() == binary_op
					&& v->get_left_operand()->equal(left_operand)
					&& v->get_right_operand()->equal(right_operand))
				return true;
		}
		return false;
	}


	binary_expression* clone() {return new binary_expression(*this);}

	size_t id() {return fresh_id;}


	~binary_expression(){
		if(left_operand) delete left_operand;
		if(right_operand) delete right_operand;
	}
};

class timed_expression : public expression {

	expression* expr;
	size_t time_frame;

	size_t fresh_id;

public:
	explicit timed_expression(): expr(0), time_frame(0), fresh_id(id_++) {}

	explicit timed_expression(expression& e, size_t t): expr(&e), time_frame(t), fresh_id(id_++) {}

	explicit timed_expression(timed_expression& e):fresh_id(e.id()){
		time_frame = e.time_frame;
		if(e.expr != 0)
			expr = e.expr->clone();
		else
			expr = 0;
	}

	expression* get_expression() {	return expr; }

	size_t get_time_frame() {	return time_frame; }

	void set_expression(expression* e) {
		if(expr != 0)
			delete expr;
		expr = e;
	}

	void set_time_frame(size_t t) { time_frame = t; }

	void pretty_print(std::ostream& out) {	print_helper(out, expr, time_frame); }

	void print_helper(std::ostream& out, expression* e, size_t t);

	bool equal(expression* e) {
		timed_expression* v = dynamic_cast<timed_expression*>(e);

		if(v != 0) {
			if (v->get_time_frame() == time_frame && v->get_expression()->equal(expr) )
				return true;
		}
		return false;
	}

	timed_expression* clone() {return new timed_expression(*this);}

	size_t id() {return fresh_id;}


	~timed_expression() {
		if(expr != 0)
			delete expr;
	}

};


inline bool is_variable(expression* e) {
	variable* var_expr = dynamic_cast<variable*>(e);
	return var_expr != 0;
}

inline bool is_literal(expression* e) {
	literal* literal_expr = dynamic_cast<literal*>(e);
	return literal_expr != 0;
}

inline bool is_true_constant(expression* e) {
	true_constant* val_true = dynamic_cast<true_constant*>(e);
	return val_true != 0;
}

inline bool is_false_constant(expression* e) {
	false_constant* val_false = dynamic_cast<false_constant*>(e);
	return val_false != 0;
}

inline bool is_boolean(expression* e) {
	boolean* bool_var = dynamic_cast<boolean*>(e);
	return bool_var != 0;
}

inline bool is_unary(expression* e) {
	unary_expression* unary_expr = dynamic_cast<unary_expression*>(e);
	return unary_expr != 0;
}

inline bool is_binary(expression* e) {
	binary_expression* binary_expr = dynamic_cast<binary_expression*>(e);
	return binary_expr != 0;
}

inline bool is_timed(expression* e) {
	timed_expression* timed_expr = dynamic_cast<timed_expression*>(e);
	return timed_expr != 0;
}


struct eq_expr
{
    size_t operator() (const expression *e) const
    {
		expression* expr = const_cast<expression*>(e);
	    return expr->id();
    }


  bool operator()(const expression* s1, const expression* s2) const
  {
	  expression* expr1 = const_cast<expression*>(s1);
	  expression* expr2 = const_cast<expression*>(s2);
	  return expr1->id() == expr2->id();
  }
};

}

hash_fun_namespace_open {

// Hash function for expressions.
template<> struct hash<const bipchecker::expression*>
{
	size_t operator() (const bipchecker::expression *s) const
	{
		bipchecker::expression* expr = const_cast<bipchecker::expression*>(s);
	    return expr->id();
	}
};
}
hash_fun_namespace_close;

#endif /* EXPRESSION_H_ */
