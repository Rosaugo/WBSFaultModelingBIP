#!/bin/bash

# --suppressions=<filename> --gen-suppressions=all --log-file="bipchecker2.txt"
valgrind --tool=memcheck --leak-check=yes --leak-resolution=high --track-origins=yes --undef-value-errors=yes --show-possibly-lost=no --free-fill=0 --num-callers=20 --log-file="memcheck.txt" -v "$@"

